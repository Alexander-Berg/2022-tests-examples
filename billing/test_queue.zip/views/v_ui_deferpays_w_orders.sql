--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_UI_DEFERPAYS_W_ORDERS
--------------------------------------------------------------------------------

create or replace view BO.V_UI_DEFERPAYS_W_ORDERS as
SELECT d.ID AS deferpay_id,
    d.parent_deferpay_id,
    d.issue_dt,
    d.repayment_dt,
    d.status_id,
    d.invoice_id,
    fi.external_id AS invoice_eid,
    fi.client_id,
    ic.NAME    AS client_name,
    ic.is_agency agency_invoice,
    decode(ic.is_agency, 1, ic.NAME) agency_name,
    d.order_id AS fict_order_id,
    o.ID order_id,
    o.service_id || '-' || o.service_order_id order_eid,
    s.cc AS service_cc,
    s.service_group_id,
    o.service_id,
    o.service_order_id,
    o.client_id AS order_client_id,
    c.NAME      AS order_client_name,
    io.text,
    round(io.quantity, 2) AS qty,
    io.type_rate,
    pt.NAME AS unit,
    io.price AS price,
    io.amount_no_discount AS sum_nodiscnt,
    io.discount_pct,
    io.amount AS sum_e,
    fi.paysys_id,
    ps.NAME         as paysys_name,
    fi.nds          as paysys_nds,
    fi.currency     as paysys_currency,
    fi.iso_currency as paysys_iso_currency,
    fi.person_id,
    nvl(
      (SELECT tav1.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav1
       WHERE
         tav1.ATTRIBUTE_BATCH_ID = pe.ATTRIBUTE_BATCH_ID
         AND tav1.CODE = 'NAME'
      ),
      NULL
    ) AS person_name,
    nvl(
      (SELECT tav2.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav2
       WHERE
         tav2.ATTRIBUTE_BATCH_ID = pe.ATTRIBUTE_BATCH_ID
         AND tav2.CODE = 'REPRESENTATIVE'
      ),
      NULL
    ) AS person_repr,
    nvl(
      (SELECT tav3.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav3
       WHERE
         tav3.ATTRIBUTE_BATCH_ID = pe.ATTRIBUTE_BATCH_ID
         AND tav3.CODE = 'EMAIL'
      ),
      NULL
    ) AS person_email,
    nvl(
      (SELECT tav4.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav4
       WHERE
         tav4.ATTRIBUTE_BATCH_ID = pe.ATTRIBUTE_BATCH_ID
         AND tav4.CODE = 'PHONE'
      ),
      NULL
    ) AS person_phone,
    ri.repayment_invoice_id,
    ri.repayment_invoice_eid,
    ri.repayment_status_id,
    '' client_logins,
    fi.contract_id
  FROM bo.t_deferpay d,
    bo.t_invoice fi,
    (SELECT ir.invoice_id,
      ir.repayment_invoice_id,
      ri.external_id repayment_invoice_eid,
      ri.status_id repayment_status_id
    FROM bo.t_invoice_repayment ir,
      bo.t_invoice ri
    WHERE ir.repayment_invoice_id = ri.ID
    AND ri.hidden                IN (0, 1)
    ) ri,
    bo.t_client ic,
    bo.t_person pe,
    bo.t_paysys ps,
    bo.t_invoice_order io,
    bo.t_order o,
    bo.t_service s,
    bo.t_client c,
    bo.t_manager m,
    bo.t_product p,
    bo.t_product_unit pu,
    bo.t_product_type pt
  WHERE d.invoice_id     = fi.ID
  AND fi.receipt_sum    <> 0
  AND fi.paysys_id       = ps.ID
  AND fi.ID              = io.invoice_id
  AND fi.type           != 'y_invoice'
  AND io.order_id        = o.ID
  AND o.service_id       = s.ID
  AND o.client_id        = c.ID
  AND o.manager_code     = m.manager_code(+)
  AND fi.person_id       = pe.ID(+)
  AND fi.client_id       = ic.ID
  AND fi.ID              = ri.invoice_id(+)
  AND o.service_code     = p.ID
  AND p.unit_id          = pu.ID
  AND pu.product_type_id = pt.ID
;
