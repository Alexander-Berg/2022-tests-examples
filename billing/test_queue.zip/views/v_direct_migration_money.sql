--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace view bo.v_direct_migration_money as
select
    round(
        sum(
            case
                when completion_qty > 0
                    then (
                        greatest(
                            least(completion_fixed_qty, cum_completion_qty)
                            - cum_completion_qty + completion_qty,
                             0
                        )
                        / completion_qty * completion_rub
                    )
                else 0
            end
        ),
        4
    )                                            as completion_fixed_money_qty,
    round(sum(consume_rub), 4)                   as consume_money_qty,
    round(sum(completion_rub), 4)                as completion_money_qty,
    round(sum(completion_real_money), 4)         as completion_real_money,
    round(sum(consume_real_money), 4)            as consume_real_money,
    max(completion_fixed_qty)                    as completion_fixed_qty,
    sum(consume_qty)                             as consume_qty,
    sum(completion_qty)                          as completion_qty,
    max(
        case
            when (
                cum_completion_qty > completion_fixed_qty
                and discount_pct != static_discount_pct
            )
                then 1
            else 0
        end
    )                                            as discount_error,
    max(
        case
            when currency not in ('RUR', 'RUB')
                then 1
            else 0
        end
    )                                            as currency_error,
    max(
        case
            when iso_currency != 'RUB'
                then 1
            else 0
        end
    )                                            as iso_currency_error,
    case
        when count(distinct currency) = 1
            then max(currency)
        else null
    end                                          as currency,
    case
        when count(distinct iso_currency) = 1
            then max(iso_currency)
        else null
    end                                          as iso_currency,
    order_id
from (
    select
        sum(co.current_qty) over (
            partition by co.parent_order_id
            order by co.id
        )                                             as cum_consume_qty,
        sum(co.completion_qty) over (
            partition by co.parent_order_id
            order by co.id
        )                                             as cum_completion_qty,
        nvl(o.completion_fixed_qty, 0)                as completion_fixed_qty,
        co.completion_qty
        / (1 - nvl(co.static_discount_pct, 0) / 100)
        * (1 - nvl(co.discount_pct, 0) / 100) * 30    as completion_rub,
        co.current_qty
        / (1 - nvl(co.static_discount_pct, 0) / 100)
        * (1 - nvl(co.discount_pct, 0) / 100) * 30    as consume_rub,
        sum(
            co.completion_qty
            / (1 - nvl(co.static_discount_pct, 0) / 100)
            * (1 - nvl(co.discount_pct, 0) / 100) * 30
        ) over (
            partition by co.parent_order_id
            order by co.id
        )                                             as cum_completion_rub,
        (
            co.completion_sum * i.currency_rate
            / i.internal_rate
        )                                             as completion_real_money,
        (
            co.current_sum * i.currency_rate
            / i.internal_rate
        )                                             as consume_real_money,
        co.parent_order_id                            as order_id,
        co.completion_qty,
        co.current_qty                                as consume_qty,
        co.discount_pct,
        co.static_discount_pct,
        co.dt,
        i.currency,
        i.iso_currency
    from
        bo.t_consume co
        join bo.t_invoice i on i.id = co.invoice_id
        join bo.t_order o on co.parent_order_id = o.id
)
group by
    order_id

\\
