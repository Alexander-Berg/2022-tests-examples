--liquibase formatted sql

/*
Бренды клиента в виде периодов действия: from_dt <= sysdate < till_dt
Так же смотри v_client_direct_brand.
*/

--changeset lightrevan:BALANCE-28633-brand-history stripComments:false
CREATE OR REPLACE VIEW bo.v_client_brand_history AS
WITH col_clients AS (
    SELECT
      cc.contract2_id contract_id,
      trunc(cc.dt) from_dt,
      lag(trunc(cc.dt), 1) OVER (
        PARTITION BY cc.contract2_id, ca.key_num
        ORDER BY cc.dt DESC, cc.id DESC
      ) till_dt,
      ca.key_num client_id,
      ca.value_num is_enabled
    FROM bo.t_contract_collateral cc
      JOIN bo.t_contract_attributes ca
        ON cc.id = ca.collateral_id
        AND ca.code = 'BRAND_CLIENTS'
    WHERE 1 = 1
      AND cc.is_cancelled IS NULL
      AND (cc.is_signed IS NOT NULL OR cc.is_cancelled IS NOT NULL)
),
    matches AS (
      SELECT
        l.client_id,
        r.client_id brand_client_id,
        greatest(l.from_dt, r.from_dt) from_dt,
        least(nvl(l.till_dt, r.till_dt), nvl(r.till_dt, l.till_dt)) till_dt,
        l.contract_id
      FROM col_clients l
        JOIN col_clients r
          ON l.contract_id = r.contract_id
          AND greatest(l.from_dt, r.from_dt) <
              least(
                  nvl(l.till_dt, greatest(l.from_dt, r.from_dt) + 1),
                  nvl(r.till_dt, greatest(l.from_dt, r.from_dt) + 1)
              )
      WHERE 1 = 1
        AND l.is_enabled = 1
        AND r.is_enabled = 1
  )
SELECT
  m.client_id,
  m.brand_client_id,
  m.from_dt,
  trunc(least(nvl(m.till_dt, ca_fin.value_dt), nvl(ca_fin.value_dt, m.till_dt))) till_dt,
  m.contract_id,
  ca_bt.value_num brand_type
FROM matches m
  LEFT JOIN bo.v_contract_last_attr ca_bt
    ON ca_bt.contract_id = m.contract_id
    AND ca_bt.code = 'BRAND_TYPE'
  LEFT JOIN bo.v_contract_signed_attr ca_fin
    ON ca_fin.contract_id = m.contract_id
    AND ca_fin.code = 'FINISH_DT'
WHERE 1 = 1
  AND from_dt < trunc(nvl(ca_fin.value_dt, from_dt + 1))
;
