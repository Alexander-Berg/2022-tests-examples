--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace view bo.v_addapter_comm_places as
select
    p.id              as place_id,
    p.search_id,
    pp.page_id        as product_id,
    pac.service_id,
    p.url,
    pac.contract_id,
    pac.external_id,
    pac.client_id,
    pac.is_developer,
    pac.is_retailer,
    pac.dt,
    pac.end_dt,
    pac.currency,
    pac.iso_currency,
    pac.nds
from
    bo.v_partner_addapter_contract pac,
    bo.t_place p,
    bo.t_place_products pp
where
    p.client_id = pac.client_id
    and p.id = pp.place_id
    and pp.page_id = pac.product_id
\\
