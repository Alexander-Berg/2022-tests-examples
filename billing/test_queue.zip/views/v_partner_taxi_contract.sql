--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace view bo.v_partner_taxi_contract as
select
    contract_id,
    start_dt,
    max(nvl(end_dt, date'9999-01-01')) as end_dt,
    max(client_id)                     as client_id,
    max(person_type)                   as person_type,
    max(firm_id)                       as firm_id,
    max(commission_type)               as commission_type,
    max(commission_pct)                as commission_pct,
    max(commission_pct_card)           as commission_pct_card,
    max(commission_sum)                as commission_sum,
    max(currency_id)                   as currency_id,
    max(iso_currency)                  as iso_currency,
    max(min_commission_sum)            as min_commission_sum,
    max(max_commission_sum)            as max_commission_sum,
    max(advance_payment_sum)           as advance_payment_sum,
    max(payment_type)                  as payment_type,
    max(service_min_cost)              as service_min_cost,
    max(card_enabled)                  as card_enabled,
    max(cash_enabled)                  as cash_enabled
from (
    select
        c.id                                         as contract_id,
        c.client_id                                  as client_id,
        p.type                                       as person_type,
        last_value(ca15.value_num ignore nulls)
        over (partition by c.id order by cl.dt)      as firm_id,
        last_value(ca3.value_num ignore nulls)
        over (partition by c.id order by cl.dt)      as commission_type,
        nvl(
            last_value(ca4.value_num ignore nulls)
            over (partition by c.id order by cl.dt),
            0
        )                                            as commission_pct,
        nvl(
            last_value(ca13.value_num ignore nulls)
            over (partition by c.id order by cl.dt),
            0
        )                                            as commission_pct_card,
        last_value(ca5.value_num ignore nulls)
        over (partition by c.id order by cl.dt)      as commission_sum,
        last_value(ca6.value_num ignore nulls)
        over (partition by c.id order by cl.dt)      as currency_id,
        last_value(ca6.value_str ignore nulls)
        over (partition by c.id order by cl.dt)      as iso_currency,
        last_value(ca8.value_num ignore nulls)
        over (partition by c.id order by cl.dt)      as min_commission_sum,
        last_value(ca14.value_num ignore nulls)
        over (partition by c.id order by cl.dt)      as max_commission_sum,
        last_value(ca9.value_num ignore nulls)
        over (partition by c.id order by cl.dt)      as advance_payment_sum,
        last_value(ca10.value_num ignore nulls)
        over (partition by c.id order by cl.dt)      as payment_type,
        cl.dt                                        as start_dt,
        nvl(
            lead (cl.dt)
            over (partition by c.id order by cl.dt),
            last_value(ca7.value_dt ignore nulls)
            over (partition by c.id order by cl.dt)
        )                                            as end_dt,
        ca11.value_num                               as service_min_cost,
        nvl(
            last_value(ca2.value_num ignore nulls)
            over (partition by c.id order by cl.dt),
            0
        )                                            as cash_enabled,
        nvl(
            last_value(ca12.value_num ignore nulls)
            over (partition by c.id order by cl.dt),
            0
        )                                            as card_enabled
    from
        bo.t_contract2 c
        join bo.t_person p on p.id = c.person_id
        left join bo.t_contract_collateral cl on cl.contract2_id = c.id
        left join bo.t_contract_collateral cl0 on
            cl0.contract2_id = c.id
            and cl0.collateral_type_id is null
            and cl0.num is null
        left join bo.t_contract_attributes ca1 on
            cl0.attribute_batch_id = ca1.attribute_batch_id
            and ca1.code = 'COMMISSION'
        left join bo.t_contract_attributes ca2 on
            cl0.attribute_batch_id = ca2.attribute_batch_id
            and ca2.code = 'SERVICES'
            and nvl(ca2.key_num, 666) = 111
        left join bo.t_contract_attributes ca3 on
            cl.attribute_batch_id = ca3.attribute_batch_id
            and ca3.code = 'PARTNER_COMMISSION_TYPE'
        left join bo.t_contract_attributes ca4 on
            cl.attribute_batch_id = ca4.attribute_batch_id
            and ca4.code = 'PARTNER_COMMISSION_PCT'
        left join bo.t_contract_attributes ca5 on
            cl.attribute_batch_id = ca5.attribute_batch_id
            and ca5.code = 'PARTNER_COMMISSION_SUM'
        left join bo.t_contract_attributes ca6 on
            cl0.attribute_batch_id = ca6.attribute_batch_id
            and ca6.code = 'CURRENCY'
        left join bo.t_contract_attributes ca7 on
            cl.attribute_batch_id = ca7.attribute_batch_id
            and ca7.code = 'FINISH_DT'
        left join bo.t_contract_attributes ca8 on
            cl.attribute_batch_id = ca8.attribute_batch_id
            and ca8.code = 'PARTNER_MIN_COMMISSION_SUM'
        left join bo.t_contract_attributes ca9 on
            cl.attribute_batch_id = ca9.attribute_batch_id
            and ca9.code = 'ADVANCE_PAYMENT_SUM'
        left join bo.t_contract_attributes ca10 on
            cl.attribute_batch_id = ca10.attribute_batch_id
            and ca10.code = 'PAYMENT_TYPE'
        left join bo.t_contract_attributes ca11 on
            cl.attribute_batch_id = ca11.attribute_batch_id
            and ca11.code = 'SERVICE_MIN_COST'
        left join bo.t_contract_attributes ca12 on
            cl.attribute_batch_id = ca12.attribute_batch_id
            and ca12.code = 'SERVICES'
            and nvl(ca12.key_num, 666) = 128
        left join bo.t_contract_attributes ca13 on
            cl.attribute_batch_id = ca13.attribute_batch_id
            and ca13.code = 'PARTNER_COMMISSION_PCT2'
        left join bo.t_contract_attributes ca14 on
            cl.attribute_batch_id = ca14.attribute_batch_id
            and ca14.code = 'PARTNER_MAX_COMMISSION_SUM'
        left join bo.t_contract_attributes ca15 on
            cl.attribute_batch_id = ca15.attribute_batch_id
            and ca15.code = 'FIRM'
    where
        c.type = 'GENERAL'
        and cl.is_cancelled is null
        and cl0.is_cancelled is null
        and (cl.is_signed is not null or cl.is_faxed is not null)
        and nvl(ca1.value_num, 1) in (0, 9)
        and exists (
            select 1
            from bo.t_contract_attributes
            where
                attribute_batch_id = cl0.attribute_batch_id
                and value_num = 1
                and key_num in (111, 128, 135)
        )
)
group by
    contract_id,
    start_dt
\\
