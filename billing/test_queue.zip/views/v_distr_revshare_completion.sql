--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114-2 stripComments:false endDelimiter:\\

create or replace view bo.v_distr_revshare_completion as

with v_turnover_puttee as (
    select
        case
            when (v.scale is null) then v.partner_pct
            else nvl(
                     sf_distr_revshare_pct(dt, scale, contract_id, page_id),
                     0)
        end as partner_pct2,
        v.*
    from v_distr_revshare_turnover v
)

select
  dc.dt,
  dc.place_id,
  dc.url,
  turnover_gross * decode(reward_type,
                          2, 1 - coalesce(avg_discount_pct, expense_pct, 0)/100,
                          1) / rus_nds.nds_koef turnover_wo_nds_rur,
  turnover_gross * decode(reward_type,
                          2, 1 - coalesce(avg_discount_pct, expense_pct, 0)/100,
                          1) / rus_nds.nds_koef / decode(currency_calculation,
                                                 1, currency_rate,
                                                 1) turnover_wo_nds,
  dc.clicks,
  dc.clicksa,
  dc.shows,
  dc.bucks,
  partner_pct2 as partner_pct,
  case when page_id = 10004 and
            ((partner_pct > 0) or (scale is not null)) and
            bucks_rs is not null
    then
      (bucks_rs * 30) / rus_nds.nds_koef
    else
      turnover_gross * decode(reward_type,
                              2, 1 - coalesce(avg_discount_pct, expense_pct, 0)/100,
                              1) / rus_nds.nds_koef * 0.01 * partner_pct2
  end partner_reward_wo_nds_rur,
  case when page_id = 10004 and
            ((partner_pct > 0) or (scale is not null)) and
            bucks_rs is not null
    then
      (bucks_rs * 30) / rus_nds.nds_koef / decode(currency_calculation,
                                          1, currency_rate,
                                          1)
    else
      turnover_gross * decode(reward_type,
                              2, 1 - coalesce(avg_discount_pct, expense_pct, 0)/100,
                              1) / rus_nds.nds_koef / decode(currency_calculation,
                                                     1, currency_rate,
                                                     1) * 0.01 * partner_pct2
  end partner_reward_wo_nds,
  dc.contract_id,
  dc.contract_end_dt,
  dc.client_id,
  dc.external_id,
  dc.test_mode,
  dc.nds,
  dc.expense_pct,
  dc.internal_type,
  dc.tag_id,
  upper(dc.currency) currency,
  dc.iso_currency,
  dc.currency_calculation,
  dc.reward_type,
  dc.page_id,
  dc.vid,
  place_tag_id,
  (rus_nds.nds_koef-1)*100 as nds_pct
from v_turnover_puttee dc
join v_nds_pct rus_nds on (rus_nds.ndsreal_id = 18 and
                           dc.dt >= rus_nds.from_dt and
                           dc.dt < rus_nds.to_dt)


\\