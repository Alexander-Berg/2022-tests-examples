--liquibase formatted sql

--changeset ufian:BALANCE-24295 stripComments:false endDelimiter:\\

/* BALANCE-19382
 * BALANCE-21324
 * PAYSYSADMIN-868
 * BALANCE-23483
 */

CREATE OR REPLACE VIEW bo.v_export_monitoring_slow AS
SELECT /*+ PARALLEL(4) */
     CAST('BO.KPI_SLA.max_shipm_delay' AS varchar2(256)) metric
     , NVL(MAX(sysdate - sh.update_dt), 0) * 24 * 60 val
     , sysdate time_stamp
FROM bo.t_shipment  sh -- select not all records for speedup
JOIN bo.t_order o
ON (sh.service_id        = o.service_id
    AND sh.service_order_id  = o.service_order_id)
JOIN bo.t_shipment_accepted sa
  ON (sh.service_id            = sa.service_id
      AND sh.service_order_id  = sa.service_order_id)
WHERE --(o.shipment_dt IS NULL AND sh.dt IS NOT NULL) or
   (sa.dt <= sh.dt AND sa.update_dt < sh.update_dt)
  AND nvl(o.group_order_id, o.id) not in (select
                                          e.object_id from bo.t_export e
                                          where e.type='UA_TRANSFER'
                                            and e.classname='Order'
                                            and e.state in (0,2)
                                            and e.object_id is not null)
  AND NVL(o.client_id, o.agency_id) not in (select
                                            e.object_id from bo.t_export e
                                            where e.type='UA_TRANSFER'
                                              and e.classname='Client'
                                              and e.state in (0,2)
                                              and e.object_id is not null)

UNION ALL

SELECT
  'BO.UA_TRANSFER.duration_hours',
  nvl((max(update_dt) - min(next_export)) * 24, 0),
  sysdate
FROM bo.t_export
WHERE
  type = 'UA_TRANSFER'
  AND classname = 'Client' AND export_dt IS NOT NULL
  AND next_export > trunc(sysdate)

UNION ALL

SELECT
  'BO.UA_TRANSFER.daystart_hours',
  nvl((max(update_dt) - trunc(sysdate)) * 24, 0),
  sysdate
FROM bo.t_export
WHERE
  type = 'UA_TRANSFER'
  AND classname = 'Client' AND export_dt IS NOT NULL
  AND next_export > trunc(sysdate)

UNION ALL

SELECT
  'BO.UA_TRANSFER.count_clients',
  count(*),
  sysdate
FROM bo.t_export
WHERE
  type = 'UA_TRANSFER'
  AND classname = 'Client'
  AND state = 0
  AND update_dt >= trunc(sysdate)

UNION ALL

SELECT
  'BO.UA_TRANSFER.lastend_client',
  nvl((max(export_dt) - trunc(sysdate)) * 24, 0),
  sysdate
FROM bo.t_export
WHERE
  type = 'UA_TRANSFER'
  AND classname = 'Client'
  AND update_dt >= trunc(sysdate)

UNION ALL

SELECT
  'BO.UA_TRANSFER.current_time',
  nvl((sysdate - trunc(sysdate)) * 24, 0),
  sysdate
FROM dual

UNION ALL

SELECT
  'BO.MONTH_PROC.unprocessed_clients',
  count(*),
  sysdate
FROM bo.t_export
WHERE
  type = 'MONTH_PROC'
  AND classname = 'Client' AND state in (0, 2)

UNION ALL

SELECT
  'BO.STATS.reverse_acts' metric,
  sum(CASE WHEN OLD_QTY > QTY
      THEN OLD_QTY - QTY ELSE QTY END) val,
  sysdate time_stamp
from bo.T_REVERSE_COMPLETION
  where update_dt > sysdate - 1./24

\\

--changeset el-yurchito:BALANCE-26069
drop view BO.V_EXPORT_MONITORING_SLOW;

