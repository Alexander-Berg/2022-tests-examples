--liquibase formatted sql

--changeset lightrevan:BALANCE-29780-v-ops stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW BO.V_OPERATION_STATS
AS
SELECT o.parent_operation_id,
       (select type_id from bo.t_operation where id = o.parent_operation_id) parent_operation_type_id,
       o.id operation_id,
       o.type_id operation_type_id,
       jo.classname,
       jo.object_id,
       jo.ordinal,
       jo.step,
       TO_DATE (jo.begin_dt, 'YYYY-MM-DD"T"HH24:MI:SS".""ZZZZZZ"') begin_dt,
       TO_DATE (jo.end_dt, 'YYYY-MM-DD"T"HH24:MI:SS".""ZZZZZZ"') end_dt,
       BO.NUMBER_FROM_JSON_STAT(jo.duration) duration,
       jo.metric_name,
       jo.metric_num
  FROM bo.t_operation o,
    json_table(nvl(DBMS_LOB.substr(stats, 6666), stats_info), '$'
         COLUMNS (object_id number PATH '$.object.id',
                  classname varchar2(64) PATH '$.object.classname',
          NESTED PATH '$.object.stats[*]'
         columns (ordinal number PATH '$.ordinal',
                  step varchar2(256) PATH '$.step',
                  begin_dt varchar2(64) PATH '$.begin_dt',
                  end_dt varchar2(64) PATH '$.end_dt',
                  duration varchar2(64) PATH '$.duration',
                  NESTED PATH '$.metrics[*]'
                    columns (metric_name varchar2(256) PATH '$.name',
                             metric_num number PATH '$.num')
                    )
                   )
                   ) AS jo
  where
    (stats is not null or stats_info is not null)

\\
