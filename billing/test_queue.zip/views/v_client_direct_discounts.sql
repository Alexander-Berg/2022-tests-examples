--liquibase formatted sql

/*
Заглушка на время выкладки. Выпилить!
*/

--changeset lightrevan:BALANCE-27390-dummy-cdd stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW bo.v_client_direct_discounts AS
SELECT
  CAST(null AS NUMBER) client_id,
  CAST(null AS DATE) dt,
  CAST(null AS NUMBER) budget,
  CAST(null AS VARCHAR2(16)) currency,
  CAST(null AS NUMBER) discount
FROM dual
WHERE 1=0

\\

--changeset lightrevan:BALANCE-27736-cdd
DROP VIEW bo.v_client_direct_discounts;
