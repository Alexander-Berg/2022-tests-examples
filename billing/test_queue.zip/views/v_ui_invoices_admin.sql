--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW BO.V_UI_INVOICES_ADMIN AS
select
     /*+ ORDERED */
    i.id invoice_id,
    i.external_id invoice_eid,
    i.external_id invoice_eid_exact,
    i.request_id,
    i.request_seq,
    i.dt invoice_dt,
    i.effective_sum,
    i.rur_sum,
    i.receipt_sum,
    i.receipt_sum_1c,
    i.consume_sum,
    p.cc paysys_cc,
    p.name paysys_name,
    i.receipt_dt,
    i.status_id,
    t.status,
    i.passport_id,
    c.name as client,
    c.id as client_id,
    c.email as client_email,
    i.hidden,
    i.total_sum total_sum,
    i.receipt_dt last_payment_dt,
    (select acc.gecos
     from bo.t_receipt rcp,bo.t_passport acc
     where acc.passport_id = rcp.oper_id and rcp.id =
        (select max(rcpt.id)
         from bo.t_receipt rcpt
         where rcpt.invoice_id = i.id)
    ) manager,
    i.manager_code,
    m.name as manager_info,
    decode(i.credit, 2, 1, 0) as is_fictive,
    case when i.receipt_sum >0 then 1
    else 0
    end as receipt_status,
    i.currency,
    i.iso_currency,
    c.internal internal_client,
    i.total_act_sum-nvl(rem.amount,0) act_total_sum,
    i.credit,
    c.suspect as client_suspect,
    i.overdraft,
    i.market_postpay,
    co.id as contract_id,
    co.external_id as contract_eid,
    c.manual_suspect,
    i.person_id
from
    bo.t_invoice i, bo.t_manager m,
    bo.t_paysys p, bo.t_client c,
    bo.t_invoice_status t,
    bo.t_contract2 co,
    bo.t_remainder rem
where
    i.hidden in (0,1)
    and i.client_id = c.id
    and i.paysys_id = p.id
    and i.status_id = t.id
    and i.manager_code = m.manager_code(+)
    and i.contract_id = co.id(+)
    and i.id = rem.invoice_id(+)

\\
