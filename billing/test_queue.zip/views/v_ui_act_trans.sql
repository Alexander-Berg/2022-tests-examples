--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW V_UI_ACT_TRANS AS
select a.act_id id,
  aa.external_id,
  o.id order_id,
  o.service_id,
  o.service_order_id,
  o.text,
  o.service_id || '-' || o.service_order_id || '-' || q.seqnum order_eid,
  o.nds order_nds,
  i.id invoice_id,
  i.external_id invoice_eid,
  i.request_id,
  i.request_seq,
  pru.name unit_name,
  prt.name type_name,
  aa.dt dt,
  sf_qty_mpl(a.act_qty, q.type_rate) quantity,
  sf_fn(a.act_sum) finish_sum,
  q.consume_sum order_sum,
  q.discount_pct discount_pct,
  o.service_code code,
  s.cc service_cc,
  s.name service_name,
  i.total_sum invoice_sum,
  i.currency,
  i.iso_currency,
  a.amount amount,
  a.act_sum act_sum,
  round(sf_price_mpl3_raw(q.price, q.nds, i.nds, i.internal_rate / i.CURRENCY_RATE), 4) price,
  fic_i.external_id fictive_invoice_eid
from bo.t_act aa
  join bo.t_invoice i on i.id = aa.invoice_id
  join bo.t_act_trans a on a.act_id = aa.id
  join bo.t_consume q on q.id = a.consume_id
  left join bo.t_invoice fic_i on fic_i.id = q.invoice_id and fic_i.credit = 2
  join bo.t_order o on o.id = q.parent_order_id
  join bo.t_service s on s.id = o.service_id
  join bo.t_product pr on pr.id=o.service_code
  join bo.t_product_unit pru on pru.id = pr.unit_id
  join bo.t_product_type prt on prt.id = pr.type_id

\\
