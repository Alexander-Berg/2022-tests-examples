--liquibase formatted sql

--changeset lightrevan:BALANCE-29001-v stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW BO.V_PYCRON AS
SELECT ST.ID AS STATE_ID,
       D.NAME,
       ST.HOST EXEC_HOST,
       ST.PID,
       ST.PPID,
       ST.STARTED AS STARTED_DT,
       ST.FINISHED AS FINISHED_DT,
       ST.STAGE,
       ST.PROGRESS,
       ST.UPDATE_DT,
       ST.EXIT_CODE,
       ST.EXIT_MESSAGE,
       ST.ERRORS,
       ST.FAILED,
       D.COMMAND,
       SH.CRONTAB,
       SH.RUN_AT_DT,
       SH.MNCLOSE_TASK,
       SH.MNCLOSE_RUN_OPENED,
       SH.RETRY_COUNT,
       SH.RETRY_INTERVAL,
       NVL(SH.HOST, 'Любой') SCHEDULE_HOST,
       NVL(l.host, 'Разрешён любой') host_lock,
       DECODE(SH.ENABLED, 1, 'Включено', 0, 'Отключено', SH.ENABLED) ENABLED,
       D.TIMEOUT,
       D.TERMINATE,
       DECODE(D.COUNT_PER_HOST, NULL, 'Один процесс на произвольном хосте',
                                       D.COUNT_PER_HOST) COUNT_PER_HOST,
       D.DESCRIPTION,
       D.OWNER_LOGIN,
       EMAILS.EMAILS REPORT_EMAILS
FROM BO.T_PYCRON_STATE ST
JOIN BO.T_PYCRON_LOCK L ON ST.ID = L.ID
JOIN BO.T_PYCRON_DESCR D ON D.NAME = L.NAME
JOIN BO.T_PYCRON_SCHEDULE SH ON SH.NAME = L.NAME
LEFT JOIN
  ( SELECT task_name,
           substr(max(sys_connect_by_path(email, ',')), 2,999) emails
      FROM ( SELECT task_name,
                    email,
                    row_number() OVER (PARTITION BY task_name ORDER BY email) rn
               FROM bo.t_pycron_responsible
           )
     START WITH rn = 1
     CONNECT BY PRIOR rn = rn-1
     AND PRIOR task_name = task_name
     GROUP BY task_name
   ) EMAILS ON EMAILS.task_name = D.NAME
WHERE (ST.HOST = l.host OR l.host IS NULL)
  AND (SH.HOST IS NULL OR SH.HOST = ST.HOST)
ORDER BY D.NAME

\\