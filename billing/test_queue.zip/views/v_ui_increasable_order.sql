--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for view V_UI_INCREASABLE_ORDER
--------------------------------------------------------------------------------

--changeset el-yurchito:BALANCE-30155 endDelimiter:\\
create or replace view BO.V_UI_INCREASABLE_ORDER as
SELECT
  o.id order_id,
  c.class_id client_id,
  o.service_id || '-' || o.service_order_id order_eid,
  s.cc service_cc,
  o.service_id,
  o.service_order_id,
  oc.name client_name,
  o.text,
  o.unit,
  ROUND(NVL(p.price, 0) / 30, 10) AS price,
  ROUND(NVL(p.price2, 0) / 30, 10) AS price_wo_nds,
  p.type_rate,
  p.name product_name,
  TRUNC(o.dt) order_dt,
  o.mru_date last_touch_dt,
  oc.id order_client_id
FROM
  bo.t_order o,
  bo.v_service s,
  bo.t_product p,
  bo.t_client c,
  bo.t_client oc
WHERE
  o.service_id = s.id
  AND o.service_code = p.id
  AND NVL(o.agency_id, o.client_id) = c.id
  AND o.client_id = oc.id
  AND s.intern = 0
  AND ((s.extra_pay = 1) OR ((s.extra_pay = 0) AND o.consume_sum = 0))
\\
