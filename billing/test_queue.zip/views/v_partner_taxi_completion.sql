--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace view bo.v_partner_taxi_completion as
with v_taxi_stat as (
select
    ts.dt                                        as dt,
    ptc.client_id,
    ptc.contract_id,
    ptc.currency_id,
    nvl(ts.payment_type, 'cash')                 as payment_type,
    ptc.iso_currency                             as currency,
    ptc.iso_currency                             as iso_currency,
    ts.type                                      as order_type,
    case
        when ts.payment_type = 'card' and ptc.card_enabled > 0
            then ts.commission_sum * (pft.nds_pct / 100 + 1)
        else null
        end                                      as card_commission_sum,
    case
        when (
            nvl(ts.payment_type, 'cash') in ('cash', 'corporate', 'prepaid')
            and ptc.cash_enabled > 0
        )
            then ts.commission_sum * (pft.nds_pct / 100 + 1)
        else null
    end                                          as cash_commission_sum,
    case
        when ts.promocode_sum is not null
            then (
                case
                    when (
                        (
                            nvl(ts.payment_type, 'cash')
                            in ('cash', 'corporate', 'prepaid')
                            and ptc.cash_enabled > 0
                        )
                        or (
                            ts.payment_type = 'card'
                            and ptc.card_enabled > 0
                        )
                    )
                        then ts.promocode_sum
                    else 0
                end
            )
    end                                          as promocode_sum,
    ptc.commission_type,
    ptc.start_dt                                 as contract_start_dt,
    ptc.end_dt                                   as contract_end_dt,
    case
        when ts.payment_type = 'card'      then 128
        when ts.payment_type = 'cash'      then 111
        when ts.payment_type = 'corporate' then 111
        when ts.payment_type = 'prepaid'   then 111
        else null
    end                                             as service_id
from
    bo.mv_partner_taxi_contract ptc
    join bo.t_partner_taxi_stat_aggr ts on
        ts.client_id = ptc.client_id
        and ts.dt >= ptc.start_dt
        and ts.dt < nvl(ptc.end_dt, ts.dt + 1)
    join bo.v_person_firm_tax pft on
        pft.firm_id = ptc.firm_id
        and pft.person_type = ptc.person_type
        and pft.start_dt <= ts.dt
        and pft.end_dt > ts.dt
)
select
    dt,
    client_id,
    contract_id,
    currency_id,
    payment_type,
    currency,
    iso_currency,
    order_type,
    nvl(v_taxi_stat.card_commission_sum, 0)            as card_commission_sum,
    nvl(v_taxi_stat.cash_commission_sum, 0)            as cash_commission_sum,
    promocode_sum,
    commission_type,
    contract_start_dt,
    contract_end_dt,
    nvl(
        nvl(card_commission_sum, cash_commission_sum),
        0
    )                                                  as commission_sum,
    service_id
from
    v_taxi_stat
\\

--changeset sfreest:BALANCE-29971-v-partner-taxi-completions-no-card-subs
create or replace view bo.v_partner_taxi_completion as
with v_taxi_stat as (
select
    ts.dt                                        as dt,
    ptc.client_id,
    ptc.contract_id,
    ptc.currency_id,
    nvl(ts.payment_type, 'cash')                 as payment_type,
    ptc.iso_currency                             as currency,
    ptc.iso_currency                             as iso_currency,
    ts.type                                      as order_type,
    case
        when ts.payment_type = 'card' and ptc.card_enabled > 0
            then ts.commission_sum * (pft.nds_pct / 100 + 1)
        else null
        end                                      as card_commission_sum,
    case
        when (
            nvl(ts.payment_type, 'cash') in ('cash', 'corporate', 'prepaid')
            and ptc.cash_enabled > 0
        )
            then ts.commission_sum * (pft.nds_pct / 100 + 1)
        else null
    end                                          as cash_commission_sum,
    case
        when ts.promocode_sum is not null
            then (
                case
                    when (
                        (
                            nvl(ts.payment_type, 'cash')
                            in ('cash', 'corporate', 'prepaid')
                            and ptc.cash_enabled > 0
                        )
                        or (
                            ts.payment_type = 'card'
                            and ptc.card_enabled > 0
                        )
                    )
                        then ts.promocode_sum
                    else 0
                end
            )
    end                                          as promocode_sum,
    case
      -- subsidy always has cash payment_type
      -- skip duplicates when client has 2 separate contracts for 111 and 128 services
      when ptc.cash_enabled > 0
        then greatest(nvl(ts.subsidy_sum, 0), 0)
      else 0
    end                                          as subsidy_sum,
    ptc.commission_type,
    ptc.start_dt                                 as contract_start_dt,
    ptc.end_dt                                   as contract_end_dt,
    case
        when ts.payment_type = 'card'      then 128
        when ts.payment_type = 'cash'      then 111
        when ts.payment_type = 'corporate' then 111
        when ts.payment_type = 'prepaid'   then 111
        else null
    end                                             as service_id
from
    bo.mv_partner_taxi_contract ptc
    join bo.t_partner_taxi_stat_aggr ts on
        ts.client_id = ptc.client_id
        and ts.dt >= ptc.start_dt
        and ts.dt < nvl(ptc.end_dt, ts.dt + 1)
    join bo.v_person_firm_tax pft on
        pft.firm_id = ptc.firm_id
        and pft.person_type = ptc.person_type
        and pft.start_dt <= ts.dt
        and pft.end_dt > ts.dt
)
select
    dt,
    client_id,
    contract_id,
    currency_id,
    payment_type,
    currency,
    iso_currency,
    order_type,
    nvl(v_taxi_stat.card_commission_sum, 0)            as card_commission_sum,
    nvl(v_taxi_stat.cash_commission_sum, 0)            as cash_commission_sum,
    promocode_sum,
    subsidy_sum,
    commission_type,
    contract_start_dt,
    contract_end_dt,
    nvl(
        nvl(card_commission_sum, cash_commission_sum),
        0
    )                                                  as commission_sum,
    service_id
from
    v_taxi_stat;
