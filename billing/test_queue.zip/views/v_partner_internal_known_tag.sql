--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114-2 stripComments:false endDelimiter:\\


 CREATE OR REPLACE FORCE EDITIONABLE VIEW "BO"."V_PARTNER_INTERNAL_KNOWN_TAG" AS

 select 1 firm_id,
     pcb.place_id,
     pcb.page_id,
     p.owner_id,
     null partner_contract_eid,
     pcb.clicks,
     pcb.shows,
     pcb.bucks,
     pcb.completion_type,
     0 hits,
     pcb.dt,
     pd."DESC" description,
     p.domain,
     100 commission_pct,
     null aggregator_pct,
     null partner_contract_id,
     null contract_end_dt,
     0 nds,
     pd.rur_click_price price,
     pd.type_id,
     null aggregator_reward,
     p.place_type,
     p.person_id,
     case when pd.type_id=4 then pcb.bucks*30
          when pd.type_id=2 then pcb.clicks * pd.rur_click_price * decode(pd.nds, 0, nds.nds_koef, 1)
          else pcb.shows/1000*885
     end partner_reward,
     case when pd.type_id=4 then pcb.bucks*30
          when pd.type_id=2 then pcb.clicks* pd.rur_click_price/0.45
          else pcb.shows/1000*885
     end turnover_with_nds_stat
 from
     (select pl.id place_id, max(pl.client_id) owner_id, max(pl.type) place_type, max(pr.id) person_id,
      max(pl.url) domain from bo.t_place pl, bo.t_person pr
      where pl.internal_type in(2,4) and pr.client_id=pl.client_id
      group by pl.id) p,
     (select
        dt, tag_id place_id,
        case when place_id=75 and page_id =542 then 2030
             --when place_id=75 and page_id =632 then 2040
             when place_id=20 and page_id= 542 then 632 end page_id, shows, clicks, bucks/1000000 bucks, bucks mbucks, 0 completion_type, 0 type
        from bo.t_partner_tags_stat3 where place_id in(20,75) and page_id in (542, 632)) pcb,
     bo.t_page_data pd,
     bo.v_nds_pct nds
 where
     p.place_id=pcb.place_id
     and pcb.page_id=pd.page_id
     and pd.contract_type='PARTNERS'
     and (nds.ndsreal_id = 18 and
          pcb.dt >= nds.from_dt and
          pcb.dt < nds.to_dt)

\\
