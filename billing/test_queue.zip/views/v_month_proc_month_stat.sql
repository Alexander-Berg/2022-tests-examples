--liquibase formatted sql

--changeset lightrevan:BALANCE-29780-v-mps stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW BO.v_month_proc_month_stat
AS
select parent_operation_id,
    (select dt from bo.t_operation where id = ss.parent_operation_id) dt,
    ordinal, step,
    sum(duration) duration,
    avg(duration) avg_duration,
    sum(num_consume) num_consume,
    sum(num_act_trans) num_act_trans,
    avg(decode(num_consume, 0, 0, duration/num_consume)) avg_per_consume,
    avg(decode(num_act_trans, 0, 0, duration/num_act_trans)) avg_per_tr,
    max(decode(num_consume, 0, 0, duration/num_consume)) max_per_consume,
    max(decode(num_act_trans, 0, 0, duration/num_act_trans)) max_per_tr,
    min(decode(num_consume, 0, 0, duration/num_consume)) min_per_consume,
    median(decode(num_consume, 0, 0, duration/num_consume)) median_per_consume,
    median(decode(num_act_trans, 0, 0, duration/num_act_trans)) median_per_tr,
    stddev(decode(num_consume, 0, 0, duration/num_consume)) dev_per_consume,
    stddev(decode(num_act_trans, 0, 0, duration/num_act_trans)) dev_per_tr
from
(select s.*,
    sum(
      case
        when metric_name = 'num_consume_dt' and step = 'mk_cache.completions4order_infos'
        then s.metric_num
        else 0
      end) over (partition by parent_operation_id, operation_id) num_consume,
      sum(
      case
        when metric_name = 'num_act_trans' and step = 'generate_acts'
        then s.metric_num
        else 0
      end) over (partition by parent_operation_id, operation_id) num_act_trans
 from bo.v_operation_stats s
  where S.CLASSNAME = 'Client' and s.operation_type_id = (select id from bo.t_operation_type where cc = 'generate_acts')
    ) ss
group by ss.parent_operation_id, ss.ordinal, ss.step
order by ss.parent_operation_id, ss.ordinal

\\
