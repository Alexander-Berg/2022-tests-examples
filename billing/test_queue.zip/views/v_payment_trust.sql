--liquibase formatted sql

--changeset vaclav:TRUST-2254-1  stripComments:false endDelimiter:/

create or replace view bo.v_payment_trust as
  SELECT p.id,
    p.dt,
    p.creator_uid,
    p.invoice_id,
    p.paysys_code,
    p.amount,
    p.currency,
    q.start_dt,
    p.payment_dt,
    p.cancel_dt,
    p.refund_to,
    p.register_line_id,
    p.chargeback_line_id,
    p.register_id,
    p.user_ip,
    p.resp_dt,
    p.resp_code,
    p.resp_desc,
    p.paysys_partner_id,
    p.service_id,
    p.processing_id,
    p.payment_method_id,
    p.firm_id,
    p.partner_id,
    p.terminal_id,
    q.payment_method,
    SUBSTR(q.payment_method, 1, DECODE( instr(q.payment_method, '-'), 0, LENGTH(q.payment_method), instr(q.payment_method, '-') - 1 )) payment_type,
    nvl(p.source_scheme, 'bo') source_scheme,
    case
        when p.service_id = 117 then 0
        when p.service_id = 124 and ym_shop_id = 29437 then 0
        else 1
    end via_yandex,
    q.trust_payment_id,
    q.notify_url,
    q.ym_invoice_id,
    q.ym_shop_id,
    q.phone wallet,
    q.order_id,
    q.request_id,
    q.purchase_token,
    q.postauth_dt,
    q.postauth_amount,
    q.payment_timeout,
    q.binding_result,
    q.rrn,
    q.approval_code,
    q.orig_payment_id
  FROM bo.t_payment p
  JOIN bo.t_ccard_bound_payment q ON p.id = q.id

/

--changeset akatovda:BALANCE-27462 stripComments:false endDelimiter:/
create or replace view bo.v_payment_trust as
  SELECT p.id,
    p.dt,
    p.creator_uid,
    p.invoice_id,
    p.paysys_code,
    p.amount,
    p.currency,
    q.start_dt,
    p.payment_dt,
    p.cancel_dt,
    p.refund_to,
    p.register_line_id,
    p.chargeback_line_id,
    p.register_id,
    p.user_ip,
    p.resp_dt,
    p.resp_code,
    p.resp_desc,
    p.paysys_partner_id,
    p.service_id,
    p.processing_id,
    p.payment_method_id,
    p.firm_id,
    p.partner_id,
    p.terminal_id,
    case when p.acs_redirect_url is not null then 1 else 0 end acs_status,
    q.payment_method,
    SUBSTR(q.payment_method, 1, DECODE( instr(q.payment_method, '-'), 0, LENGTH(q.payment_method), instr(q.payment_method, '-') - 1 )) payment_type,
    nvl(p.source_scheme, 'bo') source_scheme,
    case
        when p.service_id = 117 then 0
        when p.service_id = 124 and ym_shop_id = 29437 then 0
        else 1
    end via_yandex,
    q.trust_payment_id,
    q.notify_url,
    q.ym_invoice_id,
    q.ym_shop_id,
    q.phone wallet,
    q.order_id,
    q.request_id,
    q.purchase_token,
    q.postauth_dt,
    q.postauth_amount,
    q.payment_timeout,
    q.binding_result,
    q.rrn,
    q.approval_code,
    q.orig_payment_id
  FROM bo.t_payment p
  JOIN bo.t_ccard_bound_payment q ON p.id = q.id
/
