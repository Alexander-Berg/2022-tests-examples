--liquibase formatted sql

--changeset lightrevan:BALANCE-28053-view stripComments:false

CREATE OR REPLACE VIEW bo.v_paysys_sort AS
  WITH all_rows AS (
      SELECT
        ps.payment_method_id,
        f.region_id,
        le.val legal_entity,
        s.id   service_id,
        ps.priority,
        ps.weight
      FROM bo.t_paysys_sort ps
        JOIN (
          SELECT DISTINCT
            region_id
          FROM bo.t_firm
        ) f ON (ps.region_id IS NULL OR ps.region_id = f.region_id)
        JOIN bo.t_service s ON (ps.service_id IS NULL OR ps.service_id = s.id)
        JOIN (
          SELECT 1 val FROM dual UNION ALL
          SELECT 0 val FROM dual
        ) le ON (ps.legal_entity IS NULL OR ps.legal_entity = le.val)
  )
  SELECT
    payment_method_id,
    region_id,
    legal_entity,
    service_id,
    weight
  FROM (
    SELECT
      ps.*,
      rank() OVER (
        PARTITION BY ps.payment_method_id, ps.region_id, ps.service_id, ps.legal_entity
        ORDER BY ps.priority
      ) rnk
    FROM all_rows ps
  )
  WHERE rnk = 1
;
