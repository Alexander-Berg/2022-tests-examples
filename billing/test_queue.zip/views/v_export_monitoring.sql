--liquibase formatted sql

--changeset yanametro:BALANCE-24532 stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW BO.V_EXPORT_MONITORING AS
SELECT /*+ PARALLEL(4) */ CAST( 'BO.EXPORT_STATE_0.' || tp.type AS varchar2(256)) metric, NVL(cnt,0) VAL, sysdate time_stamp
  FROM bo.t_export_type tp
LEFT OUTER JOIN
  (  SELECT /*+ NO_USE_HASH_AGGREGATION */ type, COUNT(1) cnt
       FROM bo.t_export
      WHERE state = 0
   GROUP BY type
  ) exp_cnt
ON tp.type = exp_cnt.type

UNION ALL

SELECT 'BO.EXPORT_STATE_2.' || tp.type metric, NVL(cnt,0) VAL, sysdate time_stamp
  FROM bo.t_export_type tp
LEFT OUTER JOIN
    (  SELECT /*+ NO_USE_HASH_AGGREGATION */ type, COUNT(1) cnt
         FROM bo.t_export
        WHERE state=2 and update_dt >= sysdate - 10
     GROUP BY type
    ) exp_cnt
ON tp.type = exp_cnt.type

UNION ALL

select 'BO.EXPORT_STATE_0.THIRDPARTY_TRANSACTIONS' metric, count(*) val, sysdate from bo.t_export time_stamp
where type='THIRDPARTY_TRANS' and STATE=0

UNION ALL

SELECT
  'BO.EXPORT_0.DELAYED.' || ERR,
  count(*) cnt,
  sysdate
FROM (
    SELECT CASE WHEN ERROR LIKE ('%stat not found%') THEN 'TAXI_STAT_NOT_FOUND'
                WHEN ERROR LIKE ('%no active contracts%') THEN 'NO_ACTIVE_CONTRACTS'
                ELSE 'OTHER ERRORS'
           END ERR
    FROM bo.t_export
    WHERE type = 'THIRDPARTY_TRANS' AND STATE = 0 AND ERROR IS NOT NULL
) GROUP BY ERR

UNION ALL

select 'BO.EXPORT_0.PARTN_ACTS' || '.' || state metric, count(*) val, sysdate time_stamp
from bo.T_EXPORT where type='PARTNER_ACTS' group by state

UNION ALL

select 'BO.CACHE' metric, sysdate - STARTED_DT val, sysdate time_stamp
from bo.V_PYCRON where name='cache_partner_balances'


UNION ALL

select 'BO.COMPL.AVIA_SHOW' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_partner_avia_show
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.t_partner_avia_show
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

UNION ALL

select 'BO.COMPL.AVIA_CLICK' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_partner_avia_click
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.t_partner_avia_click
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

UNION ALL

select 'BO.COMPL.PARTNER_ORDER_COMPLETION' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_partner_order_completion
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.t_partner_order_completion
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

UNION ALL

select 'BO.COMPL.PARTNER_TAXI_STAT' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_partner_taxi_stat
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.t_partner_taxi_stat
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

UNION ALL

select 'BO.COMPL.PARTNER_TAGS_STAT3' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_partner_tags_stat3
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.t_partner_tags_stat3
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

UNION ALL

select 'BO.COMPL.PARTNER_MULTISHIP_STAT' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_partner_multiship_stat
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.t_partner_multiship_stat
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

UNION ALL

select 'BO.COMPL.PARTNER_ADDAPTER_STAT' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_partner_addapter_stat
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.T_PARTNER_ADDAPTER_STAT
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

    UNION ALL

select 'BO.COMPL.PARTNER_DSP_STAT' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_PARTNER_DSP_STAT
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.t_PARTNER_DSP_STAT
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

UNION ALL

select 'BO.COMPL.PARTNER_ADFOX_STAT' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_PARTNER_ADFOX_STAT
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.t_PARTNER_ADFOX_STAT
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

UNION ALL

select 'BO.COMPL.PARTNER_HEALTH_STAT' metric, b/(a+1) val, SYSDATE time_stamp
from
(select ROWNUM id, (select count(*)
from bo.t_PARTNER_HEALTH_STAT
WHERE DT >= TRUNC(SYSDATE-1, 'DD') and DT <= TRUNC(SYSDATE, 'DD')) a
from dual)
t_a
left join
(select ROWNUM id, (select count(*)
from bo.t_PARTNER_HEALTH_STAT
where DT >= TRUNC(SYSDATE, 'DD')
) b
from dual)
t_b
on t_a.id=t_b.id

UNION ALL

SELECT 'BO.TON.' || name, count(*), sysdate time_stamp
FROM
  (
  select nvl(codes.name, 'OP_' || ton.opcode) name
  from (
      select (user_data).order_id * 1000 - trunc((user_data).order_id) * 1000 opcode
	  from bo.ton
      where delay is null
      ) ton
  left outer join (
    select 'ORDER_OPCODE' name, 1 code from dual union
    select 'CLIENT_OPCODE', 10 from dual union
    select 'INVOICE_OPCODE', 20 from dual union
    select 'CONTRACT_OPCODE', 30 from dual union
    select 'SUB_CONTINUATION_ERROR_OPCODE', 40 from dual union
    select 'PARKING_PARTNER_OPCODE', 50 from dual union
    select 'BONUS_ADMISSION_OPCODE', 60 from dual union
    select 'BONUS_NOTIFY_OPCODE', 70 from dual
      ) codes on ton.opcode = codes.code
  )
GROUP BY name

UNION ALL

select 'BO.CALL_STAT_2_AVG.' || host || '.' || method,  avg, end_dt from (
    select method, host, end_dt, avg, row_number() over (PARTITION BY host, METHOD order by end_dt desc) rn
    from BO.T_CALL_STAT2
    where /*method in ('get_payment_preview', 'ctl_issue_invoice',
        'get_invoice', 'Balance.CreateTransferMultiple', 'get_contract2',
        'get_data_for_publisher', 'get_publisher_output', 'Balance.CreateInvoice',
        'BalanceSimple.CreateBasket', 'get_payment_choices', 'Balance.CreateFastPayment',
        'Balance2.GetTaxiBalance')
      and*/ end_dt > sysdate - 15/24/60
)
where rn = 1

UNION ALL

SELECT 'BO.CALL_STAT_2_PERC80.' || host || '.' || method,  PERC80, end_dt
  FROM (
    SELECT method, host, end_dt, PERC80, row_number() over (PARTITION BY host, METHOD order by end_dt desc) rn
      FROM BO.T_CALL_STAT2
     WHERE /*method in ('get_payment_preview', 'ctl_issue_invoice',
        'get_invoice', 'Balance.CreateTransferMultiple', 'get_contract2',
        'get_data_for_publisher', 'get_publisher_output', 'Balance.CreateInvoice',
        'BalanceSimple.CreateBasket', 'get_payment_choices', 'Balance.CreateFastPayment',
        'Balance2.GetTaxiBalance')
       AND*/ end_dt > sysdate - 15/24/60
  )
 WHERE rn = 1

UNION ALL

SELECT 'BO.KPI_SLA.max_rcpt1c_delay' metric, NVL(MAX(sysdate - exp.update_dt), 0) * 24 * 60 val, sysdate
  FROM bo.t_invoice i
  JOIN bo.t_person p
    ON p.id = i.person_id
  JOIN bo.t_export exp
    ON exp.object_id = i.id
   AND exp.type = 'PROCESS_PAYMENTS'
   AND exp.classname='Invoice'
 WHERE exp.state  = 0
   AND exp.traceback NOT LIKE 'DEFER_INVOICE_PAYMENT%'
   AND exp.traceback NOT LIKE 'UNMODERATED_TRANSFER%'

UNION ALL

SELECT 'BO.KPI_SLA.max_notif_delay',
  NVL(MAX(sysdate - CAST(SCN_TO_TIMESTAMP(ORA_ROWSCN) AS DATE)), 0) * 24 * 60 max_delay,
  sysdate
FROM bo.ton
WHERE retry_count = 0 and (user_data).order_id * 1000 - trunc((user_data).order_id) * 1000 = 1
AND delay        IS NULL

UNION ALL

SELECT 'BO.INVOICECOUNT.'
  || paysys_id metric,
  COUNT(*) val,
  TRUNC(sysdate, 'MI') time_stamp
FROM bo.t_invoice
WHERE dt >= TRUNC(sysdate, 'MI') - 1/24/60
AND dt    < TRUNC(sysdate, 'MI')
GROUP BY paysys_id

UNION ALL

SELECT 'BO.PAYMENTSUM.'
  || paysys_code metric,
  SUM(amount*NVL(bo.pk_discounts.sf_get_currency_rate(sysdate, currency),1)) val,
  TRUNC(sysdate, 'MI') time_stamp
FROM bo.t_payment
WHERE dt >= TRUNC(sysdate, 'MI') - 1/24/60
AND dt    < TRUNC(sysdate, 'MI')
GROUP BY paysys_code

UNION ALL

SELECT *
  FROM bo.mv_export_monitoring_slow

UNION ALL

SELECT 'BO.PYCRON.enabled_terminated_tasks_count' metric, count(1) val, sysdate time_stamp
  FROM bo.v_pycron
 WHERE enabled = 'Включено'
   AND terminate = 1
   AND trunc(sysdate) - trunc(update_dt) > 3

UNION ALL

SELECT 'BO.PYCRON.count_' || status metric, count(1) val, sysdate time_stamp
  FROM bo.t_pycron_state_history
  WHERE dt >= TRUNC(sysdate)
GROUP BY status

UNION ALL

SELECT * FROM (
    with metric0 as (
      select
        TABLE_NAME table_name,
        SUM(INSERTS) inserts,
        SUM(UPDATES) updates,
        SUM(DELETES) deletes
      from ALL_TAB_MODIFICATIONS
      WHERE TABLE_OWNER = 'BO' AND TABLE_NAME IN ('T_CONSUME', 'T_RECEIPT', 'T_OPERATION', 'T_REVERSE')
      GROUP BY TABLE_NAME
    ),
    metric1  as (
      SELECT
        table_name table_name,
        'INSERT' metric_type,
        inserts metric_value
      FROM metric0
      UNION ALL
      SELECT table_name, 'DELETE', deletes FROM metric0
      UNION ALL
      SELECT table_name, 'UPDATE', updates FROM metric0
    )
    SELECT
      'BO.STATS.' || table_name || '_' || metric_type metric,
      metric_value val,
      sysdate time_stamp
    FROM metric1
)
UNION ALL
    SELECT 'BO.COLL_STAT2.GetPagesStat.' || host metric, avg val, sysdate time_stamp
FROM bo.T_CALL_STAT2 WHERE (host, end_dt) IN
(SELECT host, max(end_dt) from bo.T_CALL_STAT2
where method like('Balance.GetPagesStat')
group by host) and method='Balance.GetPagesStat'


  union ALL

    SELECT 'BO.COLL_STAT2.GetPagesTagsStat.' || host metric, avg val, end_dt time_stamp
FROM bo.T_CALL_STAT2 WHERE (host, end_dt) IN
(SELECT host, max(end_dt) from bo.T_CALL_STAT2
where method like('Balance.GetPagesTagsStat')
group by host) and method='Balance.GetPagesTagsStat'


  union ALL

    SELECT 'BO.COLL_STAT2.GetDspStat.' || host metric, avg val, end_dt time_stamp
FROM bo.T_CALL_STAT2 WHERE (host, end_dt) IN
(SELECT host, max(end_dt) from bo.T_CALL_STAT2
where method like('Balance.GetDspStat')
group by host) and method='Balance.GetDspStat'

union ALL

SELECT 'BO.COLL_STAT2.GetInternalPagesStat.' || host metric, avg val, end_dt time_stamp
FROM bo.T_CALL_STAT2 WHERE (host, end_dt) IN
(SELECT host, max(end_dt) from bo.T_CALL_STAT2
where method like('Balance.GetInternalPagesStat')
group by host) and method='Balance.GetInternalPagesStat'

union ALL

SELECT 'BO.COLL_STAT2.GetInternalPagesTagsStat.' || host metric, avg val, end_dt time_stamp
FROM bo.T_CALL_STAT2 WHERE (host, end_dt) IN
(SELECT host, max(end_dt) from bo.T_CALL_STAT2
where method like('Balance.GetInternalPagesTagsStat')
group by host) and method='Balance.GetInternalPagesTagsStat'

\\

--changeset el-yurchito:BALANCE-26069
drop view BO.V_EXPORT_MONITORING;

--changeset el-yurchito:BALANCE-26069-2
drop view BO.v_graphite_one_min;
