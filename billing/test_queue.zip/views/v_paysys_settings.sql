--liquibase formatted sql

--changeset lightrevan:BALANCE-26114-settings-view

CREATE OR REPLACE VIEW BO.V_PAYSYS_SETTINGS AS
with
keys as (
  SELECT
    pm.id payment_method_id,
    f.id firm_id,
    f.REGION_ID,
    cur.iso_currency,
    legal.val legal_entity,
    resident.val resident,
    pg.id paysys_group_id
  from bo.t_firm f
  CROSS JOIN (
    select 1 val from dual UNION ALL
    select 0 val from dual
  ) resident
  CROSS JOIN (
    select 1 val from dual UNION ALL
    select 0 val from dual
  ) legal
  CROSS JOIN (
    SELECT DISTINCT
      decode(currency, 'RUR', 'RUB', currency) iso_currency
    FROM bo.T_TERMINAL
  ) cur
  CROSS JOIN bo.T_PAYMENT_METHOD pm
  CROSS JOIN BO.T_PAYSYS_GROUP pg
),
row_params as (
  SELECT DISTINCT
    keys.payment_method_id,
    keys.REGION_ID,
    keys.firm_id,
    keys.iso_currency,
    keys.legal_entity,
    keys.resident,
    keys.paysys_group_id,
    s.name,
    first_value(s.value_num) over (PARTITION BY s.name, keys.payment_method_id, keys.REGION_ID, keys.firm_id, keys.iso_currency, keys.legal_entity, keys.resident, keys.paysys_group_id ORDER BY s.priority) value_num,
    first_value(s.value_str) over (PARTITION BY s.name, keys.payment_method_id, keys.REGION_ID, keys.firm_id, keys.iso_currency, keys.legal_entity, keys.resident, keys.paysys_group_id ORDER BY s.priority) value_str
  from keys
  join bo.T_PAYSYS_SETTINGS s
    on keys.payment_method_id = nvl(s.payment_method_id, keys.payment_method_id)
    and keys.region_id = nvl(s.region_id, keys.region_id)
    and keys.firm_id = nvl(s.firm_id, keys.firm_id)
    and keys.iso_currency = nvl(s.iso_currency, keys.iso_currency)
    and keys.legal_entity = nvl(s.legal_entity, keys.legal_entity)
    and keys.resident = nvl(s.resident, keys.resident)
    and keys.paysys_group_id = nvl(s.paysys_group_id, keys.paysys_group_id)
)
SELECT
  p.payment_method_id,
  p.REGION_ID,
  p.firm_id,
  p.iso_currency,
  p.legal_entity,
  p.resident,
  p.paysys_group_id,
  max(decode(p.name, 'WAIT_PAYMENT_DAY_NUM', p.value_num, null)) WAIT_PAYMENT_DAY_NUM,
  max(decode(p.name, 'WAIT_PAYMENT_DAY_TYPE', p.value_num, null)) WAIT_PAYMENT_DAY_TYPE,
  max(decode(p.name, 'INVOICE_SENDABLE', p.value_num, null)) INVOICE_SENDABLE,
  max(decode(p.name, 'ALLOW_UNMODERATED', p.value_num, null)) ALLOW_UNMODERATED,
  max(decode(p.name, 'FOR_AGENCY', p.value_num, null)) FOR_AGENCY,
  max(decode(p.name, 'CREDIT_CARD', p.value_num, null)) CREDIT_CARD,
  max(decode(p.name, 'MOBILE', p.value_num, null)) MOBILE,
  max(decode(p.name, 'INSTANT', p.value_num, null)) INSTANT,
  max(decode(p.name, 'INAPP', p.value_num, null)) INAPP,
  max(decode(p.name, 'CERTIFICATE', p.value_num, null)) CERTIFICATE,
  max(decode(p.name, 'PREFIX', p.value_str, null)) PREFIX
from row_params p
GROUP BY
  p.payment_method_id,
  p.REGION_ID,
  p.firm_id,
  p.iso_currency,
  p.legal_entity,
  p.resident,
  p.paysys_group_id
;
