--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_UI_ACT_ORDER
--------------------------------------------------------------------------------

create or replace view BO.V_UI_ACT_ORDER as
SELECT
    acts."EXTERNAL_ID",acts."ACT_ID",acts."ACT_DT",acts."INVOICE_ID",acts."REQUEST_ID",acts."REQUEST_SEQ",
    acts."PASSPORT_ID",acts."CLIENT_ID",acts."PAYSYS_CC",acts."PAYSYS_NAME",acts."PAYSYS_CERTIFICATE",acts."AMOUNT",
    acts."ACT_SUM",acts."AMOUNT_NDS",acts."CURRENCY",acts."ISO_CURRENCY",acts."CURRENCY_NUM_CODE",
    acts."ISO_CURRENCY_NUM_CODE",acts."INVOICE_EID",acts."FACTURA",acts."PERSON_ID",acts."PERSON_NAME",
    acts."INVOICE_AMOUNT",acts."INVOICE_CURRENCY",acts."INVOICE_ISO_CURRENCY",acts."INVOICE_CURRENCY_RATE",
    acts."NDS_PCT",acts."PAYMENT_TERM_DT",acts."PAID_AMOUNT",acts."OVERDRAFT",acts."CREDIT",acts."CONTRACT_ID",
    acts."CONTRACT_EID",acts."INVOICE_CLOSED",acts."OUR_FAULT",acts."FIRM_ID",
    o.id                                    order_id,
    o.service_id || '-' || service_order_id order_number,
    o.client_id                             order_client_id,
    at.amount                               at_amount,
    o.agency_id,
    fic_i.external_id                       fictive_invoice_eid,
    o.service_code                          product_id,
    (SELECT nvl(tav1.value_str, null)
     FROM
       bo.t_person tp1
        left outer join
       bo.t_attribute_values tav1
          on tp1.attribute_batch_id = tav1.attribute_batch_id
     WHERE
       tp1.id = (
         SELECT value_num
         FROM bo.t_extprops e_prop
         WHERE e_prop.classname = 'Invoice' AND
               e_prop.object_id = acts.invoice_id AND
               attrname = 'endbuyer_id'
       )
       and tav1.code = 'NAME'
    ) endbuyer_name,
    (SELECT nvl(tav2.value_str, null)
     FROM
       bo.t_person tp2
        left outer join
       bo.t_attribute_values tav2
          on tp2.attribute_batch_id = tav2.attribute_batch_id
     WHERE
       tp2.id = (
         SELECT value_num
         FROM bo.t_extprops e_prop
         WHERE e_prop.classname = 'Invoice' AND
               e_prop.object_id = acts.invoice_id AND
               attrname = 'endbuyer_id'
       )
       and tav2.code = 'INN'
    ) endbuyer_inn,
    cc.id consume_id
  FROM
    bo.v_ui_acts acts
    JOIN bo.t_act_trans at ON at.act_id = acts.act_id AND at.netting IS NULL
    JOIN bo.t_consume cc ON cc.id = at.consume_id
    JOIN bo.t_order o ON o.id = cc.parent_order_id
    LEFT JOIN bo.t_invoice fic_i ON fic_i.id = cc.invoice_id AND fic_i.credit = 2
;
