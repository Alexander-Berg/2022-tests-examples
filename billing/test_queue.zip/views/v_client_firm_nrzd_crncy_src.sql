--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

create or replace view BO.v_client_firm_nrzd_crncy_src as
select o.client_id client_id, i.firm_id, decode(pc.resident, 1, 0, 1) non_resident, i.currency, i.iso_currency,
 o.service_code as product_id, i.id invoice_id, co.id as consume_id, co.dt as consume_dt
from BO.t_order o
join BO.t_consume co on co.parent_order_id = o.id
join BO.t_invoice i on co.invoice_id = i.id
join BO.t_person p on p.id = i.person_id
join BO.t_person_category pc on p.type = pc.category

\\
