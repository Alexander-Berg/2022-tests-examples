--liquibase formatted sql

--changeset quark:BALANCE-25720 stripComments:false endDelimiter:\\

create or replace view bo.v_person_firm_tax as
  select
    f.id firm_id,
    pc.category person_type,
    vtp.nds_pct,
    vtp.start_dt,
    vtp.end_dt
  from
    bo.t_person_category pc
    join bo.t_firm f on f.region_id = pc.region_id
    join bo.v_tax_policy vtp on pc.region_id = vtp.region_id and pc.resident = vtp.resident
  where
    nvl(vtp.default_tax, 0) = 1
    and (f.tax_policy_id is null
         or f.tax_policy_id is not null
            and pc.region_id = f.region_id and pc.resident != 1)
  union all
  select
    f.id firm_id,
    pc.category person_type,
    vtp.nds_pct,
    vtp.start_dt,
    vtp.end_dt
  from
    bo.t_person_category pc
    join bo.t_firm f on f.region_id = pc.region_id and pc.resident = 1
    join bo.v_tax_policy vtp on f.tax_policy_id = vtp.tax_policy_id

\\
