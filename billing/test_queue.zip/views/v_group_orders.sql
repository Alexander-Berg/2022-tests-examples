--liquibase formatted sql

--changeset lightrevan:BALANCE-25393-6 stripComments:false endDelimiter:\\

CREATE OR REPLACE FORCE VIEW BO.v_group_orders AS

SELECT o.id root_order_id, o.*
FROM bo.t_order o

UNION ALL

SELECT o.group_order_id root_order_id, o.*
FROM bo.t_order o
WHERE o.group_order_id IS NOT NULL

UNION ALL

SELECT o.group_order_id root_order_id, o_in.*
FROM bo.t_order o
INNER JOIN bo.t_order o_in ON o.id = o_in.group_order_id
WHERE o.group_order_id IS NOT NULL

\\