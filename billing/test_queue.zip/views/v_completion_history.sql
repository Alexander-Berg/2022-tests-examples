--liquibase formatted sql

--changeset lightrevan:BALANCE-27390-ch stripComments:false

CREATE OR REPLACE VIEW BO.V_COMPLETION_HISTORY AS
(
  select 
    order_id, 
    start_dt, 
    end_dt, 
    completion_sum, 
    completion_qty, 
    days, 
    bucks, 
    shows, 
    clicks, 
    units, 
    money
  from bo.t_completion_history
)
union all
(
  select 
    o.id order_id, 
    nvl(trunc(s.dt), date'2000-1-1') start_dt,
    trunc(sysdate + 1) end_dt, 
    s.consumed_sum completion_sum, 
    s.consumption completion_qty,
    s.days, 
    s.bucks,
    s.shows, 
    s.clicks,
    s.units,
    s.money
  from 
    bo.t_shipment s
    join bo.t_order o on o.service_id = s.service_id and s.service_order_id = o.service_order_id
);
