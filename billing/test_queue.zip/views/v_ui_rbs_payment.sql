--liquibase formatted sql

--changeset srg91:TRUST-2114 stripComments:false endDelimiter:/

CREATE OR REPLACE VIEW V_UI_RBS_PAYMENT AS
select
    p.dt,
    p.invoice_id,
    i.client_id,
    cl.name client,
    p.id as invoice_prc_eid,
    i.external_id as invoice_eid,
    r.mdorder,
    p.amount as payment_sum,
    r.paid_dt,
    r.cancelled_dt,
    r.fraud_dt,
    r.fraud_failed_dt,
    r.closed_dt,
    r.failed_dt,
    r.approval_code,
    p.register_id,
    r.CARD_HOLDER,
    r.IP_ADDRESS,
    p.CURRENCY,
    r.card_number,
    substr(r.card_number, -4) as card_suffix,
    -1 as status,
    r.fraud_suspicion_dt,
    r.chargeback_dt
from t_payment p, t_rbs_payment r, t_invoice i, t_client cl
where p.id = r.id and p.invoice_id = i.id and cl.id = i.client_id

/