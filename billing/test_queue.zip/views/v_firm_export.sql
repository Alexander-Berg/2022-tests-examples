--liquibase formatted sql

--changeset ngolovkin:BALANCE-27813-1 stripComments:false endDelimiter:\\
CREATE OR REPLACE VIEW bo.v_firm_export AS

SELECT fe.*,
	ou.NAME oebs_name,
	ou.date_from start_dt,
	ou.date_to end_dt,
	ou.short_code oebs_short_code,
	CASE 
		WHEN (
				ou.date_from IS NULL
				OR ou.date_from <= sysdate
				)
			AND (
				ou.date_to IS NULL
				OR ou.date_to > sysdate
				)
			THEN 1
		ELSE 0
		END active
FROM bo.T_FIRM_EXPORT fe
LEFT JOIN bo.mv_oebs_operation_unit ou ON fe.OEBS_ORG_ID = ou.organization_id
	AND fe.export_type = 'OEBS'

\\