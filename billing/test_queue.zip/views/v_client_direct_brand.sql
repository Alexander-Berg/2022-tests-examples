--liquibase formatted sql

/*
actual_states - выбирает раками текущие состояния атрибута BRAND_CLIENTS договоров на список дат - несколько дней вперёд и назад
BRAND_TYPE - Директ
Просроченные бренды не выбираются
Итоговый запрос позволяет по дате и клиенту получить список клиентов в бренде и id договора
Смотри так же v_client_brand_history.
*/

--changeset lightrevan:BALANCE-26921 stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW bo.V_client_direct_brand AS
with actual_states as (
  select *
  from (
      select dates.dt dt, ca.key_num client_id, ca.collateral_id, ca.cl_dt, ca.contract2_id, ca.value_num, brand_type.value_num brand_type, dense_rank() over (PARTITION BY ca.contract2_id, ca.code, NVL (ca.key_num, -1), dates.dt order by ca.stamp desc) rank
      from BO.v_contract_signed_attr_history ca 
      join bo.v_contract_dates dates on ca.code='BRAND_CLIENTS' and ca.cl_dt <= dates.dt
      join BO.v_contract_signed_attr_history brand_type on brand_type.contract2_id = ca.contract2_id and brand_type.code='BRAND_TYPE'
      where not exists (
          select * 
          from (
            select contract2_id, value_dt finish_dt, dense_rank() over (partition by contract2_id order by cl_dt desc) dr
            from bo.v_contract_signed_attr_history 
            where code = 'FINISH_DT'
          ) ca_ex
          where dr = 1 and trunc(ca_ex.finish_dt) <= dates.dt and ca_ex.contract2_id=ca.contract2_id
      )
    and brand_type.value_num in (7, 77) -- TODO отключить условие + переименовать в v_client_brand
  ) caa 
  where caa.rank = 1 and caa.value_num = 1 
)
select left_side.contract2_id contract_id, left_side.dt dt, left_side.client_id client_id, right_side.client_id brand_client_id, c.class_id main_client_class_id, left_side.brand_type
from actual_states left_side join actual_states right_side on left_side.contract2_id = right_side.contract2_id and left_side.dt = right_side.dt 
join bo.t_contract2 con on left_side.contract2_id = con.id join bo.t_client c on c.id = con.client_id
order by contract_id, dt, client_id

\\
