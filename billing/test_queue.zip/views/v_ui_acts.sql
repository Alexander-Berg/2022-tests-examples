--liquibase formatted sql

--changeset ngolovkin:BALANCE-24296 stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW BO.V_UI_ACTS AS
  SELECT
    a.external_id,
    a.id              as act_id,
    a.dt              as act_dt,
    i.id              as invoice_id,
    i.request_id,
    i.request_seq,
    i.passport_id,
    a.client_id,
    p.cc              as paysys_cc,
    p.name            as paysys_name,
    p.certificate     as paysys_certificate,
    a.amount,
    NULL              as act_sum,
    a.amount_nds,
    i.currency,
    i.iso_currency,
    cur.num_code      as currency_num_code,
    iso_cur.num_code  as iso_currency_num_code,
    i.external_id     as invoice_eid,
    a.factura,
    i.person_id,
    pe.name           as person_name,
    i.total_sum       as invoice_amount,
    i.currency        as invoice_currency,
    i.iso_currency    as invoice_iso_currency,
    i.currency_rate   as invoice_currency_rate,
    i.nds_pct,
    a.payment_term_dt,
    a.paid_amount,
    i.overdraft,
    i.credit,
    i.contract_id,
    co.external_id    as contract_eid,
    inv_closed.closed as invoice_closed,
    ba.our_fault,
    i.firm_id
  FROM
    bo.t_act a,
    (SELECT *
     FROM bo.t_bad_debt_act
     WHERE hidden = 0) ba,
    bo.t_invoice i,
    bo.t_currency cur,
    bo.t_iso_currency iso_cur,
    bo.t_paysys p,
    bo.t_person pe,
    bo.t_contract2 co,
    (SELECT
       id,
       CASE
       WHEN invoice_sum = act_sum
         THEN 1
       ELSE 0
       END closed
     FROM
       (SELECT
          i.id,
          i.total_act_sum * i.currency_rate act_sum,
          decode(
              i.credit,
              1, i.receipt_sum,
              greatest(
                  i.receipt_sum,
                  decode(
                      i.overdraft,
                      1, i.effective_sum,
                      i.consume_sum)
              )
          ) * i.internal_rate               invoice_sum
        FROM bo.t_invoice i)) inv_closed
  where cur.char_code = i.currency
        AND iso_cur.alpha_code = decode(upper(i.currency), 'RUR', 'RUB', upper(i.currency))
        AND a.invoice_id = i.ID
        AND i.paysys_id = p.ID
        AND a.type <> 'internal'
        AND a.hidden <> 4
        AND i.person_id = pe.id (+)
        AND i.contract_id = co.id (+)
        AND a.id = ba.act_id (+)
        AND inv_closed.id = i.id

\\
