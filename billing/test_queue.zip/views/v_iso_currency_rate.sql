--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace view bo.v_iso_currency_rate as
select
    src_cc                         as rate_src,
    dt                             as from_dt,
    nvl(
        lead(dt) over (
            partition by
                src_cc,
                iso_currency_from,
                iso_currency_to
            order by dt
        ),
        sysdate + 2
    )                              as to_dt,
    iso_currency_from,
    rate_from,
    iso_currency_to,
    rate_to
from
    bo.t_iso_currency_rate
\\
