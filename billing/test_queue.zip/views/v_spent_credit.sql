--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW bo.V_SPENT_CREDIT AS
SELECT   c.ID consume_id,
            inv.client_id client_id,
            o.service_code product_id,
            inv.contract_id contract_id,
            (c.current_sum * inv.internal_rate) spent,
            (c.current_sum * inv.internal_rate / inv.currency_rate) spent_currency,
            inv.currency,
            inv.iso_currency,
            inv.dt,
            inv.currency_rate
     FROM   bo.t_consume c, bo.t_order o, bo.t_invoice inv
    WHERE       c.parent_order_id = o.ID
            AND c.invoice_id = inv.ID
            AND inv.credit = 2
            AND NOT EXISTS
                  (SELECT   1
                     FROM   bo.t_invoice_repayment ir, bo.t_invoice i, bo.t_deferpay d
                    WHERE   ir.repayment_invoice_id = i.ID
                            AND i.hidden < 2
                            AND i.status_id < 5
                            AND i.receipt_sum > 0
                            AND c.invoice_id = d.invoice_id
                            AND d.repayment_dt IS NOT NULL
                            AND ir.invoice_id = c.invoice_id)

\\
