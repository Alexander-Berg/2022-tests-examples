--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_UI_MUTUAL_SETTLEMENTS_BASE
--------------------------------------------------------------------------------

create or replace view BO.V_UI_MUTUAL_SETTLEMENTS_BASE as
SELECT
    i.client_id,
    nvl(
      (SELECT tav1.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav1
       WHERE
         tav1.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav1.CODE = 'NAME'
      ),
      NULL
    )                      person_name,
    p.ID                   person_id,
    i.ID                   invoice_id,
    i.external_id          invoice_eid,
    i.dt,
    i.currency,
    i.iso_currency,
    'oebs'                 t,
    oe.cash_receipt_number doc_num,
    oe.receipt_date        doc_dt,
    oe.amount              debet,
    0                      credit,
    ps.certificate         paysys_certificate
  FROM
    bo.t_oebs_cash_payment_fact oe,
    bo.t_invoice i,
    bo.t_person p,
    bo.t_paysys ps
  WHERE
    oe.receipt_number = i.external_id
    AND i.person_id = p.ID (+)
    AND oe.receipt_date >= TO_DATE('01.01.2008', 'DD.MM.YYYY')
    AND SUBSTR(i.external_id, 1, INSTR(i.external_id, '-') - 1) IN ('Б', 'N', 'R', 'BR')
    AND nvl(oe.operation_type, 'INSERT') <> 'SF_AVANS'
    AND i.paysys_id = ps.ID
  UNION ALL
  SELECT
    i.client_id,
    nvl(
      (SELECT tav2.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav2
       WHERE
         tav2.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav2.CODE = 'NAME'
      ),
      NULL
    )                                person_name,
    p.ID                             person_id,
    i.ID                             invoice_id,
    i.external_id                    invoice_eid,
    i.dt,
    i.currency,
    i.iso_currency,
    '1c'                             t,
    d1.doc_type || ' ' || d1.doc_num doc_num,
    d1.doc_date                      doc_dt,
    p1.doc_sum                       debet,
    0                                credit,
    ps.certificate                   paysys_certificate
  FROM
    bo.t_1c_payments_v2 p1,
    bo.t_1c_documents_v2 d1,
    bo.t_invoice i,
    bo.t_person p,
    bo.t_paysys ps
  WHERE
    p1.invoice_eid = i.external_id
    AND i.person_id = p.ID (+)
    AND p1.dt = d1.dt
    AND p1.file_str = d1.file_str
    AND d1.doc_date < TO_DATE('01.01.2008', 'DD.MM.YYYY')
    AND SUBSTR(i.external_id, 1, 1) IN ('Б', 'N', 'R')
    AND i.paysys_id = ps.ID
  UNION ALL
  SELECT
    i.client_id,
    nvl(
      (SELECT tav3.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav3
       WHERE
         tav3.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav3.CODE = 'NAME'
      ),
      NULL
    )              person_name,
    p.ID           person_id,
    i.ID           invoice_id,
    i.external_id  invoice_eid,
    i.dt,
    i.currency,
    i.iso_currency,
    'act'          t,
    a.external_id  doc_num,
    a.dt           doc_dt,
    0              debet,
    a.amount       credit,
    ps.certificate paysys_certificate
  FROM
    bo.t_act a,
    bo.t_invoice i,
    bo.t_person p,
    bo.t_paysys ps
  WHERE
    a.invoice_id = i.ID
    AND i.person_id = p.ID (+)
    AND a.hidden < 4
    AND a.type <> 'internal'
    AND  SUBSTR(i.external_id, 1, 1) IN ('Б', 'N', 'R')
    AND i.paysys_id = ps.ID
;
