--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW V_UI_INVOICE_1C_PAYMENTS_X AS
select
  i.id as invoice_id,
  i.external_id as invoice_eid,
  i.currency,
  i.iso_currency,
  p.doc_sum as sum,
  p.dt,
  d.doc_date
from
  t_invoice i, t_1c_payments_v2 p, v_1c_active_docs d
where
  p.invoice_eid = i.external_id
  and p.dt = d.dt
  and p.file_str = d.file_str
  and d.doc_date < to_date('2008-01-01', 'YYYY-MM-DD')
  and i.credit in (0,1)
union all
select
  i.id as invoice_id,
  i.external_id as invoice_eid,
  i.currency,
  i.iso_currency,
  p.amount as sum,
  p.last_update_date as dt,
  p.receipt_date as doc_date
from
  t_oebs_cash_payment_fact p, t_invoice i
where
  p.receipt_number = i.external_id
  and regexp_like(i.external_id, '-[0-9][0-9]?$')
  and p.receipt_date >= to_date('2008-01-01', 'YYYY-MM-DD')
  and i.credit in (0,1)

\\
