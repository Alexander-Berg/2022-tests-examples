--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_UI_PERSONS
--------------------------------------------------------------------------------

create or replace view BO.V_UI_PERSONS as
SELECT
  tp.id,
  tp.type,
  tp.hidden,
  nvl(tav1.VALUE_NUM, 0) AS is_partner,
  tav2.VALUE_STR AS NAME,
  tav3.VALUE_STR AS EMAIL,
  tav4.VALUE_STR AS INN,
  tav5.VALUE_STR AS KPP,
  tc.id   AS client_id,
  tc.name AS client_name,
  (SELECT COUNT(*)
   FROM bo.t_invoice ti
   WHERE ti.person_id = tp.id) AS invoice_count
  FROM
    bo.t_person tp
      inner join
    bo.t_client tc
      on tp.CLIENT_ID = tc.ID
      left join
    bo.T_ATTRIBUTE_VALUES tav1
        on tav1.CODE = 'IS_PARTNER' and tav1.ATTRIBUTE_BATCH_ID = tp.ATTRIBUTE_BATCH_ID
      left join
    bo.T_ATTRIBUTE_VALUES tav2
        on tav2.CODE = 'NAME' and tav2.ATTRIBUTE_BATCH_ID = tp.ATTRIBUTE_BATCH_ID
      left join
    bo.T_ATTRIBUTE_VALUES tav3
        on tav3.CODE = 'EMAIL' and tav3.ATTRIBUTE_BATCH_ID = tp.ATTRIBUTE_BATCH_ID
      left join
    bo.T_ATTRIBUTE_VALUES tav4
        on tav4.CODE = 'INN' and tav4.ATTRIBUTE_BATCH_ID = tp.ATTRIBUTE_BATCH_ID
      left join
    bo.T_ATTRIBUTE_VALUES tav5
        on tav5.CODE = 'KPP' and tav5.ATTRIBUTE_BATCH_ID = tp.ATTRIBUTE_BATCH_ID
;
