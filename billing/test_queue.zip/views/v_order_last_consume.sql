--liquibase formatted sql

--changeset lightrevan:BALANCE-29465-view stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW bo.v_order_last_consume AS
  SELECT
    parent_order_id order_id,
    max(id)         consume_id
  FROM bo.t_consume
  GROUP BY parent_order_id

\\
