--liquibase formatted sql

--changeset lightrevan:BALANCE-26114-paysys-view-1  stripComments:false endDelimiter:/

CREATE OR replace VIEW bo.v_paysys AS
WITH firm_paysys
AS (
	SELECT decode(ps.firm_id, cf.firm_id, ps.id, cf.firm_id * 100000 + ps.id) id,
		ps.dt,
		ps.weight,
		ps.cc,
		ps.extern,
		ps.NAME,
		ps.nsp,
		ps.private,
		ps.reversable,
		ps.invoice_sendable,
		ps.nds,
		ps.person_type_code,
		ps.currency,
		ps.for_agency,
		ps.suppress_discounts,
		ps.category,
		ps.nds_pct,
		ps.prefix,
		cf.firm_id,
		ps.instant,
		ps.allow_unmoderated,
		ps.fraudable,
		ps.lang_id,
		ps.contract_needed,
		ps.monthly_reportable,
		ps.iso_currency,
		ps.wait_payment_day_num,
		ps.wait_payment_day_type,
		ps.barter,
		ps.credit_card,
		ps.mobile,
		ps.inapp,
		ps.first_limit,
		ps.second_limit,
		ps.certificate,
		ps.payment_method_id,
		ps.id paysys_original_id,
		ps.group_id,
		cf.region_id,
		cf.legal_entity,
		cf.resident
	FROM bo.t_paysys_old ps
	INNER JOIN (
		SELECT pc.category,
		  pc.region_id,
		  pc.ur legal_entity,
		  pc.resident,
			f.id firm_id
		FROM bo.t_person_category pc
		INNER JOIN bo.t_firm f ON pc.region_id = f.region_id
		) cf ON cf.category = ps.category
		AND NOT EXISTS (
			SELECT *
			FROM bo.t_paysys_old ps2
			WHERE ps2.cc = ps.cc
				AND cf.firm_id = ps2.firm_id
				AND ps2.id != ps.id
			)
	ORDER BY id
),
all_paysys AS (
  SELECT ps.id,
    ps.dt,
    ps.weight,
    ps.cc,
    ps.extern,
    ps.NAME,
    ps.nsp,
    ps.private,
    ps.reversable,
    ps.invoice_sendable,
    ps.nds,
    ps.person_type_code,
    ps.currency,
    ps.for_agency,
    ps.suppress_discounts,
    ps.category,
    ps.nds_pct,
    ps.prefix,
    ps.firm_id,
    ps.instant,
    ps.allow_unmoderated,
    ps.fraudable,
    ps.lang_id,
    ps.contract_needed,
    ps.monthly_reportable,
    ps.iso_currency,
    ps.wait_payment_day_num,
    ps.wait_payment_day_type,
    ps.barter,
    ps.credit_card,
    ps.mobile,
    ps.inapp,
    ps.first_limit,
    ps.second_limit,
    ps.certificate,
    ps.payment_method_id,
    ps.group_id,
    ps.region_id,
    ps.legal_entity,
    ps.resident
  FROM firm_paysys ps
  WHERE NOT EXISTS (
      SELECT *
      FROM firm_paysys ps2
      WHERE ps2.cc = ps.cc
        AND ps2.paysys_original_id < ps.paysys_original_id
        AND ps2.firm_id = ps.firm_id
      )

  union all

  select
    power(10,14) * firm.id + decode(cur.num_code, 810, 643, cur.num_code) * power(10,10) + payment_methods.id * power(10,4) + mod(ORA_HASH(pc.category),10000) ID,
    t.dt                      DT,
    200                       weight,
    CAST(pc.category || '_' || payment_methods.cc || '_' || decode(upper(cur.char_code), 'RUR', 'RUB', upper(cur.char_code)) AS varchar2(256)) CC, -------------
    1                         extern,
    CAST(pc.name || ' ' || payment_methods.cc || ' ' || decode(upper(cur.char_code), 'RUR', 'RUB', upper(cur.char_code)) AS varchar2(256)) NAME, ------------
    0                         NSP,
    0                         PRIVATE,
    1                         REVERSABLE,
    0                         INVOICE_SENDABLE,
    1                         nds,
    -1                        PERSON_TYPE_CODE,
    cur.char_code             CURRENCY,
    1                         FOR_AGENCY,
    0                         suppress_discounts,
    pc.category               CATEGORY,   --------
    18                        nds_pct,
    'Б'                       prefix,
    firm.id                   FIRM_ID,  ---------
    1                         INSTANT,
    0                         ALLOW_UNMODERATED,
    1                         FRAUDABLE,
    1                         LANG_ID,
    0                         CONTRACT_NEEDED,
    0                         monthly_reportable,
    decode(upper(cur.char_code), 'RUR', 'RUB', upper(cur.char_code))  ISO_CURRENCY,   --------
    14                        WAIT_PAYMENT_DAY_NUM,
    0                         WAIT_PAYMENT_DAY_TYPE,
    0                         BARTER,
    0                         CREDIT_CARD,
    1                         MOBILE,
    0                         inapp,
    --null                      first_limit,
    t.max_amount              first_limit,
    --null                      second_limit,
    t.max_amount              second_limit,
    0                         certificate,
    payment_methods.id        payment_method_id,
    2 group_id, --auto_trust
    pc.region_id,
    pc.ur legal_entity,
    pc.resident
  from dual ps
  join bo.t_person_category pc on 1=1--pc.admin_only is not null -- skip endbuyer_*
  join bo.t_firm firm on firm.region_id = pc.region_id
  join (
      select t.currency, t.firm_id, max(t.max_amount) max_amount, min(t.dt) dt, t.payment_method_id
      from bo.t_terminal t
      where firm_id is not null
      group by t.currency, t.firm_id, t.payment_method_id
      ) t on t.firm_id = firm.id
  join bo.t_currency cur on cur.char_code = t.currency
  join (
    select id, 'trust_' || cc cc from bo.t_payment_method
    where cc in ('card', 'yamoney_wallet')
  --union all
  --select 1601, 'trust_api' from dual
  ) payment_methods on t.payment_method_id = payment_methods.id or payment_methods.id = 1601
)
SELECT
  ps.id,
	ps.dt,
	ps.weight,
	ps.cc,
	ps.extern,
	ps.NAME,
	ps.nsp,
	ps.private,
	ps.reversable,
	nvl(s.invoice_sendable, ps.invoice_sendable) invoice_sendable,
	ps.nds,
	ps.person_type_code,
	ps.currency,
	nvl(s.for_agency, ps.for_agency) for_agency,
	ps.suppress_discounts,
	ps.category,
	ps.nds_pct,
	nvl(s.prefix, ps.prefix) prefix,
	ps.firm_id,
	nvl(s.instant, ps.instant) instant,
	nvl(s.allow_unmoderated, ps.allow_unmoderated) allow_unmoderated,
	ps.fraudable,
	ps.lang_id,
	ps.contract_needed,
	ps.monthly_reportable,
	ps.iso_currency,
	nvl(s.wait_payment_day_num, ps.wait_payment_day_num) wait_payment_day_num,
	nvl(s.wait_payment_day_type, ps.wait_payment_day_type) wait_payment_day_type,
	ps.barter,
	nvl(s.credit_card, ps.credit_card) credit_card,
	nvl(s.mobile, ps.mobile) mobile,
	nvl(s.inapp, ps.inapp) inapp,
	ps.first_limit,
	ps.second_limit,
	nvl(s.certificate, ps.certificate) certificate,
	ps.payment_method_id,
	ps.group_id,
	ps.region_id,
  ps.legal_entity,
  ps.resident
FROM all_paysys ps
left join bo.V_PAYSYS_SETTINGS s
  on ps.REGION_ID = s.REGION_ID
  and ps.firm_id = s.firm_id
  and ps.resident = s.resident
  and ps.legal_entity = s.legal_entity
  and nvl(ps.iso_currency, ps.currency) = s.iso_currency
  and ps.PAYMENT_METHOD_ID = s.PAYMENT_METHOD_ID
  and ps.group_id = s.paysys_group_id
/