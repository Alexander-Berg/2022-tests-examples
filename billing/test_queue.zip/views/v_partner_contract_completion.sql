--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_PARTNER_CONTRACT_COMPLETION
--------------------------------------------------------------------------------

create or replace view BO.V_PARTNER_CONTRACT_COMPLETION as
with v_partner_turnover_expense as (
  select
       service_id,
       start_dt,
       nvl(lead (start_dt-1) over (partition BY service_id order by start_dt), sysdate+365) end_dt,
       pct
  from bo.t_partner_turnover_expense
  )

  SELECT
    pcp.firm_id,
    pcb.place_id,
    pcp.client_id owner_id,
    pcp.id partner_contract_eid,
    pd.page_id,
    pcb.clicks,
    pcb.shows,
    pcb.bucks,
    pcb.completion_type,
    pcb.dt,
    decode(pcp.reward_type, 2, nvl(exp.pct, 0), 0) avg_discount_pct,
    NVL(pcb.hits,0) hits,
    pd."DESC" description,
    p.url domain,
    pcp.id partner_contract_id,
    DECODE(pd.page_id, 2060, pcp.bm_market_pct, 2070, pcp.market_api_pct, 854,
    pcp.bm_direct_pct, pcp.partner_pct) commission_pct,
    pcp.AGREGATOR_PCT aggregator_pct,
    pcp.contract_end_dt contract_end_dt,
    contract_nds.nds_pct nds,
    CASE
      WHEN pd.type_id=1
      THEN
        (
          SELECT
            q.price
          FROM
            bo.mv_partner_mkb_price q
          WHERE
            q.place_id     =plo.place_id
          AND q.contract_id=pcp.id
        )
      WHEN pd.type_id=2
      THEN pd.rur_click_price
      ELSE NULL
    END price,
    pd.type_id,
    CASE
      WHEN pd.type_id=6
      THEN pcb.bucks*30
      WHEN pd.type_id=1
      THEN
        (
          SELECT
            q.price
          FROM
            bo.mv_partner_mkb_price q
          WHERE
            q.place_id     = plo.place_id
          AND q.contract_id=pcp.id
        )
        * contract_nds.nds_koef*pcb.shows/1000
      WHEN pd.type_id=2
      THEN pd.rur_click_price * pcb.clicks * decode(pd.nds, 0, russia_nds.nds_koef, 1)
      ELSE pcb.bucks                                                         * decode(pcp.reward_type, 2, 1-nvl(exp.pct, 0)*0.01, 1)
                                                                             * NVL(DECODE(pd.page_id, 2060, pcp.bm_market_pct,
        2070, pcp.market_api_pct, 854, pcp.bm_direct_pct, pcp.partner_pct),0)*
        0.01                                                                 *
        30
    END partner_reward,
    CASE
      WHEN pd.type_id=4
      THEN pcb.bucks*30*decode(pcp.reward_type, 2, 1-nvl(exp.pct, 0)*0.01, 1)
      WHEN pd.type_id=2
      THEN pd.rur_click_price*pcb.clicks/0.45
      ELSE NULL
    END turnover_with_nds,
    CASE
      WHEN pd.type_id=4
      THEN pcb.bucks*30*decode(pcp.reward_type, 2, 1-nvl(exp.pct, 0)*0.01, 1)
      WHEN pd.type_id=2
      THEN pd.rur_click_price*pcb.clicks/0.45
        -- shit method for calc mkb turnover
      WHEN pd.type_id=1
      THEN 885*pcb.shows/1000
      ELSE 0
    END turnover_with_nds_stat,
    CASE
      WHEN pd.type_id=2
      THEN (pcb.clicks * pd.rur_click_price/(pcp.partner_pct*0.01)*(NVL(pcp.agregator_pct,0)*0.01))
            * decode(pd.nds, 0, russia_nds.nds_koef, 1)
      ELSE pcb.bucks        * decode(pcp.reward_type, 2, 1-nvl(exp.pct, 0)*0.01, 1)*NVL(pcp.agregator_pct,0)*0.01*30
    END aggregator_reward,
    p.type place_type,
    CASE
      WHEN c.partner_type IN (2,3)
      THEN (
        select tav.value_str
        from bo.t_attribute_values tav
        where
          tav.ATTRIBUTE_BATCH_ID = person.ATTRIBUTE_BATCH_ID
          and tav.CODE = 'LONGNAME'
      )
      ELSE NULL
    END aggregator_name,
    pcp.person_id,
    'RUR' currency,
    'RUB' iso_currency
  FROM
    bo.t_partner_completion_buffer pcb,
    bo.t_page_data pd,
    bo.mv_partner_contract_puttee pcp,
    bo.mv_partner_place_owners plo,
    bo.t_mkb_category mc,
    bo.t_place p,
    bo.t_person person,
    bo.t_client c,
    v_partner_turnover_expense exp,
    bo.t_contract2 c2,
    bo.v_nds_pct russia_nds,
    bo.v_nds_pct contract_nds
  WHERE
    pd.page_id NOT IN (100005,632,643, 2060, 854)
    AND c2.id = pcp.id
    AND c2.type = pd.contract_type
    AND pd.contract_type = 'PARTNERS'
    AND pd.service_id = exp.service_id(+)
    and pcb.dt>=nvl(exp.start_dt, pcb.dt - 1)
    and pcb.dt<=nvl(exp.end_dt, pcb.dt + 1)
    AND pcb.page_id   = pd.page_id
    AND pcb.dt       >= plo.start_dt
    AND pcb.dt       <= NVL(plo.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
    AND pcp.client_id =plo.billing_client_id
    AND pcb.place_id  = plo.place_id
    AND pcb.dt       >=pcp.dt
    AND pcb.dt       <=NVL(pcp.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
    AND mc.ID(+)     =p.mkb_category_id
    AND p.id         =plo.place_id
    AND pcp.client_id=c.id
    AND person.id(+) =pcp.person_id
    and (russia_nds.ndsreal_id = 18 and
         pcb.dt >= russia_nds.from_dt and
         pcb.dt < russia_nds.to_dt)
    and (contract_nds.ndsreal_id = pcp.nds and
         pcb.dt >= contract_nds.from_dt and
         pcb.dt < contract_nds.to_dt)
;
