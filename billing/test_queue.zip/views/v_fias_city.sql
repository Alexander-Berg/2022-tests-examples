--liquibase formatted sql

--changeset lightrevan:BALANCE-30262 stripComments:false
CREATE OR REPLACE VIEW "BO"."V_FIAS_CITY" AS
SELECT DISTINCT
  t1.guid guid,
  t1.formal_name,
  t1.short_name
FROM
  bo.t_fias t1
  LEFT JOIN bo.t_fias t2
            ON t2.parent_guid = t1.guid
              AND t2.live_status = 1
WHERE
  t1.live_status = 1
  AND (
    t1.obj_level = 6
    OR (
      t1.obj_level IN (1, 3)
      AND (
        t2.obj_level = 7
        OR t2.obj_level = 65 AND NOT exists(SELECT * FROM bo.t_fias t3 WHERE t3.parent_guid = t2.guid AND t3.live_status = 1)
      )
    )
    OR t1.obj_level = 4 AND t2.obj_level > 6
  )
;
