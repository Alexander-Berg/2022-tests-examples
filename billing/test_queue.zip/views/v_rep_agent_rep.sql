--liquibase formatted sql

--changeset yanametro:BALANCE-24275 stripComments:false endDelimiter:\\

create or replace force view "BO"."V_REP_AGENT_REP"
as
  select
    o.service_id,
    o.id                  order_id,
    a.id                  act_id,
    a.external_id         act_external_id,
    at.act_qty,
    inv.id                invoice_id,
    at.amount             act_amount,
    a.dt                  dt,
    0                     shows,
    0                     clicks,
    0                     bucks,
    0                     money,
    0                     days,
    0                     units,
    inv.currency,
    inv.iso_currency,
    inv.internal_rate,
    o.text                description,
    o.service_id
    || '-'
    || o.service_order_id order_eid,
    con.id                contract_id
  from bo.t_invoice inv
    join bo.t_act a
      on a.invoice_id = inv.id
    join bo.t_act_trans at
      on at.act_id = a.id
    join bo.t_consume q
      on q.id = at.consume_id
    join bo.t_order o
      on o.id = q.parent_order_id
    join bo.t_product p
      on p.id = o.service_code
    join bo.t_contract2 con
      on con.id = inv.contract_id
    join bo.t_thirdparty_service ts
      on o.service_id = ts.id and nvl(ts.agent_report, 0) = 1
  where
    a.hidden < 4 and
    a.dt >= date '2015-12-01' and
    (case
      when a.client_id = ts.force_partner_id then 0
      else 1
    end) = 1
  union all
  select
    service_id,
    order_id,
    act_id,
    act_external_id,
    act_qty,
    invoice_id,
    act_amount,
    dt,
    shows,
    clicks,
    bucks,
    money,
    days,
    units,
    currency,
    iso_currency,
    internal_rate,
    description,
    order_eid,
    contract_id
  from bo.t_agent_report_before_bu

\\
