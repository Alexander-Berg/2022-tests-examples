--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_UI_DEFERPAYS_W_ORDERS_OLD
--------------------------------------------------------------------------------

create or replace view BO.V_UI_DEFERPAYS_W_ORDERS_OLD as
SELECT
  d.ID AS deferpay_id,
  d.parent_deferpay_id,
  d.issue_dt,
  d.repayment_dt,
  d.status_id,
  d.invoice_id,
  fi.external_id AS invoice_eid,
  fi.client_id,
  ic.NAME AS client_name,
  d.order_id AS fict_order_id,
  o.ID order_id,
  o.service_id || '-' || o.service_order_id order_eid,
  s.cc,
  o.service_order_id,
  o.client_id AS order_client_id,
  c.NAME AS order_client_name,
  io.text,
  io.quantity,
  io.type_rate,
  pt.NAME AS unit,
  io.price,
  io.amount_no_discount,
  io.discount_pct,
  io.amount,
  fi.paysys_id,
  ps.NAME AS paysys_name,
  fi.nds AS paysys_nds,
  fi.currency AS paysys_currency,
  fi.iso_currency AS paysys_iso_currency,
  fi.person_id,
  nvl(
    (SELECT tav.value_str
     FROM "BO"."T_ATTRIBUTE_VALUES" tav
     WHERE
       tav.ATTRIBUTE_BATCH_ID = pe.ATTRIBUTE_BATCH_ID
       AND tav.CODE = 'NAME'
    ),
    NULL
  ) AS person_name,
  ri.repayment_invoice_id,
  ri.repayment_invoice_eid,
  ri.repayment_status_id,
  '' client_logins
FROM
  bo.t_deferpay d,
  bo.t_invoice fi,
  (SELECT
     ir.invoice_id, ir.repayment_invoice_id,
     ri.external_id repayment_invoice_eid,
     ri.status_id repayment_status_id
   FROM bo.t_invoice_repayment ir, bo.t_invoice ri
   WHERE
     ir.repayment_invoice_id = ri.ID AND ri.hidden IN (0, 1)) ri,
  bo.t_client ic,
  bo.t_person pe,
  bo.t_paysys ps,
  bo.t_invoice_order io,
  bo.t_order o,
  bo.t_service s,
  bo.t_client c,
  bo.t_manager m,
  bo.t_product p,
  bo.t_product_unit pu,
  bo.t_product_type pt
WHERE
  d.invoice_id = fi.ID
  AND fi.receipt_sum <> 0
  AND fi.paysys_id = ps.ID
  AND fi.ID = io.invoice_id
  AND io.order_id = o.ID
  AND o.service_id = s.ID
  AND o.client_id = c.ID
  AND o.manager_code = m.manager_code(+)
  AND fi.person_id = pe.ID(+)
  AND fi.client_id = ic.ID
  AND fi.ID = ri.invoice_id(+)
  AND o.service_code = p.ID
  AND p.unit_id = pu.ID
  AND pu.product_type_id = pt.ID
;
