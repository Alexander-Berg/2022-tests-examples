--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

CREATE OR REPLACE FORCE VIEW "BO"."V_UI_CONSUMES_HISTORY"
  AS
  SELECT /*+ opt_param('optimizer_dynamic_sampling' 0)*/
    'consume'                                     as oper_type,
    v_aux.contract_id                             as contract_id,
    v_aux.invoice_id                              as invoice_id,
    v_aux.invoice_eid                             as invoice_eid,
    v_aux.invoice_credit                          as invoice_credit,
    v_aux.invoice_type                            as invoice_type,
    v_aux.invoice_dt                              as invoice_dt,
    v_aux.invoice_currency                        as invoice_currency,
    v_aux.invoice_iso_currency                    as invoice_iso_currency,
    v_aux.operation_id                            as operation_id,
    v_aux.operation_dt                            as operation_dt,
    v_aux.client_id                               as client_id,
    ord.text                                      as order_text,
    ord.service_id || '-' || ord.service_order_id as order_eid,
    ord.service_id                                as service_id,
    ord.service_order_id                          as service_order_id,
    subclt.name                                   as order_client_name,
    subclt.id                                     as order_client_id,
    srv.cc                                        as service_cc,
    srv.service_group_id                          as service_group_id,
    (
      SELECT SUM(consume_sum)
      FROM bo.t_consume c
      WHERE c.invoice_id = v_aux.invoice_id AND c.parent_order_id = ord.id AND c.operation_id = v_aux.operation_id
    ) AS consume_sum
  FROM
    BO.V_UI_CONSUMES_HISTORY_AUX v_aux
    JOIN bo.t_consume con   ON con.invoice_id = v_aux.invoice_id AND con.operation_id = v_aux.operation_id
    JOIN bo.t_order ord     ON ord.id = con.parent_order_id
    JOIN bo.t_client subclt ON subclt.id = ord.client_id
    JOIN bo.t_service srv   ON srv.id = ord.service_id

  UNION ALL

  SELECT
    'reverse'                                     as oper_type,
    v_aux.contract_id                             as contract_id,
    v_aux.invoice_id                              as invoice_id,
    v_aux.invoice_eid                             as invoice_eid,
    v_aux.invoice_credit                          as invoice_credit,
    v_aux.invoice_type                            as invoice_type,
    v_aux.invoice_dt                              as invoice_dt,
    v_aux.invoice_currency                        as invoice_currency,
    v_aux.invoice_iso_currency                    as invoice_iso_currency,
    v_aux.operation_id                            as operation_id,
    v_aux.operation_dt                            as operation_dt,
    v_aux.client_id                               as client_id,
    ord.text                                      as order_text,
    ord.service_id || '-' || ord.service_order_id as order_eid,
    ord.service_id                                as service_id,
    ord.service_order_id                          as service_order_id,
    subclt.name                                   as order_client_name,
    subclt.id                                     as order_client_id,
    srv.cc                                        as service_cc,
    srv.service_group_id                          as service_group_id,
    (
      SELECT 0 - SUM(reverse_sum)
      FROM bo.t_reverse r
      WHERE r.invoice_id = v_aux.invoice_id AND r.parent_order_id = ord.id AND r.operation_id = v_aux.operation_id
    ) AS consume_sum
  FROM
    BO.V_UI_CONSUMES_HISTORY_AUX v_aux
    JOIN bo.t_reverse rev   ON rev.invoice_id = v_aux.invoice_id AND rev.operation_id = v_aux.operation_id and rev.reverse_qty < 0
    JOIN bo.t_order ord     ON ord.id = rev.parent_order_id
    JOIN bo.t_client subclt ON subclt.id = ord.client_id
    JOIN bo.t_service srv   ON srv.id = ord.service_id

  UNION ALL

  SELECT
    'receipt'                                     as oper_type,
    v_aux.contract_id                             as contract_id,
    v_aux.invoice_id                              as invoice_id,
    v_aux.invoice_eid                             as invoice_eid,
    v_aux.invoice_credit                          as invoice_credit,
    v_aux.invoice_type                            as invoice_type,
    v_aux.invoice_dt                              as invoice_dt,
    v_aux.invoice_currency                        as invoice_currency,
    v_aux.invoice_iso_currency                    as invoice_iso_currency,
    v_aux.operation_id                            as operation_id,
    v_aux.operation_dt                            as operation_dt,
    v_aux.client_id                               as client_id,
    NULL                                          as order_text,
    NULL                                          as order_eid,
    NULL                                          as service_id,
    NULL                                          as service_order_id,
    NULL                                          as order_client_name,
    NULL                                          as order_client_id,
    NULL                                          as service_cc,
    NULL                                          as service_group_id,
    (
      SELECT SUM(receipt_sum)
      FROM bo.t_receipt r
      WHERE r.invoice_id = v_aux.invoice_id AND r.operation_id = v_aux.operation_id
    ) AS consume_sum
  FROM
    BO.V_UI_CONSUMES_HISTORY_AUX v_aux
    JOIN bo.t_receipt rec ON rec.invoice_id = v_aux.invoice_id AND rec.operation_id = v_aux.operation_id and rec.receipt_sum < 0

\\
