--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_UI_CONTRACT_APEX
--------------------------------------------------------------------------------

CREATE OR REPLACE VIEW "BO"."V_UI_CONTRACT_APEX" AS
SELECT
  co.id                            AS contract_id,
  co.external_id                   AS contract_eid,
  cl.dt                            AS dt,
  f2.value_dt                      AS finish_dt,
  f13_1.value_dt                   AS sent_dt,
  bo.sf_nullif(f4.value_num, 0)    AS manager_code,
  m.name                           AS manager_name,
  bo.sf_nullif(f8.value_num, 0)    AS manager_bo_code,
  m_bo.name                        AS manager_bo_name,
  bo.sf_nullif(clients.id, 0)      AS client_id,
  clients.name                     AS client_name,
  bo.sf_nullif(agencies.id, 0)     AS agency_id,
  agencies.name                    AS agency_name,
  bo.sf_nullif(co.person_id, 0)    AS person_id,
  nvl(
      (SELECT tav1.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav1
       WHERE
         tav1.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav1.CODE = 'NAME'
      ),
      NULL
  )                                AS person_name,
  nvl(
      (SELECT tav2.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav2
       WHERE
         tav2.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav2.CODE = 'CITY'
      ),
      NULL
  )                                AS person_city,
  nvl(
      (SELECT tav3.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav3
       WHERE
         tav3.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav3.CODE = 'PHONE'
      ),
      NULL
  )                                AS person_phone,
  nvl(
      (SELECT tav4.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav4
       WHERE
         tav4.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav4.CODE = 'EMAIL'
      ),
      NULL
  )                                AS person_email,
  nvl(
      (SELECT tav5.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav5
       WHERE
         tav5.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav5.CODE = 'REPRESENTATIVE'
      ),
      NULL
  )                                AS representative,
  com.value_num                    AS contract_type,
  en.value                         AS contract_type_name,
  nvl(f5.value_num, 0)             AS commission,
  com_type.name                    AS commission_name,
  nvl(f6.value_num, 0)             AS supercommission,
  scom.name                        AS scommission_name,
  f9.value_num                     AS com_charge_type,
  f12.services                     AS service_name,
  f7.value_num                     AS payment_type,
  cl.is_signed                     AS is_signed,
  f10.value_num                    AS wo_nds,
  cl.is_faxed                      AS is_faxed,
  cl.is_cancelled                  AS is_cancelled,
  f11.value_str                    AS memo,
  cast(f11a.value_str || dbms_lob.substr(f11a.value_clob, 512, 1) AS VARCHAR2(512 CHAR))  AS memo_contr,
  co.type                          AS ctype,
  f14.value_num                    AS firm_id,
  f16.value_num                    AS print_form_type,
  nvl(
      (SELECT DISTINCT f15_1.value_num
       FROM
         "BO"."T_CONTRACT_COLLATERAL"  f15
          JOIN
         "BO"."T_ATTRIBUTE_VALUES"     f15_1
            ON f15_1.attribute_batch_id = f15.attribute_batch_id
               AND f15_1.code = 'IS_BOOKED'
               AND f15_1.value_num = 1
       WHERE f15.contract2_id = co.id
      ),
  0)                               AS is_booked
  FROM
    "BO"."T_CONTRACT2"                          co
      LEFT OUTER JOIN
    "BO"."T_CONTRACT_COLLATERAL"                cl
        ON cl.contract2_id = co.id AND cl.num IS NULL AND cl.collateral_type_id IS NULL
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                com
        ON com.contract_id = co.id AND com.code = 'COMMISSION'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f2
        ON f2.contract_id = co.id AND f2.code = 'FINISH_DT'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f4
        ON f4.contract_id = co.id AND f4.code = 'MANAGER_CODE'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f5
        ON f5.contract_id = co.id AND f5.code = 'COMMISSION_TYPE'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f6
        ON f6.contract_id = co.id AND f6.code = 'SUPERCOMMISSION'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f7
        ON f7.contract_id = co.id AND f7.code = 'PAYMENT_TYPE'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f8
        ON f8.contract_id = co.id AND f8.code = 'MANAGER_BO_CODE'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f9
        ON f9.contract_id = co.id AND f9.code = 'COMMISSION_CHARGE_TYPE'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f10
        ON f10.contract_id = co.id AND f10.code = 'DISCARD_NDS'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f11
        ON f11.contract_id = co.id AND f11.code = 'MEMO'
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"                f14
        ON f14.contract_id = co.id AND f14.code = 'FIRM'
      LEFT OUTER JOIN
    "BO"."T_MANAGER"                            m
        ON m.manager_code = f4.value_num
      LEFT OUTER JOIN
    "BO"."T_MANAGER"                            m_bo
        ON m_bo.manager_code = f8.value_num
      LEFT OUTER JOIN
    "BO"."T_PERSON"                             p
        ON p.id = co.person_id
      LEFT OUTER JOIN
    "BO"."T_CLIENT"                             clients
        ON co.client_id = clients.id AND clients.is_agency = 0
      LEFT OUTER JOIN
    "BO"."T_CLIENT"                             agencies
        ON co.client_id = agencies.id AND agencies.is_agency <> 0
      LEFT OUTER JOIN
    "BO"."T_CONTRACT_COMSN_TYPE"                com_type
        ON com_type.id = f5.value_num
      LEFT OUTER JOIN
    "BO"."T_SUPERCOMMISSION_TYPE"               scom
        ON scom.id = f6.value_num
      LEFT OUTER JOIN
    "BO"."T_ENUMS_TREE"                         en
        ON com.value_num = en.code AND en.parent_id = 1400
      LEFT OUTER JOIN
    "BO"."V_CONTRACT_SERVICES"                  f12
        ON f12.contract_id = co.id
      LEFT OUTER JOIN
    "BO"."T_CONTRACT_COLLATERAL"                f13
        ON f13.contract2_id = co.id
           AND f13.num IS NULL
           AND f13.collateral_type_id IS NULL
      LEFT OUTER JOIN
    "BO"."T_ATTRIBUTE_VALUES"                   f13_1
        ON f13_1.attribute_batch_id = f13.attribute_batch_id AND f13_1.code = 'SENT_DT'
    -- REPORTS-1099
      LEFT OUTER JOIN
    "BO"."T_ATTRIBUTE_VALUES"                   f11a
        ON f11a.attribute_batch_id = f13.attribute_batch_id AND f11a.code = 'MEMO'
    -- REPORTS-1444
      LEFT OUTER JOIN
    "BO"."MV_CONTRACT_LAST_ATTR"  f16
        ON f16.contract_id = co.id
           AND f16.code = 'PRINT_FORM_TYPE'
;
