--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114-1 stripComments:false endDelimiter:\\
create or replace view v_nds_pct as
  select
    tax_policy_id,
    ndsreal_id,
    dt as from_dt,
    nvl(
        lead(dt) over (
            partition by
                tax_policy_id
            order by dt
        ),
        to_date('01.01.9999', 'DD.MM.YYYY')
    ) as to_dt,
    nds_pct,
    1+(0.01*nds_pct) as nds_koef

from bo.t_tax_policy_pct t
join bo.t_nds_map m using (tax_policy_id)
\\