--liquibase formatted sql

--changeset lightrevan:BALANCE-27778-vppr stripComments:false

CREATE OR REPLACE VIEW bo.v_pay_policy_routing AS
  SELECT DISTINCT
    ppr.service_id,
    ppr.region_id,
    is_agency.val     is_agency,
    is_contract.val is_contract,
    ppr.pay_policy_part_id
  FROM (
       SELECT
         service_id,
         region_id,
         is_agency,
         is_contract,
         pay_policy_part_id,
         dense_rank()
           OVER (PARTITION BY service_id, region_id ORDER BY priority) rnk
       FROM (
         SELECT
           ppr.service_id,
           ppr.region_id,
           ppr.is_agency,
           ppr.is_contract,
           ppr.pay_policy_part_id,
           1 priority
         FROM bo.t_pay_policy_routing ppr
         WHERE ppr.service_id IS NOT NULL
               AND ppr.region_id IS NOT NULL

         UNION ALL

         SELECT
           ppr.service_id,
           cnt.region_id,
           ppr.is_agency,
           ppr.is_contract,
           ppr.pay_policy_part_id,
           2
         FROM bo.t_pay_policy_routing ppr
           CROSS JOIN bo.t_country cnt
         WHERE 1 = 1
               AND ppr.service_id IS NOT NULL
               AND ppr.region_id IS NULL

         UNION ALL

         SELECT
           s.id,
           ppr.region_id,
           ppr.is_agency,
           ppr.is_contract,
           ppr.pay_policy_part_id,
           3
         FROM bo.t_pay_policy_routing ppr
           CROSS JOIN bo.t_service s
         WHERE 1 = 1
               AND ppr.service_id IS NULL
               AND ppr.region_id IS NOT NULL

         UNION ALL

         SELECT
           s.id,
           cnt.region_id,
           ppr.is_agency,
           ppr.is_contract,
           ppr.pay_policy_part_id,
           4
         FROM bo.t_pay_policy_routing ppr
           CROSS JOIN bo.t_service s
           CROSS JOIN bo.t_country cnt
         WHERE 1 = 1
               AND ppr.service_id IS NULL
               AND ppr.region_id IS NULL
       )
     ) ppr
    JOIN (
      SELECT 1 val FROM dual
      UNION ALL
      SELECT 0 FROM dual
    ) is_agency ON (ppr.is_agency IS NULL OR ppr.is_agency = is_agency.val)
    JOIN (
      SELECT 1 val FROM dual
      UNION ALL
      SELECT 0 FROM dual
    ) is_contract ON (ppr.is_contract IS NULL OR ppr.is_contract = is_contract.val)
  WHERE rnk = 1;
