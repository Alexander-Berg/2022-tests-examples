--liquibase formatted sql

--changeset quark:BALANCE-24421 stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW bo.v_tax_policy AS
SELECT tp.id tax_policy_id,
	tpp.id tax_policy_pct_id,
	tp.region_id,
	tp.resident,
	tpp.dt start_dt,
	tpp.end_dt,
	tpp.nds_pct,
	tpp.nsp_pct,
	tp.default_tax,
	tp.NAME || ' c ' || tpp.dt NAME,
  tpp.row_number,
  tpp.row_number_desc
FROM bo.t_tax_policy tp
INNER JOIN (
	SELECT CASE
			WHEN LAG(tpp.dt) OVER (
					PARTITION BY tpp.tax_policy_id ORDER BY tpp.dt
					) IS NULL
				THEN DATE '1970-1-1'
			ELSE tpp.dt
			END dt,
		nvl(LEAD(tpp.dt) OVER (
				PARTITION BY tpp.tax_policy_id ORDER BY tpp.dt
				), DATE '3000-1-1') end_dt,
		tpp.tax_policy_id,
		tpp.nds_pct,
		tpp.nsp_pct,
		tpp.id,
    row_number() OVER (PARTITION BY tpp.tax_policy_id ORDER BY tpp.dt) row_number,
    row_number() OVER (PARTITION BY tpp.tax_policy_id ORDER BY tpp.dt desc) row_number_desc
	FROM BO.t_tax_policy_pct tpp
	WHERE hidden = 0
	) tpp ON tpp.tax_policy_id = tp.id
WHERE tp.hidden = 0
ORDER BY
	tp.default_tax DESC,
	tp.resident DESC,
	tp.region_id,
	tpp.dt

\\
