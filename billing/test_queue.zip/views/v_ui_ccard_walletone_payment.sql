--liquibase formatted sql

--changeset srg91:TRUST-2097 stripComments:false endDelimiter:/

create or replace view bo.v_ui_ccard_walletone_payment as
select
  p.invoice_id,
  i.external_id invoice_eid,
  i.client_id,
  cl.name client,
  p.dt create_dt,
  p.payment_dt,
  pr.register_dt,
  p.cancel_dt,
  p.id payment_id,
  p.amount,
  p.service_id,
  p.creator_uid,
  pass.login creator_login,
  p.currency,
  p.register_id,
  p.resp_dt,
  p.resp_code,
  p.resp_desc,
  pp.external_account_id card_number,
  substr(pp.external_account_id, -4) card_suffix
from bo.t_payment p
join bo.t_paymaster_payment pp on p.id = pp.id
left outer join bo.t_payment_register pr on p.register_id  = pr.id
left outer join bo.t_invoice i on p.invoice_id = i.id
left outer join bo.t_client cl on i.client_id = cl.id
left outer join bo.t_passport pass on p.creator_uid = pass.passport_id
where 1=1
  and p.paysys_code like 'WALLETONE%'

/