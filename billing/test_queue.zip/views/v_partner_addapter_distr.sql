--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114 stripComments:false endDelimiter:\\

create or replace view bo.v_partner_addapter_distr as
with v_partner_addapter_distr_pre as (
    select
        adstat.dt                                as dt,
        dcp.id                                   as contract_id,
        dcp.client_id,
        dcp.place_id,
        dcp.url,
        adstat.page_id,
        dcp.search_id                            as clid,
        nvl(adstat.money, 0)                     as money,
        decode(
            dcp.iso_currency,
            'RUB', 1,
            (
                select rate_to/rate_from
                from bo.mv_iso_currency_rate icr
                where
                    icr.rate_src = 'cbr'
                    and icr.iso_currency_from = dcp.iso_currency
                    and icr.iso_currency_to = 'RUB'
                    and adstat.dt >= icr.from_dt
                    and adstat.dt < icr.to_dt
            )
        )                                        as currency_rate,
        nds.nds_pct                              as nds,
        adstat.installs,
        adstat.linked_clid,
        dcp.currency,
        dcp.iso_currency,
        pd."DESC"                                as description,
        pd.type_id,
        dcp.tag_id
    from
        bo.mv_distr_contract_places dcp,
        bo.t_place_products pp,
        bo.t_page_data pd,
        bo.t_partner_addapter_stat adstat,
        bo.v_nds_pct nds
    where
        dcp.contract_type in (3, 4)
        and (
            (dcp.uni_has_addapter_ret = 1 and dcp.product_id = 4009)
            or (dcp.uni_has_addapter_dev = 1 and dcp.product_id = 4011)
        )
        and pp.place_id = dcp.place_id
        and pd.page_id = pp.page_id
        and dcp.dt <= adstat.dt
        and adstat.dt <= nvl(dcp.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
        and adstat.page_id = pp.page_id
        and adstat.clid = dcp.search_id
        and (nds.ndsreal_id = dcp.nds and
             adstat.dt >= nds.from_dt and
             adstat.dt < nds.to_dt)
)
select
    dt,
    contract_id,
    page_id                                    as product_id,
    client_id,
    place_id,
    url,
    page_id,
    clid,
    (money / currency_rate)                    as money_wo_nds,
    (money / currency_rate) * (1 + nds * 0.01) as money_w_nds,
    nds,
    installs,
    linked_clid,
    currency,
    iso_currency,
    description,
    type_id,
    tag_id
from
    v_partner_addapter_distr_pre
\\
