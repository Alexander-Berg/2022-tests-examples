--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114 stripComments:false endDelimiter:\\

create or replace view bo.v_distr_serphits as
with v_serphits_transit_data as (
    select
        pcb.dt,
        dcp.place_id,
        dcp.url,
        pcb.page_id,
        pcb.hits hits,
        prod.price,
        prod.price_iso_currency                  as price_iso_currency,
        case
            when prod.price_iso_currency is not null
            then (
                select cm.rate_src
                from
                    bo.t_currency_matching cm
                where
                    cm.trade_with_iso_currency = dcp.iso_currency
                    and cm.base_iso_currency = prod.price_iso_currency
            )
        end                                      as rate_src,
        dcp.id                                   as contract_id,
        pcb.completion_type,
        case
            when pd.tailable = 1
                then dcp.end_dt
            else dcp.tailless_end_dt
        end                                      as contract_end_dt,
        dcp.external_id,
        dcp.client_id,
        dcp.test_mode,
        dcp.currency,
        dcp.iso_currency,
        nds.nds_pct                              as nds,
        dcp.internal_type,
        pd."DESC"                                as description,
        pd.type_id,
        dcp.tag_id                               as place_tag_id
    from
        bo.mv_distr_contract_places dcp,
        bo.t_page_data pd,
        bo.mv_dist_contract_download_prod prod,
        bo.t_partner_completion_buffer pcb,
        bo.v_nds_pct nds
    where
        dcp.id = prod.contract_id(+)
        and dcp.product_id = 100005
        and pd.page_id = dcp.product_id
        and pd.contract_type = 'DISTRIBUTION'
        and prod.page_id = pd.page_id
        and pcb.page_id = dcp.product_id
        and dcp.dt <= pcb.dt
        and pcb.place_id = dcp.search_id
        and pcb.dt <= nvl(
            decode(pd.tailable, 1, dcp.end_dt, dcp.tailless_end_dt),
            pcb.dt + 1
        )
        and (
            pcb.dt >= prod.dt
            and pcb.dt <= nvl(prod.end_dt, pcb.dt + 1)
        )
        and (nds.ndsreal_id = dcp.nds and
             pcb.dt >= nds.from_dt and
             pcb.dt < nds.to_dt)
),
v_serphits_rewards as (
    select
        std.*,
        nvl(
            case
                when std.rate_src is not null
                    then (
                        select rate_to/rate_from
                        from bo.mv_iso_currency_rate icr
                        where
                            icr.rate_src = std.rate_src
                            and icr.iso_currency_from = std.iso_currency
                            and icr.iso_currency_to = std.price_iso_currency
                            and std.dt >= icr.from_dt
                            and std.dt < icr.to_dt
                    )
            end,
            1
        )                                        as rate
    from
        v_serphits_transit_data std
)
select
    dt,
    place_id,
    url,
    page_id,
    hits,
    hits / 1000 * price / rate                    as partner_reward_wo_nds,
    hits / 1000 * price / rate * (1 + nds * 0.01) as partner_reward,
    price,
    contract_id,
    completion_type,
    contract_end_dt,
    external_id,
    client_id,
    test_mode,
    upper(currency)                               as currency,
    iso_currency,
    nds,
    internal_type,
    description,
    type_id,
    place_tag_id
from
    v_serphits_rewards sr
\\
