--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114 stripComments:false endDelimiter:\\

create or replace view bo.v_partner_addapter_comm as
with v_partner_addapter_comm_pre as (
    select
        adstat.dt,
        p.contract_id,
        p.client_id,
        p.product_id,
        p.service_id,
        adstat.page_id,
        p.search_id                              as clid,
        nvl(adstat.money, 0)                     as money,
        decode(
            p.iso_currency,
            'RUB', 1,
            (
                select rate_to/rate_from
                from bo.mv_iso_currency_rate icr
                where
                    icr.rate_src = 'cbr'
                    and icr.iso_currency_from = p.iso_currency
                    and icr.iso_currency_to = 'RUB'
                    and adstat.dt >= icr.from_dt
                    and adstat.dt < icr.to_dt
            )
        )                                        as currency_rate,
        nds.nds_pct                              as nds,
        adstat.installs                          as installs,
        adstat.linked_clid                       as linked_clid,
        p.currency,
        p.iso_currency
    from
        bo.mv_addapter_comm_places p,
        bo.t_partner_addapter_stat adstat,
        bo.v_nds_pct nds
    where
        p.dt <= adstat.dt
        and adstat.dt <= nvl(p.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
        and adstat.clid = p.search_id
        and adstat.page_id = p.product_id
        and (nds.ndsreal_id = p.nds and
             adstat.dt >= nds.from_dt and
             adstat.dt < nds.to_dt)
)
select
    dt,
    contract_id,
    page_id                                    as product_id,
    service_id,
    client_id,
    page_id,
    clid,
    (money / currency_rate)                    as money_wo_nds,
    (money / currency_rate) * (1 + nds * 0.01) as money_w_nds,
    installs,
    linked_clid,
    currency,
    iso_currency
from
    v_partner_addapter_comm_pre
\\
