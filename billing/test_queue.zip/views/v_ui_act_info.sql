--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW V_UI_ACT_INFO AS
select
  a.id,
  a.external_id,
  a.dt,
  a.invoice_id,
  i.external_id invoice_eid,
  a.client_id,
  c.name client_name,
  i.request_id,
  i.total_sum total_sum,
  i.receipt_sum_1c,
  i.currency,
  i.iso_currency,
  a.factura
from
t_act a,
t_client c,
t_invoice i
where
a.client_id = c.id and
i.id = a.invoice_id

\\
