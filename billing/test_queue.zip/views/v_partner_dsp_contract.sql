--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114-2 stripComments:false endDelimiter:\\

create or replace view bo.v_partner_dsp_contract as
select
    c.id                                         as contract_id,
    c.client_id                                  as client_id,
    cur.char_code                                as currency,
    ca3.value_str                                as iso_currency,
    ca4.value_num                                as firm_id,
    col0.dt                                      as start_dt,
    ca7.value_dt                                 as finish_dt,
    p.type                                       as person_type,
    decode(pc.resident, 1, 0, 1) non_resident,
    case
        when pc.resident = 0
            then 0
        when pc.resident = 1 and ca4.value_num = 1
            then 18
        when pc.resident = 1 and ca4.value_num = 7
            then 8
    end                                          as nds_pct,
    ca8.value_num                                as service_min_cost,
    ca9.value_num                                as test_period_duration
from
    bo.t_contract2 c
    join bo.t_person p on p.id = c.person_id
    join bo.t_person_category pc on p.type=pc.category
    join bo.t_contract_collateral col0 on
        c.id = col0.contract2_id
        and col0.num is null
        and col0.collateral_type_id is null
        and col0.is_cancelled is null
        and (
            col0.is_signed is not null
            or col0.is_faxed is not null
        )
    join bo.v_contract_signed_attr ca2 on
        c.id = ca2.contract_id
        and ca2.code = 'SERVICES'
        and ca2.key_num = 80
        and ca2.value_num = 1
    join bo.v_contract_signed_attr ca3 on
        c.id = ca3.contract_id
        and ca3.code = 'CURRENCY'
    left join bo.t_currency cur on ca3.value_num = cur.num_code
    left outer join bo.v_contract_signed_attr ca4 on
        c.id = ca4.contract_id
        and ca4.code = 'FIRM'
    left outer join bo.v_contract_signed_attr ca7 on
        c.id = ca7.contract_id
        and ca7.code = 'FINISH_DT'
    left join bo.v_contract_signed_attr ca8 on
        c.id = ca8.contract_id
        and ca8.code = 'SERVICE_MIN_COST'
    left join bo.v_contract_signed_attr ca9 on
        c.id = ca9.contract_id
        and ca9.code = 'TEST_PERIOD_DURATION'
where
    c.type = 'GENERAL'
\\
