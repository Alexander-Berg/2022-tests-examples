--liquibase formatted sql

--changeset akatovda:BALANCE-30597--service-xmlrpc-permission endDelimiter:\\

CREATE OR REPLACE FORCE VIEW "BO"."V_SERVICE_XMLRPC_METHOD" ("ABC_ID", "METHOD_NAME", "NAMESPACE")
AS
  SELECT
      p.abc_id abc_id,
      mg.method_name method_name,
      mg.namespace namespace
  FROM BO.T_SERVICE_XMLRPC_METHODS_GROUP mg
      JOIN BO.T_SERVICE_XMLRPC_PERMISSION p ON mg.GROUP_ID = p.GROUP_ID
\\
