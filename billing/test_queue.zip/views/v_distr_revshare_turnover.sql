--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30427 stripComments:false endDelimiter:\\

create or replace view bo.v_distr_revshare_turnover as
with v_partner_turnover_expense as (
    select
        service_id,
        start_dt,
        nvl(
            lead (start_dt - 1)
            over (partition by service_id
                  order by start_dt),
            sysdate + 365
        )                                       as end_dt,
        pct
    from bo.t_partner_turnover_expense
)
select --+ NOPARALLEL
    pcb.dt,
    dcp.place_id,
    dcp.url,
    (pcb.bucks / 1000000) * 30                  as turnover_gross,
    pcb.clicks,
    pcb.clicksa,
    case when dcp.product_id = 10004
      then pcb.orders
      else pcb.shows
    end                                         as shows,
    pcb.bucks / 1000000                         as bucks,
    pcb.bucks_rs / 1000000                      as bucks_rs,
    dcrp.partner_pct,
    dcp.id contract_id,
    dcp.contract_end_dt,
    dcp.client_id,
    dcp.external_id,
    dcp.test_mode,
    nds.nds_pct                                 as nds,
    dp.place_id tag_id,
    dcp.avg_discount_pct,
    decode(
        dcp.reward_type,
        2, (
            select pct
            from v_partner_turnover_expense exp
            where
                exp.service_id = pd.service_id
                and exp.start_dt <= pcb.dt
                and exp.end_dt >= pcb.dt
        ),
        0
    )                                           as expense_pct,
    dcp.internal_type,
    case
        when dcp.currency_calculation = 1
            then dcp.currency
        else 'RUR'
    end                                         as currency,
    case
        when dcp.currency_calculation = 1
            then dcp.iso_currency
        else 'RUB'
    end                                         as iso_currency,
    nvl(
        decode(
            dcp.iso_currency,
            'RUB', 1,
            (
                select rate_to/rate_from
                from
                    bo.mv_iso_currency_rate icr,
                    bo.t_currency_matching cm
                where
                    icr.rate_src = cm.rate_src
                    and icr.iso_currency_from = cm.trade_with_iso_currency
                    and icr.iso_currency_to = cm.base_iso_currency
                    and icr.iso_currency_from = dcp.iso_currency
                    and icr.iso_currency_to = 'RUB'
                    and pcb.dt >= icr.from_dt
                    and pcb.dt < icr.to_dt
            )
        ),
        0
    )                                           as currency_rate,
    dcp.currency_calculation,
    dcp.reward_type,
    result_page_data.page_id,
    pcb.vid,
    dcp.tag_id                                  as place_tag_id,
    dcrp.scale
from
    bo.mv_distr_contract_places dcp,
    bo.t_partner_tags_stat3 pcb,
    bo.t_distribution_pages dp,
    bo.t_page_data pd,
    bo.t_page_data result_page_data,
    bo.mv_dist_contract_revshare_prod dcrp,
    bo.v_nds_pct nds
where
    (
        dcp.contract_type = 1
        or (
            dcp.contract_type in (3, 4, 6, 8)
            and dcp.uni_has_revshare = 1
        )
    )
    and dcp.product_id in (
        10000,
        10002,
        10003,
        10004,
        10007,
        10100,
        13002,
        13003
    )
    and pcb.tag_id = dcp.search_id
    and pcb.dt >= dcp.dt
    and pcb.dt <= nvl(dcp.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
    and pcb.completion_type not in (6, 7)
    and dp.place_id = pcb.place_id
    and dp.page_id = pcb.page_id
    and dp.dimension = 1
    and pd.page_id = dp.page_id
    and result_page_data.page_id = dp.result_page_id
    and result_page_data.contract_type = 'DISTRIBUTION'
    and result_page_data.page_id = dcp.product_id
    and (
        dcrp.contract_id = dcp.id
        and dcrp.page_id = result_page_data.page_id
        and pcb.dt >= dcrp.dt
        and pcb.dt <= nvl(dcrp.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
    )
    and (nds.ndsreal_id = dcp.nds   and
         pcb.dt >= nds.from_dt and
         pcb.dt < nds.to_dt)
\\
