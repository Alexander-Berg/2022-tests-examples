--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_PARTNER_CONTRACT_COMPLETION2
--------------------------------------------------------------------------------

create or replace view BO.V_PARTNER_CONTRACT_COMPLETION2 as
SELECT
    pcp.firm_id,
    pcb.place_id,
    pcp.client_id owner_id,
    pcp.id partner_contract_eid,
    pd.page_id,
    pcb.clicks,
    pcb.shows,
    pcb.bucks,
    pcb.completion_type,
    pcb.dt,
    NVL(pcb.hits,0) hits,
    pd."DESC" description,
    p.url domain,
    pcp.id partner_contract_id,
    DECODE(pd.page_id, 2060, pcp.bm_market_pct, 2070, pcp.market_api_pct, 854, pcp.bm_direct_pct, pcp.partner_pct) commission_pct,
    pcp.AGREGATOR_PCT aggregator_pct,
    pcp.contract_end_dt contract_end_dt,
    pcp.nds,
    CASE
      WHEN pd.type_id=1
      THEN
        (
          SELECT
            q.price
          FROM
            bo.mv_partner_mkb_price q
          WHERE
            q.place_id     =plo.place_id
          AND q.contract_id=pcp.id
        )
      WHEN pd.type_id=2
      THEN pd.rur_click_price
      ELSE NULL
    END price,
    pd.type_id,
    CASE
      WHEN pd.type_id=6
      THEN pcb.bucks*30
      WHEN pd.type_id=1
      THEN
        (
          SELECT
            q.price
          FROM
            bo.mv_partner_mkb_price q
          WHERE
            q.place_id     = plo.place_id
          AND q.contract_id=pcp.id
        )
        *1.18*pcb.shows/1000
      WHEN pd.type_id=2
      THEN pd.rur_click_price                                                *pcb.clicks/0.45*(pcp.partner_pct*0.01)
      ELSE pcb.bucks                                                         *NVL(DECODE(pd.page_id, 2060, pcp.bm_market_pct,
        2070, pcp.market_api_pct, 854, pcp.bm_direct_pct, pcp.partner_pct),0)*
        0.01                                                                 *
        30
    END partner_reward,
    CASE
      WHEN pd.type_id=4
      THEN pcb.bucks*30
      WHEN pd.type_id=2
      THEN pd.rur_click_price*pcb.clicks/0.45
      ELSE NULL
    END turnover_with_nds,
    CASE
      WHEN pd.type_id=4
      THEN pcb.bucks*30
      WHEN pd.type_id=2
      THEN pd.rur_click_price*pcb.clicks/0.45
        -- shit method for calc mkb turnover
      WHEN pd.type_id=1
      THEN 885*pcb.shows/1000
      ELSE 0
    END turnover_with_nds_stat,
    CASE
      WHEN pd.type_id=2
      THEN pcb.clicks       *pd.rur_click_price/(pcp.partner_pct*0.01)*(NVL(
        pcp.agregator_pct,0)*0.01)
      ELSE pcb.bucks        *NVL(pcp.agregator_pct,0)*0.01*30
    END aggregator_reward,
    p.type place_type,
    CASE
      WHEN c.partner_type IN(2,3)
      THEN (
        select tav.value_str
        from bo.t_attribute_values tav
        where
          tav.ATTRIBUTE_BATCH_ID = person.ATTRIBUTE_BATCH_ID
          and tav.CODE = 'LONGNAME'
      )
      ELSE NULL
    END aggregator_name,
    pcp.person_id
  FROM
    bo.t_partner_completion_buffer pcb,
    bo.t_page_data pd,
    bo.mv_partner_contract_puttee pcp,
    bo.mv_partner_place_owners plo,
    bo.t_mkb_category mc,
    bo.t_place p,
    bo.t_person person,
    bo.t_client c
  WHERE
    pd.page_id NOT IN (632, 643, 2060, 854)
  AND pcb.page_id   =pd.page_id
  AND pcb.dt       >= plo.start_dt
  AND pcb.dt       <= NVL(plo.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
  AND pcp.client_id =plo.billing_client_id
  AND pcb.place_id  = plo.place_id
  AND pcb.dt       >=pcp.dt
  AND pcb.dt       <=NVL(pcp.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
  AND mc.ID(+)     =p.mkb_category_id
  AND p.id         =plo.place_id
  AND pcp.client_id=c.id
  AND person.id    =pcp.person_id
;