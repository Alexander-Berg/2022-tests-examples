--liquibase formatted sql

--changeset lightrevan:BALANCE-21037 stripComments:false

/*
Вьюшка позволяет найти налог для продукта по дате, стране офиса и резидентности плательщика

Пример запроса:

SELECT tax_id,
	nds_pct,
	nsp_pct,
	tax_policy_pct_id
FROM bo.v_product_tax
WHERE product_id = 1475
	AND start_dt <= sysdate
	AND end_dt > sysdate
	AND region_id = 225
	AND resident = 1;

*/

CREATE OR REPLACE VIEW bo.v_product_tax AS
WITH
  taxes AS (
    SELECT
      t.id,
      t.product_id,
      t.dt,
      nvl(
        lead(t.dt, 1)
          OVER (PARTITION BY t.product_id, tp.region_id, tp.resident ORDER BY t.dt, t.update_dt, t.id),
        DATE '3000-01-01'
      ) end_dt,
      t.tax_policy_id,
      tp.region_id,
      tp.resident,
      tp.default_tax
    FROM bo.t_tax t
      JOIN bo.t_tax_policy tp ON t.tax_policy_id = tp.id
    WHERE t.hidden = 0
      AND tp.hidden = 0
  ),
  policy_pct AS (
    SELECT
      id,
      tax_policy_id,
      dt,
      nvl(
        lead(dt)
          OVER (PARTITION BY tax_policy_id ORDER BY dt),
        DATE '3000-01-01'
      ) end_dt,
      nds_pct,
      nsp_pct
    FROM bo.t_tax_policy_pct
    WHERE hidden = 0
  )
SELECT
  t.id tax_id,
  t.product_id,
  t.region_id,
  t.resident,
  t.default_tax,
  greatest(t.dt, tpp.dt) start_dt,
  least(t.end_dt, tpp.end_dt) end_dt,
  tpp.nds_pct,
  tpp.nsp_pct,
  t.tax_policy_id,
  tpp.id tax_policy_pct_id
FROM taxes t
  JOIN policy_pct tpp ON t.tax_policy_id = tpp.tax_policy_id
WHERE greatest(t.dt, tpp.dt) < least(t.end_dt, tpp.end_dt)
;
