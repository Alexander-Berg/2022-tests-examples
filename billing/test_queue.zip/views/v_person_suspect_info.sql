--liquibase formatted sql

--changeset lightrevan:BALANCE-26499 stripComments:false
CREATE OR REPLACE VIEW bo.v_person_suspect_info AS
SELECT
  p.id person_id,
  p.type,
  case
    when (
      select count(*) from bo.T_INVOICE i
      where i.PERSON_ID = p.id
        and ROWNUM < 3
    ) = 1 then 1
    else 0
  end has_single_invoice,
  case
    when exists(
        select 1 from bo.T_INVOICE i
          join bo.T_PERSON p_ on i.PERSON_ID = p_.id
          join bo.T_PERSON_CATEGORY pc_ on p_.TYPE = pc_.CATEGORY
          join bo.t_paysys ps on i.PAYSYS_ID = ps.id
        where 1=1
          and i.CLIENT_ID = p.CLIENT_ID
          and pc_.ur = pc.ur
          and i.hidden = 0
          and i.status_id != 5
          and i.credit = 0
          and ps.cc not in ('co', 'ce')
          and ps.EXTERN != 0
          and i.RECEIPT_DT_1C is null
          and not exists (
            select 1 from bo.T_PAYMENT pm
            where 1=1
              and pm.INVOICE_ID = i.id
              and pm.PAYMENT_DT is NOT NULL
              and pm.CANCEL_DT is NULL
          )
          and i.CONSUME_SUM > 0
          and trunc(i.RECEIPT_DT) <= bo.sf_add_working_days(trunc(sysdate), case when pc.ur = 1 then -conf.ur_delay else -conf.nonur_delay end)
    ) then 1
    else 0
  end has_manual_unpaid_by_client,
  case
    when exists(
        select 1 from bo.T_INVOICE i
          join bo.T_PERSON p_ on i.PERSON_ID = p_.id
          join bo.T_PERSON_CATEGORY pc_ on p_.TYPE = pc_.CATEGORY
          join bo.t_paysys ps on i.PAYSYS_ID = ps.id
        where 1=1
          and i.CLIENT_ID = p.CLIENT_ID
          and pc_.ur = pc.ur
          and i.hidden = 0
          and i.status_id != 5
          and i.credit = 0
          and ps.cc not in ('co', 'ce')
          and ps.EXTERN != 0
          and (i.RECEIPT_DT_1C is not null
            or exists (
              select 1 from bo.T_PAYMENT pm
              where 1=1
                and pm.INVOICE_ID = i.id
                and pm.PAYMENT_DT is NOT NULL
                and pm.CANCEL_DT is NULL
            )
          )
          and i.CONSUME_SUM > 0
    ) then 1
    else 0
  end has_paid_by_client,
  case
    when exists(
        select 1 from bo.T_INVOICE i
          join bo.t_paysys ps on i.PAYSYS_ID = ps.id
        where 1=1
          and i.PERSON_ID = p.id
          and i.hidden = 0
          and i.status_id != 5
          and i.credit = 0
          and ps.cc not in ('co', 'ce')
          and ps.EXTERN != 0
          and i.RECEIPT_DT_1C is null
          and not exists (
            select 1 from bo.T_PAYMENT pm
            where 1=1
              and pm.INVOICE_ID = i.id
              and pm.PAYMENT_DT is NOT NULL
              and pm.CANCEL_DT is NULL
          )
    ) then 1
    else 0
  end has_unpaid,
  case
    when exists(
        select 1 from bo.T_INVOICE i
          join bo.t_paysys ps on i.PAYSYS_ID = ps.id
        where i.PERSON_ID = p.id
          and i.hidden = 0
          and i.status_id != 5
          and i.credit = 0
          and ps.cc not in ('co', 'ce')
          and ps.EXTERN != 0
          and (i.RECEIPT_DT_1C is not null
            or exists (
              select 1 from bo.T_PAYMENT pm
              where 1=1
                and pm.INVOICE_ID = i.id
                and pm.PAYMENT_DT is NOT NULL
                and pm.CANCEL_DT is NULL
            )
          )
          and i.CONSUME_SUM > 0
    ) then 1
    else 0
  end has_paid
from (
    select
      max(decode(item, 'INVOICE_SUSPECT_UR_RECEIPT_DELAY', VALUE_NUM, 0)) ur_delay,
      max(decode(item, 'INVOICE_SUSPECT_NONUR_RECEIPT_DELAY', VALUE_NUM, 0)) nonur_delay
    from bo.T_CONFIG
    where item in ('INVOICE_SUSPECT_UR_RECEIPT_DELAY', 'INVOICE_SUSPECT_NONUR_RECEIPT_DELAY')
  ) conf
  cross join bo.T_PERSON p
  join bo.t_person_category pc on p.type = pc.category
;
