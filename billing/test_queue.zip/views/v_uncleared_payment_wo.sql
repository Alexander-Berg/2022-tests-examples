--liquibase formatted sql

--changeset quark:BALANCE-25118 stripComments:false endDelimiter:/

create or replace force view bo.v_uncleared_payment_wo
  (count) as
select count(*)
from bo.t_payment p
join bo.t_paymaster_payment pp
  on pp.id = p.id
where 1=1
  and p.paysys_code like 'WALLETONE_%'
  and p.payment_dt is not null
  and p.payment_dt < sysdate - 6
  and p.payment_dt > sysdate - 14
  and p.cancel_dt is null
  and pp.fraud_dt is null
  and pp.postauth_dt is null

/
