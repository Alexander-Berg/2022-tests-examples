--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace view bo.v_allowed_currencies as
select
    cm.id,
    ic1.num_code                                              as base_cc_num,
    ic1.alpha_code                                            as base_cc_char,
    nvl(et1.value, ic1.name || ' (' || ic1.alpha_code || ')') as base_cc_name,
    ic2.num_code                                              as cc_num,
    ic2.alpha_code                                            as cc_char,
    nvl(et2.value, ic2.name || ' (' || ic2.alpha_code || ')') as cc_name,
    cm.rate_src_id,
    cm.rate_src
from
    bo.t_currency_matching cm,
    bo.t_iso_currency      ic1,
    bo.t_iso_currency      ic2,
    bo.t_enums_tree        et1,
    bo.t_enums_tree        et2

where
    ic1.alpha_code = cm.base_iso_currency
    and ic2.alpha_code = cm.trade_with_iso_currency
    and et1.code (+) = to_char(ic1.num_code)
    and et2.code (+) = to_char(ic2.num_code)
order by
    cm.id
\\
