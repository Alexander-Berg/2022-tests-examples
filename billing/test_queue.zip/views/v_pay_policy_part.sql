--liquibase formatted sql

--changeset lightrevan:BALANCE-27778-vppp stripComments:false

CREATE OR REPLACE VIEW bo.v_pay_policy_part AS
  SELECT
    ppp.id,
    ppp.firm_id,
    le.val legal_entity,
    ppp.category,
    ppp.is_atypical,
    ppp.description
  FROM bo.t_pay_policy_part ppp
    JOIN (
      SELECT 1 val FROM dual
      UNION ALL
      SELECT 0 val FROM dual
    ) le ON (ppp.legal_entity IS NULL OR ppp.legal_entity = le.val)
;
