--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114 endDelimiter:\\
create or replace view bo.v_partner_dsp_completion as
with cl_dsp as (
        select /* + MATERIALIZE */
            client_id, dsp_id
        from
            bo.t_client_dsp
        union all
        select distinct client_id, client_id from bo.mv_partner_dsp_contract
)
select
    dc.contract_id,
    dc.client_id,
    dc.currency,
    dc.iso_currency,
    dc.firm_id,
    dc.start_dt,
    dc.finish_dt,
    dc.person_type,
    dc.non_resident,
    nds.nds_pct,
    ds.shows,
    ds.hits,
    ds.dsp_id,
    ds.dt,
    case when dc.currency = 'RUR' then ds.dsp_charge
    else ds.dsp_charge/(
        select
            rate
        from
            bo.t_currency_rate_v2
        where
            cc = dc.currency
            and rate_src_id = 1000
            and base_cc = 'RUR'
            and rate_dt = ds.dt
    )
    end dsp_charge_wo_nds,
    ds.dsp_charge dsp_charge_rur_wo_nds,
    ds.place_id
from
    bo.t_partner_dsp_stat ds,
    bo.mv_partner_dsp_contract dc,
    cl_dsp,
    bo.v_nds_pct nds
where
    ds.dt >= dc.start_dt and
    ds.dt < nvl(dc.finish_dt, trunc(sysdate)) and
    ds.dsp_id = cl_dsp.dsp_id and
    dc.client_id = cl_dsp.client_id
    and (nds.ndsreal_id = dc.nds_pct and
             ds.dt >= nds.from_dt and
             ds.dt < nds.to_dt)

\\
