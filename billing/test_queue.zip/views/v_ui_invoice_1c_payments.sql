--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

create or replace view v_ui_invoice_1c_payments as
select
    i.ID invoice_id,
    i.external_id invoice_eid,
    i.currency,
    i.iso_currency,
    v.SUM doc_sum,
    v.dt,
    v.doc_date,
    v.payment_date,
    v.payment_number,
    v.source_type,
    j.id src_invoice_id,
    j.external_id  src_invoice_eid,
    v.creation_date
from bo.v_oebs_receipts v
    join bo.t_invoice i on v.invoice_eid = i.external_id
    left outer join bo.t_invoice j on v.source_type = j.external_id
where i.extern = 0

\\
