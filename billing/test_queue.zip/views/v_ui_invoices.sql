--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 runOnChange:true stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW BO.V_UI_INVOICES AS
select
        i.id invoice_id,
        i.external_id invoice_eid, --Номер счета
        i.external_id invoice_eid_exact,
        i.request_id,
        i.request_seq,
        i.dt invoice_dt, --Дата счета,

        case
          when (i.type = 'personal_account')
          then (
            select value_str
            from bo.t_extprops e_prop
            where e_prop.classname = 'PersonalAccount' and
                  e_prop.object_id = i.id and
                  attrname = 'service_code'
          )
          else null
        end as service_code,

        round(i.effective_sum, 2) effective_sum,
        i.rur_sum,
        round(i.receipt_sum, 2) receipt_sum,

        case
            when (i.overdraft=1 and sysdate-1 > i.payment_term_dt and i.consume_sum = i.total_act_sum and i.total_act_sum > 0)
            then i.total_act_sum - round((i.receipt_sum*i.internal_rate)/i.currency_rate,2)
            else i.total_sum - round((i.receipt_sum*i.internal_rate)/i.currency_rate,2)
        end as amount_to_pay,

        ( select nvl(sum(a.amount),0) from t_act a join t_bad_debt_act ba on ba.act_id=a.id where ba.our_fault=1 and i.id = a.invoice_id) bad_debt_amount,

        -- сумма OEBS с учетом Ы-счетов
        (select nvl(sum(i2.receipt_sum_1c), 0)
        from t_invoice i2
        left outer join t_invoice_repayment ir on ir.repayment_invoice_id=i2.id
        where ir.invoice_id=i.id) + round(i.receipt_sum_1c, 2) receipt_sum_1c,
        -- старый способ получения сумм OEBS
        -- round(i.receipt_sum_1c, 2) receipt_sum_1c,
        i.receipt_dt,
        case
            when i.credit = 2 -- fictive invoice
            then to_date(null)
            when p.instant = 1 -- and p.fraudable = 0 disabled. See BALANCE-10742
            then i.receipt_dt
            else i.receipt_dt_1c
        end as last_payment_dt,
        case
            when i.credit = 2 -- fictive invoice
            then 0
            when p.instant = 1 -- and p.fraudable = 0 disabled. See BALANCE-10742
            then round(i.receipt_sum, 2)
            else round(i.receipt_sum_1c, 2)
        end as payment_sum, -- Настоящая сумма оплаты
        round(i.consume_sum, 2) consume_sum,
        p.cc paysys_cc,
        p.name paysys_name,
        p.id paysys_id,
        i.firm_id,
        f.title firm_title,
        p.certificate paysys_certificate,
        i.status_id,
        t.status,
        i.passport_id,
        i.hidden,
        round(i.total_sum, 2) total_sum,
        (   select acc.gecos
            from bo.t_receipt rcp, bo.t_passport acc
            where acc.passport_id = rcp.oper_id and rcp.id =
            (   select max(rcpt.id)
                from bo.t_receipt rcpt
                where rcpt.invoice_id = i.id)
        ) manager,
        i.manager_code,
        m.name as manager_info,
        decode(i.credit, 2, 1, 0) as is_fictive,
        case
            when decode(p.instant, 0, i.receipt_sum_1c, i.receipt_sum) > 0
            then 1
            else 0
        end as receipt_status,
        i.currency, -- Валюта
        i.iso_currency, -- Валюта
        i.currency_rate, --Курс
        (select nvl(sum(i2.total_act_sum), 0)
        from t_invoice i2
        left outer join t_invoice_repayment ir on ir.repayment_invoice_id=i2.id
        where ir.invoice_id=i.id) + round(i.total_act_sum-nvl(rem.amount,0), 2) act_total_sum, -- сумма актов по ы-счетам для новых лс + сумма актов
        -- старый способ определения суммы актов
        -- round(i.total_act_sum-nvl(rem.amount,0), 2) act_total_sum,
        i.credit,
        i.overdraft,
        i.market_postpay,
        co.id as contract_id,
        co.external_id as contract_eid,
        com.value_num as contract_commission,
        i.person_id,
        p.invoice_sendable paysys_invoice_sendable,
        i.receipt_dt_1c,
        p.instant paysys_instant,
        (   select nvl(max(1), 0)
            from bo.t_invoice_template itd
            where itd.invoice_id = i.id
                and itd.deleted_dt is null
        ) is_auto_invoice,
        ai.id parent_auto_invoice_id,
        ai.external_id parent_auto_invoice_eid,
        i.fast_payment,
        i.client_id,
        i.payment_number,
        i.payment_date,
        i.payment_term_dt,
        i.postpay,
        i.type

    from
        bo.t_invoice i,
        bo.t_manager m,
        bo.t_paysys p,
        bo.t_firm f,
        bo.t_invoice_status t,
        bo.t_contract2 co,
        bo.t_invoice_template itp,
        bo.t_remainder rem,
        bo.t_invoice ai,
        bo.mv_contract_last_attr com

    where
        i.hidden in (0,1)
        and i.paysys_id = p.id
        and i.firm_id   = f.id
        and i.status_id = t.id
        and i.manager_code = m.manager_code(+)
        and i.contract_id = co.id(+)
        and i.id = rem.invoice_id(+)
        and i.parent_template_id = itp.id(+)
        and itp.invoice_id = ai.id(+)
        and com.contract_id(+) = co.ID
        and com.code(+) = 'COMMISSION'

\\
