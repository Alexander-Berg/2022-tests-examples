--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_UI_PARTNER_CONTRACT
--------------------------------------------------------------------------------

CREATE OR REPLACE VIEW "BO"."V_UI_PARTNER_CONTRACT" AS
select
    co.type                       as contract_class,
    co.id,
    co.id                         as contract_id,
    co.external_id                as contract_eid,
    f3.dt                         as dt,
    f2.value_dt                   as finish_dt,
    f13.value_num                 as currency,
    f13.value_str                 as iso_currency,
    f14.value_num                 as reward_type,
    bo.sf_nullif(f4.value_num, 0) as manager_code,
    m.name                        as manager_name,
    m.login                       as manager_login,
    m.email                       as manager_email,
    bo.sf_nullif(clients.id, 0)   as client_id,
    logins.login                  as client_login,
    clients.name                  as client_name,
    bo.sf_nullif(co.person_id, 0) as person_id,
    nvl(
      (SELECT tav1.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav1
       WHERE
         tav1.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav1.CODE = 'NAME'
      ),
      NULL
    )                             as person_name,
    nvl(
      (SELECT tav2.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav2
       WHERE
         tav2.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav2.CODE = 'INN'
      ),
      NULL
    )                             as person_inn,
    f1.value_num                  as nds_pct,
    f5.value_num                  as contract_type,
    f5.value_num                  as distribution_ctype,
    f7.value_num                  as payment_type,
    cl.is_signed                  as is_signed,
    cl.is_faxed                   as is_faxed,
    cl.is_cancelled               as is_cancelled,
    f8.value_num                  as doc_set,
    f9.value_num                  as partner_pct,
    f10.value_num                 as agregator_pct,
    nvl(f11.value_num, 1)         as firm,
    f12.value_num                 as test_mode,
    f2_1.value_dt                 as sent_dt,
    f16.value_dt                  as is_booked_dt,
    f17.value_dt                  as is_suspended,
    f15.value_num                 as tag_id,
    dist_tag.name                 as tag_name,
    f18.value_num                 as platform_type,
    f19.services,
    f20.value_num                 as is_offer
from
    bo.t_contract2 co
    left outer join bo.t_contract_collateral cl on
        cl.contract2_id = co.id
        and cl.num is null
        and cl.collateral_type_id is null
    left outer join bo.v_contract_last_attr f1 on
        f1.contract_id = co.id and f1.code = 'NDS'
    left outer join bo.v_contract_last_attr f2 on
        f2.contract_id = co.id and f2.code = 'END_DT'
    left outer join (
        select
            id,
            min(dt) as dt
        from (
            select
                co.id as id,
                cl.dt as dt
            from
                bo.t_contract2 co,
                bo.t_contract_collateral cl
            where
                cl.contract2_id = co.id
        )
        group by id
    ) f3 on f3.id = co.id
    left outer join bo.v_contract_last_attr f4 on
        f4.contract_id = co.id
        and f4.code = 'MANAGER_CODE'
    left outer join bo.v_contract_last_attr f5 on
        f5.contract_id = co.id
        and f5.code = 'CONTRACT_TYPE'
    left outer join bo.v_contract_last_attr f7 on
        f7.contract_id = co.id
        and f7.code = 'PAYMENT_TYPE'
    left outer join bo.v_contract_last_attr f8 on
        f8.contract_id = co.id
        and f8.code = 'DOC_SET'
    left outer join bo.v_contract_last_attr f9 on
        f9.contract_id = co.id
        and f9.code = 'PARTNER_PCT'
    left outer join bo.v_contract_last_attr f10 on
        f10.contract_id = co.id
        and f10.code = 'AGREGATOR_PCT'
    left outer join bo.v_contract_last_attr f11 on
        f11.contract_id = co.id
        and f11.code = 'FIRM'
    left outer join bo.v_contract_last_attr f12 on
        f12.contract_id = co.id
        and f12.code = 'TEST_MODE'
    left outer join bo.v_contract_last_attr f13 on
        f13.contract_id = co.id
        and f13.code = 'CURRENCY'
    left outer join bo.v_contract_last_attr f14 on
        f14.contract_id = co.id
        and f14.code = 'REWARD_TYPE'
    left outer join bo.v_contract_last_attr f15 on
        f15.contract_id = co.id
        and f15.code = 'DISTRIBUTION_TAG'
    left outer join bo.t_distribution_tag dist_tag on
        f15.value_num = dist_tag.id
    left outer join bo.t_manager m on m.manager_code = f4.value_num
    left outer join bo.t_person p on p.id = co.person_id
    left outer join bo.t_client clients on co.client_id = clients.ID
    left outer join bo.v_contract_last_attr f2_1 on
        f2_1.attribute_batch_id = cl.attribute_batch_id
        and f2_1.code = 'SENT_DT'
    left outer join bo.v_contract_last_attr f16 on
        f16.attribute_batch_id = cl.attribute_batch_id
        and f16.code = 'IS_BOOKED_DT'
    left outer join bo.v_contract_last_attr f17 on
        f17.attribute_batch_id = cl.attribute_batch_id
        and f17.code = 'IS_SUSPENDED'
    left outer join (
        select
            client_id,
            max(login) as login
        from bo.t_account
        group by client_id
    ) logins on
        co.client_id = logins.client_id
    left outer join bo.v_contract_last_attr f17 on
        f17.contract_id = co.id
        and f17.code = 'PARENT_CONTRACT_ID'
        and co.type = 'DISTRIBUTION'
    left outer join bo.v_contract_last_attr f18 on
        f18.attribute_batch_id = cl.attribute_batch_id
        and f18.code = 'PLATFORM_TYPE'
    left outer join (
        select
            contract_id,
            ltrim(
                extract(
                    xmlagg(xmlelement("V", ', ' || s.name)),
                    '/V/text()'
                ),
                ','
            ) as services
        from
            bo.v_contract_last_attr la
            left outer join bo.t_service s on s.id = la.key_num
        where
            code = 'SERVICES'
            and value_num = 1
        group by contract_id
    ) f19 on
        f19.contract_id = co.id
        and co.type = 'SPENDABLE'
    left outer join bo.v_contract_last_attr f20 on
        f20.attribute_batch_id = cl.attribute_batch_id
        and f20.code = 'IS_OFFER'
where
    co.type in (
        'GEOCONTEXT',
        'PARTNERS',
        'DISTRIBUTION',
        'AFISHA',
        'PREFERRED_DEAL',
        'SPENDABLE',
        'ACQUIRING'
    )
    and f17.value_num is null
;