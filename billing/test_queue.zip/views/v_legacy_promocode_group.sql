--liquibase formatted sql

--changeset lightrevan:BALANCE-28416-legacy-view stripComments:false endDelimiter:\\
CREATE OR REPLACE VIEW bo.v_legacy_promocode_group as
SELECT
  id,
  start_dt,
  end_dt,
  'LegacyPromoCodeGroup' calc_class_name,
  replace(
      '{'
      || nvl2(bonus1, '"bonus1": ' || bonus1 || ',', '')
      || nvl2(bonus2, '"bonus2": ' || bonus2 || ',', '')
      || nvl2(minimal_qty, '"minimal_qty": ' || minimal_qty || ',', '')
      || nvl2(discount_pct, '"discount_pct": ' || discount_pct || ',', '')
      || nvl2(multicurrency_bonuses, '"multicurrency_bonuses": ' || multicurrency_bonuses || ',', '')
      || nvl2(middle_dt, '"middle_dt": "' || to_char(middle_dt, 'YYYY-MM-DD HH24:MI:SS') || '",', '')
      || '}',
      ',}',
      '}'
  ) calc_params,
  service_ids,
  event_id,
  firm_id,
  reservation_days,
  ticket_id,
  new_clients_only,
  valid_until_paid,
  is_global_unique,
  need_unique_urls,
  skip_reservation_check
FROM (
  SELECT
    pc.*,
    nvl(s.service_ids, '[7, 11]') service_ids
  FROM bo.t_promo_code pc
    LEFT JOIN (
      SELECT
        object_id,
        '[' || listagg(ep.value_num, ',')
          WITHIN GROUP (ORDER BY ep.value_num) || ']' service_ids
      FROM bo.t_extprops ep
      WHERE ep.classname = 'PromoCode'
        AND ep.attrname = 'service_ids'
        AND ep.value_num IS NOT NULL
      GROUP BY object_id
    ) s ON pc.id = s.object_id
)

\\
