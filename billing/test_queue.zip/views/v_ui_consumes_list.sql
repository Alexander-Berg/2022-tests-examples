--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for view V_UI_CONSUMES_LIST
--------------------------------------------------------------------------------

--changeset el-yurchito:BALANCE-30155 endDelimiter:\\
create or replace view BO.V_UI_CONSUMES_LIST as
select /*+ RULE */
  c.id as consume_id,
  i.id as invoice_id,
  i.external_id as invoice_eid,
  i.receipt_dt,
  c.dt as consume_dt,
  p.name as paysys_name,
  o.service_id || '-' || o.service_order_id || '-' || c.seqnum as order_eid,
  o.id as order_id,
  o.service_id,
  s.cc as service_cc,
  o.service_order_id,
  o.text,
  o.unit,
  o.client_id,
  cl.name as client_name,
  c.consume_qty,
  c.consume_sum,
  c.current_qty,
  c.current_sum,
  c.completion_qty,
  c.completion_sum,
  c.act_qty,
  c.act_sum,
  c.static_discount_pct,
  c.discount_pct,
  round(sf_price_mpl3_raw(c.price, c.nds, i.nds, 1), 4) as price,
  i.nds,
  pr.name as product_name,
  s.is_auto_completion is_auto_completion
from
  bo.t_consume c,
  bo.t_order o,
  bo.t_invoice i,
  bo.t_paysys p,
  bo.v_service s,
  bo.t_client cl,
  bo.t_product pr
where
  c.parent_order_id = o.id
  and c.invoice_id = i.id
  and i.paysys_id = p.id
  and o.service_id = s.id
  and o.client_id = cl.id
  and pr.id = o.service_code
order by c.id
\\
