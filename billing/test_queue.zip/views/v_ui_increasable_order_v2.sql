--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for view V_UI_INCREASABLE_ORDER_V2
--------------------------------------------------------------------------------

--changeset el-yurchito:BALANCE-30155 endDelimiter:\\
create or replace view BO.V_UI_INCREASABLE_ORDER_V2 as
select
  "ORDER_ID",
  "CLIENT_ID",
  "ORDER_EID",
  "SERVICE_CC",
  "SERVICE_ID",
  "SERVICE_ORDER_ID",
  "CLIENT_NAME",
  "TEXT",
  "UNIT",
  "PRICE",
  "PRICE_WO_NDS",
  "TYPE_RATE",
  "PRODUCT_NAME",
  "LAST_TOUCH_DT"
from (
  select
    order_id,
    client_id,
    order_eid,
    service_cc,
    service_id,
    service_order_id,
    client_name,
    text,
    unit,
    price,
    price_wo_nds,
    type_rate,
    product_name,
    case
      when last_consume_dt > order_dt
      then last_consume_dt
      else order_dt
    end last_touch_dt
  from (
    select
      o.id order_id,
      x.client_id,
      max(o.service_id) || '-' || max(o.service_order_id) order_eid,
      max(s.cc) service_cc,
      max(o.service_id) service_id,
      max(o.service_order_id) service_order_id,
      max(c.name) client_name,
      max(o.text) text,
      max(o.unit) unit,
      round(max(nvl(p.price, 0))/30, 10) as price,
      round(max(nvl(p.price2, 0))/30, 10) as price_wo_nds,
      max(p.type_rate) type_rate,
      max(p.name) product_name,
      trunc(nvl(max(co.dt), to_date('1970-01-01', 'YYYY-MM-DD'))) last_consume_dt,
      trunc(max(o.dt)) order_dt
    from (
        select
          r.client_id,
          r.related_client_id
        from v_related_client r
        union
        select
          r.client_id_first as client_id,
          r.client_id_second as related_client_id
        from v_client_class_all r
      ) x,
      bo.t_order o,
      bo.t_consume co,
      bo.v_service s,
      bo.t_product p,
      bo.t_client c
    where
      x.related_client_id = o.client_id
      and co.parent_order_id(+) = o.id
      and o.service_id = s.id
      and o.service_code = p.id
      and o.client_id = c.id
      and s.intern = 0 and ((s.extra_pay = 1) or ((s.extra_pay = 0) and o.consume_sum = 0))
    group by x.client_id, o.id
  )
)
order by
  client_id,
  last_touch_dt desc,
  service_id desc,
  service_order_id desc
\\
