--liquibase formatted sql

--changeset lightrevan:BALANCE-27778-denorm-view-2 stripComments:false

CREATE OR REPLACE VIEW bo.v_pay_policy_csd_groups AS
  WITH
      csd AS (
        SELECT DISTINCT
          csd.service_id,
          csd.region_id,
          csd.agency,
          csd.pay_policy_id,
          pp.description pay_policy,
          ppf.category,
          pc.ur,
          pc.resident,
          pc.is_default,
          ppf.firm_id,
          f.region_id firm_region_id,
          fc.currency
        FROM bo.v_country_service_data csd
          JOIN bo.t_pay_policy pp ON csd.pay_policy_id = pp.id
          JOIN bo.t_pay_policy_firm ppf ON csd.pay_policy_id = ppf.pay_policy_id
          JOIN bo.t_firm f ON ppf.firm_id = f.id
          JOIN bo.t_person_category pc ON ppf.category = pc.category
          LEFT JOIN bo.t_firm_currency fc ON ppf.pay_policy_id = fc.pay_policy_id
    )
    , paysys AS (
      SELECT
        ps.id paysys_id,
        ps.cc paysys,
        ps.payment_method_id,
        pm.cc payment_method,
        ps.name,
        ps.currency,
        ps.firm_id,
        ps.category,
        pc.ur,
        pc.resident,
        pc.is_default,
        pc.region_id firm_region_id,
        ps.group_id paysys_group_id
      FROM bo.t_paysys ps
        JOIN bo.t_payment_method pm ON ps.payment_method_id = pm.id
        JOIN bo.t_person_category pc ON ps.category = pc.category
      WHERE ps.extern = 1
  )
    , paysys_service AS (
      SELECT DISTINCT
        ps.payment_method_id,
        ps.payment_method,
        ps.currency,
        ps.firm_id,
        ps.category,
        ps.ur,
        ps.resident,
        ps.is_default,
        ps.firm_region_id,
        ps.paysys_group_id,
        pss.service_id
      FROM paysys ps
        JOIN (
               SELECT DISTINCT
                 ps_.cc,
                 pss_.service_id
               FROM bo.t_paysys ps_
                 JOIN bo.t_paysys_service pss_ ON ps_.id = pss_.paysys_id
             ) pss ON ps.paysys = pss.cc
  )
    , csd_paysyses AS (
      SELECT DISTINCT
        csd.service_id,
        csd.region_id,
        csd.agency,
        csd.firm_id,
        csd.firm_region_id,
        csd.pay_policy_id,
        csd.pay_policy,
        csd.category,
        csd.ur,
        csd.resident,
        csd.is_default,
        pss.currency,
        pss.payment_method_id,
        pss.payment_method,
        pss.paysys_group_id
      FROM csd
        LEFT JOIN paysys_service pss
          ON csd.service_id = pss.service_id
             AND csd.firm_id = pss.firm_id
             AND csd.category = pss.category
             AND nvl(csd.currency, pss.currency) = pss.currency

      UNION ALL

      SELECT DISTINCT
        csd.service_id,
        csd.region_id,
        csd.agency,
        pss.firm_id,
        pss.firm_region_id,
        csd.pay_policy_id,
        NULL,
        pss.category,
        pss.ur,
        pss.resident,
        pss.is_default,
        pss.currency,
        pss.payment_method_id,
        pss.payment_method,
        pss.paysys_group_id
      FROM paysys_service pss
      JOIN bo.v_country_service_data csd
        ON pss.service_id = csd.service_id
        AND csd.pay_policy_id IS NULL
  )
    , pay_policy_group_raw AS (
      SELECT DISTINCT
        service_id,
        region_id,
        agency,
        firm_id,
        firm_region_id,
        ur legal_entity,
        CASE
          WHEN is_default = 0 THEN category
          WHEN pay_policy_id IS NULL THEN category
          WHEN resident != decode(region_id, firm_region_id, 1, 0) THEN category
        END category,
        nvl2(pay_policy_id, 0, 1) is_atypical,
        payment_method_id,
        payment_method,
        currency,
        paysys_group_id
      FROM csd_paysyses
  )
    , pay_policy_group AS (
      SELECT
        service_id,
        region_id,
        agency,
        firm_id,
        firm_region_id,
        legal_entity,
        category,
        is_atypical,
        payment_method_id,
        payment_method,
        currency,
        paysys_group_id,
        listagg(nvl2(PAYMENT_METHOD, payment_method || '|' || currency || '|' || paysys_group_id, null), '%')
          WITHIN GROUP (ORDER BY payment_method, currency, paysys_group_id)
          OVER (PARTITION BY service_id, region_id, agency, firm_id, legal_entity, category, is_atypical) pm_group
      FROM pay_policy_group_raw
  )
    , pay_policy_group_le AS (
      SELECT DISTINCT
        service_id,
        region_id,
        agency,
        firm_id,
        firm_region_id,
        CASE
          WHEN cnt_le > 1 THEN NULL
          ELSE legal_entity
        END legal_entity,
        category,
        is_atypical,
        payment_method_id,
        payment_method,
        currency,
        paysys_group_id,
        pm_group
      FROM (
        SELECT
          pp.*,
          count(DISTINCT legal_entity)
            OVER (PARTITION BY service_id, region_id, agency, firm_id, category, is_atypical, pm_group) cnt_le
        FROM pay_policy_group pp
      )
  )
  SELECT DISTINCT
    service_id,
    region_id,
    CASE
    WHEN cnt_ag > 1
      THEN NULL
      ELSE agency
    END agency,
    firm_id,
    firm_region_id,
    legal_entity,
    category,
    is_atypical,
    payment_method_id,
    payment_method,
    currency,
    paysys_group_id,
    pm_group
  FROM (
    SELECT
      pp.*,
      count(DISTINCT agency)
        OVER (PARTITION BY service_id, region_id, firm_id, legal_entity, category, is_atypical, pm_group) cnt_ag
    FROM pay_policy_group_le pp
  )
;
