--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for view V_UI_ORDER_INFO
--------------------------------------------------------------------------------

--changeset el-yurchito:BALANCE-30155 endDelimiter:\\
create or replace view BO.V_UI_ORDER_INFO as
SELECT
  o.id as order_id,
  o.dt as order_dt,
  o.passport_id,
  o.client_id,
  o.service_id,
  s.cc as service_cc,
  o.service_order_id,
  o.service_id || '-' || o.service_order_id as order_eid,
  o.text,
  o.unit,
  o.completion_qty,
  o.consume_qty as current_qty,
  o.completion_sum,
  o.consume_sum as current_sum,
  s.name as service_name,
  s.url_orders as service_orders_url,
  s.extra_pay,
  c.name as client_name,
  c.email as client_email,
  m.manager_code, m.name as manager_name,
  c2.id as agency_id,
  c2.name AS agency_name
FROM
  bo.t_order o,
  bo.t_client c,
  bo.v_service s,
  bo.t_manager m,
  bo.t_client c2
WHERE
  o.client_id = c.ID
  AND o.service_id = s.id
  and o.pid is null
  and o.manager_code = m.manager_code(+)
  and o.agency_id = c2.id(+)
\\
