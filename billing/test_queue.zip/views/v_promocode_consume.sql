--liquibase formatted sql

--changeset natabers:BALANCE-28045-v_promocode_consume

create or replace view bo.v_promocode_consume as
select x.parent_order_id order_id,
       x.invoice_id invoice_id,
       x.promocode_id promocode_id,
       sum(x.current_promocode_qty) current_promocode_qty,
       sum(x.completion_promocode_qty) completion_promocode_qty,
       sum(x.act_promocode_qty) act_promocode_qty,
       sum(x.available_promocode_qty) available_promocode_qty,
       sum(x.current_promocode_qty - x.completion_promocode_qty) unused_promocode_qty
	from (
		SELECT
			co.parent_order_id parent_order_id,
			i.id invoice_id,
			i.promo_code_id promocode_id,
			co.current_qty * (1 - (100 - co.DISCOUNT_PCT) / (100 - i.AGENCY_DISCOUNT_PCT)) current_promocode_qty,
			co.completion_qty * (1 - (100 - co.DISCOUNT_PCT) / (100 - i.AGENCY_DISCOUNT_PCT)) completion_promocode_qty,
			co.act_qty * (1 - (100 - co.DISCOUNT_PCT) / (100 - i.AGENCY_DISCOUNT_PCT)) act_promocode_qty,
			greatest(co.current_qty - greatest(co.completion_qty, co.act_qty), 0)
			  * (1 - (100 - co.DISCOUNT_PCT) / (100 - i.AGENCY_DISCOUNT_PCT)) available_promocode_qty
		FROM bo.t_consume co
			JOIN bo.t_invoice i ON i.id = co.invoice_id AND i.promo_code_id IS NOT NULL
		WHERE co.archive = 0 and co.current_qty > co.completion_qty
	) x
GROUP BY x.parent_order_id, x.invoice_id, x.promocode_id;
