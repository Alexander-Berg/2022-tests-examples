--liquibase formatted sql

--changeset srg91:TRUST-2569-CLIENT_HISTORY
create or replace view bo.v_client_history as
(
  select
    id client_id,
    dt start_dt,
    SYSDATE end_dt,
    client_type_id,
    NAME,
    email,
    phone,
    fax,
    url,
    is_agency,
    person_id,
    id_1c,
    internal,
    is_wholesaler,
    full_repayment,
    class_id,
    agency_id,
    oper_id,
    suspect,
    creator_uid,
    manual_suspect,
    is_aggregator,
    direct25,
    is_docs_separated,
    is_docs_detailed,
    manual_suspect_comment,
    budget,
    overdraft_limit,
    overdraft_ban,
    region_id ,
    partner_type,
    subregion_id,
    office_id,
    deny_cc
  from bo.t_client
)
union all
(
  select
    client_id,
    start_dt,
    end_dt,
    client_type_id,
    NAME,
    email,
    phone,
    fax,
    url,
    is_agency,
    person_id,
    id_1c,
    internal,
    is_wholesaler,
    full_repayment,
    class_id,
    agency_id,
    oper_id,
    suspect,
    creator_uid,
    manual_suspect,
    is_aggregator,
    direct25,
    is_docs_separated,
    is_docs_detailed,
    manual_suspect_comment,
    budget,
    overdraft_limit,
    overdraft_ban,
    region_id ,
    partner_type,
    subregion_id,
    office_id,
    deny_cc
  from bo.t_client_history_v2
)
;
