--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace view bo.v_distr_contract_download_prod as
select /*+ opt_param('_optimizer_cbqt_or_expansion' 'OFF') */
    contract_id,
    collateral_id,
    dt,
    end_dt,
    page_id,
    price,
    price_currency,
    price_iso_currency
from (
    select
        c.id                                     as contract_id,
        ca.collateral_id,
        case
            when cl.id = cl0.id and nvl(ca2.value_num, 1) not in (3, 4, 6)
                then cl.dt - 365
            when cl.id = cl0.id and nvl(ca2.value_num, 1) in (3, 4, 6)
                then nvl(ca3.value_dt,cl.dt)
            else cl.dt
        end                                      as dt,
        (
            lead(cl.dt)
            over (
                partition by c.id,
                ca.key_num order by cl.dt
            )
        ) - 1                                    as end_dt,
        ca.key_num                               as page_id,
        ca.value_num                             as price,
        ca4.value_num                            as price_currency,
        ca4.value_str                            as price_iso_currency
    from
        bo.t_contract2 c,
        bo.v_contract_signed_attr2 ca,
        bo.v_contract_signed_attr2 ca2,
        bo.v_contract_signed_attr2 ca3,
        bo.v_contract_signed_attr2 ca4,
        bo.t_contract_collateral cl,
        bo.t_contract_collateral cl0
    where
        c.id = cl0.contract2_id
        and cl0.is_cancelled is null
        and cl0.num is null
        and cl0.collateral_type_id is null
        and cl.is_cancelled is null
        and (
            cl.attribute_batch_id = ca.attribute_batch_id
            and ca.contract2_id = c.id
            and ca.code = 'PRODUCTS_DOWNLOAD'
        )
        and (
            cl0.attribute_batch_id = ca2.attribute_batch_id
            and ca2.code = 'CONTRACT_TYPE'
        )
        and (
            cl0.attribute_batch_id = ca3.attribute_batch_id (+)
            and ca3.code (+) = 'SERVICE_START_DT'
        )
        and (
            cl.attribute_batch_id  = ca4.attribute_batch_id (+)
            and ca4.code (+) = 'PRODUCTS_CURRENCY'
        )
    union all
    select
        c.id                                     as contract_id,
        ca.collateral_id,
        case
            when cl.id = cl0.id and nvl(ca2.value_num, 1) not in (3, 4, 6)
                then cl.dt - 365
            when cl.id = cl0.id and nvl(ca2.value_num, 1) in (3, 4, 6)
                then nvl(ca3.value_dt,cl.dt)
            else cl.dt
        end                                      as dt,
        (
            lead(cl.dt)
            over (
                partition by c.id,
                ca.code order by cl.dt
            )
        ) - 1                                    as end_dt,
        decode(
            ca.code,
            'INSTALL_PRICE',    10001,
            'ADVISOR_PRICE',    2080,
            'ACTIVATION_PRICE', 3010,
            100005
        )                                        as page_id,
        ca.value_num                             as price,
        ca4.value_num                            as price_currency,
        ca4.value_str                            as price_iso_currency
    from
        bo.t_contract2 c,
        bo.v_contract_signed_attr2 ca,
        bo.v_contract_signed_attr2 ca2,
        bo.v_contract_signed_attr2 ca3,
        bo.v_contract_signed_attr2 ca4,
        bo.t_contract_collateral cl,
        bo.t_contract_collateral cl0
    where
        c.id = cl0.contract2_id
        and cl0.is_cancelled is null
        and cl0.num is null
        and cl0.collateral_type_id is null
        and cl.is_cancelled is null
        and (
            cl.attribute_batch_id = ca.attribute_batch_id
            and ca.contract2_id = c.id
        )
        and (
            cl0.attribute_batch_id = ca2.attribute_batch_id
            and ca2.code = 'CONTRACT_TYPE'
        )
        and (
            (
                ca.code in (
                    'INSTALL_PRICE',
                    'ADVISOR_PRICE',
                    'ACTIVATION_PRICE'
                )
                and cl.attribute_batch_id = ca4.attribute_batch_id
                and ca4.code = 'PRODUCTS_CURRENCY'
            )
            or (
                ca.code = 'SEARCH_PRICE'
                and cl.attribute_batch_id = ca4.attribute_batch_id
                and ca4.code = 'SEARCH_CURRENCY'
            )
        )
        and (
            cl0.attribute_batch_id = ca3.attribute_batch_id (+)
            and ca3.code (+) = 'SERVICE_START_DT'
        )
)
where
    price is not null
\\
