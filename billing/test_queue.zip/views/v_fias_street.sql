--liquibase formatted sql

--changeset lightrevan:BALANCE-30229-street stripComments:false
CREATE OR REPLACE VIEW bo.v_fias_street AS
  WITH city_streets (guid, parent_guid, formal_name, short_name, parent_name, obj_level, live_status) AS (
    SELECT
      f.guid,
      f.guid parent_guid,
      f.formal_name,
      f.short_name,
      NULL parent_name,
      NULL obj_level,
      NULL live_status
    FROM bo.mv_fias_city f

    UNION ALL

    SELECT
      f.guid,
      p.parent_guid,
      f.formal_name,
      f.short_name,
      p.formal_name || ' ' || p.short_name || nvl2(p.parent_name, ', ', '') || p.parent_name parent_name,
      f.obj_level,
      f.live_status
    FROM
      city_streets p
      JOIN bo.t_fias f
           ON p.guid = f.parent_guid
    )
    SELECT
      guid,
      parent_guid,
      formal_name,
      short_name,
      cast(parent_name AS VARCHAR2(4000 CHAR)) parent_name
    FROM city_streets
    WHERE
      live_status = 1
      AND obj_level > 6
;
