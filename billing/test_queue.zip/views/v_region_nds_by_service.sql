--liquibase formatted sql

--changeset lightrevan:BALANCE-29256 stripComments:false

CREATE OR REPLACE VIEW BO.V_REGION_NDS_BY_SERVICE
/*
Вьюшка для мультивалютности. Для региона выдаёт историю ставок НДС по сервису для валютных продуктов сервиса
*/
AS
    SELECT 
        pp.region_id,
        pp.service_id,
        pp.agency,
        pp.firm_region_id,
        pp.resident,
        pp.firm_id,
        tp.id tax_policy_id,
        pct.dt,
        pct.nds_pct,
        pct.nsp_pct
    FROM 
        (
            SELECT
              csd.REGION_ID,
              csd.SERVICE_ID,
              csd.AGENCY,
              pc.REGION_ID firm_region_id,
              pc.resident,
              pc.firm_id
            FROM bo.t_config c
            JOIN BO.v_country_service_data csd ON c.item = 'COMMON_NEW_PAY_POLICY' AND c.value_num = 0
            join
            (
                select distinct pc.region_id, pc.resident, ppf.pay_policy_id, ppf.firm_id
                from bo.t_person_category pc
                join bo.t_pay_policy_firm ppf on ppf.category = pc.category and not (ppf.pay_policy_id in (701, 702, 703) and ppf.firm_id in (7))
            ) pc on pc.pay_policy_id = csd.pay_policy_id

            UNION ALL

            SELECT DISTINCT
              ppr.region_id,
              ppr.service_id,
              ppr.is_agency agency,
              f.region_id firm_region_id,
              decode(f.region_id, ppr.region_id, 1, 0) resident,
              ppp.firm_id
            FROM bo.t_config c
              JOIN bo.v_pay_policy_routing ppr ON c.item = 'COMMON_NEW_PAY_POLICY' AND c.value_num = 1
              JOIN bo.v_pay_policy_part ppp ON ppr.pay_policy_part_id = ppp.id
              JOIN bo.t_firm f ON ppp.firm_id = f.id
            WHERE ppr.is_contract = 0
              AND nvl(ppp.category, '-') != 'by_ytph' --аналог условия для пп 701/702
        ) pp
        left JOIN BO.t_tax_policy tp ON (tp.region_id = pp.firm_region_id AND tp.resident = pp.resident and tp.hidden = 0) and
        exists (
          select *
          from
              BO.t_product p
              join bo.t_tax t on p.id = t.product_id
              join BO.t_product_unit pu on p.unit_id = pu.id
          where
              (
              p.engine_id = pp.service_id and
              t.tax_policy_id = tp.id and
              t.hidden = 0 and
              pu.iso_currency is not null
              )
      ) 
      left JOIN BO.t_tax_policy_pct pct ON tp.id = pct.tax_policy_id and pct.hidden = 0
;
