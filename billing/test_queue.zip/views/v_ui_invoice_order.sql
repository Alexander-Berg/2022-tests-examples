--liquibase formatted sql

--changeset el-yurchito:BALANCE-29824 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_UI_INVOICE_ORDER" AS
  SELECT
    invoices.*,
    o.id                                      AS order_id,
    o.service_id || '-' || o.service_order_id AS order_number,    -- Номер заказа
    nvl(o.client_id, invoices.CLIENT_ID)      AS order_client_id,
    round(io.amount, 2)                       AS amount           -- Сумма заявки as Сумма заявленных услуг по заказу
  FROM
    "BO"."V_UI_INVOICES" invoices
      LEFT OUTER JOIN
    "BO"."T_INVOICE_ORDER" io
        ON invoices.INVOICE_ID = io.INVOICE_ID
      LEFT OUTER JOIN
    "BO"."T_ORDER" o
        ON io.ORDER_ID = o.ID
\\
