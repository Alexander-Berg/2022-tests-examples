--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

/*
Вьюшка позволяет найти цену продукта по дате и валюте.

Пример запроса:

select
    price_id,
    target_iso_currency,
    price,
    price_iso_currency,
    price_wo_tax
from
    bo.v_product_price
where
    product_id = 1475
    and start_dt <= sysdate
    and end_dt > sysdate
    and target_iso_currency in (
        'ZAR',
        'RUB',
        'USD'
    );

Если нет цены для валюты target_iso_currency, то подбирается подходящая цена в
другой валюте (указано в price_iso_currency), после чего нужно самостоятельно
привести цену к нужной валюте через курс на запрашиваемую дату.
*/

create or replace view bo.v_product_price as
select
    pri.id                                       as price_id,
    pri.product_id,
    pri.dt                                       as start_dt,
    nvl(
        lead(pri.dt)
        over (
            partition by pri.product_id,
            filter_iso_cur.alpha_code order by pri.dt,
            pri.update_dt desc
        ),
        date'3000-1-1'
    )                                            as end_dt,
    decode(
        filter_iso_cur.alpha_code,
        'RUB', 'RUR',
        filter_iso_cur.alpha_code
    )                                            as target_currency,
    filter_iso_cur.alpha_code                    as target_iso_currency,
    case
        when pu.iso_currency is not null
            then 1
        else
            pri.price
    end                                          as price,
    decode(
        nvl(pu.iso_currency, iso_cur.alpha_code),
        'RUB', 'RUR',
        nvl(pu.iso_currency, iso_cur.alpha_code)
    )                                            as price_currency,
    nvl(pu.iso_currency, iso_cur.alpha_code)     as price_iso_currency,
    pri.tax,
    pri.use_main_cost,
    pri.tax_policy_pct_id,
    tpp.nds_pct,
    tpp.nsp_pct,
    case
        when pu.iso_currency is not null
            then 1
        when pri.tax = 0
            then pri.price
        when tpp.nds_pct is not null and tpp.nsp_pct is not null
            then pri.price * 100 / (100 + tpp.nds_pct + tpp.nsp_pct)
        when (
            pri.tax = 1
            and iso_cur.alpha_code = pr.reference_price_iso_currency
        )
            then pri.price / 1.18
        else
            null
    end                                          as price_wo_tax,
    pu.iso_currency                              as product_iso_currency
from
    bo.t_product pr
    inner join bo.t_product_unit pu on pu.id = pr.unit_id
    left join bo.t_price pri on pr.id = pri.product_id
    left join bo.t_iso_currency iso_cur on
        iso_cur.alpha_code = pri.iso_currency
    left join bo.t_iso_currency filter_iso_cur on
        filter_iso_cur.alpha_code = iso_cur.alpha_code
        or (
            iso_cur.alpha_code = 'RUB'
            and not exists (
                select 1
                from bo.t_price p
                where
                    p.product_id = pri.product_id
                    and filter_iso_cur.alpha_code = p.iso_currency
                    and p.hidden = 0
            )
        )
    left join bo.t_tax_policy_pct tpp on
        tpp.id = pri.tax_policy_pct_id
        and pri.tax = 1
where
    pri.hidden = 0
\\
