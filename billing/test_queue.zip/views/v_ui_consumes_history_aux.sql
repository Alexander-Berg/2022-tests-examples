--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

CREATE OR REPLACE FORCE VIEW "BO"."V_UI_CONSUMES_HISTORY_AUX"
  AS
  SELECT
    cntr2.id              AS contract_id,
    inv.id                AS invoice_id,
    inv.external_id       AS invoice_eid,
    inv.credit            AS invoice_credit,
    inv.type              AS invoice_type,
    inv.dt                AS invoice_dt,
    inv.currency          AS invoice_currency,
    inv.iso_currency      AS invoice_iso_currency,
    inv.passport_id       AS passport_id,
    clt.id                AS client_id,
    op.id                 AS operation_id,
    op.dt                 AS operation_dt
  FROM
    bo.t_contract2 cntr2
    JOIN bo.t_contract_collateral cntr_col    ON cntr_col.contract2_id = cntr2.id
    JOIN bo.mv_contract_signed_attr cntr_attr ON cntr_attr.collateral_id = cntr_col.id AND cntr_attr.code = 'PERSONAL_ACCOUNT_FICTIVE' AND cntr_attr.value_num = 1
    JOIN bo.t_invoice inv   ON inv.contract_id = cntr2.id
    JOIN bo.t_client clt    ON clt.id = inv.client_id
    JOIN (
      SELECT op.invoice_id real_invoice_id, op.*
      FROM bo.t_operation op
      WHERE op.type_id = 2
      UNION ALL
      SELECT dp.invoice_id real_invoice_id, op.*
      FROM bo.t_operation op JOIN bo.t_deferpay dp ON op.id = dp.operation_id
      WHERE op.type_id = (select id from bo.t_operation_type where cc = 'deferred_pay')
  ) op ON op.real_invoice_id = inv.id

\\
