--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 endDelimiter:\\

create or replace view bo.v_distribution_contract as
select
    c.client_id,
    c.person_id,
    c.id,
    last_value(ca21.value_num ignore nulls)
    over (partition by c.id order by cl.dt)            as parent_contract_id,
    cl.dt                                              as contract_start_dt,
    case
        when cl.id = cl0.id
            then nvl(ca14.value_dt, cl.dt)
        else cl.dt
    end                                                as dt,
    c.external_id,
    last_value(mngr.passport_id ignore nulls)
    over (partition by c.id order by cl.dt)            as manager_uid,
    last_value(mngr.domain_passport_id ignore nulls)
    over (partition by c.id order by cl.dt)            as manager_internal_uid,
    cl.id                                              as collateral_id,
    cl.is_signed,
    cl.is_faxed,
    nvl(
        lead (cl.dt - 1)
        over (partition by c.id order by cl.dt),
        bo.sf_add_months(
            last_value(ca3.value_dt ignore nulls)
            over (partition by c.id order by cl.dt),
            nvl(
                last_value(ca4.value_num ignore nulls)
                over (partition by c.id order by cl.dt),
                0
            )
        )
    )                                                  as end_dt,
    nvl(
        lead (cl.dt - 1)
        over (partition by c.id order by cl.dt),
        last_value(ca3.value_dt ignore nulls)
        over (partition by c.id order by cl.dt)
    )                                                  as tailless_end_dt,
    last_value(ca1.value_num ignore nulls)
    over (partition by c.id order by cl.dt)            as nds,
    last_value(ca3.value_dt ignore nulls)
    over (partition by c.id order by cl.dt)            as contract_end_dt,
    last_value(ca4.value_num ignore nulls)
    over (partition by c.id order by cl.dt)            as tail_time,
    last_value(ca15.value_num ignore nulls)
    over (partition by c.id order by cl.dt)            as avg_discount_pct,
    ca6.value_num                                      as contract_type,
    nvl(ca5.value_num, 0)                              as test_mode,
    nvl(
        last_value(ca7.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as install_price,
    nvl(
        last_value(ca22.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as advisor_price,
    nvl(
        last_value(ca23.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as activation_price,
    nvl(
        last_value(ca24.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as search_price,
    nvl(
        last_value(ca8.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        1
    )                                                  as reward_type,
    upper(nvl(cur.char_code, cur.iso_code))            as currency,
    iso_cur.alpha_code                                 as iso_currency,
    nvl(
        last_value(ca10.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as uni_has_revshare,
    nvl(
        last_value(ca11.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as uni_has_fixed,
    nvl(
        last_value(ca12.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as uni_has_searches,
    nvl(
        last_value(ca27.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as uni_has_addapter_ret,
    nvl(
        last_value(ca28.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as uni_has_addapter_dev,
    nvl(
        last_value(ca16.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as fixed_scale_id,
    nvl(
        last_value(ca17.value_num ignore nulls)
        over (partition by c.id order by cl.dt),
        0
    )                                                  as currency_calculation,
    nvl(ca18.value_num, 0)                             as tag_id,
    last_value(ca19.value_num ignore nulls)
    over (partition by c.id order by cl.dt)            as products_currency,
    last_value(ca19.value_str ignore nulls)
    over (partition by c.id order by cl.dt)            as products_iso_currency,
    last_value(ca20.value_num ignore nulls)
    over (partition by c.id order by cl.dt)            as search_currency,
    last_value(ca20.value_str ignore nulls)
    over (partition by c.id order by cl.dt)            as search_iso_currency,
    last_value(ca25.value_num ignore nulls)
    over (partition by c.id order by cl.dt)            as platform_type,
    last_value(ca26.value_num ignore nulls)
    over (partition by c.id order by cl.dt)            as firm_id,
    last_value(ca30.value_num ignore nulls)
    over (partition by c.id order by cl.dt)            as payment_type
from
    bo.t_contract2 c
    left join bo.t_contract_collateral cl on
        cl.contract2_id = c.id
        and nvl(cl.collateral_type_id, 0) != 3040
    left join bo.t_contract_collateral cl0 on
        cl0.contract2_id = c.id
        and cl0.collateral_type_id is null
        and cl0.num is null
    left outer join bo.t_contract_attributes ca1 on
        cl.attribute_batch_id = ca1.attribute_batch_id
        and ca1.code = 'NDS'
    left outer join bo.t_contract_attributes ca3 on
        cl.attribute_batch_id = ca3.attribute_batch_id
        and ca3.code = 'END_DT'
    left outer join bo.t_contract_attributes ca4 on
        cl.attribute_batch_id = ca4.attribute_batch_id
        and ca4.code = 'TAIL_TIME'
    left outer join bo.t_contract_attributes ca5 on
        cl0.attribute_batch_id = ca5.attribute_batch_id
        and ca5.code = 'TEST_MODE'
    left outer join bo.t_contract_attributes ca6 on
        cl0.attribute_batch_id = ca6.attribute_batch_id
        and ca6.code = 'CONTRACT_TYPE'
    left outer join bo.t_contract_attributes ca7 on
        cl.attribute_batch_id = ca7.attribute_batch_id
        and ca7.code = 'INSTALL_PRICE'
    left outer join bo.t_contract_attributes ca8 on
        cl.attribute_batch_id = ca8.attribute_batch_id
        and ca8.code = 'REWARD_TYPE'
    left outer join bo.t_contract_attributes ca10 on
        cl.attribute_batch_id = ca10.attribute_batch_id
        and ca10.code = 'SUPPLEMENTS'
        and ca10.key_num = 1
        and ca10.value_num = 1
    left outer join bo.t_contract_attributes ca11 on
        cl.attribute_batch_id = ca11.attribute_batch_id
        and ca11.code = 'SUPPLEMENTS'
        and ca11.key_num = 2
        and ca11.value_num = 1
    left outer join bo.t_contract_attributes ca12 on
        cl.attribute_batch_id = ca12.attribute_batch_id
        and ca12.code = 'SUPPLEMENTS'
        and ca12.key_num = 3
        and ca12.value_num = 1
    left outer join bo.t_contract_attributes ca27 on
        cl.attribute_batch_id = ca27.attribute_batch_id
        and ca27.code = 'SUPPLEMENTS'
        and ca27.key_num = 4
        and ca27.value_num = 1
    left outer join bo.t_contract_attributes ca28 on
        cl.attribute_batch_id = ca28.attribute_batch_id
        and ca28.code = 'SUPPLEMENTS'
        and ca28.key_num = 5
        and ca28.value_num = 1
    left outer join bo.t_contract_attributes ca13 on
        cl0.attribute_batch_id = ca13.attribute_batch_id
        and ca13.code = 'CURRENCY'
    left outer join bo.t_contract_attributes ca14 on
        cl0.attribute_batch_id = ca14.attribute_batch_id
        and ca14.code = 'SERVICE_START_DT'
    left outer join bo.t_contract_attributes ca15 on
        cl.attribute_batch_id = ca15.attribute_batch_id
        and ca15.code = 'AVG_DISCOUNT_PCT'
    left outer join bo.t_contract_attributes ca16 on
        cl.attribute_batch_id = ca16.attribute_batch_id
        and ca16.code = 'FIXED_SCALE'
    left outer join bo.t_contract_attributes ca17 on
        cl.attribute_batch_id = ca17.attribute_batch_id
        and ca17.code = 'CURRENCY_CALCULATION'
    left outer join bo.t_contract_attributes ca18 on
        cl0.attribute_batch_id = ca18.attribute_batch_id
        and ca18.code = 'DISTRIBUTION_TAG'
    left outer join bo.t_contract_attributes ca19 on
        cl.attribute_batch_id = ca19.attribute_batch_id
        and ca19.code = 'PRODUCTS_CURRENCY'
    left outer join bo.t_contract_attributes ca20 on
        cl.attribute_batch_id = ca20.attribute_batch_id
        and ca20.code = 'SEARCH_CURRENCY'
    left outer join bo.t_contract_attributes ca21 on
        cl.attribute_batch_id = ca21.attribute_batch_id
        and ca21.code = 'PARENT_CONTRACT_ID'
    left outer join bo.t_contract_attributes ca22 on
        cl.attribute_batch_id = ca22.attribute_batch_id
        and ca22.code = 'ADVISOR_PRICE'
    left outer join bo.t_contract_attributes ca23 on
        cl.attribute_batch_id = ca23.attribute_batch_id
        and ca23.code = 'ACTIVATION_PRICE'
    left outer join bo.t_contract_attributes ca24 on
        cl.attribute_batch_id = ca24.attribute_batch_id
        and ca24.code = 'SEARCH_PRICE'
    left outer join bo.t_contract_attributes ca25 on
        cl.attribute_batch_id = ca25.attribute_batch_id
        and ca25.code = 'PLATFORM_TYPE'
    left outer join bo.t_contract_attributes ca26 on
        cl.attribute_batch_id = ca26.attribute_batch_id
        and ca26.code = 'FIRM'
    left outer join bo.t_contract_attributes ca29 on
        cl.attribute_batch_id = ca29.attribute_batch_id
        and ca29.code = 'MANAGER_CODE'
    left outer join bo.t_contract_attributes ca30 on
        cl.attribute_batch_id = ca30.attribute_batch_id
        and ca30.code = 'PAYMENT_TYPE'
    left outer join bo.t_manager_inner mngr on
        ca29.value_num = mngr.manager_code
    left join bo.t_currency cur on
        cur.iso_num_code = ca13.value_num
    left join bo.t_iso_currency iso_cur on
        iso_cur.alpha_code = ca13.value_str
where
    cl.is_cancelled is null
    and cl0.is_cancelled is null
    and (
        (
            cl.is_signed is not null
            or cl.is_faxed is not null
        )
        or (nvl(ca5.value_num, 0) = 1)
    )
    and c.type = 'DISTRIBUTION'
\\
