--liquibase formatted sql

--changeset akatovda:BALANCE-29102-0 endDelimiter:\\

create or replace view bo.v_partner_service_payments as
select services.KEY_NUM as SERVICE_ID, payments.*
from bo.mv_partner_payment_data payments
inner join bo.v_contract_last_attr2 services
on (services.code = 'SERVICES' and services.CONTRACT2_ID = payments.BILLING_CONTRACT_ID)
\\
