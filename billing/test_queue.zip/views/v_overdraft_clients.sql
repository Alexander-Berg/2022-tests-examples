--liquibase formatted sql

/*
получает по клиенту список входящих в бренд и эквивалентность клиентов
для директа на несколько дней до и после текущей

Типичное использование:


select brand_client_id
from bo.v_overdraft_clients
where client_id = 59608 and dt = trunc(sysdate)
*/

--changeset lightrevan:BALANCE-27390-oc stripComments:false endDelimiter:\\

CREATE OR REPLACE VIEW bo.v_overdraft_clients AS
SELECT client_id, 
  brand_client_id, 
  dt, 
  contract_id, 
  nvl(max(main_client_class_id), max(client_class_id)) main_client_class_id,
  max(brand_count) brand_count
FROM
  (
  SELECT client_id, 
    brand_client_id, 
    dt,  
    max(contract_id)              OVER (PARTITION BY client_id, nvl(dt, trunc(sysdate))) contract_id, 
    client_class_id, 
    COUNT(DISTINCT contract_id)   OVER (PARTITION BY client_id, nvl(dt, trunc(sysdate))) brand_count, 
    max(main_client_class_id)     OVER (PARTITION BY client_id, nvl(dt, trunc(sysdate))) main_client_class_id 
  FROM
    (SELECT c.id client_id,
      c.class_id client_class_id,
      NVL(c2_eq.id, c_eq.id) brand_client_id,
      dates.dt dt,
      max(cb.contract_id) contract_id,
      cb.main_client_class_id
     FROM 
       bo.t_client c
     JOIN 
       bo.t_client c_eq ON c.class_id = c_eq.class_id
     JOIN
       bo.v_contract_dates dates on 1=1
     LEFT JOIN
       (SELECT client_id,
               dt,
               contract_id,
               brand_client_id, 
               main_client_class_id
          FROM bo.mv_client_direct_brand
         WHERE brand_type = 7
       ) cb ON c_eq.id = cb.client_id AND dates.dt = cb.dt
     LEFT JOIN 
       bo.t_client c2 ON cb.brand_client_id = c2.id
     LEFT JOIN 
       bo.t_client c2_eq ON c2.class_id = c2_eq.class_id
     GROUP BY c.id, c.class_id, NVL(c2_eq.id, c_eq.id), dates.dt, cb.main_client_class_id
    )
  )
GROUP BY client_id, brand_client_id, dt, contract_id
HAVING max(brand_count) < 2

\\