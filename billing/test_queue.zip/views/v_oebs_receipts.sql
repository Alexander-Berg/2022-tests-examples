--liquibase formatted sql

--changeset el-yurchito:BALANCE-27359 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_OEBS_RECEIPTS" AS
SELECT
  p.invoice_eid,
  p.doc_sum SUM,
  p.dt,
  d.doc_date,
  NULL payment_date,
  doc_type || ' ' || doc_num payment_number,
  NULL source_type,
  NULL comiss_date,
  NULL creation_date
FROM
  "BO"."T_1C_PAYMENTS_V2" p,
  "BO".T_1C_DOCUMENTS_V2 d
WHERE
  p.dt = d.dt
    AND
  p.file_str = d.file_str
    AND
  d.doc_date < TO_DATE ('01.01.2008', 'DD.MM.YYYY')
UNION ALL
SELECT
  receipt_number invoice_eid,
  amount SUM,
  last_update_date dt,
  receipt_date doc_date,
  payment_date,
  payment_number,
  source_type,
  comiss_date,
  creation_date
FROM
  "BO"."T_OEBS_CASH_PAYMENT_FACT"
WHERE
  receipt_number LIKE '%-%-%'
    AND
  NVL(operation_type, 'INSERT') NOT IN ('CORRECTION_NETTING', 'SF_AVANS')
    AND
  receipt_date >= TO_DATE ('01.01.2008', 'DD.MM.YYYY')
UNION ALL
SELECT
  invoice_eid,
  SUM,
  dt,
  doc_date,
  NULL,
  MEMO,
  NULL source_type,
  NULL comiss_date,
  NULL creation_date
FROM
  "BO"."T_CORRECTION_PAYMENT"
\\
