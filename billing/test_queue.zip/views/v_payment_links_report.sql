--liquibase formatted sql

--changeset vaclav:TRUST-2254-2 runOnChange:true stripComments:false endDelimiter:/

create or replace view bo.v_payment_links_report as
select p.service_id,
       p.purchase_token link_id,
       max(o.service_order_id_str) service_order_id,
       p.dt link_dt,
       p.amount,
       case when p.currency = 'RUR' then 'RUB'
            else p.currency end currency,
       nvl(px.cancel_dt, px.payment_dt) status_dt,
       case when px.cancel_dt is null and px.payment_dt is null
              then 0
            when px.cancel_dt is null and px.payment_dt is not  null
              then 1
            when px.cancel_dt is not null and px.payment_dt is null
              then 2
            when px.cancel_dt is not null and px.payment_dt is not null
              then 3
       end payment_status,
       px.purchase_token,
       px.trust_payment_id,
       px.rrn external_id
  from bo.v_payment_trust p
  left outer join (
    select pl1.id link_id, max(pl2.id) payment_id
      from bo.v_payment_trust pl1
      join bo.v_payment_trust pl2 on pl2.orig_payment_id = pl1.id
     group by pl1.id
  ) pl on p.id = pl.link_id
  left outer join bo.v_payment_trust px on px.id = pl.payment_id
  join bo.t_request_order ro on p.request_id = ro.request_id
  join bo.t_order o on ro.parent_order_id = o.id
 where p.trust_payment_id like 'x%'
 group by p.service_id, p.id, p.dt, p.amount, p.currency,
          p.purchase_token, px.purchase_token, px.payment_dt, px.cancel_dt,
          px.trust_payment_id, px.rrn

/
