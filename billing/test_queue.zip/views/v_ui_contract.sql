--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_UI_CONTRACT
--------------------------------------------------------------------------------

CREATE OR REPLACE VIEW "BO"."V_UI_CONTRACT" AS
SELECT
  co.ID,
  co.ID AS contract_id,
  co.external_id AS contract_eid,
  f3.dt AS dt,
  f2.value_dt AS finish_dt,
  f12.value_dt AS sent_dt,
  sf_nullif (f4.value_num, 0) AS manager_code,
  m.NAME AS manager_name,
  m.login AS manager_login,
  m.email AS manager_email,
  sf_nullif (clients.ID, 0) AS client_id,
  clients.NAME AS client_name,
  sf_nullif (agencies.ID, 0) AS agency_id,
  agencies.NAME AS agency_name,
  sf_nullif (co.person_id, 0) AS person_id,
  nvl(
      (SELECT tav1.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav1
       WHERE
         tav1.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav1.CODE = 'NAME'
      ),
      NULL
  ) AS person_name,
  nvl(
      (SELECT tav2.value_str
       FROM "BO"."T_ATTRIBUTE_VALUES" tav2
       WHERE
         tav2.ATTRIBUTE_BATCH_ID = p.ATTRIBUTE_BATCH_ID
         AND tav2.CODE = 'INN'
      ),
      NULL
  ) AS person_inn,
  com.value_num AS commission,
  f1.value_num AS wo_nds,
  f5.value_num AS commission_type,
  f6.value_num AS supercommission,
  f7.value_num AS payment_type,
  cl.is_signed AS is_signed,
  cl.is_faxed AS is_faxed,
  cl.is_cancelled AS is_cancelled,
  f8.value_num AS payment_term,
  f9.value_num AS discount_pct,
  f10.value_num AS discount_fixed,
  f13.value_num AS is_booked,
  f14.value_dt AS is_booked_dt,
  f15.value_dt AS is_suspended,
  f11.services
FROM
  "BO"."T_CONTRACT2" co
    LEFT OUTER JOIN
  "BO"."T_CONTRACT_COLLATERAL" cl
      ON cl.contract2_id = co.ID AND cl.num IS NULL
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" com
      ON com.contract_id = co.ID AND com.code = 'COMMISSION'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f1
      ON f1.contract_id = co.ID AND f1.code = 'DISCARD_NDS'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f2
      ON f2.contract_id = co.ID AND f2.code = 'FINISH_DT'
    LEFT OUTER JOIN
  (SELECT ID, MIN (dt) dt
   FROM (
     SELECT co.ID ID, cl.dt dt
     FROM "BO"."T_CONTRACT2" co, "BO"."T_CONTRACT_COLLATERAL" cl
     WHERE cl.contract2_id = co.ID
   )
   GROUP BY ID) f3
      ON f3.ID = co.ID
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f4
      ON f4.contract_id = co.ID AND f4.code = 'MANAGER_CODE'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f5
      ON f5.contract_id = co.ID AND f5.code = 'COMMISSION_TYPE'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f6
      ON f6.contract_id = co.ID AND f6.code = 'SUPERCOMMISSION'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f7
      ON f7.contract_id = co.ID AND f7.code = 'PAYMENT_TYPE'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f8
      ON f8.contract_id = co.ID AND f8.code = 'PAYMENT_TERM'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f9
      ON f9.contract_id = co.ID AND f9.code = 'DISCOUNT_PCT'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f10
      ON f10.contract_id = co.ID AND f10.code = 'DISCOUNT_FIXED'
    LEFT OUTER JOIN
  "BO"."T_ATTRIBUTE_VALUES" f12
      ON f12.attribute_batch_id = cl.attribute_batch_id AND f12.CODE = 'SENT_DT'
    LEFT OUTER JOIN
   "BO"."V_CONTRACT_SIGNED_ATTR" f13
      ON f13.contract_id = co.ID AND f13.code = 'IS_BOOKED'
    LEFT OUTER JOIN
   "BO"."V_CONTRACT_SIGNED_ATTR" f14
      ON f14.contract_id = co.ID AND f14.code = 'IS_BOOKED_DT'
    LEFT OUTER JOIN
   "BO"."V_CONTRACT_SIGNED_ATTR" f15
      ON f15.contract_id = co.ID AND f15.code = 'IS_SUSPENDED'
    LEFT OUTER JOIN
  "BO"."T_MANAGER" m
      ON m.manager_code = f4.value_num
    LEFT OUTER JOIN
  "BO"."T_PERSON" p
      ON p.ID = co.person_id
    LEFT OUTER JOIN
  "BO"."T_CLIENT" clients
      ON co.client_id = clients.ID AND clients.is_agency = 0
    LEFT OUTER JOIN
  "BO"."T_CLIENT" agencies
      ON co.client_id = agencies.ID AND agencies.is_agency <> 0
    LEFT OUTER JOIN
    (SELECT
       contract_id,
       LTRIM(EXTRACT(xmlagg(xmlelement( "V", ', ' || s.name ) ), '/V/text()') , ',') services
     FROM
       "BO"."V_CONTRACT_LAST_ATTR" la
          LEFT OUTER JOIN
       "BO"."T_SERVICE" s
            ON s.id = la.key_num
     WHERE
       code = 'SERVICES' AND value_num = 1
     GROUP BY contract_id) f11
      ON f11.contract_id = co.ID
WHERE
  co.TYPE = 'GENERAL'
;
