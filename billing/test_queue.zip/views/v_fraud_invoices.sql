--liquibase formatted sql

--changeset nebaruzdin:BALANCE-23787 stripComments:false endDelimiter:\\

/*
 *  Счета с подозрением на фрод. Для CRM.
 *
 *  BALANCE-11146
 */
create or replace view bo.v_fraud_invoices as
  select c.id                  as client_id,
         i.id                  as invoice_id,
         i.external_id         as invoice_eid,
         i.dt                  as invoice_dt,
         i.receipt_dt          as invoice_on_dt,
         i.manager_code        as invoice_manager_id,
         (
            select acc.gecos
              from bo.t_receipt rcp,
                   bo.t_passport acc
             where acc.passport_id = rcp.oper_id
               and rcp.id = (
                             select max (rcpt.id)
                               from bo.t_receipt rcpt
                              where rcpt.invoice_id = i.id
                            )
         )                     as invoice_on_manager,
         i.currency            as invoice_curr,
         i.iso_currency        as invoice_iso_cur,
         i.total_sum           as invoice_sum,
         i.paysys_id           as invoice_paysys_id
    from bo.t_invoice  i
    join bo.t_paysys   p    on p.id = i.paysys_id
                           and i.firm_id = 1
                           and (p.instant=1 and p.fraudable = 0 or p.invoice_sendable=1)
                           and p.extern=1
    join bo.t_client   c    on c.id = i.client_id
                           and c.internal = 0
   where i.hidden < 2
     and i.receipt_sum_1c = 0
     and i.receipt_sum > 0
     and i.consume_sum > 0                  -- exclude invoices where money on orderless
     and i.client_id <> 401098
     and i.dt >= date'2007-01-01'
     and i.overdraft = 0
     and i.credit = 0
     and substr(i.external_id,1,1) in ('Б','N','R')
     and nvl(trunc(i.receipt_dt), date'1970-01-01') <
            ( sysdate - decode( i.paysys_id,
                             1001, 9,
                             1003, (decode(trunc(i.receipt_dt+1)-trunc(i.receipt_dt,'D'),
                                           5, 3,
                                           6, 2,
                                           7, 1,
                                           1)
                                   ),
                             1013, 13,
                             1014, 13,
                             1000, 10,
                             1015, 10,
                             1019, 4,
                             1023, 13,
                             1024, 4,
                             0)
            )
     and not exists (
                         select 1
                           from bo.t_act           ba
                           join bo.t_bad_debt_act  bda on bda.ACT_ID = ba.id
                                                      and bda.hidden = 0
                          where ba.invoice_id = i.id
                            and rownum = 1
                    )
     and not exists (
                        select 1
                          from bo.t_order o,
                               bo.t_invoice_order io
                         where o.id = io.order_id
                           and o.service_id = 35
                           and io.invoice_id = i.id
                           and rownum <= 1
                    )

\\
