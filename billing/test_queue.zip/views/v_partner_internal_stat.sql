--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114-1 stripComments:false endDelimiter:\\


 CREATE OR REPLACE FORCE EDITIONABLE VIEW "BO"."V_PARTNER_INTERNAL_STAT" AS

 select
     1 firm_id,
     pcb.place_id,
     pcb.page_id,
     p.owner_id,
     null partner_contract_eid,
     pcb.clicks,
     pcb.shows,
     pcb.bucks,
     pcb.completion_type,
     pcb.dt,
     nvl(pcb.hits,0) hits,
     pd."DESC" description,
     p.domain,
     100 commission_pct,
     null aggregator_pct,
     null partner_contract_id,
     null contract_end_dt,
     0 nds,
     pd.rur_click_price price,
     pd.type_id,
     null aggregator_reward,
     p.place_type,
     p.person_id,
     case when pd.type_id=4 then pcb.bucks*30
          when pd.type_id=2 then pcb.clicks * pd.rur_click_price * decode(pd.nds, 0, nds.nds_koef, 1)
          when pd.type_id=6 then pcb.bucks*30
          else pcb.shows/1000*nvl(p.mkb_price, 0)*nds.nds_koef
     end partner_reward,
     case when pd.type_id=4 then pcb.bucks*30
          when pd.type_id=6 then pcb.bucks*30
          when pd.type_id=2 then pcb.clicks* pd.rur_click_price/0.45
          else pcb.shows/1000*885
     end turnover_with_nds_stat
 from
     (
     select pl.id place_id, max(pl.client_id) owner_id, max(pl.type) place_type, max(pr.id) person_id,
      max(pl.url) domain, max(mk.price) mkb_price from t_place pl, t_person pr, t_mkb_category mk
      where pl.internal_type in(2,4) and pr.client_id=pl.client_id and
      pl.mcb_flag=mk.id(+)
      group by pl.id
      ) p,
     (select * from t_partner_completion_buffer where page_id not in(632, 643)) pcb,
     t_page_data pd,
     bo.v_nds_pct nds
 where
     p.place_id=pcb.place_id
     and pcb.page_id=pd.page_id
     and pd.contract_type='PARTNERS'
     and (nds.ndsreal_id = 18 and
          pcb.dt >= nds.from_dt and
          pcb.dt < nds.to_dt)

\\
