--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace view bo.v_distribution_contract_places as
select
    p.id place_id,
    p.search_id,
    pp.page_id product_id,
    p.url,
    dc.client_id,
    dc.person_id,
    dc.id,
    dc.dt,
    dc.external_id,
    dc.end_dt,
    dc.tailless_end_dt,
    dc.nds,
    dc.contract_end_dt,
    dc.tail_time,
    dc.contract_type,
    dc.test_mode,
    dc.install_price,
    dc.reward_type,
    p.internal_type,
    p.payment_type,
    dc.currency,
    dc.iso_currency,
    dc.avg_discount_pct,
    dc.uni_has_revshare,
    dc.uni_has_fixed,
    dc.uni_has_searches,
    dc.uni_has_addapter_ret,
    dc.uni_has_addapter_dev,
    dc.currency_calculation,
    dc.products_currency,
    dc.products_iso_currency,
    dc.search_currency,
    dc.search_iso_currency,
    dc.tag_id
from
    bo.v_distribution_contract dc,
    bo.t_place p,
    bo.t_place_products pp
where
    p.tag_id = dc.tag_id
    and pp.place_id = p.id
    and pp.page_id not in (4010, 4012)
    and p.type = 8
\\
