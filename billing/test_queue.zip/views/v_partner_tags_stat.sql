--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_PARTNER_TAGS_STAT
--------------------------------------------------------------------------------

create or replace view BO.V_PARTNER_TAGS_STAT as
with v_partner_turnover_expense as (
  select
    service_id,
    start_dt,
    nvl(lead (start_dt-1) over (partition BY service_id order by start_dt), sysdate+365) end_dt,
    pct
  from bo.t_partner_turnover_expense
)
select
  pcp.firm_id,
  pcb.place_id,
  pcp.client_id owner_id,
  pcp.id partner_contract_eid,
  pd.page_id,
  pcb.clicks,
  pcb.shows,
  pcb.bucks,
  pcb.completion_type,
  pcb.dt,
  pd."DESC" description,
  p.url domain,
  pcp.id partner_contract_id,
  decode(pd.page_id, 2060, pcp.bm_market_pct, 854, pcp.bm_direct_pct, pcp.partner_pct) commission_pct,
  pcp.AGREGATOR_PCT aggregator_pct,
  pcp.contract_end_dt contract_end_dt,
  nds.nds_pct,
  case when pd.type_id=1 then (select q.price from bo.mv_partner_mkb_price q
           where q.place_id=plo.place_id and q.contract_id=pcp.id)
       when pd.type_id=2 then pd.rur_click_price
  else
    Null
  end price,
  pd.type_id,
  case when pd.type_id=1 then (select q.price from bo.mv_partner_mkb_price q
                               where q.place_id = plo.place_id and q.contract_id=pcp.id
                               ) * nds.nds_koef
                                 * pcb.shows/1000
       when pd.type_id=2 then pd.rur_click_price*pcb.clicks/0.45*(pcp.partner_pct*0.01)
  else
    pcb.bucks * pcp.partner_pct
              * decode(pcp.reward_type, 2, 1 - nvl(exp.pct, 0) * 0.01, 1)
              * 0.01*30
  end partner_reward,
  case when pd.type_id=4 then pcb.bucks*30*decode(pcp.reward_type, 2, 1 - nvl(exp.pct, 0) * 0.01, 1)
       when pd.type_id=2 then pd.rur_click_price*pcb.clicks / 0.45
  else null
  end turnover_with_nds,
  case when pd.type_id=4 then pcb.bucks*30*decode(pcp.reward_type, 2, 1 - nvl(exp.pct, 0) * 0.01, 1)
       when pd.type_id=2 then pd.rur_click_price*pcb.clicks / 0.45
       -- shit method for calc mkb turnover
       when pd.type_id=1 then 885*pcb.shows/1000
  else 0
  end turnover_with_nds_stat,
  case when pd.type_id=2 then
    pcb.clicks*pd.rur_click_price/(pcp.partner_pct * 0.01) * (nvl(pcp.agregator_pct, 0) * 0.01)
  else
    pcb.bucks * decode(pcp.reward_type, 2, 1 - nvl(exp.pct, 0) * 0.01, 1)
              * nvl(pcp.agregator_pct,0)
              * 0.01 * 30
  end aggregator_reward,
  p.type place_type,
  case when c.partner_type in(2,3) then(
    select tav.value_str
    from bo.t_attribute_values tav
    where
      tav.ATTRIBUTE_BATCH_ID = person.ATTRIBUTE_BATCH_ID
      and tav.CODE = 'LONGNAME'
  )
  else null
  end aggregator_name,
  pcb.tag_id,
  person.id person_id,
  pcb.type
from
  (select dt, tag_id, place_id, page_id, shows, clicks, bucks/1000000 bucks, bucks mbucks, 0 completion_type, nvl(type, 0) type
    from bo.t_partner_tags_stat3) pcb,
  bo.t_page_data pd,
  bo.mv_partner_contract_puttee pcp,
  bo.mv_partner_place_owners plo,
  bo.t_mkb_category mc,
  bo.t_place p,
  bo.t_person person,
  bo.t_client c,
  bo.t_contract2 c2,
  v_partner_turnover_expense exp,
  bo.v_nds_pct nds
where
  pcb.page_id=pd.page_id
  and c2.id = pcp.id
  and c2.type = pd.contract_type
  and pd.contract_type = 'PARTNERS'
  and pd.service_id = exp.service_id(+)
  and pcb.dt>=nvl(exp.start_dt, pcb.dt - 1)
  and pcb.dt<=nvl(exp.end_dt, pcb.dt + 1)
  and pcb.dt>= plo.start_dt
  and pcb.dt<= nvl(plo.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
  and pcp.client_id=plo.billing_client_id
  and pcb.place_id = plo.place_id
  and pcb.dt>=pcp.dt
  and pcb.dt<=nvl(pcp.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
  and mc.ID(+)=p.mkb_category_id
  and p.id=plo.place_id
  and pcp.client_id=c.id
  and person.id(+)=pcp.person_id
  and (nds.ndsreal_id = pcp.nds and
       pcb.dt >= nds.from_dt and
       pcb.dt < nds.to_dt)
;
