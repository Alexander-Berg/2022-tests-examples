--liquibase formatted sql

-- NOTE: recreate on changes on BO and META!!!

--changeset lightrevan:BALANCE-29737 stripComments:false runAlways:true context:test

CREATE OR REPLACE VIEW BO.T_ACT
AS
select * from bo.t_act_internal
where hidden < 4 and type = 'generic';
