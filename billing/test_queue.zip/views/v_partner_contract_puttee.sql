--liquibase formatted sql

--changeset vorobyov-as:BALANCE-27878-2-3 stripComments:false endDelimiter:\\

CREATE OR REPLACE FORCE EDITIONABLE VIEW "BO"."V_PARTNER_CONTRACT_PUTTEE" AS

select
c.client_id,
c.person_id,
c.id,
case
  when cl.id = col0.id
    then nvl(f18.value_dt, cl.dt)
  else cl.dt
end dt,
c.external_id,
nvl(last_value(f16.value_num ignore nulls) over (partition BY c.id order by cl.dt), 1) reward_type,
last_value(f2.value_num ignore nulls) over (partition BY c.id order by cl.dt) partner_pct,
last_value(f3.value_num ignore nulls) over (partition BY c.id order by cl.dt) agregator_pct,
last_value(f15.value_num ignore nulls) over (partition BY c.id order by cl.dt) dsp_agregation_pct,
last_value(f14.value_num ignore nulls) over (partition BY c.id order by cl.dt) contract_type,
last_value(f4.value_num ignore nulls) over (partition BY c.id order by cl.dt) doc_set,
last_value(f5.value_num ignore nulls) over (partition BY c.id order by cl.dt) payment_type,
last_value(f7.value_num ignore nulls) over (partition BY c.id order by cl.dt) bm_direct_pct,
last_value(f8.value_num ignore nulls) over (partition BY c.id order by cl.dt) bm_market_pct,
last_value(f1.value_num ignore nulls) over (partition BY c.id order by cl.dt) nds,
last_value(f9.value_dt ignore nulls) over (partition BY c.id order by cl.dt) contract_end_dt,
last_value(f10.value_num ignore nulls) over (partition BY c.id order by cl.dt) search_forms,
last_value(f11.value_num ignore nulls) over (partition BY c.id order by cl.dt) market_banner,
nvl(lead (cl.dt-1) over (partition BY c.id order by cl.dt),
  last_value(f9.value_dt ignore nulls) over (partition BY c.id order by cl.dt)
) AS end_dt,
nvl(f12.value_num, 1) firm_id,
last_value(f13.value_num ignore nulls) over (partition BY c.id order by cl.dt) market_api_pct,
last_value(f17.value_num ignore nulls) over (partition BY c.id order by cl.dt) test_mode
from
    bo.t_contract2 c left join bo.t_contract_collateral cl
          ON cl.contract2_id = c.id
          LEFT JOIN bo.t_contract_collateral col0 ON col0.contract2_id=c.id
          left outer join bo.t_contract_collateral_types coltype on
          cl.collateral_type_id = coltype.id
          LEFT OUTER JOIN bo.t_contract_attributes f1
          ON f1.collateral_id = cl.ID AND f1.code = 'NDS'
          LEFT OUTER JOIN bo.t_contract_attributes f2
          ON f2.collateral_id = cl.ID and f2.code = 'PARTNER_PCT'
          LEFT OUTER JOIN bo.t_contract_attributes f3
          ON f3.collateral_id = cl.ID and f3.code = 'AGREGATOR_PCT'
          LEFT OUTER JOIN bo.t_contract_attributes f4
          ON f4.collateral_id = cl.ID and f4.code = 'DOC_SET'
          LEFT OUTER JOIN bo.t_contract_attributes f5
          ON f5.collateral_id = cl.ID and f5.code = 'PAYMENT_TYPE'
          LEFT OUTER JOIN bo.t_contract_attributes f7
          ON f7.collateral_id = cl.ID and f7.code = 'BM_DIRECT_PCT'
          LEFT OUTER JOIN bo.t_contract_attributes f8
          ON f8.collateral_id = cl.ID and f8.code = 'BM_MARKET_PCT'
          LEFT OUTER JOIN bo.t_contract_attributes f9
          ON f9.collateral_id = cl.ID and f9.code = 'END_DT'
          LEFT OUTER JOIN bo.t_contract_attributes f10
          ON f10.collateral_id = cl.ID and f10.code = 'SEARCH_FORMS'
          LEFT OUTER JOIN bo.t_contract_attributes f11
          ON f11.collateral_id = cl.ID and f11.code = 'MARKET_BANNER'
          LEFT OUTER JOIN bo.t_contract_attributes f12
          ON f12.collateral_id = col0.ID and f12.code = 'FIRM'
          LEFT OUTER JOIN bo.t_contract_attributes f13
          ON f13.collateral_id = cl.ID and f13.code = 'MARKET_API_PCT'
          LEFT OUTER JOIN bo.t_contract_attributes f14
          ON f14.collateral_id = col0.ID and f14.code = 'CONTRACT_TYPE'
          LEFT OUTER JOIN bo.t_contract_attributes f15
          ON f15.collateral_id = cl.ID and f15.code = 'DSP_AGREGATION_PCT'
          LEFT OUTER JOIN bo.t_contract_attributes f16
          ON f16.collateral_id = cl.ID and f16.code = 'REWARD_TYPE'
          LEFT OUTER JOIN bo.t_contract_attributes f17
          ON f17.collateral_id = cl.ID and f17.code = 'TEST_MODE'
          LEFT OUTER JOIN bo.t_contract_attributes f18
          ON f18.collateral_id = cl.ID and f18.code = 'SERVICE_START_DT'
where c.type='PARTNERS' and cl.is_cancelled is null and col0.collateral_type_id is null and col0.num is null
and (coltype.collateral_class='ANNOUNCEMENT' or cl.is_signed is not null or cl.is_faxed is not null or f17.value_num=1)
and nvl(cl.collateral_type_id, 0) != 2040
\\
