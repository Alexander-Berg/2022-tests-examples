--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_UI_PAYMENT_INFO
--------------------------------------------------------------------------------

create or replace view BO.V_UI_PAYMENT_INFO as
WITH
  payment_status AS (
    SELECT /*+ PARALLEL(t_payment, 5) */
      id,
      CASE
        WHEN cancel_dt IS NULL AND payment_dt IS NULL AND postauth_dt IS NULL
          -- INITIAL
        THEN 1
        WHEN cancel_dt IS NULL AND payment_dt IS NOT NULL AND postauth_dt IS NULL
        -- AUTHORIZED
        THEN 2
        WHEN cancel_dt IS NULL AND payment_dt IS NOT NULL AND postauth_dt IS NOT NULL
        -- POSTAUTHORIZED
        THEN 3
        WHEN cancel_dt IS NOT NULL AND payment_dt IS NULL AND postauth_dt IS NULL
        -- NOT_AUTHORIZED
        THEN 4
        WHEN cancel_dt IS NOT NULL AND payment_dt IS NOT NULL AND postauth_dt IS NOT NULL AND  nvl(postauth_amount, 0) = 0
        -- CANCELED
        THEN 5
        WHEN cancel_dt IS NOT NULL AND payment_dt IS NOT NULL AND postauth_dt IS NOT NULL AND nvl(postauth_amount, 0) > 0
        -- REFUNDED
        THEN 6
      END payment_status_id,
      greatest(nvl(payment_dt, dt), nvl(cancel_dt, dt), nvl(postauth_dt, dt)) update_dt
    FROM bo.t_payment
  )
SELECT
    p.id               balance_payment_id,
    p.transaction_id   transaction_id,
    p.trust_payment_id trust_payment_id,
    p.purchase_token purchase_token,

    i.id invoice_id,
    i.external_id invoice_eid,

    pass.passport_id passport_id,
    pass.login passport_login,

    ps.payment_status_id payment_status_id,
    decode(ps.payment_status_id,
           1, 'Создан',
           2, 'Авторизован',
           3, 'Поставторизован',
           4, 'Не авторизован',
           5, 'Отменен',
           6, 'Возвращен') payment_status,
    ps.update_dt payment_status_update_dt,

    p.user_ip user_ip,
    p.terminal_id terminal_id,
    p.currency currency,
    p.amount amount,
    p.postauth_amount postauth_amount,
    p.register_id register_id,
    p.user_account user_account,
    p.card_holder card_holder,
    p.approval_code approval_code,
    p.rrn rrn,
    p.resp_desc payment_resp_desc,

    p.dt create_dt,
    p.payment_dt payment_dt,
    p.postauth_dt postauth_dt,
    p.cancel_dt cancel_dt,
    pr.register_dt register_dt,

    c.id client_id,
    c.name client_name,

    pers.name person_name,
    pers.phone person_phone,
    pers.email person_email,

    pers.name || ' (' || pers.phone || ') ' || pers.email person_info,

    s.id service_id,
    s.cc service_cc,
    s.name service_name,

    f.id firm_id,
    f.title firm_title,

    pm.cc payment_method_cc,
    pm.name payment_method_name,

    proc.cc processing_cc,
    proc.name processing_name
  FROM
    BO.t_payment p
    JOIN payment_status ps on p.id = ps.id
    LEFT OUTER JOIN bo.t_terminal t ON p.terminal_id = t.id
    JOIN bo.t_payment_method pm ON t.payment_method_id = pm.id
    JOIN bo.t_processing proc ON t.processing_id = proc.id
    LEFT OUTER JOIN bo.t_firm f on t.firm_id = f.id
    JOIN bo.t_service s on p.service_id = s.id
    LEFT OUTER JOIN BO.t_passport pass ON p.creator_uid = pass.passport_id
    LEFT OUTER JOIN BO.t_payment_register pr ON p.register_id = pr.id
    LEFT OUTER JOIN BO.t_invoice i ON p.invoice_id = i.id
    LEFT OUTER JOIN BO.t_client c ON i.client_id = c.id
    LEFT OUTER JOIN (
      select
        tp.id,
        nvl((select tav1.value_str
             from bo.t_attribute_values tav1
             where
               tav1.code = 'NAME'
               and tav1.attribute_batch_id = tp.attribute_batch_id
          ),
          null
        ) name,
        nvl((select tav2.value_str
             from bo.t_attribute_values tav2
             where
               tav2.code = 'PHONE'
               and tav2.attribute_batch_id = tp.attribute_batch_id
          ),
          null
        ) phone,
        nvl((select tav3.value_str
             from bo.t_attribute_values tav3
             where
               tav3.code = 'EMAIL'
               and tav3.attribute_batch_id = tp.attribute_batch_id
          ),
          null
        ) email
      from
        bo.T_PERSON tp
    ) pers on pers.id = i.person_id
;
