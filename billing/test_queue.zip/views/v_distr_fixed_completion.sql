--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace view bo.v_distr_fixed_completion as
with v_partner_reward as (
    select
        dft.dt,
        dft.place_id,
        dft.url,
        dft.page_id,
        dft.shows                                as shows,
        dft.bucks,
        dft.shows * bo.sf_get_dist_fixed_price(
            dft.dt, dft.contract_id, dft.page_id
        )                                        as partner_reward_in_price_cur,
        bo.sf_get_dist_fixed_price(
            dft.dt, dft.contract_id, dft.page_id
        )                                        as price,
        dft.contract_id,
        dft.contract_end_dt,
        dft.external_id,
        dft.client_id,
        dft.test_mode,
        dft.nds,
        dft.internal_type,
        dft.currency,
        dft.iso_currency,
        dft.currency_calculation,
        dft.price_iso_currency,
        dft.rate_src,
        nvl(
            (
                select rate_to/rate_from
                from bo.mv_iso_currency_rate icr
                where
                    icr.rate_src = nvl(dft.rate_src, 'cbr')
                    and icr.iso_currency_from = dft.iso_currency
                    and icr.iso_currency_to = dft.price_iso_currency
                    and dft.dt >= icr.from_dt
                    and dft.dt < icr.to_dt
            ),
            1
        )                                        as prod_to_contr_rate,
        nvl(
            case
                when dft.iso_currency = 'RUB'
                    then 1
                else (
                    select rate_to/rate_from
                    from bo.mv_iso_currency_rate icr
                    where
                        icr.rate_src = 'cbr'
                        and icr.iso_currency_from = dft.iso_currency
                        and icr.iso_currency_to = 'RUB'
                        and dft.dt >= icr.from_dt
                        and dft.dt < icr.to_dt
                )
            end,
            0
        )                                        as contract_currency_rate,
        dft.vid,
        dft.place_tag_id
    from
        bo.v_distr_fixed_turnover dft
)
select
    pr.dt,
    pr.place_id,
    pr.url,
    pr.page_id,
    pr.shows shows,
    pr.bucks * 30                                as turnover,
    case
        when pr.currency_calculation = 1
            then pr.partner_reward_in_price_cur
                 / pr.prod_to_contr_rate
        else pr.partner_reward_in_price_cur
    end                                          as partner_reward_wo_nds,
    case
        when pr.currency_calculation = 1
            then pr.partner_reward_in_price_cur
                 / pr.prod_to_contr_rate
                 * contract_currency_rate
        else pr.partner_reward_in_price_cur
             * contract_currency_rate
    end                                          as partner_reward_wo_nds_rur,
    (
        case
            when pr.currency_calculation = 1
                then pr.partner_reward_in_price_cur
                     / pr.prod_to_contr_rate
            else pr.partner_reward_in_price_cur
        end
    ) * (1 + pr.nds * 0.01)                       as partner_reward,
    pr.contract_id,
    pr.contract_end_dt,
    pr.external_id,
    pr.client_id,
    pr.test_mode,
    pr.nds,
    pr.internal_type,
    upper(pr.currency) currency,
    pr.iso_currency,
    pr.vid,
    pr.place_tag_id
from
    v_partner_reward pr
\\
