--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_PARTNER_KNOW_STAT_COMP
--------------------------------------------------------------------------------

create or replace view BO.V_PARTNER_KNOW_STAT_COMP as
select
      pcp.firm_id,
      pcb.place_id,
      pcp.client_id owner_id,
      pcp.id partner_contract_eid,
      pd.page_id,
      pcb.clicks,
      pcb.shows,
      pcb.bucks,
      pcb.completion_type,
      0 hits,
      pcb.dt,
      pd."DESC" description,
      p.url domain,
      pcp.id partner_contract_id,
      decode(pd.page_id, 2060, pcp.bm_market_pct, 854, pcp.bm_direct_pct, pcp.partner_pct) commission_pct,
      pcp.AGREGATOR_PCT aggregator_pct,
      pcp.contract_end_dt contract_end_dt,
      nds.nds_pct nds,
      case when pd.type_id=1 then (select q.price from bo.mv_partner_mkb_price q
               where q.place_id=plo.place_id and q.contract_id=pcp.id)
           when pd.type_id=2 then pd.rur_click_price
      else
        Null
      end price,
      pd.type_id,
      case when pd.type_id=1 then (select q.price from bo.mv_partner_mkb_price q
               where q.place_id = plo.place_id and q.contract_id=pcp.id)*nds.nds_koef*pcb.shows/1000
           when pd.type_id=2 then pd.rur_click_price * pcb.clicks * decode(pd.nds, 0, nds.nds_koef, 1)
      else
           pcb.bucks*pcp.partner_pct*0.01*30
      end partner_reward,
      case when pd.type_id=4 then pcb.bucks*30
           when pd.type_id=2 then pd.rur_click_price*pcb.clicks/0.45
      else null
      end turnover_with_nds,
      case when pd.type_id=4 then pcb.bucks*30
           when pd.type_id=2 then pd.rur_click_price*pcb.clicks/0.45
           -- shit method for calc mkb turnover
           when pd.type_id=1 then 885*pcb.shows/1000
      else 0
      end turnover_with_nds_stat,
      case when pd.type_id=2 then
        (pcb.clicks*pd.rur_click_price/(pcp.partner_pct*0.01)*(nvl(pcp.agregator_pct,0)*0.01)) * decode(pd.nds, 0, nds.nds_koef, 1)
      else
          pcb.bucks*nvl(pcp.agregator_pct,0)*0.01*30
      end aggregator_reward,
      p.type place_type,
      case when c.partner_type in(2,3) then (
        select tav.value_str
        from bo.t_attribute_values tav
        where
          tav.ATTRIBUTE_BATCH_ID = person.ATTRIBUTE_BATCH_ID
          and tav.CODE = 'LONGNAME'
      )
      else null
      end aggregator_name,
      pcp.person_id,
      'RUR' currency,
      'RUB' iso_currency
  from
      (select
        bk.dt, bk.tag_id place_id, tags.page_id,
        bk.shows, bk.clicks, bk.bucks/1000000 bucks, bk.bucks mbucks, 0 completion_type, 0 type
        from bo.t_partner_tags_stat3 bk, bo.t_known_tags tags, bo.t_place p
        where bk.place_id=tags.bk_place_id and bk.page_id=tags.bk_page_id and
        p.type=tags.place_type and bk.tag_id=p.id
      ) pcb,

      bo.t_page_data pd,
      bo.mv_partner_contract_puttee pcp,
      bo.mv_partner_place_owners plo,
      bo.t_mkb_category mc,
      bo.t_place p,
      bo.t_person person,
      bo.t_client c,
      bo.t_contract2 c2,
      bo.v_nds_pct nds
  where
      pcb.page_id=pd.page_id
      and c2.id = pcp.id
      and c2.type = pd.contract_type
      and pd.contract_type = 'PARTNERS'
      and pcb.dt>= plo.start_dt
      and pcb.dt<= nvl(plo.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
      and pcp.client_id=plo.billing_client_id
      and pcb.place_id = plo.place_id
      and pcb.dt>=pcp.dt
      and pcb.dt<=nvl(pcp.end_dt, to_date('01.01.9999', 'DD.MM.YYYY'))
      and mc.ID(+)=p.mkb_category_id
      and p.id=plo.place_id
      and pcp.client_id=c.id
      and person.id(+)=pcp.person_id
      and (nds.ndsreal_id = pcp.nds and
           pcb.dt >= nds.from_dt and
           pcb.dt < nds.to_dt)
;
