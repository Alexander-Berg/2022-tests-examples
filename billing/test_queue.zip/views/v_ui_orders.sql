--liquibase formatted sql

--changeset dolvik:BALANCE-27769 stripComments:false runOnChange:true endDelimiter:\\

CREATE OR REPLACE FORCE VIEW "BO"."V_UI_ORDERS"
  AS
    SELECT
      o.id                                        AS order_id,
      o.service_id || '-' || o.service_order_id   AS order_eid,
      o.service_order_id,
      o.service_id,
      o.service_code,
      o.linked_order_id,
      s.service_group_id,
      s.cc                                        AS service_cc,
      s.name                                      AS service_name,
      s.url_orders                                AS service_orders_url,
      o.dt AS order_dt,
      o.text,
      o.consumes_count,
      o.consume_qty,
      o.consume_sum,
      o.completion_qty,
      o.completion_sum,
      (o.consume_qty - o.completion_qty)          AS remain_qty,
      (o.consume_sum - o.completion_sum)          AS remain_sum,
      o.client_id,
      c.name                                      AS client,
      c.is_agency,
      o.passport_id,
      o.manager_code,
      m.name                                      AS manager_name,
      s.extra_pay,
      s.intern                                    AS service_internal,
      o.hidden,
      CASE WHEN pt.id = 6 AND pu.ISO_CURRENCY IS NOT NULL
        THEN pu.ISO_CURRENCY
      ELSE pt.NAME
      END AS unit,
      pu.TYPE_RATE,
      o.agency_id,
      a.name                                      AS agency,
      o.tag,
      ro.service_order_id                         AS root_order_service_order_id,
      ro.service_id || '-' || ro.service_order_id AS root_order_eid,
      ros.cc                                      AS root_order_service_cc
    FROM
      bo.t_order o,
      bo.t_order ro,
      bo.t_service s,
      bo.t_service ros,
      bo.t_manager m,
      bo.t_client c,
      bo.t_product p,
      bo.t_product_unit pu,
      bo.t_product_type pt,
      bo.t_client a
    WHERE
      o.service_id = s.id                AND
      o.manager_code = m.manager_code(+) AND
      o.group_order_id = ro.id(+)        AND
      ro.service_id = ros.id(+)          AND
      o.client_id = c.id                 AND
      o.agency_id = a.id(+)              AND
      o.pid IS NULL                      AND
      o.service_code = p.id              AND
      p.unit_id = pu.id                  AND
      pu.product_type_id = pt.id

\\

--changeset el-yurchito:BALANCE-30155 endDelimiter:\\
create or replace view BO.V_UI_ORDERS as
SELECT
  o.id                                        AS order_id,
  o.service_id || '-' || o.service_order_id   AS order_eid,
  o.service_order_id,
  o.service_id,
  o.service_code,
  o.linked_order_id,
  s.service_group_id,
  s.cc                                        AS service_cc,
  s.name                                      AS service_name,
  s.url_orders                                AS service_orders_url,
  o.dt AS order_dt,
  o.text,
  o.consumes_count,
  o.consume_qty,
  o.consume_sum,
  o.completion_qty,
  o.completion_sum,
  (o.consume_qty - o.completion_qty)          AS remain_qty,
  (o.consume_sum - o.completion_sum)          AS remain_sum,
  o.client_id,
  c.name                                      AS client,
  c.is_agency,
  o.passport_id,
  o.manager_code,
  m.name                                      AS manager_name,
  s.extra_pay,
  s.intern                                    AS service_internal,
  o.hidden,
  CASE WHEN pt.id = 6 AND pu.ISO_CURRENCY IS NOT NULL
    THEN pu.ISO_CURRENCY
  ELSE pt.NAME
  END AS unit,
  pu.TYPE_RATE,
  o.agency_id,
  a.name                                      AS agency,
  o.tag,
  ro.service_order_id                         AS root_order_service_order_id,
  ro.service_id || '-' || ro.service_order_id AS root_order_eid,
  ros.cc                                      AS root_order_service_cc
FROM
  bo.t_order o,
  bo.t_order ro,
  bo.v_service s,
  meta.t_service ros,
  bo.t_manager m,
  bo.t_client c,
  bo.t_product p,
  bo.t_product_unit pu,
  bo.t_product_type pt,
  bo.t_client a
WHERE
  o.service_id = s.id
  AND o.manager_code = m.manager_code(+)
  AND o.group_order_id = ro.id(+)
  AND ro.service_id = ros.id(+)
  AND o.client_id = c.id
  AND o.agency_id = a.id(+)
  AND o.pid IS NULL
  AND o.service_code = p.id
  AND p.unit_id = pu.id
  AND pu.product_type_id = pt.id
\\
