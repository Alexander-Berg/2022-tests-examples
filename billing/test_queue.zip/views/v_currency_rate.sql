--liquibase formatted sql

--changeset nebaruzdin:BALANCE-24282-2 stripComments:false endDelimiter:\\

create or replace view bo.v_currency_rate as
with v_currency_rate_tmp as (
  select
    case
      when rate_src_id = 1002
      then selling_rate
      else decode(rate_src_id,
                  1001, 1/rate,
                  rate)
    end rate,
    rate_dt,
    case
      when rate_src_id = 1001
      then cc
      else base_cc
    end base_cc,
    case
      when rate_src_id = 1001
      then base_cc
      else cc
    end cc,
    rate_src_id
  from bo.t_currency_rate_v2 cr
  where rate_src_id != 1111
)

select
  rate,
  rate_dt from_dt,
  upper(base_cc) base_cc,
  c1.num_code base_cc_num,
  upper(cc) cc,
  c2.num_code cc_num,
  nvl(
    lead(rate_dt)
    over (
      partition
      by upper(cc), upper(base_cc), rate_src_id
      order by rate_dt
    ), sysdate+2
  ) to_dt,
  rate_src_id
from
  v_currency_rate_tmp crt,
  t_iso_currency c1,
  t_iso_currency c2
where
  decode(upper(crt.base_cc), 'RUR', 'RUB', upper(crt.base_cc)) = c1.alpha_code
  and decode(upper(crt.cc), 'RUR', 'RUB', upper(crt.cc)) = c2.alpha_code
  and c2.num_code is not null

\\
