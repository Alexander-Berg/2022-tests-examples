--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114-3 stripComments:false endDelimiter:\\

create or replace view bo.v_distr_fixed_turnover as
select /*+ opt_param('_optimizer_push_pred_cost_based' 'false')*/
    pcb.dt,
    dcp.place_id,
    dcp.url,
    pcb.page_id,
    case
        when pcb.page_id = 2080
            then pcb.clicks
        else pcb.shows
    end                                          as shows,
    pcb.bucks,
    dcp.id                                       as contract_id,
    case
        when pd.tailable = 1
            then dcp.end_dt
        else dcp.tailless_end_dt
    end                                          as contract_end_dt,
    dcp.external_id,
    dcp.client_id,
    dcp.test_mode,
    nds.nds_pct                                  as nds,
    dcp.internal_type,
    case
        when dcp.currency_calculation = 1
            then dcp.currency
        else 'RUR'
    end                                          as currency,
    case
        when dcp.currency_calculation = 1
            then dcp.iso_currency
        else 'RUB'
    end                                          as iso_currency,
    dcp.currency_calculation,
    pcb.vid,
    dcp.products_currency                        as price_currency,
    dcp.products_iso_currency                    as price_iso_currency,
    case
        when dcp.products_iso_currency is not null
            then (
                select rate_src_id
                from bo.t_currency_matching cm
                where
                    cm.trade_with_iso_currency = dcp.iso_currency
                    and cm.base_iso_currency = dcp.products_iso_currency
            )
    end                                          as cb_id,
    case
        when dcp.products_iso_currency is not null
            then (
                select rate_src
                from bo.t_currency_matching cm
                where
                    cm.trade_with_iso_currency = dcp.iso_currency
                    and cm.base_iso_currency = dcp.products_iso_currency
            )
    end                                          as rate_src,
    dcp.tag_id                                   as place_tag_id
from
    bo.mv_distr_contract_places dcp,
    bo.t_partner_completion_buffer pcb,
    bo.t_page_data pd,
    bo.v_nds_pct nds
where
    (
        dcp.contract_type = 2
        or (
            dcp.contract_type in (3, 4, 6, 8)
            and dcp.uni_has_fixed = 1
        )
    )
    and pcb.dt >= dcp.dt
    and pcb.dt <= nvl(
        decode(pd.tailable, 1, dcp.end_dt, dcp.tailless_end_dt),
        to_date('01.01.9999', 'DD.MM.YYYY')
    )
    and pcb.page_id = dcp.product_id
    and pd.page_id = pcb.page_id
    and (
        (
            dcp.product_id not in (10001, 2080, 3010)
            and pcb.place_id = dcp.place_id
            and pd.unit_id = 10
        )
        or (
            dcp.product_id in (10001, 2080, 3010)
            and pcb.place_id = dcp.search_id
        )
    )
    and (nds.ndsreal_id = dcp.nds and
         pcb.dt >= nds.from_dt and
         pcb.dt < nds.to_dt)
\\
