--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114 stripComments:false endDelimiter:\\

create or replace view bo.v_partner_addapter_contract as
select
    c.id                                           as contract_id,
    c.external_id,
    c.client_id                                    as client_id,
    (
        select char_code
        from bo.t_currency
        where num_code = ca1.value_num
    )                                              as currency,
    ca1.value_str                                  as iso_currency,
    cl0.dt                                         as dt,
    ca2.value_dt - 1                               as end_dt,
    case
        when ca3.key_num = 141
            then 1
        else 0
    end                                            as is_developer,
    case
        when ca3.key_num = 142
            then 1
        else 0
    end                                            as is_retailer,
    ca3.key_num                                    as service_id,
    decode(
        ca3.key_num,
        141, 4012,
        142, 4010,
        null
    )                                              as product_id,
    ca4.value_num                                  as firm_id,
    case
        when ca5.value_num = 72
            then 0
        when pc.resident = 0
            then 0
        when pc.resident = 1 and ca4.value_num = 1
            then 18
        when pc.resident = 1 and ca4.value_num = 7
            then 8
    end                                            as nds
from
    bo.t_contract2 c
    join bo.t_person p on p.id = c.person_id
    join bo.t_person_category pc on p.type = pc.category
    left join bo.t_contract_collateral cl0 on
        cl0.contract2_id = c.id
        and cl0.collateral_type_id is null
        and cl0.num is null
        and cl0.is_cancelled is null
        and (
            cl0.is_signed is not null
            or cl0.is_faxed is not null
        )
    left join bo.v_contract_signed_attr ca1 on
        c.id = ca1.contract_id and ca1.code = 'CURRENCY'
    left join bo.v_contract_signed_attr ca2 on
        c.id = ca2.contract_id and ca2.code = 'FINISH_DT'
    left join bo.v_contract_signed_attr ca3 on
        c.id = ca3.contract_id and ca3.code = 'SERVICES'
    left join bo.v_contract_signed_attr ca4 on
        c.id = ca4.contract_id and ca4.code = 'FIRM'
    left join bo.v_contract_signed_attr ca5 on
        c.id = ca5.contract_id and ca5.code = 'COMMISSION'
where
    c.type = 'GENERAL'
    and ca3.key_num in (141, 142)
    and ca3.value_num = 1
\\
