--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for view V_OFFER_ACTIVATION_CONTRACT
--------------------------------------------------------------------------------

CREATE OR REPLACE VIEW "BO"."V_OFFER_ACTIVATION_CONTRACT" as
WITH config_services as (
          SELECT /* +MATERIALIZE */ jt.id
          FROM
            "BO"."T_CONFIG" tc,
            json_table(
              tc.value_json, '$[*]'
              columns (id number path '$')
            ) as jt
          where tc.item = 'PROCESS_TAXI_ENQUEUE_SERVICES'
)
SELECT
  contract_id,
  start_dt,
  max(nvl(end_dt, date'9999-12-31')) end_dt,
  max(payment_type) payment_type
FROM (
  SELECT
    c.id contract_id,
    cl.dt start_dt,
    nvl(
        lead (cl.dt) OVER (PARTITION BY c.id ORDER BY cl.dt),
        last_value(ca1.value_dt IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt)
    ) end_dt,
    last_value(ca2.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) payment_type
  FROM
    "BO"."T_CONTRACT2" c
      LEFT JOIN
    "BO"."T_CONTRACT_COLLATERAL" cl
        ON cl.contract2_id = c.id
      LEFT JOIN
    "BO"."T_ATTRIBUTE_VALUES" ca1
        ON cl.attribute_batch_id = ca1.attribute_batch_id and ca1.code = 'FINISH_DT'
      LEFT JOIN
    "BO"."T_ATTRIBUTE_VALUES" ca2
        ON cl.attribute_batch_id = ca2.attribute_batch_id and ca2.code = 'PAYMENT_TYPE'
  WHERE
    c.type = 'GENERAL'
    AND cl.is_cancelled IS NULL
    AND (cl.is_signed IS NOT NULL OR cl.is_faxed IS NOT NULL)
    AND exists (
      SELECT 1
      FROM "BO"."T_ATTRIBUTE_VALUES" av
      JOIN config_services cs ON av.key_num = cs.id
      WHERE
        attribute_batch_id = cl.attribute_batch_id
        AND code = 'SERVICES'
        AND value_num = 1
    )
)
GROUP BY
  contract_id, start_dt
;
