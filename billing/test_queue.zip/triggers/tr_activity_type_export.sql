--liquibase formatted sql

--changeset azurkin:BALANCE-29575-tr_activity_type_export stripComments:false splitStatements:false

CREATE OR REPLACE TRIGGER BO.tr_activity_type_export
after insert or update of name, parent_id
ON BO.T_ACTIVITY_TYPE referencing new as new
for each row
begin
  pk_export_queue.enqueue(
    p_id => :new.id,
    p_cls => 'ActivityType',
    p_queue => 'OEBS'
  );
end;
