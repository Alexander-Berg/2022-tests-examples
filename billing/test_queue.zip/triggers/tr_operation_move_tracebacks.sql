--liquibase formatted sql

/******************************************************************************
   NAME:       TR_OPERATION_MOVE_TRACEBACKS
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        09.07.2015      isupov       1. Created this trigger.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     TR_OPERATION_MOVE_TRACEBACKS
      Sysdate:         09.07.2015
      Date and Time:   09.07.2015, 16:29:36, and 09.07.2015 16:29:36
      Username:        isupov (set in TOAD Options, Proc Templates)
      Table Name:      T_OPERATION (set in the "New PL/SQL Object" dialog)
      Trigger Options:  (set in the "New PL/SQL Object" dialog)
******************************************************************************/

--changeset lightrevan:BALANCE-29780-trig stripComments:false endDelimiter:\\

CREATE OR REPLACE TRIGGER bo.tr_operation_move_tracebacks
  BEFORE INSERT OR UPDATE
  ON bo.t_operation
  REFERENCING new AS new old AS old
  FOR EACH ROW
  BEGIN

    IF :new.create_traceback_arch IS NOT NULL
    THEN
      :new.create_traceback_id := bo.pk_hash_data.create_from_compressed(
          :new.create_traceback_arch,
          :new.create_traceback_hash
      );
      :new.create_traceback_arch := NULL;
      :new.create_traceback_hash := NULL;
    END IF;

    IF :new.create_traceback IS NOT NULL
    THEN
      :new.create_traceback_id := bo.pk_hash_data.create_from_clob(:new.create_traceback);
      :new.create_traceback := NULL;
    END IF;

    IF :new.insert_traceback IS NOT NULL
    THEN
      :new.insert_traceback_id := bo.pk_hash_data.create_from_clob(:new.insert_traceback);
      :new.insert_traceback := NULL;
    END IF;

    IF :new.coverage IS NOT NULL
    THEN
      :new.coverage_id := bo.pk_hash_data.create_from_clob(:new.coverage);
      :new.coverage := NULL;
    END IF;

  END tr_operation_move_tracebacks;

\\
