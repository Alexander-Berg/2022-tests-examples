--liquibase formatted sql

--changeset azurkin:BALANCE-29575-tr_export_upd stripComments:false splitStatements:false

create or replace trigger bo.tr_export_upd
    BEFORE UPDATE OR DELETE
OF   STATE
ON bo.t_export
    REFERENCING NEW AS NEW OLD AS OLD
    FOR EACH ROW

BEGIN
    INSERT INTO bo.t_export_history(
        object_id,
        start_dt,
        end_dt,
        rate,
        state,
        error,
        enqueue_dt,
        export_dt,
        TYPE,
        classname,
        next_export,
        hostname,
        reason,
        TRACEBACK)
    VALUES (
        :OLD.object_id,
        :OLD.update_dt,
        SYSDATE,
        :OLD.rate,
        :OLD.state,
        :OLD.error,
        :OLD.export_dt,
        :OLD.enqueue_dt,
        :OLD.TYPE,
        :OLD.classname,
        :OLD.next_export,
        :OLD.hostname,
        :OLD.reason,
        :OLD.TRACEBACK
    );

    IF UPDATING
    THEN
        :NEW.update_dt := SYSDATE;
    END IF;
END;
