--liquibase formatted sql

--changeset azurkin:BALANCE-29575-tr_product_name_export stripComments:false splitStatements:false

CREATE OR REPLACE TRIGGER BO.tr_product_name_export
after insert or update of product_name, product_fullname, lang_id
ON BO.T_PRODUCT_NAME referencing new as new
for each row
begin
    pk_export_queue.enqueue(
      p_id => :new.product_id,
      p_cls => 'Product',
      p_queue => 'OEBS'
    );
end;
