--liquibase formatted sql

--changeset lightrevan:BALANCE-28170 stripComments:false endDelimiter:\\

CREATE OR REPLACE TRIGGER "BO"."TR_CONSUME_ARCHIVE" BEFORE INSERT OR UPDATE
OF CONSUME_QTY
  ,CURRENT_QTY
  ,COMPLETION_QTY
  ,ACT_QTY
  ,CURRENT_SUM
  ,COMPLETION_SUM
  ,ACT_SUM
  ,ARCHIVE
ON "BO"."T_CONSUME"
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW
BEGIN
    IF :new.CURRENT_QTY = :new.COMPLETION_QTY
       AND :new.CURRENT_QTY = :new.ACT_QTY
       AND :new.CURRENT_SUM = :new.COMPLETION_SUM
       AND :new.CURRENT_SUM = :new.ACT_SUM
    THEN
        :new.ARCHIVE := 1;
    ELSE
        :new.ARCHIVE := 0;
    END IF;

    IF :old.ARCHIVE IS NOT NULL AND :old.ARCHIVE != :new.ARCHIVE
    THEN
        pk_cache.reset_order_cache(:new.parent_order_id);
    END IF;
END;

//
