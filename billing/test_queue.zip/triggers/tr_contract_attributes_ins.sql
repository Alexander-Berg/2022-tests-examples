--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 stripComments:false endDelimiter:\\

create or replace trigger bo.tr_contract_attributes_ins
    before insert
    on bo.t_contract_attributes
    for each row
declare
    foo number;
    char_code varchar(16);
begin
    if :new.id is null then
        select s_contract_attributes_id.nextval into foo from dual;
        :new.id := foo;
    end if;

    -- BALANCE-28708: Ensure currency alpha code is filled when numeric code is present.
    if (
        :new.code in ('CURRENCY', 'PRODUCTS_CURRENCY', 'SEARCH_CURRENCY')
        and :new.value_str is null
        and :new.value_num is not null
    ) then
        select char_code into char_code
        from bo.t_currency
        where num_code = decode(:new.value_num, 643, 810, :new.value_num);
        case upper(char_code)
            when 'RUR' then :new.value_str := 'RUB';
            else :new.value_str := upper(char_code);
        end case;
    end if;
end;
\\
