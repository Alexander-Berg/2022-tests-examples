--liquibase formatted sql

--changeset azurkin:BALANCE-29575-tr_product_group_export stripComments:false splitStatements:false

CREATE OR REPLACE TRIGGER BO.tr_product_group_export
after insert or update of name, parent_id
ON BO.T_PRODUCT_GROUP referencing new as new
for each row
begin
  pk_export_queue.enqueue(
    p_id => :new.id,
    p_cls => 'ProductGroup',
    p_queue => 'OEBS'
  );
end;
