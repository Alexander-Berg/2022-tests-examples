--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28474 stripComments:false endDelimiter:\\

create or replace trigger bo.tr_service_price_upd
    before update or delete of
        id,
        service_product_id,
        dt,
        region_id,
        clid, price,
        currency,
        update_dt,
        iso_currency
    on bo.t_service_price
    for each row
begin
    insert into bo.t_service_price_history (
        id,
        start_dt,
        end_dt,
        service_product_id,
        dt,
        region_id,
        clid,
        price,
        currency,
        iso_currency
    )
    values (
        :old.id,
        :old.update_dt,
        sysdate,
        :old.service_product_id,
        :old.dt,
        :old.region_id,
        :old.clid,
        :old.price,
        :old.currency,
        :old.iso_currency
    );
    if updating
    then
        :new.update_dt := sysdate;
    end if;
end;
\\
