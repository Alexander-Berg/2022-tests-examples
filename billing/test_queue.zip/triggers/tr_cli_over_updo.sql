--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28474 stripComments:false endDelimiter:\\

create or replace trigger bo.tr_cli_over_updo
    before update of
        service_id,
        overdraft_limit,
        firm_id,
        currency,
        iso_currency
    on bo.t_client_overdraft
    for each row when (
        new.overdraft_limit <> old.overdraft_limit
        or new.firm_id <> old.firm_id
        or new.service_id <> old.service_id
        or nvl(new.currency, -1) <> nvl(old.currency, -1)
        or nvl(new.iso_currency, -1) <> nvl(old.iso_currency, -1)
    )
begin
    insert into bo.t_client_overdraft_history (
        client_id,
        start_dt,
        end_dt,
        overdraft_limit,
        currency,
        iso_currency,
        service_id,
        firm_id
    )
    values (
        :old.client_id,
        :old.update_dt,
        sysdate,
        :old.overdraft_limit,
        :old.currency,
        :old.iso_currency,
        :old.service_id,
        :old.firm_id
    );
    :new.update_dt := sysdate;
end;
\\
