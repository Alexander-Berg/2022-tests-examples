--liquibase formatted sql

--changeset lightrevan:BALANCE-29105-2 stripComments:false endDelimiter:\\

create or replace trigger bo.tr_invoice_upd
    before delete or update of
        dt,
        passport_id,
        request_id,
        request_seq,
        paysys_id,
        payment_method_id,
        legal_entity,
        resident,
        rur_sum,
        status_id,
        hidden,
        effective_sum,
        client_id,
        person_id,
        contact_id,
        external_id,
        contract_id,
        total_sum,
        manager_code,
        currency,
        nds,
        nds_pct,
        currency_rate,
        internal_rate,
        usd_rate,
        credit,
        overdraft,
        market_postpay,
        upd_contract_dt,
        agency_discount_pct,
        bank_id,
        extern,
        payment_term_id,
        unilateral,
        promo_code_id,
        turn_on_dt,
        iso_currency
    on bo.t_invoice
    for each row
DECLARE
    module_name varchar2(256);
    action_name varchar2(256);
begin
    -- optional disabling of trigger for data migrations
    -- use DBMS_APPLICATION_INFO.SET_ACTION('t_invoice migration') in each transaction
    DBMS_APPLICATION_INFO.READ_MODULE(module_name, action_name);
    IF action_name = 't_invoice migration' THEN
        RETURN;
    END IF;

    -- if both paysys and payment_method change
    -- we consider that they are changed correctly
    IF :OLD.paysys_id != :NEW.paysys_id
        AND nvl(:OLD.payment_method_id, -1) = nvl(:NEW.payment_method_id, -1) THEN

      SELECT
        ps.payment_method_id
        INTO :NEW.payment_method_id
      FROM bo.t_paysys ps
      WHERE ps.id = :NEW.paysys_id;

      IF :NEW.person_id IS NULL THEN
        SELECT
          pc.ur, pc.resident
          INTO :NEW.legal_entity, :NEW.resident
        FROM bo.t_paysys ps
        JOIN bo.t_person_category pc on ps.category = pc.category
        WHERE ps.id = :NEW.paysys_id;
      END IF;
    END IF;

    -- if person changes with either legal_entity or resident
    -- consider it correct as with paysyses
    IF nvl(:OLD.person_id, -1) != :NEW.person_id
        AND nvl(:OLD.legal_entity, -1) = nvl(:NEW.legal_entity, -1)
        AND nvl(:OLD.resident, -1) = nvl(:NEW.resident, -1) THEN

      SELECT
        pc.ur, pc.resident
        INTO :NEW.legal_entity, :NEW.resident
      FROM bo.t_person p
      JOIN bo.t_person_category pc on p.type = pc.category
      WHERE p.id = :NEW.person_id;
    END IF;

    insert into bo.t_invoice_history (
        invoice_id,
        dt,
        end_dt,
        passport_id,
        request_id,
        request_seq,
        paysys_id,
        payment_method_id,
        legal_entity,
        resident,
        rur_sum,
        status_id,
        hidden,
        effective_sum,
        client_id,
        person_id,
        contact_id,
        external_id,
        contract_id,
        total_sum,
        manager_code,
        currency,
        iso_currency,
        nds,
        nds_pct,
        currency_rate,
        internal_rate,
        usd_rate,
        credit,
        overdraft,
        market_postpay,
        upd_contract_dt,
        agency_discount_pct,
        bank_id,
        extern,
        payment_term_id,
        unilateral,
        promo_code_id,
        turn_on_dt
    )
    values (
        :old.id,
        :old.dt,
        sysdate,
        :old.passport_id,
        :old.request_id,
        :old.request_seq,
        :old.paysys_id,
        :old.payment_method_id,
        :old.legal_entity,
        :old.resident,
        :old.rur_sum,
        decode(:old.status_id, 5, 5, 0),
        :old.hidden,
        :old.effective_sum,
        :old.client_id,
        :old.person_id,
        :old.contact_id,
        :old.external_id,
        :old.contract_id,
        :old.total_sum,
        :old.manager_code,
        :old.currency,
        :old.iso_currency,
        :old.nds,
        :old.nds_pct,
        :old.currency_rate,
        :old.internal_rate,
        :old.usd_rate,
        :old.credit,
        :old.overdraft,
        :old.market_postpay,
        :old.upd_contract_dt,
        :old.agency_discount_pct,
        :old.bank_id,
        :old.extern,
        :old.payment_term_id,
        :old.unilateral,
        :old.promo_code_id,
        :old.turn_on_dt
    );
end;
\\
