--liquibase formatted sql

CREATE OR REPLACE TRIGGER bo.tr_order_insa
AFTER INSERT  ON bo.T_ORDER
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
  insert into t_object_notification(opcode, object_id, last_scn)
    values(1, :new.id, 0);
END;
