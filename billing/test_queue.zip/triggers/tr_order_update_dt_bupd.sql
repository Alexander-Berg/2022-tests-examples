--liquibase formatted sql

CREATE OR REPLACE TRIGGER BO.TR_ORDER_UPDATE_DT_BUPD
BEFORE UPDATE
OF CONSUME_SUM
  ,COMPLETION_SUM
  ,CONSUME_QTY
  ,COMPLETION_QTY
ON BO.T_ORDER
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
begin
  if ((:old.consume_sum <> :new.consume_sum) or (:old.consume_qty <> :new.consume_qty) or
  (:old.completion_sum <> :new.completion_sum) or (:old.completion_qty <> :new.completion_qty))
  then
  		:new.update_dt := sysdate;
  end if;
end;
