--liquibase formatted sql

--changeset natabers:BALANCE-28633-t_overdraft_params-trigger endDelimiter:\\
create or replace trigger bo.tr_overdraft_params_upd
  before update of id, dt, client_id, person_id, service_id, payment_method_cc, iso_currency, client_limit, hidden or delete
  on bo.t_overdraft_params referencing new as new old as old
  for each row
  begin
    insert into bo.t_overdraft_params_history (overdraft_params_id, dt, client_id, person_id, service_id, payment_method_cc, iso_currency, client_limit, hidden)
      values(:old.id, :old.dt, :old.client_id, :old.person_id, :old.service_id, :old.payment_method_cc, :old.iso_currency, :old.client_limit, :old.hidden);
  end;
\\
