--liquibase formatted sql

--changeset yanametro:BALANCE-25180 stripComments:false endDelimiter:\\
CREATE OR REPLACE TRIGGER bo.tr_th_corr_export_insert
after insert on bo.t_thirdparty_corrections
for each row
  begin
    if (:new.auto = 0) then
      pk_export_queue.enqueue(:new.id, 'ThirdPartyCorrection', 'OEBS', 0);
    end if;
  end;

\\
