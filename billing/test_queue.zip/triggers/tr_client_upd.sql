--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28474 stripComments:false endDelimiter:\\

create or replace trigger bo.tr_client_upd
    before update
    on bo.t_client
    for each row
begin
    if
        (
            :new.manual_suspect_comment is not null
            and :old.manual_suspect_comment is not null
            and dbms_lob.compare(
                :new.manual_suspect_comment,
                :old.manual_suspect_comment
            ) = -1
        )
        or (
            :new.manual_suspect_comment is not null
            and :old.manual_suspect_comment is null
        )
        or (
            :new.manual_suspect_comment is null
            and :old.manual_suspect_comment is not null
        )
        or nvl(:new.name, -1) <> nvl(:old.name, -1)
        or nvl(:new.email, -1) <> nvl(:old.email, -1)
        or :new.dt <> :old.dt
        or :new.client_type_id <> :old.client_type_id
        or nvl(:new.phone, -1) <> nvl(:old.phone, -1)
        or nvl(:new.fax, -1) <> nvl(:old.fax, -1)
        or nvl(:new.url, -1) <> nvl(:old.url, -1)
        or :new.is_agency <> :old.is_agency
        or nvl(:new.person_id, -1) <> nvl(:old.person_id, -1)
        or nvl(:new.id_1c, -1) <> nvl(:old.id_1c, -1)
        or :new.internal <> :old.internal
        or nvl(:new.is_wholesaler, -1) <> nvl(:old.is_wholesaler, -1)
        or :new.full_repayment <> :old.full_repayment
        or :new.class_id <> :old.class_id
        or :new.agency_id <> :old.agency_id
        or nvl(:new.oper_id, -1) <> nvl(:old.oper_id, -1)
        or nvl(:new.creator_uid, -1) <> nvl(:old.creator_uid, -1)
        or :new.manual_suspect <> :old.manual_suspect
        or nvl(:new.is_aggregator, -1) <> nvl(:old.is_aggregator, -1)
        or :new.direct25 <> :old.direct25
        or :new.is_docs_separated <> :old.is_docs_separated
        or :new.is_docs_detailed <> :old.is_docs_detailed
        or :new.budget <> :old.budget
        or :new.overdraft_limit <> :old.overdraft_limit
        or :new.overdraft_ban <> :old.overdraft_ban
        or nvl(:new.region_id, -1) <> nvl(:old.region_id, -1)
        or :new.partner_type <> :old.partner_type
        or :new.subregion_id <> :old.subregion_id
        or :new.office_id <> :old.office_id
        or :new.deny_cc <> :old.deny_cc
        or nvl(:new.iso_currency_payment, -1)
           <> nvl(:old.iso_currency_payment, -1)
    then
        insert into bo.t_client_history_v2 (
            client_id,
            start_dt,
            end_dt,
            client_type_id,
            name,
            email,
            phone,
            fax,
            url,
            is_agency,
            person_id,
            id_1c,
            internal,
            is_wholesaler,
            full_repayment,
            class_id,
            agency_id,
            oper_id,
            suspect,
            creator_uid,
            manual_suspect,
            is_aggregator,
            direct25,
            is_docs_separated,
            is_docs_detailed,
            manual_suspect_comment,
            budget,
            overdraft_limit,
            overdraft_ban,
            region_id,
            partner_type,
            subregion_id,
            office_id,
            deny_cc,
            iso_currency_payment
        )
        values (
            :old.id,
            :old.dt,
            sysdate,
            :old.client_type_id,
            :old.name,
            :old.email,
            :old.phone,
            :old.fax,
            :old.url,
            :old.is_agency,
            :old.person_id,
            :old.id_1c,
            :old.internal,
            :old.is_wholesaler,
            :old.full_repayment,
            :old.class_id,
            :old.agency_id,
            :old.oper_id,
            :old.suspect,
            :old.creator_uid,
            :old.manual_suspect,
            :old.is_aggregator,
            :old.direct25,
            :old.is_docs_separated,
            :old.is_docs_detailed,
            :old.manual_suspect_comment,
            :old.budget,
            :old.overdraft_limit,
            :old.overdraft_ban,
            :old.region_id,
            :old.partner_type,
            :old.subregion_id,
            :old.office_id,
            :old.deny_cc,
            :old.iso_currency_payment
        );

        :new.dt := sysdate;
    end if;
end;
\\
