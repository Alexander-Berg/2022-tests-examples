--liquibase formatted sql

--changeset shorrty:BALANCE-26274-12 stripComments:false endDelimiter:\\
create or replace trigger bo.tr_yt_export_metadata_inc
after insert or update on bo.t_yt_export_metadata
referencing new as new old as old
for each row
declare
    l_is_table      number;
    l_db_id         varchar2(8);
    l_tbl_name      varchar2(64);
    l_tbl_owner     varchar2(32);
begin
    if :new.is_incremental = 1 then
        l_tbl_owner := upper(substr(:new.source, 1, instr(:new.source, '.')-1));
        l_tbl_name := upper(substr(:new.source, instr(:new.source, '.')+1));

        -- является ли таблицей
        select count(1) into l_is_table from all_tables 
         where owner = l_tbl_owner
           and table_name = l_tbl_name;

        if l_is_table = 0 then
            raise_application_error (-20999, 'Only tables are supported for inc export');
        end if;

        select count(1) into l_is_table from all_tab_columns
         where owner = l_tbl_owner
           and table_name = l_tbl_name
           and column_name = 'ID';

        if l_is_table = 0 then
            raise_application_error (-20999, 'There is should be ID column in '||
                l_tbl_name||' table for inc export');
        end if;

        -- RO нельзя, т.к. изменения еще не будут доезжать до RO,
        -- когда мы захотим их экспортировать и пометить, что экспортировали
        if lower(substr(:new.database_id, -3)) = '_ro' then
            raise_application_error (-20999, 'RO db is not allowed');
        end if;
    end if;
end;

\\
