--liquibase formatted sql

--changeset azurkin:BALANCE-29575-tr_cur_rate2_insupd stripComments:false splitStatements:false

CREATE OR REPLACE TRIGGER BO.TR_CUR_RATE2_INSUPD
AFTER INSERT OR UPDATE of rate
ON BO.T_CURRENCY_RATE_V2
REFERENCING NEW AS NEW
FOR EACH ROW
begin
  pk_export_queue.enqueue(
    p_id => :new.id,
    p_cls => 'CurrencyRate',
    p_queue => 'OEBS'
  );
end;
