--liquibase formatted sql

--changeset azurkin:BALANCE-29575-tr_product_export stripComments:false splitStatements:false

create or replace trigger bo.tr_product_export
after insert or update of name, fullname, engine_id, product_group_id, activity_type_id, unit_id, hide_contract
on bo.t_product
referencing new as new
for each row
begin
  -- skip trust products
  if nvl(:new.common, 0) != 1 then
    pk_export_queue.enqueue(
      p_id => :new.id,
      p_cls => 'Product',
      p_queue => 'OEBS'
    );
  end if;
end;
