--liquibase formatted sql

--changeset natabers:BALANCE-29642 stripComments:false endDelimiter:\\

CREATE OR REPLACE TRIGGER TR_EXPORT_TYPE_PARTITIONING
  AFTER INSERT
  ON T_EXPORT_TYPE
  FOR EACH ROW
  DECLARE
    partition_count NUMBER;
    subpart_tmpl_count NUMBER;
    cmd_add_partition VARCHAR2(4096);
    TPL VARCHAR2(4096);
    ex  NUMBER;
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN

  -- t_export partitions
  SELECT count(partition_name) INTO partition_count FROM user_tab_partitions
    WHERE partition_name = :NEW.TYPE AND TABLE_NAME = 'T_EXPORT';

  IF partition_count = 0 THEN
    EXECUTE IMMEDIATE 'ALTER TABLE BO.T_EXPORT ADD PARTITION ' || :NEW.TYPE || ' VALUES (''' || :NEW.TYPE || ''')';
  END IF;

  -- t_export_history subpartition_template
  SELECT count(subpartition_name) INTO subpart_tmpl_count FROM user_subpartition_templates
    WHERE table_name = 'T_EXPORT_HISTORY' and subpartition_name = :NEW.TYPE;

  IF subpart_tmpl_count = 0 THEN
    SELECT 'ALTER TABLE BO.T_EXPORT_HISTORY SET SUBPARTITION TEMPLATE (' ||
             LISTAGG('SUBPARTITION ' || PARTITION_NAME || ' VALUES(''' || PARTITION_NAME || ''')', ', ' || CHR(10))
             WITHIN GROUP (ORDER BY 1) || ')' tmpl
    INTO TPL
    FROM ALL_TAB_PARTITIONS
    WHERE TABLE_NAME = 'T_EXPORT' AND TABLE_OWNER = 'BO';
    DBMS_OUTPUT.PUT_LINE(TPL);
    EXECUTE IMMEDIATE TPL;
  END IF;

  -- t_export_history subpartitions
  FOR need IN (SELECT
                     tp2.PARTITION_NAME,
                     tp1.HIGH_VALUE,
                     tp1.PARTITION_NAME PNAME
                   FROM ALL_TAB_PARTITIONS tp1
                     CROSS JOIN
                     ALL_TAB_PARTITIONS tp2
                   WHERE tp1.TABLE_NAME = 'T_EXPORT' AND tp1.TABLE_OWNER = 'BO'
                         AND tp2.TABLE_NAME = 'T_EXPORT_HISTORY' AND tp2.TABLE_OWNER = 'BO')
      LOOP
        ex := 0;
        FOR parts IN (SELECT
                        sub.PARTITION_NAME,
                        HIGH_VALUE
                      FROM ALL_TAB_SUBPARTITIONS sub
                      WHERE sub.table_name = 'T_EXPORT_HISTORY' AND sub.TABLE_OWNER = 'BO'
                            AND sub.PARTITION_NAME = need.PARTITION_NAME)
        LOOP
          IF parts.HIGH_VALUE = need.HIGH_VALUE
          THEN
            ex := 1;
            EXIT;
          END IF;
        END LOOP;

        IF ex = 0  -- if subpartitions does not exist
        THEN
          TPL := 'ALTER TABLE BO.T_EXPORT_HISTORY MODIFY PARTITION ' ||
                 need.PARTITION_NAME || ' ADD SUBPARTITION ' ||
                 need.PARTITION_NAME || '_' ||
                 need.PNAME || ' VALUES (' || need.HIGH_VALUE || ')';
          DBMS_OUTPUT.PUT_LINE(TPL);
          EXECUTE IMMEDIATE TPL;
         END IF;
      END LOOP;
END;
\\
