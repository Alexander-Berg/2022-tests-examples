--liquibase formatted sql

--changeset lightrevan:BALANCE-25286 stripComments:false endDelimiter:\\

CREATE OR REPLACE PROCEDURE bo.delete_pycron_task
  (p_name in varchar2)
IS
BEGIN
  DELETE FROM bo.t_pycron_state
        WHERE id IN (
          SELECT id
            FROM bo.t_pycron_lock
           WHERE name = p_name
        )
  ;
  DELETE FROM bo.t_pycron_lock
        WHERE name = p_name
  ;
  DELETE FROM bo.t_pycron_schedule
        WHERE name = p_name
  ;
  DELETE FROM bo.t_pycron_responsible
        WHERE task_name = p_name
  ;
  DELETE FROM bo.t_pycron_descr
        WHERE name = p_name
  ;
  DELETE FROM bo.t_pycron_state_history
        WHERE name = p_name
  ;
END;

\\
