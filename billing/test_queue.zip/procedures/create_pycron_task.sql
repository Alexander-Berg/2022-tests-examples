--liquibase formatted sql

--changeset lightrevan:BALANCE-29802 stripComments:false endDelimiter:\\

CREATE OR REPLACE PROCEDURE bo.create_pycron_task
  ( p_name in varchar2
  , d_command in varchar2
  , d_description in varchar2
  , d_owner_login in varchar2
  , s_crontab in varchar2 default null
  , s_run_at_dt in date default null
  , s_mnclose_task in varchar2 default null
  , s_mnclose_run_opened in number default null
  , d_count_per_host in number DEFAULT null
  , d_timeout in number DEFAULT 900
  , d_terminate in number DEFAULT 0
  , r_email in varchar2 DEFAULT 'balance-monitoring@yandex-team.ru'
  , s_host in varchar2 DEFAULT null
  , s_enabled in number DEFAULT 1
  , s_retry_count in number DEFAULT null
  , s_retry_interval in number DEFAULT 5
  )
IS
BEGIN
  DELETE FROM bo.t_pycron_schedule
        WHERE name = p_name
  ;
  DELETE FROM bo.t_pycron_responsible
        WHERE task_name = p_name
  ;
  DELETE FROM bo.t_pycron_descr
        WHERE name = p_name
  ;

  INSERT INTO bo.t_pycron_descr ( name, command, timeout, description
                                , count_per_host, terminate, owner_login
                                )
                         VALUES ( p_name, d_command, d_timeout, d_description
                                , d_count_per_host, d_terminate, d_owner_login
                                )
  ;
  INSERT INTO bo.t_pycron_responsible (task_name, email)
                               VALUES (p_name, r_email)
  ;
  INSERT INTO bo.t_pycron_schedule ( id, name
                                   , crontab, run_at_dt, mnclose_task, mnclose_run_opened
                                   , host, enabled, retry_count, retry_interval
                                   )
                            VALUES ( bo.s_pycron_schedule.nextval, p_name
                                   , s_crontab, s_run_at_dt, s_mnclose_task, s_mnclose_run_opened
                                   , s_host, s_enabled, s_retry_count, s_retry_interval
                                   )
  ;
  DELETE FROM bo.t_pycron_state_history
        WHERE name = p_name
  ;
END;

\\
