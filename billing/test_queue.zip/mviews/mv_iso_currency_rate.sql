--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708 endDelimiter:\\

create materialized view bo.mv_iso_currency_rate
    refresh force start with sysdate next sysdate + 10 / 1440
as
    select * from bo.v_iso_currency_rate
\\
