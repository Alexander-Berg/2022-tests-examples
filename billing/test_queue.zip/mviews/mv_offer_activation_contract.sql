--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for materialized view MV_OFFER_ACTIVATION_CONTRACT
--------------------------------------------------------------------------------

CREATE MATERIALIZED VIEW "BO"."MV_OFFER_ACTIVATION_CONTRACT" (
    "CONTRACT_ID", "START_DT", "END_DT", "PAYMENT_TYPE"
  )
  BUILD IMMEDIATE
  USING INDEX
  REFRESH FORCE ON DEMAND START WITH sysdate + 0 NEXT sysdate + 1/144
  USING DEFAULT LOCAL ROLLBACK SEGMENT
  USING ENFORCED CONSTRAINTS DISABLE QUERY REWRITE
AS
  SELECT
    "CONTRACT_ID",
    "START_DT",
    "END_DT",
    "PAYMENT_TYPE"
  FROM
    "BO"."V_OFFER_ACTIVATION_CONTRACT"
;
