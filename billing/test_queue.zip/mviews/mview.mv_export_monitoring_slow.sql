--liquibase formatted sql


/* BALANCE-19382
 */
CREATE MATERIALIZED VIEW bo.mv_export_monitoring_slow
BUILD IMMEDIATE
REFRESH COMPLETE
NEXT (SYSDATE + 15 / 1440)
AS
SELECT * from bo.v_export_monitoring_slow

--changeset el-yurchito:BALANCE-26069
drop MATERIALIZED VIEW BO.MV_EXPORT_MONITORING_SLOW;
