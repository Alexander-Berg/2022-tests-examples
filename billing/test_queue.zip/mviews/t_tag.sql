--liquibase formatted sql

--changeset natabers:BALANCE-24007-3

CREATE MATERIALIZED VIEW BO.T_TAG
REFRESH FORCE ON DEMAND START WITH sysdate+0 NEXT sysdate+1/144
  AS
SELECT * FROM "BO"."T_TAG"@"METADB.YANDEX.RU" "T_TAG";

--changeset natabers:BALANCE-24007-4

call SYSTEM.P_INFR_MVMON('BO', 'T_TAG', 10, 1440, 'N');
