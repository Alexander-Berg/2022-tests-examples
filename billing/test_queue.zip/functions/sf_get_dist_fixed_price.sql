--liquibase formatted sql

--changeset vorobyov-as:BALANCE-29730 stripComments:false endDelimiter:\\

create or replace function sf_get_dist_fixed_price
( p_dt in date,
  p_contract_id in number,
  p_page_id in number
) return number deterministic as
scl_id number;
scale_name varchar2(128);
budget number;
price number;
begin
    select fixed_scale_id into scl_id from bo.v_distribution_contract
        where id = p_contract_id and
              dt <= p_dt and nvl(end_dt, p_dt + 1) >= p_dt;
    if p_page_id in (10001, 2080, 3010) or scl_id = 0 then
        begin
        select price into price from bo.mv_dist_contract_download_prod
            where page_id = p_page_id and
                 contract_id = p_contract_id and
                 dt <= p_dt and nvl(end_dt, p_dt + 1) >= p_dt;
        return price;
        exception
            when NO_DATA_FOUND
            then return 0;
        end;
     elsif scl_id > 0 then
     begin

        select ds_prod.scale_name
            into scale_name
            from bo.t_distr_download_scale_prod ds_prod, bo.t_distr_download_scale ds
            where
              ds_prod.download_type_id = p_page_id and
              ds.id = scl_id and
              ds_prod.download_scale_id = ds.id and
              hidden = 0 and
              nvl(start_dt, p_dt - 1) <= p_dt and
              nvl(end_dt, p_dt + 1) >= p_dt;

         select sum(shows)
             into budget
             from bo.v_distr_fixed_turnover
             where contract_id = p_contract_id and
                   page_id = p_page_id and
                   dt >= trunc(p_dt, 'month') and
                   dt < add_months(trunc(p_dt, 'month'), 1);
         return bo.sf_eval_scale(scale_name, p_dt, budget);
     end;
     end if;
     return 0;
end;

\\