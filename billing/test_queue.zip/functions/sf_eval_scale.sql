--liquibase formatted sql

--changeset vorobyov-as:BALANCE-29731 stripComments:false endDelimiter:\\


create or replace function

sf_eval_scale(
  p_scale_name IN VARCHAR2,
  p_dt IN DATE,
  p_val IN NUMBER
) RETURN NUMBER DETERMINISTIC
as
v_y NUMBER;
cursor c is
      select x, y from bo.t_scale_points where hidden = 0 and nvl(start_dt, p_dt - 1) <= p_dt and
      nvl(end_dt, p_dt + 1) >= p_dt and scale_code = p_scale_name and namespace = 'distribution'
      order by x;
begin
   for scale_val in c loop
   begin
    if p_val >= scale_val.x then
      v_y:= scale_val.y;
    end if;
   end;
   END LOOP;
   return v_y;
end;
\\

