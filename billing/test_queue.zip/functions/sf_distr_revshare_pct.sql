--liquibase formatted sql

--changeset vorobyov-as:scale_cash_fix stripComments:false endDelimiter:\\

create or replace function sf_distr_revshare_pct (
    p_dt in date,
    p_scale in varchar2,
    p_contract_id in number,
    p_page_id in number
) return number deterministic as

    unit_id number;
    start_month date;
    x_val number;
    pct number;

begin

    begin
        select pct into pct
        from bo.t_distr_scale_pct
        where contract_id = p_contract_id and
              page_id = p_page_id and
              month_dt = trunc(p_dt, 'month');
    exception
        when no_data_found then
            select y into pct
            from (
                select y
                    from bo.t_scale_points
                    where
                        scale_code = p_scale and
                        namespace = 'distribution' and
                        hidden = 0 and
                        nvl(start_dt, p_dt) <= p_dt and
                        nvl(end_dt, p_dt+1) >  p_dt
                    order by x
            ) where rownum = 1;
    end;

    return pct;
end;
\\