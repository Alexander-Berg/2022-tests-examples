--liquibase formatted sql

--changeset el-yurchito:BALANCE-29540-1 endDelimiter:\\
CREATE TABLE "BO"."T_CONTRACT_PDF_EMAIL"
(
  "ID" NUMBER PRIMARY KEY NOT NULL,
  "HIDDEN" NUMBER DEFAULT 0 NOT NULL,
  "FIRM_ID" NUMBER NOT NULL,
  "EMAIL" VARCHAR2(64) NOT NULL,
  CONSTRAINT "FK_CPE_FIRM_ID"
    FOREIGN KEY ("FIRM_ID")
    REFERENCES "META"."T_FIRM" ("ID") ENABLE
)
\\

--changeset el-yurchito:BALANCE-29540-2 endDelimiter:\\
CREATE SEQUENCE "BO"."S_CONTRACT_PDF_EMAIL_PK"
\\

--changeset el-yurchito:BALANCE-29540-3 endDelimiter:\\
CREATE INDEX "BO"."IDX_CPE_FIRM_ID" ON "BO"."T_CONTRACT_PDF_EMAIL" ("FIRM_ID")
\\

--changeset el-yurchito:BALANCE-29540-4 endDelimiter:\\
CREATE OR REPLACE TRIGGER "BO"."TR_CONTRACT_PDF_EMAIL_INS"
  BEFORE INSERT ON "BO"."T_CONTRACT_PDF_EMAIL"
  FOR EACH ROW
BEGIN
  IF :new.id IS NULL THEN
    SELECT "BO"."S_CONTRACT_PDF_EMAIL_PK".nextval INTO :new.id FROM dual;
  END IF;
END;
\\

--changeset el-yurchito:BALANCE-29540-5 endDelimiter:\\
INSERT INTO "BO"."T_CONTRACT_PDF_EMAIL" ("FIRM_ID", "EMAIL")
    SELECT 13, 'corptaxi-docs@yandex-team.ru' FROM dual
      UNION ALL
    SELECT 13, 'taxi-docs@yandex-team.ru' FROM dual
      UNION ALL
    SELECT 13, 'taxi-new@yandex-team.ru' FROM dual
      UNION ALL
    SELECT 22, 'documents@taxi.yandex.com' FROM dual
      UNION ALL
    SELECT 115, 'documents@taxi.yandex.com' FROM dual
      UNION ALL
    SELECT 26, 'documents@taxi.yandex.com' FROM dual
      UNION ALL
    SELECT 24, 'documents@taxi.yandex.com' FROM dual
      UNION ALL
    SELECT 31, 'documents@taxi.yandex.com' FROM dual
      UNION ALL
    SELECT 25, 'docs@support.yandex.kz' FROM dual
      UNION ALL
    SELECT 1, 'comission@yandex-team.ru' FROM dual
      UNION ALL
    SELECT 1, 'docs-project@yandex-team.ru' FROM dual
      UNION ALL
    SELECT 18, 'com-ofd@yandex-team.ru' FROM dual
      UNION ALL
    SELECT 111, 'market-docs@yandex-team.ru' FROM dual
      UNION ALL
    SELECT 7, 'vip-invoice@support.yandex.com' FROM dual
      UNION ALL
    SELECT 12, 'classifieds-docs@yandex-team.ru' FROM dual
      UNION ALL
    SELECT 113, 'docs-project@yandex-team.ru' FROM dual
\\
