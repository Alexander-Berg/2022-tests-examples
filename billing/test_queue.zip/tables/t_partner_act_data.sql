--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_PARTNER_ACT_DATA
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_PARTNER_ACT_DATA"
   (	"PARTNER_CONTRACT_ID" NUMBER NOT NULL ENABLE,
	"PLACE_ID" NUMBER,
	"PAGE_ID" NUMBER,
	"OWNER_ID" NUMBER,
	"CLICKS" NUMBER,
	"SHOWS" NUMBER,
	"BUCKS" NUMBER,
	"DESCRIPTION" VARCHAR2(256 BYTE),
	"DT" DATE,
	"COMMISSION_PCT" NUMBER,
	"AGGREGATOR_PCT" NUMBER,
	"NDS" NUMBER,
	"PRODUCT_PRICE" NUMBER,
	"TYPE_ID" NUMBER,
	"PARTNER_REWARD" NUMBER,
	"AGGREGATOR_REWARD" NUMBER,
	"DOMAIN" VARCHAR2(512 BYTE),
	"PARTNER_REWARD_WO_NDS" NUMBER,
	"AGGREGATOR_REWARD_WO_NDS" NUMBER,
	"TURNOVER" NUMBER,
	"PARTNER_CONTRACT_EID" NUMBER,
	"END_DT" DATE,
	"STATUS" NUMBER NOT NULL ENABLE,
	"COMPLETION_TYPE" NUMBER,
	"PLACE_TYPE" NUMBER,
	"AGGREGATOR_NAME" VARCHAR2(256 BYTE),
	"AVG_DISCOUNT_PCT" NUMBER,
	"AVG_COMMISSION_PCT" NUMBER,
	"FACTOR_PCT" NUMBER,
	"ACT_REWARD_WO_NDS" NUMBER,
	"ACT_REWARD" NUMBER,
	"ACT_TURNOVER" NUMBER,
	"UPDATE_DT" DATE,
	"BLOCK_ID" NUMBER,
	"DSP_ID" NUMBER,
	"DSP_CHARGE" NUMBER,
	"CURRENCY" VARCHAR2(32 BYTE),
	"HITS" NUMBER,
	"TAG_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset nebaruzdin:BALANCE-23787

alter table bo.t_partner_act_data add iso_currency varchar2(16);

--changeset vorobyov-as:BALANCE-25148

alter table bo.t_partner_act_data add real_contract_id number;

--changeset vorobyov-as:BALANCE-27096
alter table bo.t_partner_act_data add product_id number;

--changeset vorobyov-as:BALANCE-27311_1
create index bo.IPARTNER_ACT_DATA_PCID on bo.T_PARTNER_ACT_DATA(PARTNER_CONTRACT_ID) parallel 16 online;

--changeset vorobyov-as:BALANCE-27311_2
alter index bo.IPARTNER_ACT_DATA_PCID noparallel;

--changeset vorobyov-as:BALANCE-27311_3
create index bo.IPARTNER_ACT_DT on bo.T_PARTNER_ACT_DATA(DT) parallel 16 online;

--changeset vorobyov-as:BALANCE-27311_4
alter index bo.IPARTNER_ACT_DT noparallel;

--changeset vorobyov-as:BALANCE-27311_5
create index bo.IPARTNER_ACT_DTPCID on bo.T_PARTNER_ACT_DATA(DT, PARTNER_CONTRACT_ID) parallel 16 online;

--changeset vorobyov-as:BALANCE-27311_6
alter index bo.IPARTNER_ACT_DTPCID noparallel;

--changeset vorobyov-as:BALANCE-27311_7 endDelimiter:\\
begin
    dbms_stats.gather_table_stats('BO', 'T_PARTNER_ACT_DATA', degree => 6);
end;
\\

--changeset quark:BALANCE-28489
alter table t_partner_act_data add (ref_partner_reward_wo_nds number, reference_currency varchar2(32));

--changeset vorobyov-as:BALANCE-28162
alter table bo.t_partner_act_data add report_dt date;

--changeset vorobyov-as:BALANCE-28162-2
alter table bo.t_partner_act_data add report_end_dt date;

--changeset nebaruzdin:BALANCE-28708

alter table bo.t_partner_act_data add reference_iso_currency varchar2(16);

--changeset el-yurchito:BALANCE-29431 endDelimiter:\\
ALTER TABLE "BO"."T_PARTNER_ACT_DATA"
		MODIFY "UPDATE_DT" DEFAULT sysdate
\\
