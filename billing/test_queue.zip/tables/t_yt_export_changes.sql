--liquibase formatted sql

--changeset shorrty:BALANCE-26486-0
create table bo.t_yt_export_changes (
    id                      number generated as identity,
    source_name             varchar2(128) not null,
    object_id               number not null,
    dml_dt                  date not null,
    dml_type                varchar2(2) not null,
    is_exported             number default 0 not null ,
    export_dt               date
) tablespace yacc_personts
partition by range (dml_dt) interval (numtodsinterval(1, 'DAY'))
subpartition by list (is_exported)
subpartition template (
    subpartition p_needs_exp values(0),
    subpartition p_exported values(1)
)
(partition p0  values less than (date'2017-10-01'));

--changeset shorrty:BALANCE-26486-1
CREATE INDEX i_yt_export_changes_src ON bo.t_yt_export_changes(source_name)
LOCAL PARALLEL 4 TABLESPACE YACC_PERSONTS;

--changeset shorrty:BALANCE-26486-2
ALTER TABLE bo.t_yt_export_changes ENABLE ROW MOVEMENT;
