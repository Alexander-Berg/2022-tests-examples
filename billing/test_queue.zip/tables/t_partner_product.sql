--liquibase formatted sql

--changeset quark:BALANCE-26189-666
create sequence bo.s_partner_product_id;

create table bo.t_partner_product
(
  id                   number        default bo.s_partner_product_id.nextval,
  product_id           number        not null,
  service_id           number        not null,
  currency_iso_code    varchar2(256) not null,
  order_type           varchar2(256) default null,
  unified_account_root number        default 0,
  netting_payment_type varchar2(256)
);

--changeset quark:BALANCE-26189-2
call dbms_mview.refresh('bo.t_product');

--changeset quark:BALANCE-26189-3
call dbms_mview.refresh('bo.t_price');

--changeset quark:BALANCE-26189-4
call dbms_mview.refresh('bo.t_tax');

--changeset quark:BALANCE-26189-5
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 503352, 111, 'RUB', 'order', 1, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 505142, 128, 'RUB', 'order', 1, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 508625, 111, 'RUB', 'childchair', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, (select id from bo.t_product where engine_id = 128 and name = 'Арендная плата за временное владение и пользование Автокреслами'), 128, 'RUB', 'childchair', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 503352, 111, 'RUB', 'commission_correction', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 505142, 128, 'RUB', 'commission_correction', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 503352, 111, 'RUB', 'driver_workshift', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 505142, 128, 'RUB', 'driver_workshift', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 507859, 111, 'USD', 'commission_correction', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 507860, 128, 'USD', 'commission_correction', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 507859, 111, 'USD', 'order', 1, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 507860, 128, 'USD', 'order', 1, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 507862, 111, 'EUR', 'commission_correction', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 507863, 128, 'EUR', 'commission_correction', 0, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 507862, 111, 'EUR', 'order', 1, 'correction_commission');
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 507863, 128, 'EUR', 'order', 1, 'correction_commission');

-- changeset quark:BALANCE-27348-1
insert into bo.t_partner_product (product_id, currency_iso_code, service_id, order_type, netting_payment_type)
    values (504076, 'RUB', 80, 'apx', null);

insert into bo.t_partner_product (product_id, currency_iso_code, service_id, order_type, netting_payment_type)
    values (504317, 'USD', 80, 'apx', null);

insert into bo.t_partner_product (product_id, currency_iso_code, service_id, order_type, netting_payment_type)
    values (504318, 'EUR', 80, 'apx', null);

insert into bo.t_partner_product (product_id, currency_iso_code, service_id, order_type, netting_payment_type)
    values (504319, 'CHF', 80, 'apx', null);


insert into bo.t_partner_product (product_id, currency_iso_code, service_id, unified_account_root)
    values (503364, 'RUB', 80, 1);

insert into bo.t_partner_product (product_id, currency_iso_code, service_id, unified_account_root)
    values (503365, 'USD', 80, 1);

insert into bo.t_partner_product (product_id, currency_iso_code, service_id, unified_account_root)
    values (503366, 'EUR', 80, 1);

insert into bo.t_partner_product (product_id, currency_iso_code, service_id, unified_account_root)
    values (503367, 'CHF', 80, 1);

--changeset quark:BALANCE-27463

insert into bo.t_partner_product (product_id, service_id, currency_iso_code, order_type, unified_account_root, netting_payment_type)
    values (507907, 111, 'UAH', 'order', 1, 'correction_commission');

insert into bo.t_partner_product (product_id, service_id, currency_iso_code, order_type, unified_account_root, netting_payment_type)
    values (507999, 128, 'UAH', 'order', 1, 'correction_commission');


--changeset quark:BALANCE-27622-2

insert into bo.t_partner_product (product_id, service_id, currency_iso_code, order_type, unified_account_root, netting_payment_type)
    values (509001, 111, 'RUB', 'hiring_with_car', 0, 'correction_commission');

insert into bo.t_partner_product (product_id, service_id, currency_iso_code, order_type, unified_account_root, netting_payment_type)
    values (509005, 128, 'RUB', 'hiring_with_car', 0, 'correction_commission');


--changeset el-yurchito:BALANCE-28141 endDelimiter:\\
ALTER TABLE "BO"."T_PARTNER_PRODUCT"
  ADD (
    "SERVICE_PRODUCT_ID" NUMBER,
    "END_DT" DATE
  )
\\

--changeset el-yurchito:BALANCE-28141-1 endDelimiter:\\
CREATE INDEX "BO"."IDX_PARTNER_PRODUCT_SP_ID"
  ON "BO"."T_PARTNER_PRODUCT" ("SERVICE_PRODUCT_ID")
  ONLINE
\\

--changeset el-yurchito:BALANCE-28141-2 endDelimiter:\\
CREATE INDEX "BO"."IDX_PARTNER_PRODUCT_END_DT"
  ON "BO"."T_PARTNER_PRODUCT" ("END_DT")
  ONLINE
\\


--changeset quark:BALANCE-27763

update bo.t_partner_product set order_type = 'main' where order_type is NULL;
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.s_partner_product_id.nextval, 504690, 120, 'RUB', 'main', 0, null);
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.s_partner_product_id.nextval, 507945, 151, 'RUB', 'main', 0, null);
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.s_partner_product_id.nextval, 505136, 126, 'RUB', 'main', 0, null);

--changeset quark:BALANCE-27763-not-null

alter table
  bo.t_partner_product
modify order_type varchar2(256) default 'main' not null;

--changeset quark:BALANCE-27763-constraint

alter table
  bo.t_partner_product
add constraint
  partner_product_unique
unique (product_id,
        service_id,
	currency_iso_code,
	order_type);

--changeset quark:BALANCE-27763-ar-products-2

insert into bo.t_partner_product (PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE)
select
  p.id,
  p.engine_id,
  u.iso_currency
from bo.t_product p join bo.t_product_unit u on p.unit_id = u.id
  where
    1 = 1
    and p.engine_id in (607, 617, 610, 601, 205, 151, 153, 172, 120, 603, 130, 135, 131, 118, 126, 605, 125, 171, 23, 602)
    and hidden = 0
    and iso_currency is not null
    and not exists (select * from bo.t_partner_product pp where pp.service_id = p.engine_id and pp.CURRENCY_ISO_CODE = u.iso_currency)
  order by p.engine_id;

--changeset quark:BALANCE-28365

update bo.t_partner_product set unified_account_root = 1 where service_id = 135;

--changeset el-yurchito:BALANCE-28402 endDelimiter:\\
INSERT INTO "BO"."T_PARTNER_PRODUCT"
  ("ID", "PRODUCT_ID", "SERVICE_ID", "CURRENCY_ISO_CODE", "ORDER_TYPE", "UNIFIED_ACCOUNT_ROOT", "NETTING_PAYMENT_TYPE")
VALUES
  ("BO"."S_PARTNER_PRODUCT_ID".nextval, 509192, 135, 'KZT', 'main', 1, 'correction_commission')
\\

--changeset quark:BALANCE-28451
call dbms_mview.refresh('bo.t_product');
call dbms_mview.refresh('bo.t_price');
call dbms_mview.refresh('bo.t_tax');

insert into bo.t_partner_product (PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE)
  select p.id, p.engine_id, u.iso_currency from bo.t_product p join bo.t_product_unit u on p.unit_id = u.id
  where
    (p.engine_id = 124 and hidden = 0
    or p.engine_id in (125, 605) and common = 0)
    and not exists (select * from bo.t_partner_product pp where pp.product_id = p.id and pp.service_id = p.engine_id)
;


--changeset yanametro:BALANCE-28419
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.s_partner_product_id.nextval, 508898, 610, 'RUB', 'bm_ag', 0, null);
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.s_partner_product_id.nextval, 509237, 610, 'RUB', 'bm_delivery', 0, null);


--changeset yanametro:BALANCE-28619
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.s_partner_product_id.nextval, 508330, 170, 'RUB', 'main', 0, null);
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.s_partner_product_id.nextval, 508331, 270, 'RUB', 'main', 0, null);
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.s_partner_product_id.nextval, 509026, 611, 'RUB', 'main', 0, null);
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE) VALUES (bo.s_partner_product_id.nextval, 509101, 616, 'RUB', 'main', 0, null);

--changeset yanametro:BALANCE-28619-1
delete from bo.t_partner_product where id=145;

--changeset el-yurchito:BALANCE-28506 endDelimiter:\\
INSERT INTO "BO"."T_PARTNER_PRODUCT"
  ("ID", "PRODUCT_ID", "SERVICE_ID", "CURRENCY_ISO_CODE", "ORDER_TYPE", "UNIFIED_ACCOUNT_ROOT")
VALUES
  ("BO"."S_PARTNER_PRODUCT_ID".nextval, 509250, 621, 'RUB', 'main', 0)
\\

--changeset el-yurchito:BALANCE-28987 endDelimiter:\\
INSERT INTO "BO"."T_PARTNER_PRODUCT"
  ("ID", "PRODUCT_ID", "SERVICE_ID", "CURRENCY_ISO_CODE", "ORDER_TYPE", "UNIFIED_ACCOUNT_ROOT")
VALUES
  ("BO"."S_PARTNER_PRODUCT_ID".nextval, 509336, 625, 'RUB', 'main', 0)
\\

--changeset sfreest:BALANCE-27749-partner-product-509232-620
INSERT INTO "BO"."T_PARTNER_PRODUCT"
  ("ID", "PRODUCT_ID", "SERVICE_ID", "CURRENCY_ISO_CODE", "ORDER_TYPE", "UNIFIED_ACCOUNT_ROOT")
VALUES
  ("BO"."S_PARTNER_PRODUCT_ID".nextval, 509232, 620, 'USD', 'main', 0);

--changeset el-yurchito:BALANCE-29493 endDelimiter:\\
INSERT INTO "BO"."T_PARTNER_PRODUCT"
  ("ID", "PRODUCT_ID", "SERVICE_ID", "CURRENCY_ISO_CODE", "ORDER_TYPE", "UNIFIED_ACCOUNT_ROOT")
VALUES
  ("BO"."S_PARTNER_PRODUCT_ID".nextval, 509406, 124, 'RUB', 'fuel', 0)
\\

--changeset akatovda:BALANCE-28741 endDelimiter:\\
INSERT INTO BO.T_PARTNER_PRODUCT
    ("ID", "PRODUCT_ID", "SERVICE_ID", "CURRENCY_ISO_CODE", "ORDER_TYPE", "UNIFIED_ACCOUNT_ROOT")
VALUES
    ("BO"."S_PARTNER_PRODUCT_ID".nextval, 509287, 111, 'RUB', 'marketplace_advert_call', 0)
\\

--changeset sfreest:BALANCE-29971-promo-subt-order labels:BALANCE-29971-dev-safe
alter table bo.t_partner_product
add promo_subt_order integer;
merge into bo.t_partner_product pp
using (
  with ua_group as (
    select product_id, service_id, currency_iso_code, max(unified_account_root) root
    from bo.t_partner_product
    where 1=1
      and service_id in (111, 128)
    group by product_id, service_id, currency_iso_code
  ),
  rank as (
    select pp.product_id, pp.service_id, pp.currency_iso_code, pp.order_type, pp.unified_account_root, ug.root,
    dense_rank() over (partition by pp.service_id, pp.currency_iso_code order by ug.root desc, pp.product_id) rnk
    from bo.t_partner_product pp
      left join ua_group ug on 1=1
        and ug.product_id = pp.product_id
        and ug.service_id = pp.service_id
        and ug.currency_iso_code = pp.currency_iso_code
    where 1=1
      and pp.service_id in (111, 128)
    order by pp.service_id, pp.currency_iso_code, rnk, pp.unified_account_root desc
  )
  select r.product_id, r.service_id, r.currency_iso_code, r.order_type, r.rnk - 1 + decode(service_id, 111, 0, 128, 1000, null) rnk
from rank r
) vals on (1=1
           and pp.product_id = vals.product_id
           and pp.service_id = vals.service_id
           and pp.currency_iso_code = vals.currency_iso_code
           and pp.order_type = vals.order_type)
when matched then update
  set pp.promo_subt_order = vals.rnk;


--changeset el-yurchito:BALANCE-30207 endDelimiter:\\
INSERT INTO "BO"."T_PARTNER_PRODUCT"
  ("ID", "PRODUCT_ID", "SERVICE_ID", "CURRENCY_ISO_CODE", "ORDER_TYPE", "UNIFIED_ACCOUNT_ROOT")
VALUES
  ("BO"."S_PARTNER_PRODUCT_ID".nextval, 509407, 636, 'RUB', 'main', 0)
\\

--changeset el-yurchito:BALANCE-30204 endDelimiter:\\
INSERT INTO "BO"."T_PARTNER_PRODUCT"
  ("ID", "PRODUCT_ID", "SERVICE_ID", "CURRENCY_ISO_CODE", "ORDER_TYPE", "UNIFIED_ACCOUNT_ROOT")
VALUES
  ("BO"."S_PARTNER_PRODUCT_ID".nextval, 509589, 638, 'RUB', 'main', 0)
\\

--changeset quark:BALANCE-30394
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE, SERVICE_PRODUCT_ID, END_DT, PROMO_SUBT_ORDER)
VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 509660, 111, 'BYN', 'commission_correction', 0, 'correction_commission', null, null, 0);
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE, SERVICE_PRODUCT_ID, END_DT, PROMO_SUBT_ORDER)
VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 509660, 111, 'BYN', 'order', 1, 'correction_commission', null, null, 0);
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE, SERVICE_PRODUCT_ID, END_DT, PROMO_SUBT_ORDER)
VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 509659, 128, 'BYN', 'commission_correction', 0, 'correction_commission', null, null, 1000);
INSERT INTO BO.T_PARTNER_PRODUCT (ID, PRODUCT_ID, SERVICE_ID, CURRENCY_ISO_CODE, ORDER_TYPE, UNIFIED_ACCOUNT_ROOT, NETTING_PAYMENT_TYPE, SERVICE_PRODUCT_ID, END_DT, PROMO_SUBT_ORDER)
VALUES (bo.S_PARTNER_PRODUCT_ID.nextval, 509659, 128, 'BYN', 'order', 1, 'correction_commission', null, null, 1000);

--changeset akatovda:BALANCE-30445 endDelimiter:\\
UPDATE (SELECT * FROM BO.T_PARTNER_PRODUCT WHERE SERVICE_ID = 111 AND ORDER_TYPE = 'marketplace_advert_call')
SET PROMO_SUBT_ORDER = 3, NETTING_PAYMENT_TYPE = 'correction_commission'
\\
