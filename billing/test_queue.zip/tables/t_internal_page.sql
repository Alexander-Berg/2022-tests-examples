--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_INTERNAL_PAGE
--------------------------------------------------------------------------------

--changeset ecialo:DWH-333

CREATE TABLE t_internal_page
(
   domain VARCHAR2(512),
   service_code VARCHAR2(5),
   ur_code VARCHAR2(4),
   CONSTRAINT domain_uniq UNIQUE (domain)
);

--changeset ecialo:DWH-333.2

DROP TABLE t_internal_page;