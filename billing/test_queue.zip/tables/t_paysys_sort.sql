--liquibase formatted sql

--changeset lightrevan:BALANCE-28053-tbl
CREATE TABLE bo.t_paysys_sort (
  payment_method_id NUMBER NOT NULL REFERENCES bo.t_payment_method(id),
  region_id NUMBER REFERENCES bo.t_country(region_id),
  legal_entity NUMBER,
  service_id NUMBER REFERENCES bo.t_service (id),
  priority NUMBER NOT NULL,
  weight NUMBER NOT NULL,
  CONSTRAINT u_paysys_sort UNIQUE (payment_method_id, region_id, legal_entity, service_id)
);

--changeset lightrevan:BALANCE-28053-tbl-data
INSERT INTO bo.t_paysys_sort (payment_method_id, priority, weight)
    SELECT
      pm.id, 10, weight
    FROM (
      SELECT 'yamoney_wallet' cc, 100 weight FROM dual UNION ALL
      SELECT 'webmoney_wallet' cc, 200 weight FROM dual UNION ALL
      SELECT 'paypal_wallet' cc, 300 weight FROM dual UNION ALL
      SELECT 'qiwi_wallet' cc, 400 weight FROM dual UNION ALL
      SELECT 'bank' cc, 500 weight FROM dual UNION ALL
      SELECT 'card' cc, 600 weight FROM dual
    ) d
    JOIN bo.t_payment_method pm ON d.cc = pm.cc
;

--changeset lightrevan:BALANCE-28053-tbl-data-ph
INSERT INTO bo.t_paysys_sort (payment_method_id, region_id, legal_entity, priority, weight)
    SELECT
      pm.id, 225, 0, 7, weight
    FROM (
      SELECT 'paypal_wallet' cc, 650 weight FROM dual UNION ALL
      SELECT 'card' cc, 450 weight FROM dual
    ) d
    JOIN bo.t_payment_method pm ON d.cc = pm.cc
;

--changeset lightrevan:BALANCE-28053-tbl-data-ur-service
INSERT INTO bo.t_paysys_sort (payment_method_id, region_id, legal_entity, service_id, priority, weight)
    SELECT
      pm.id, 225, 1, s.id, 5, weight
    FROM (
      SELECT 'card' cc, 450 weight FROM dual
    ) d
    CROSS JOIN (
      SELECT 103 id FROM dual UNION ALL
      SELECT 202 FROM dual
    ) s
    JOIN bo.t_payment_method pm ON d.cc = pm.cc
;

--changeset lightrevan:BALANCE-28053-tbl-data-ph-service
INSERT INTO bo.t_paysys_sort (payment_method_id, region_id, legal_entity, service_id, priority, weight)
    SELECT
      pm.id, 225, 0, 103, 5, weight
    FROM (
      SELECT 'card' cc, 600 weight FROM dual
    ) d
    JOIN bo.t_payment_method pm ON d.cc = pm.cc
;
