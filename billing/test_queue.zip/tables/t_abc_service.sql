--liquibase formatted sql

--changeset akatovda:BALANCE-27443
CREATE TABLE "BO"."T_ABC_SERVICE" (
        "ABC_ID" NUMBER,
        "SERVICE_ID" NUMBER,
        "ENV" VARCHAR(10),
        CONSTRAINT "T_ABC_SERVICE_PK" PRIMARY KEY ("ABC_ID"),
        CONSTRAINT "T_ABC_SERVICE_SID" FOREIGN KEY (SERVICE_ID) REFERENCES T_SERVICE (ID)
);

--changeset akatovda:BALANCE-27443-init
INSERT INTO BO.T_ABC_SERVICE VALUES (2000497, 143, 'prod'); -- cloud prod
INSERT INTO BO.T_ABC_SERVICE VALUES (2000508, 143, 'test'); -- cloud test
INSERT INTO BO.T_ABC_SERVICE VALUES (2000601, 143, 'test'); -- balance test as cloud

--changeset sfreest:BALANCE-29139-add-addappter-service
insert into bo.t_abc_service values (2001658, 630,  'prod');
insert into bo.t_abc_service values (2001656, 630,  'test');

--changeset sfreest:BALANCE-29169-upd-tvm-identy
update bo.t_abc_service
set abc_id = 2000290
where 1=1
  and abc_id = 2001656
  and service_id = 630
  and env = 'test';
update bo.t_abc_service
set abc_id = 2000293
where 1=1
  and abc_id = 2001658
  and service_id = 630
  and env = 'prod';

--changeset akatovda:BALANCE-30074--tvm-for-tickets
INSERT INTO BO.T_ABC_SERVICE VALUES (2000172, 118, 'test'); -- yandex.ticket dev worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000173, 118, 'test'); -- yandex.ticket dev CMS

INSERT INTO BO.T_ABC_SERVICE VALUES (2000167, 118, 'test'); -- yandex.ticket test worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000170, 118, 'test'); -- yandex.ticket test CMS

INSERT INTO BO.T_ABC_SERVICE VALUES (2000177, 118, 'test'); -- yandex.ticket stress worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000178, 118, 'test'); -- yandex.ticket stress CMS

INSERT INTO BO.T_ABC_SERVICE VALUES (2000168, 118, 'prod'); -- yandex.ticket prod worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000171, 118, 'prod'); -- yandex.ticket prod CMS

--changeset akatovda:BALANCE-30074--tvm-for-tickets-x
alter table BO.T_ABC_SERVICE DISABLE constraint "T_ABC_SERVICE_PK";

--changeset akatovda:BALANCE-30074--tvm-for-tickets-2
INSERT INTO BO.T_ABC_SERVICE VALUES (2000172, 126, 'test'); -- yandex.ticket dev worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000173, 126, 'test'); -- yandex.ticket dev CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000172, 131, 'test'); -- yandex.ticket dev worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000173, 131, 'test'); -- yandex.ticket dev CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000172, 638, 'test'); -- yandex.ticket dev worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000173, 638, 'test'); -- yandex.ticket dev CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000172, 617, 'test'); -- yandex.ticket dev worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000173, 617, 'test'); -- yandex.ticket dev CMS

INSERT INTO BO.T_ABC_SERVICE VALUES (2000167, 126, 'test'); -- yandex.ticket test worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000170, 126, 'test'); -- yandex.ticket test CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000167, 131, 'test'); -- yandex.ticket test worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000170, 131, 'test'); -- yandex.ticket test CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000167, 638, 'test'); -- yandex.ticket test worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000170, 638, 'test'); -- yandex.ticket test CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000167, 617, 'test'); -- yandex.ticket test worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000170, 617, 'test'); -- yandex.ticket test CMS

INSERT INTO BO.T_ABC_SERVICE VALUES (2000177, 126, 'test'); -- yandex.ticket stress worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000178, 126, 'test'); -- yandex.ticket stress CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000177, 131, 'test'); -- yandex.ticket stress worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000178, 131, 'test'); -- yandex.ticket stress CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000177, 638, 'test'); -- yandex.ticket stress worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000178, 638, 'test'); -- yandex.ticket stress CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000177, 617, 'test'); -- yandex.ticket stress worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000178, 617, 'test'); -- yandex.ticket stress CMS

INSERT INTO BO.T_ABC_SERVICE VALUES (2000168, 126, 'prod'); -- yandex.ticket prod worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000171, 126, 'prod'); -- yandex.ticket prod CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000168, 131, 'prod'); -- yandex.ticket prod worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000171, 131, 'prod'); -- yandex.ticket prod CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000168, 638, 'prod'); -- yandex.ticket prod worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000171, 638, 'prod'); -- yandex.ticket prod CMS
INSERT INTO BO.T_ABC_SERVICE VALUES (2000168, 617, 'prod'); -- yandex.ticket prod worker
INSERT INTO BO.T_ABC_SERVICE VALUES (2000171, 617, 'prod'); -- yandex.ticket prod CMS
