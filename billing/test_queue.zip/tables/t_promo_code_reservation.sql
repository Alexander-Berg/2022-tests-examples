--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_PROMO_CODE_RESERVATION
--------------------------------------------------------------------------------

CREATE TABLE bo.t_promo_code_reservation
(
  client_id    NUMBER NOT NULL
    CONSTRAINT t_promo_code_reservation_r01
    REFERENCES t_client,
  promocode_id NUMBER NOT NULL
    CONSTRAINT t_promo_code_reservation_r02
    REFERENCES t_promo_code,
  begin_dt     DATE   NOT NULL,
  end_dt       DATE,
  CONSTRAINT t_promo_code_reservation_pk
  PRIMARY KEY (client_id, promocode_id, begin_dt)
);

CREATE INDEX t_promo_code_reserva_2_indx ON t_promo_code_reservation (promocode_id);
