--liquibase formatted sql

--changeset skydreamer:TRUST-2813

ALTER TABLE bo.t_binbase
ADD (
  update_dt DATE,
  update_login VARCHAR2(64)
);


