--liquibase formatted sql


--changeset srg91:TRUST-3274
create table bo.t_raw_register (
  id number not null,
  dt date default sysdate not null,
  register_dt date not null,
  incoming_mail_id number,
  attach_name varchar2(255),
  amount number not null,
  commission number not null,
  currency varchar2(16),
  constraint pk_raw_register_id primary key (id),
  constraint fk_raw_register_mail_id foreign key (incoming_mail_id) references bo.t_incoming_mail (id)
);

create index bo.i_raw_register_reg_dt on bo.t_raw_register (register_dt);


