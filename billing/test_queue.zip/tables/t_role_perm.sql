--liquibase formatted sql

  CREATE TABLE "BO"."T_ROLE"
   ("PERM" NUMBER NOT NULL ENABLE,
    "ROLE_ID" NUMBER NOT NULL ENABLE,
     CONSTRAINT "FK_ROLE_ROLE_ID" FOREIGN KEY ("ROLE_ID")
      REFERENCES "BO"."T_ROLE_NAME" ("ID") ENABLE,
     CONSTRAINT "FK_ROLE_PERM" FOREIGN KEY ("PERM")
      REFERENCES "BO"."T_PERMITION" ("PERM") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."IDX_ROLE_ROLE_ID" ON "BO"."T_ROLE" ("ROLE_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."ROLE_PERM_IDX" ON "BO"."T_ROLE" ("PERM")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_ITS" ;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "BO"."T_ROLE_PERM" ("ROLE_ID", "PERM") AS
  select role_id, perm from bo.t_role;

--changeset vaclav:TRUST-2266-2

insert into bo.t_role_perm (perm, role_id) values (4002, 402);
insert into bo.t_role_perm (perm, role_id) values (0, 402);

--changeset ashvedunov:BALANCE-23866-2

insert into bo.t_role_perm (perm, role_id) values (50, 40);

--changeset nebaruzdin:BALANCE-25259

insert into bo.t_role_perm (perm, role_id) values (53, 0);
insert into bo.t_role_perm (perm, role_id) values (53, 1);

--changeset dimonb:BALANCE-24783

insert into bo.t_role_perm (perm, role_id) values ((select perm from bo.t_permition where code = 'AlterPrintTemplate'), 0);

--changeset dimonb:BALANCE-24783-1
insert into bo.t_role_perm (perm, role_id) values ((select perm from bo.t_permition where code = 'AlterPrintTemplate'), 41);

--changeset srg91:TRUST-3631
-- Менеджер по фрод-мониторингу
insert into bo.t_role_perm
values (61, 0); -- Доступ в админку

insert into bo.t_role_perm
values (61, 1); -- Просмотр счетов

insert into bo.t_role_perm
values (61, 23); -- Действия менеджера

insert into bo.t_role_perm
values (61, 28); -- Редактирование клиента

insert into bo.t_role_perm
values (61, 58); -- Редактирование фрода

-- Менеджер по договорам
insert into bo.t_role_perm
values (62, 0); -- Доступ в админку

insert into bo.t_role_perm
values (62, 20); -- Изменение договоров

insert into bo.t_role_perm
values (62, 23); -- Действия менеджера

insert into bo.t_role_perm
values (61, 28); -- Редактирование клиента

insert into bo.t_role_perm
values (62, 56); -- Просмотр терминалов

insert into bo.t_role_perm
values (62, 57); -- Редактирование терминалов

-- Add EditTerminal to all BillingSupport
insert into bo.t_role_perm
select
  role_id,
  57
from bo.t_role_perm
where
  perm = 1100
;

-- Add ViewTerminal to all ViewFishes
insert into bo.t_role_perm
select
  role_id,
  56
from bo.t_role_perm
where
  perm = 22
  and role_id not in (61, 62)
;


--changeset srg91:TRUST-3631-fraud

-- Add ClientFraudStatusEdit to all BillingSupport
insert into bo.t_role_perm
select
  role_id,
  58
from bo.t_role_perm
where
  perm = 1100
  and role_id != 62
;


--changeset srg91:TRUST-3631-crate-client
insert into bo.t_role_perm
values (62, 27); -- Создание клиентов


--changeset srg91:TRUST-3631-edit-client
insert into bo.t_role_perm
values (62, 28); -- Редактирование клиента

--changeset nebaruzdin:BALANCE-27232

insert into bo.t_role_perm
values (101, 2001);

--changeset quark:BALANCE-28047

insert into bo.t_role
(select
  distinct
  (select perm from bo.t_permission where code = 'AlterFirmNVTaxiuber'),
  role_id
from bo.t_role_perm rp
  join bo.t_permission p on rp.perm = p.perm
where code = 'AlterFirmRU');

--changeset dolvik:BALANCE-28144

insert into bo.t_role_perm
values (0, 64);

--changeset natabers:BALANCE-28045-3

insert into bo.t_role_perm
values (10216, 4003);
