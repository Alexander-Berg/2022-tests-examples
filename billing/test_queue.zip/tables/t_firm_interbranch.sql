--liquibase formatted sql


--changeset isupov:FIX-BALANCE-24056-1 stripComments:false endDelimiter:/

CREATE TABLE BO.T_FIRM_INTERBRANCH
(
  id            NUMBER,
  root_firm_id  NUMBER                          NOT NULL,
  firm_id       NUMBER                          NOT NULL,
  contract_id   NUMBER                          NOT NULL
)
/

--changeset isupov:FIX-BALANCE-24056-2 stripComments:false endDelimiter:/
ALTER TABLE BO.T_FIRM_INTERBRANCH ADD (
  CONSTRAINT T_FIRM_INTERBRANCH_PK
  PRIMARY KEY
  (id)
  ENABLE VALIDATE,
  CONSTRAINT T_FIRM_INTERBRANCH_U01
  UNIQUE (firm_id, root_firm_id)
  ENABLE VALIDATE)
/

--changeset isupov:FIX-BALANCE-24056-3 stripComments:false endDelimiter:/
ALTER TABLE BO.T_FIRM_INTERBRANCH ADD (
  CONSTRAINT T_FIRM_INTERBRANCH_R01
  FOREIGN KEY (contract_id)
  REFERENCES BO.T_CONTRACT2 (ID)
  ENABLE VALIDATE)
/

--changeset isupov:FIX-BALANCE-24056-4 stripComments:false endDelimiter:/

CREATE SEQUENCE BO.S_FIRM_INTERBRANCH START WITH 1 INCREMENT BY 1

/

--changeset isupov:FIX-BALANCE-24056-51 stripComments:false

insert into bo.t_firm_interbranch (id, root_firm_id, firm_id, contract_id)
(select bo.s_firm_interbranch.nextval, 1, id, contract_id from bo.t_firm where contract_id is not null);

insert into bo.t_firm_interbranch (id, root_firm_id, firm_id, contract_id)
    values (bo.s_firm_interbranch.nextval, 111, 7, 260944);

insert into bo.t_firm_interbranch (id, root_firm_id, firm_id, contract_id)
    values (bo.s_firm_interbranch.nextval, 111, 2, 260752);

--changeset isupov:FIX-BALANCE-24056-6 stripComments:false endDelimiter:/

ALTER TABLE BO.T_FIRM_INTERBRANCH ADD (invoice_paysys_id  NUMBER)

/

--changeset isupov:FIX-BALANCE-24056-7 stripComments:false

update bo.t_firm_interbranch set invoice_paysys_id = 1060 where root_firm_id = 1 and contract_id = 237598;
update bo.t_firm_interbranch set invoice_paysys_id = 1047 where root_firm_id = 1 and contract_id = 76255;
update bo.t_firm_interbranch set invoice_paysys_id = 1096 where root_firm_id = 1 and contract_id = 76317;
update bo.t_firm_interbranch set invoice_paysys_id = 1023 where root_firm_id = 1 and contract_id = 76256;
update bo.t_firm_interbranch set invoice_paysys_id = 1013 where root_firm_id = 1 and contract_id = 63592;
update bo.t_firm_interbranch set invoice_paysys_id = 1100 where root_firm_id = 1 and contract_id = 61815;

update bo.t_firm_interbranch set invoice_paysys_id = 11101023 where root_firm_id = 111 and contract_id = 260944;
update bo.t_firm_interbranch set invoice_paysys_id = 1046 where root_firm_id = 111 and contract_id = 260752;


ALTER TABLE BO.T_FIRM_INTERBRANCH MODIFY(INVOICE_PAYSYS_ID  NOT NULL);

/

--changeset isupov:FIX-BALANCE-24056-8 stripComments:false

CREATE INDEX BO.IDX_FIRM_INTERBRANCH_CNT ON BO.T_FIRM_INTERBRANCH (CONTRACT_ID);
