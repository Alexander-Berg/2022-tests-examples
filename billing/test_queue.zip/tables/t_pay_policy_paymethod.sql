--liquibase formatted sql

--changeset lightrevan:BALANCE-27778-ppp
CREATE TABLE bo.t_pay_policy_paymethod (
  pay_policy_part_id NUMBER REFERENCES bo.t_pay_policy_part (id),
  payment_method_id NUMBER REFERENCES bo.t_payment_method (id),
  iso_currency VARCHAR2(16) REFERENCES bo.t_iso_currency(alpha_code),
  paysys_group_id NUMBER DEFAULT 0,
  CONSTRAINT pk_pay_policy_paymethod PRIMARY KEY (pay_policy_part_id, payment_method_id, iso_currency, paysys_group_id),
  CONSTRAINT t_pp_paymethod_group_fk FOREIGN KEY (paysys_group_id) REFERENCES bo.T_PAYSYS_GROUP(ID)
);

--changeset lightrevan:BALANCE-29370
alter table BO.T_PAY_POLICY_PAYMETHOD disable constraint SYS_C002849605;
alter table BO.T_PAY_POLICY_PAYMETHOD drop constraint SYS_C002849605;

--changeset lightrevan:BALANCE-29552-ppm-upd
UPDATE bo.t_pay_policy_paymethod ppm
SET paysys_group_id = 5
WHERE payment_method_id = 1204
  AND pay_policy_part_id = (
    SELECT ppp.id
    FROM bo.t_pay_policy_routing ppr
      JOIN bo.t_pay_policy_part ppp ON ppr.pay_policy_part_id = ppp.id
    WHERE 1 = 1
          AND ppr.service_id = 42
          AND ppp.legal_entity = 0
  )
;

--changeset sfreest:BALANCE-29271-pay-policy-paymethod
INSERT INTO bo.t_pay_policy_paymethod(pay_policy_part_id, payment_method_id, iso_currency)
VALUES ((select id from bo.t_pay_policy_part where description='Contract-service pay policy for Yandex E-commerce Limited'), 1001, 'USD');

--changeset nebaruzdin:BALANCE-29364

insert into bo.t_pay_policy_paymethod
values ((select id from bo.t_pay_policy_part where firm_id = 34 and category = 'ph'), 1001, 'RUB', 0);
insert into bo.t_pay_policy_paymethod
values ((select id from bo.t_pay_policy_part where firm_id = 34 and category = 'ur'), 1001, 'RUB', 0);
insert into bo.t_pay_policy_paymethod
values ((select id from bo.t_pay_policy_part where firm_id = 34 and category = 'yt'), 1001, 'RUB', 0);
