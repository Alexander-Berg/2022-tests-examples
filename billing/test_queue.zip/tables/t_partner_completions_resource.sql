--liquibase formatted sql

--changeset quark:BALANCE-25341-1
create table BO.T_PARTNER_COMPLETIONS_RESOURCE
(
	ID NUMBER not null
		constraint PK_PC_RESOURCE_ID
			primary key,
	SOURCE_NAME VARCHAR2(256),
	DT DATE
);

--changeset yanametro:BALANCE-25341-2
create sequence bo.s_partner_comp_resource_id
  START WITH 1
  INCREMENT BY 1;

--changeset yanametro:BALANCE-25341-3 endDilimiter:/
begin
  bo.create_pycron_task( 'process_resource'
                       , 'YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor.cfg.xml yb-python -pysupport balance/queue_processor.py PARTNER_COMPL'
                       , 'Забор откруток'
                       , 'yanametro'
                       , '*/30 * * * *'
                       , r_email => 'yanametro@yandex-team.ru'
                       );
end;
/
