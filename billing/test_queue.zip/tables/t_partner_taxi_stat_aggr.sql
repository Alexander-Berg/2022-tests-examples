--liquibase formatted sql

--changeset quark:BALANCE-26326-5

create table bo.t_partner_taxi_stat_aggr (
    dt date,
    client_id number not null,
    commission_currency varchar(10) not null,
    payment_type varchar(255),
    commission_sum number,
    promocode_sum number,
    type varchar(255)
);

--changeset quark:BALANCE-26326-6

comment on column bo.t_partner_taxi_stat_aggr.dt is 'UTC';

--changeset quark:BALANCE-26326-7

create index bo.i_prtn_taxi_stat_aggr_dt on bo.t_partner_taxi_stat_aggr (dt);
create index bo.i_prtn_taxi_stat_aggr_client on bo.t_partner_taxi_stat_aggr (client_id);

--changeset sfreest:BALANCE-29971-partner-stat-aggr
alter table bo.t_partner_taxi_stat_aggr
add subsidy_sum number;
