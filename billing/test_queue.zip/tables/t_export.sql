--liquibase formatted sql

--------------------------------------------------------
--  DDL for Table T_ORDER
--------------------------------------------------------

CREATE TABLE BO.T_EXPORT
(
  CLASSNAME    VARCHAR2(64 BYTE)                NOT NULL,
  OBJECT_ID    NUMBER                           NOT NULL,
  UPDATE_DT    DATE                             DEFAULT sysdate               NOT NULL,
  RATE         NUMBER                           DEFAULT 0                     NOT NULL,
  STATE        NUMBER                           DEFAULT 0                     NOT NULL,
  ERROR        VARCHAR2(1024 BYTE),
  EXPORT_DT    DATE,
  HOSTNAME     VARCHAR2(256 BYTE),
  TYPE         VARCHAR2(20 BYTE)                NOT NULL,
  NEXT_EXPORT  DATE                             DEFAULT sysdate,
  PRIORITY     NUMBER                           DEFAULT 0,
  INPUT        BLOB,
  TRACEBACK    CLOB,
  OUTPUT       CLOB,
  REASON       VARCHAR2(128 CHAR)               DEFAULT null
)
LOB (INPUT) STORE AS (
  TABLESPACE  YACC_PERSONTS
  ENABLE      STORAGE IN ROW
  CHUNK       4096
  RETENTION
  NOCACHE
  NOLOGGING)
LOB (TRACEBACK) STORE AS (
  TABLESPACE  YACC_PERSONTS
  ENABLE      STORAGE IN ROW
  CHUNK       4096
  RETENTION
  NOCACHE
  NOLOGGING)
LOB (OUTPUT) STORE AS (
  TABLESPACE  YACC_PERSONTS
  ENABLE      STORAGE IN ROW
  CHUNK       4096
  RETENTION
  NOCACHE
  NOLOGGING)
NOCOMPRESS
TABLESPACE YACC_PERSONTS
RESULT_CACHE (MODE DEFAULT)
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
PARTITION BY LIST (TYPE)
(
  PARTITION OEBS_IMPORT VALUES ('OEBS_IMPORT')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA_TRANSFER VALUES ('UA_TRANSFER')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MONTH_PROC VALUES ('MONTH_PROC')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION US VALUES ('US')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_SEND VALUES ('SMS_SEND')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CLIENT_BATCH VALUES ('CLIENT_BATCH')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OVERDRAFT VALUES ('OVERDRAFT')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BUDGET VALUES ('BUDGET')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION P_DEAL_EXPORT VALUES ('P_DEAL_EXPORT')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CONTRACT_NOTIFY VALUES ('CONTRACT_NOTIFY')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_PAYMENTS VALUES ('PROCESS_PAYMENTS')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_NOTIFY VALUES ('SMS_NOTIFY')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OEBS VALUES ('OEBS')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_ACTS VALUES ('PARTNER_ACTS')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BYR VALUES ('BYR')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION KZ VALUES ('KZ')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA VALUES ('UA')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MIGRATE_TO_CURRENCY VALUES ('MIGRATE_TO_CURRENCY')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_COMPLETION VALUES ('PROCESS_COMPLETION')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_CACHE VALUES ('PROCESS_CACHE')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION THIRDPARTY_TRANS VALUES ('THIRDPARTY_TRANS')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION YT_EXPORT VALUES ('YT_EXPORT')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_BALANCES VALUES ('PARTNER_BALANCES')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION EMAIL_DOCUMENT VALUES ('EMAIL_DOCUMENT')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_REFUNDS VALUES ('PROCESS_REFUNDS')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION POSTAUTH_PAYMENTS VALUES ('POSTAUTH_PAYMENTS')
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    LOB (OUTPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (TRACEBACK) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    LOB (INPUT) STORE AS (
      TABLESPACE  YACC_PERSONTS
      ENABLE      STORAGE IN ROW
      CHUNK       4096
      RETENTION
      NOCACHE
      LOGGING)
    PCTUSED    40
    PCTFREE    10
    INITRANS   1
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
)
NOCACHE
NOPARALLEL
MONITORING;


CREATE INDEX BO.I_EXPORT_NEXT_EXPORT ON BO.T_EXPORT
(NEXT_EXPORT)
  TABLESPACE YACC_PERSONTS
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  STORAGE    (
              BUFFER_POOL      DEFAULT
              FLASH_CACHE      DEFAULT
              CELL_FLASH_CACHE DEFAULT
             )
LOGGING
LOCAL (
  PARTITION OEBS_IMPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA_TRANSFER
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MONTH_PROC
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION US
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_SEND
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CLIENT_BATCH
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OVERDRAFT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BUDGET
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION P_DEAL_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CONTRACT_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OEBS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_ACTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BYR
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION KZ
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MIGRATE_TO_CURRENCY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_COMPLETION
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_CACHE
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION THIRDPARTY_TRANS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION YT_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_BALANCES
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION EMAIL_DOCUMENT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_REFUNDS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION POSTAUTH_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
)
NOPARALLEL;

CREATE UNIQUE INDEX BO.I_EXPORT_OBJECT_ID_CLASSNAME ON BO.T_EXPORT
(CLASSNAME, OBJECT_ID, TYPE)
  TABLESPACE YACC_PERSONTS
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  STORAGE    (
              BUFFER_POOL      DEFAULT
              FLASH_CACHE      DEFAULT
              CELL_FLASH_CACHE DEFAULT
             )
LOGGING
LOCAL (
  PARTITION OEBS_IMPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA_TRANSFER
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MONTH_PROC
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION US
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_SEND
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CLIENT_BATCH
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OVERDRAFT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BUDGET
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION P_DEAL_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CONTRACT_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OEBS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_ACTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BYR
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION KZ
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MIGRATE_TO_CURRENCY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_COMPLETION
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_CACHE
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION THIRDPARTY_TRANS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION YT_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_BALANCES
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION EMAIL_DOCUMENT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_REFUNDS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION POSTAUTH_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
)
NOPARALLEL;

CREATE INDEX BO.I_EXPORT_RATE ON BO.T_EXPORT
(RATE)
  TABLESPACE YACC_PERSONTS
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  STORAGE    (
              BUFFER_POOL      DEFAULT
              FLASH_CACHE      DEFAULT
              CELL_FLASH_CACHE DEFAULT
             )
LOGGING
LOCAL (
  PARTITION OEBS_IMPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA_TRANSFER
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MONTH_PROC
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION US
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_SEND
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CLIENT_BATCH
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OVERDRAFT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BUDGET
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION P_DEAL_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CONTRACT_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OEBS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_ACTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BYR
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION KZ
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MIGRATE_TO_CURRENCY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_COMPLETION
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_CACHE
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION THIRDPARTY_TRANS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION YT_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_BALANCES
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION EMAIL_DOCUMENT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_REFUNDS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION POSTAUTH_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
)
NOPARALLEL;

CREATE INDEX BO.I_EXPORT_RATE_STATE ON BO.T_EXPORT
(TYPE, STATE, NEXT_EXPORT)
  TABLESPACE YACC_PERSONTS
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  STORAGE    (
              BUFFER_POOL      DEFAULT
              FLASH_CACHE      DEFAULT
              CELL_FLASH_CACHE DEFAULT
             )
LOGGING
LOCAL (
  PARTITION OEBS_IMPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA_TRANSFER
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MONTH_PROC
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION US
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_SEND
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CLIENT_BATCH
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OVERDRAFT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BUDGET
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION P_DEAL_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CONTRACT_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OEBS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_ACTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BYR
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION KZ
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MIGRATE_TO_CURRENCY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_COMPLETION
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_CACHE
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION THIRDPARTY_TRANS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION YT_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_BALANCES
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION EMAIL_DOCUMENT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_REFUNDS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION POSTAUTH_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
)
NOPARALLEL;

CREATE INDEX BO.I_EXPORT_RATE_STATE_PRIORITY ON BO.T_EXPORT
(STATE, PRIORITY, RATE, NEXT_EXPORT)
  PCTFREE    10
  INITRANS   2
  MAXTRANS   255
  STORAGE    (
              BUFFER_POOL      DEFAULT
              FLASH_CACHE      DEFAULT
              CELL_FLASH_CACHE DEFAULT
             )
LOCAL (
  PARTITION OEBS_IMPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA_TRANSFER
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MONTH_PROC
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION US
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_SEND
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CLIENT_BATCH
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OVERDRAFT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BUDGET
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION P_DEAL_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION CONTRACT_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION SMS_NOTIFY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION OEBS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_ACTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION BYR
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION KZ
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION UA
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION MIGRATE_TO_CURRENCY
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_COMPLETION
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_CACHE
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION THIRDPARTY_TRANS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION YT_EXPORT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PARTNER_BALANCES
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION EMAIL_DOCUMENT
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION PROCESS_REFUNDS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               ),
  PARTITION POSTAUTH_PAYMENTS
    LOGGING
    NOCOMPRESS
    TABLESPACE YACC_PERSONTS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
)
NOPARALLEL;

--changeset isupov:FIX-BALANCE-24170-1 stripComments:false
ALTER TABLE BO.T_EXPORT ADD (config  VARCHAR2(4000 BYTE)                   DEFAULT null);

--changeset isupov:FIX-BALANCE-24170-2 stripComments:false
ALTER TABLE bo.t_export ADD (enqueue_hostname VARCHAR2(128)
  GENERATED ALWAYS AS (json_value(config, '$.enqueue_hostname' RETURNING VARCHAR2(128))));

--changeset akatovda:BALANCE-24291-1 endDelimiter:\\
DECLARE
  partition_count NUMBER;
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  SELECT count(partition_name) INTO partition_count FROM user_tab_partitions WHERE partition_name = 'STAT_AGGREGATOR' AND TABLE_NAME = 'T_EXPORT';
  IF partition_count = 0 THEN
    EXECUTE IMMEDIATE 'ALTER TABLE BO.T_EXPORT ADD PARTITION STAT_AGGREGATOR VALUES (''' || 'STAT_AGGREGATOR' || ''')';
  END IF;
END;
\\

--changeset akatovda:BALANCE-24291-2 endDelimiter:\\
DECLARE
  TPL VARCHAR2(4096);
  ex  NUMBER;
BEGIN
  SELECT 'ALTER TABLE BO.T_EXPORT_HISTORY SET SUBPARTITION TEMPLATE (' ||
         LISTAGG('SUBPARTITION ' || PARTITION_NAME || ' VALUES(''' || PARTITION_NAME || ''')', ', ' || CHR(10))
         WITHIN GROUP (
           ORDER BY 1) || ')' tmpl
  INTO TPL
  FROM ALL_TAB_PARTITIONS
  WHERE
    TABLE_NAME = 'T_EXPORT' AND TABLE_OWNER = 'BO';
  DBMS_OUTPUT.PUT_LINE(TPL);
  EXECUTE IMMEDIATE TPL;

  FOR need IN (SELECT
                 tp2.PARTITION_NAME,
                 tp1.HIGH_VALUE,
                 tp1.PARTITION_NAME PNAME
               FROM ALL_TAB_PARTITIONS tp1
                 CROSS JOIN
                 ALL_TAB_PARTITIONS tp2
               WHERE tp1.TABLE_NAME = 'T_EXPORT' AND tp1.TABLE_OWNER = 'BO'
                     AND tp2.TABLE_NAME = 'T_EXPORT_HISTORY' AND tp2.TABLE_OWNER = 'BO')
  LOOP
    ex := 0;
    FOR parts IN (SELECT
                    sub.PARTITION_NAME,
                    HIGH_VALUE
                  FROM ALL_TAB_SUBPARTITIONS sub
                  WHERE sub.table_name = 'T_EXPORT_HISTORY' AND sub.TABLE_OWNER = 'BO'
                        AND sub.PARTITION_NAME = need.PARTITION_NAME)
    LOOP
      IF parts.HIGH_VALUE = need.HIGH_VALUE
      THEN
        ex := 1;
        EXIT;
      END IF;
    END LOOP;

    IF ex = 0
    THEN
      TPL := 'ALTER TABLE BO.T_EXPORT_HISTORY MODIFY PARTITION ' ||
             need.PARTITION_NAME || ' ADD SUBPARTITION ' ||
             need.PARTITION_NAME || '_' ||
             need.PNAME || ' VALUES (' || need.HIGH_VALUE || ')';
      DBMS_OUTPUT.PUT_LINE(TPL);
      EXECUTE IMMEDIATE TPL;
    END IF;
  END LOOP;
END;
\\

--changeset ngolovkin:BALANCE-25670-2
update (
select * from bo.t_export where type = 'CASH_REGISTER' and object_id = 239692902
) set rate = 0, state = 0;

--changeset yanametro:BALANCE-25341 endDelimiter:\\
DECLARE
  TPL VARCHAR2(4096);
  ex  NUMBER;
BEGIN
  SELECT 'ALTER TABLE BO.T_EXPORT_HISTORY SET SUBPARTITION TEMPLATE (' ||
         LISTAGG('SUBPARTITION ' || PARTITION_NAME || ' VALUES(''' || PARTITION_NAME || ''')', ', ' || CHR(10))
         WITHIN GROUP (
           ORDER BY 1) || ')' tmpl
  INTO TPL
  FROM ALL_TAB_PARTITIONS
  WHERE
    TABLE_NAME = 'T_EXPORT' AND TABLE_OWNER = 'BO';
  DBMS_OUTPUT.PUT_LINE(TPL);
  EXECUTE IMMEDIATE TPL;

  FOR need IN (SELECT
                 tp2.PARTITION_NAME,
                 tp1.HIGH_VALUE,
                 tp1.PARTITION_NAME PNAME
               FROM ALL_TAB_PARTITIONS tp1
                 CROSS JOIN
                 ALL_TAB_PARTITIONS tp2
               WHERE tp1.TABLE_NAME = 'T_EXPORT' AND tp1.TABLE_OWNER = 'BO'
                     AND tp2.TABLE_NAME = 'T_EXPORT_HISTORY' AND tp2.TABLE_OWNER = 'BO')
  LOOP
    ex := 0;
    FOR parts IN (SELECT
                    sub.PARTITION_NAME,
                    HIGH_VALUE
                  FROM ALL_TAB_SUBPARTITIONS sub
                  WHERE sub.table_name = 'T_EXPORT_HISTORY' AND sub.TABLE_OWNER = 'BO'
                        AND sub.PARTITION_NAME = need.PARTITION_NAME)
    LOOP
      IF parts.HIGH_VALUE = need.HIGH_VALUE
      THEN
        ex := 1;
        EXIT;
      END IF;
    END LOOP;

    IF ex = 0
    THEN
      TPL := 'ALTER TABLE BO.T_EXPORT_HISTORY MODIFY PARTITION ' ||
             need.PARTITION_NAME || ' ADD SUBPARTITION ' ||
             need.PARTITION_NAME || '_' ||
             need.PNAME || ' VALUES (' || need.HIGH_VALUE || ')';
      DBMS_OUTPUT.PUT_LINE(TPL);
      EXECUTE IMMEDIATE TPL;
    END IF;
  END LOOP;
END;
\\


--changeset vorobyov-as:completions_overhaul-1
alter table bo.t_export add partition ENTITY_COMPL values ('ENTITY_COMPL');

--changeset vorobyov-as:completions_overhaul-2
insert into t_export_type values (
'ENTITY_COMPL', (select params from t_export_type where TYPE = 'PARTNER_COMPL'));

--changeset azurkin:BALANCE-29575-add-enqueue_dt
ALTER TABLE BO.t_export ADD enqueue_dt date;

--changeset azurkin:BALANCE-29575-add-export_priority
alter table bo.t_export add export_priority as (
  case
    when state = 0
      and next_export is null
    then nvl(priority, 0)
    else null
  end
)
;
