--liquibase formatted sql

--changeset vorobyov-as:scale_cash_fix-3
create table bo.t_distr_scale_pct (
  contract_id number,
  page_id number,
  month_dt date,
  pct number,
  budget number
);

--changeset vorobyov-as:scale_cash_fix-index-1
alter table bo.t_distr_scale_pct
add constraint pk_t_distr_scale_pct
primary key (contract_id, page_id, month_dt);