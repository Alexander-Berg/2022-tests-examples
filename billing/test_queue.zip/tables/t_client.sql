--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_CLIENT
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_CLIENT"
   (	"ID" NUMBER NOT NULL ENABLE,
	"DT" DATE DEFAULT (SYSDATE) NOT NULL ENABLE,
	"CLIENT_TYPE_ID" NUMBER,
	"NAME" VARCHAR2(512 BYTE),
	"EMAIL" VARCHAR2(256 BYTE),
	"PHONE" VARCHAR2(256 CHAR),
	"FAX" VARCHAR2(128 CHAR),
	"URL" VARCHAR2(256 BYTE),
	"IS_AGENCY" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"PERSON_ID" NUMBER,
	"ID_1C" NUMBER,
	"INTERNAL" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"IS_WHOLESALER" NUMBER,
	"FULL_REPAYMENT" NUMBER DEFAULT 1 NOT NULL ENABLE,
	"CLASS_ID" NUMBER NOT NULL ENABLE,
	"AGENCY_ID" NUMBER,
	"OPER_ID" NUMBER,
	"SUSPECT" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"CREATOR_UID" NUMBER,
	"OVERDRAFT_LIMIT" NUMBER DEFAULT 0,
	"OVERDRAFT_BAN" NUMBER DEFAULT 0,
	"BUDGET" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"IS_AGGREGATOR" NUMBER DEFAULT 0,
	"CREATION_DT" DATE DEFAULT SYSDATE NOT NULL ENABLE,
	"PARTNER_TYPE" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"MANUAL_SUSPECT" NUMBER(1,0) DEFAULT 0 NOT NULL ENABLE,
	"CITY" VARCHAR2(256 BYTE),
	"RELIABLE_CC_PAYER" NUMBER(1,0),
	"DENY_CC" NUMBER(1,0) DEFAULT 0,
	"MANUAL_DISCOUNT" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"DIRECT25" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"IS_DOCS_SEPARATED" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"IS_DOCS_DETAILED" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"MANUAL_SUSPECT_COMMENT" CLOB,
	"IS_NON_RESIDENT" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"FULLNAME" VARCHAR2(512 BYTE),
	"CURRENCY_PAYMENT" VARCHAR2(16 BYTE),
	"DOMAIN_CHECK_STATUS" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"DOMAIN_CHECK_COMMENT" CLOB,
	"REGION_ID" NUMBER,
	"SUBREGION_ID" NUMBER(*,0),
	"OFFICE_ID" NUMBER(*,0),
	 CONSTRAINT "T_CLIENT_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 524288 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_KTS"  ENABLE,
	 CONSTRAINT "CHECK_ID" CHECK ( id<>0) ENABLE,
	 CONSTRAINT "T_CLIENT_C_NR01" CHECK (IS_NON_RESIDENT = 0 OR
( FULLNAME IS NOT NULL AND CURRENCY_PAYMENT IS NOT NULL)) ENABLE,
	 CONSTRAINT "CK_CLIENT_FIELDS_LINEBREAK" CHECK (
name||email||phone||fax||url not like '%'||Chr(10)||'%' and
name||email||phone||fax||url not like '%'||Chr(13)||'%'
) ENABLE,
	 CONSTRAINT "T_CLIENT_PERSON_ID_FK" FOREIGN KEY ("PERSON_ID")
	  REFERENCES "BO"."T_PERSON" ("ID") ENABLE,
	 FOREIGN KEY ("REGION_ID")
	  REFERENCES "BO"."T_COUNTRY" ("REGION_ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"
 LOB ("MANUAL_SUSPECT_COMMENT") STORE AS BASICFILE (
  TABLESPACE "YACC_PERSONTS" ENABLE STORAGE IN ROW CHUNK 4096 RETENTION
  NOCACHE LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT))
 LOB ("DOMAIN_CHECK_COMMENT") STORE AS BASICFILE (
  TABLESPACE "YACC_PERSONTS" ENABLE STORAGE IN ROW CHUNK 4096 RETENTION
  NOCACHE LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT))
   CACHE ;

  CREATE INDEX "BO"."IDX_CLIENT_REGID" ON "BO"."T_CLIENT" ("REGION_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."T_CLIENT_AGENCY_ID_IDX" ON "BO"."T_CLIENT" ("AGENCY_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 524288 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_ITS" ;

  CREATE INDEX "BO"."T_CLIENT_CLASS_ID_IDX" ON "BO"."T_CLIENT" ("CLASS_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 524288 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_ITS" ;

  CREATE INDEX "BO"."T_CLIENT_CREATOR_UID_IDX" ON "BO"."T_CLIENT" ("CREATOR_UID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."T_CLIENT_DOMAIN_CHECK_IDX" ON "BO"."T_CLIENT" ("DOMAIN_CHECK_STATUS")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."T_CLIENT_ID_1C_IDX" ON "BO"."T_CLIENT" ("ID_1C")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 524288 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_ITS" ;

  CREATE INDEX "BO"."T_CLIENT_PERSON_ID_IDX" ON "BO"."T_CLIENT" ("PERSON_ID")
  PCTFREE 10 INITRANS 83 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 524288 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_ITS"
  PARALLEL 5 ;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_CLIENT_UPD"
   BEFORE UPDATE                                          /*dt,
                                                            client_type_id,
                                                            NAME,
                                                            email,
                                                            phone,
                                                            fax,
                                                            url,
                                                            is_agency,
                                                            person_id,
                                                            id_1c,
                                                            internal,
                                                            is_wholesaler,
                                                            full_repayment,
                                                            class_id,
                                                            agency_id,
                                                            oper_id,
                                                            creator_uid,
                                                            manual_suspect,
                                                            is_aggregator,
                                                            direct25,
                                                            is_docs_separated,
                                                            is_docs_detailed*/
   ON bo.t_client
   REFERENCING NEW AS NEW OLD AS OLD
   FOR EACH ROW

BEGIN
   IF    (    :NEW.manual_suspect_comment IS NOT NULL
          AND :OLD.manual_suspect_comment IS NOT NULL
          AND DBMS_LOB.compare (:NEW.manual_suspect_comment,
                                :OLD.manual_suspect_comment
                               ) = -1
         )
      OR (    :NEW.manual_suspect_comment IS NOT NULL
          AND :OLD.manual_suspect_comment IS NULL
         )
      OR (    :NEW.manual_suspect_comment IS NULL
          AND :OLD.manual_suspect_comment IS NOT NULL
         )
      OR NVL (:NEW.NAME, -1) <> NVL (:OLD.NAME, -1)
      OR NVL (:NEW.email, -1) <> NVL (:OLD.email, -1)
      OR :NEW.dt <> :OLD.dt
      OR :NEW.client_type_id <> :OLD.client_type_id
      OR NVL (:NEW.phone, -1) <> NVL (:OLD.phone, -1)
      OR NVL (:NEW.fax, -1) <> NVL (:OLD.fax, -1)
      OR NVL (:NEW.url, -1) <> NVL (:OLD.url, -1)
      OR :NEW.is_agency <> :OLD.is_agency
      OR NVL (:NEW.person_id, -1) <> NVL (:OLD.person_id, -1)
      OR NVL (:NEW.id_1c, -1) <> NVL (:OLD.id_1c, -1)
      OR :NEW.internal <> :OLD.internal
      OR NVL (:NEW.is_wholesaler, -1) <> NVL (:OLD.is_wholesaler, -1)
      OR :NEW.full_repayment <> :OLD.full_repayment
      OR :NEW.class_id <> :OLD.class_id
      OR :NEW.agency_id <> :OLD.agency_id
      OR NVL (:NEW.oper_id, -1) <> NVL (:OLD.oper_id, -1)
      OR NVL (:NEW.creator_uid, -1) <> NVL (:OLD.creator_uid, -1)
      OR :NEW.manual_suspect <> :OLD.manual_suspect
      OR NVL (:NEW.is_aggregator, -1) <> NVL (:OLD.is_aggregator, -1)
      OR :NEW.direct25 <> :OLD.direct25
      OR :NEW.is_docs_separated <> :OLD.is_docs_separated
      OR :NEW.is_docs_detailed <> :OLD.is_docs_detailed
      OR :NEW.budget <> :OLD.budget
      OR :NEW.overdraft_limit <> :OLD.overdraft_limit
      OR :NEW.overdraft_ban <> :OLD.overdraft_ban
      OR NVL(:NEW.region_id, -1) <> NVL(:OLD.region_id, -1)
      OR :NEW.PARTNER_TYPE <> :OLD.PARTNER_TYPE
      OR :NEW.SUBREGION_ID <> :OLD.SUBREGION_ID
      OR :NEW.OFFICE_ID <> :OLD.OFFICE_ID
   THEN
      INSERT INTO bo.t_client_history_v2
                  (client_id, start_dt, end_dt, client_type_id,
                   NAME, email, phone, fax, url,
                   is_agency, person_id, id_1c,
                   internal, is_wholesaler, full_repayment,
                   class_id, agency_id, oper_id,
                   suspect, creator_uid, manual_suspect,
                   is_aggregator, direct25,
                   is_docs_separated, is_docs_detailed,
                   manual_suspect_comment, budget,
                   overdraft_limit, overdraft_ban, region_id
                   , PARTNER_TYPE
                   ,SUBREGION_ID, OFFICE_ID)
           VALUES (:OLD.ID, :OLD.dt, SYSDATE, :OLD.client_type_id,
                   :OLD.NAME, :OLD.email, :OLD.phone, :OLD.fax, :OLD.url,
                   :OLD.is_agency, :OLD.person_id, :OLD.id_1c,
                   :OLD.internal, :OLD.is_wholesaler, :OLD.full_repayment,
                   :OLD.class_id, :OLD.agency_id, :OLD.oper_id,
                   :OLD.suspect, :OLD.creator_uid, :OLD.manual_suspect,
                   :OLD.is_aggregator, :OLD.direct25,
                   :OLD.is_docs_separated, :OLD.is_docs_detailed,
                   :OLD.manual_suspect_comment, :OLD.budget,
                   :OLD.overdraft_limit, :OLD.overdraft_ban, :OLD.region_id , :OLD.PARTNER_TYPE,
                   :OLD.SUBREGION_ID, :OLD.OFFICE_ID
                  );

      :NEW.dt := SYSDATE;
   END IF;
END;
/
ALTER TRIGGER "BO"."TR_CLIENT_UPD" ENABLE;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_CLIENT_REGION_ID_CHANGE"
before update
of region_id
on bo.t_client
referencing new as new old as old
for each row
declare
  p_has_currency_orders number;
begin
    --                                                                                                      BALANCE-16182
    if :old.region_id is not null and nvl(:old.region_id, -1) != nvl(:new.region_id, -1) and not (nvl(:old.region_id, -1) = 149 and nvl(:new.region_id, -1) = 225) then

        select case when exists (
            select *
            from
              bo.t_order o
              join BO.t_client_service_data csd on csd.service_id = o.service_id
            where
              csd.class_id = :old.id
              and
              o.service_id in (
                select id
                from bo.t_service
                where client_only = 0
                )
              and
              csd.iso_currency is not null and csd.migrate_to_currency is not null and csd.migrate_to_currency < sysdate
              and
              o.client_id = :old.id
        ) then 1 else 0 end has_currency_orders
        into p_has_currency_orders
        from dual;
        if p_has_currency_orders = 1 then
            raise_application_error(-20001, 'Can not change region_id for client ' || :old.id || '. Old is ' || :old.region_id || ', new is ' || :new.region_id);
        end if;
    end if;
end;
/
ALTER TRIGGER "BO"."TR_CLIENT_REGION_ID_CHANGE" ENABLE;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_CLIENT_GRANT_AGENCY"
AFTER INSERT OR UPDATE
OF IS_AGENCY
ON BO.T_CLIENT
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
    cursor c_users(p_client_id in number) is
        select uc.passport_id, ru.role_id, count(a.perm) perm_cnt
            from v_user_client uc, t_role_user ru, t_acl_2 a
            where uc.client_id = p_client_id and
                uc.passport_id = ru.passport_id(+) and
                uc.passport_id = a.passport_id(+)
            group by uc.passport_id, ru.role_id;
BEGIN
    IF :NEW.IS_AGENCY IS NOT NULL AND
        :NEW.IS_AGENCY <> 0
    THEN
        -- grant Agency role to all users of this client.
        for rec in c_users(:NEW.id) loop
            if rec.perm_cnt = 0 then
                if rec.role_id is null then
                    insert into t_role_user(role_id, passport_id)
                        values(2, rec.passport_id);
                end if;
                if rec.role_id = 3 then
                    update t_role_user set role_id = 2
                        where passport_id = rec.passport_id;
                end if;
            end if;
        end loop;
    ELSE
        -- revoke Agency role from all users of this client.
        for rec in c_users(:NEW.id) loop
            if rec.perm_cnt = 0 then
                if rec.role_id is null then
                    insert into t_role_user(role_id, passport_id)
                        values(3, rec.passport_id);
                end if;
                if rec.role_id = 2 then
                    update t_role_user set role_id = 3
                        where passport_id = rec.passport_id;
                end if;
            end if;
        end loop;
    END IF;
END;
/
ALTER TRIGGER "BO"."TR_CLIENT_GRANT_AGENCY" ENABLE;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_CLIENT_INSA"
AFTER INSERT  ON bo.T_CLIENT
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
  insert into t_object_notification(opcode, object_id, last_scn)
    values(10, :new.id, 0);
END;
/
ALTER TRIGGER "BO"."TR_CLIENT_INSA" ENABLE;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_CLIENT_BINS"
BEFORE INSERT
ON BO.T_CLIENT
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
BEGIN
  IF :new.id IS NULL THEN
    SELECT S_CLIENT_ID.nextval INTO :new.id FROM dual;
  END IF;
  IF :new.class_id IS NULL THEN
    :NEW.class_id := :NEW.ID;
  END IF;
  IF :new.agency_id IS NULL AND :new.is_agency = 1 THEN
    :NEW.agency_id := :NEW.ID;
  END IF;
END;
/
ALTER TRIGGER "BO"."TR_CLIENT_BINS" ENABLE;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_CLIENT_UPDO"
BEFORE UPDATE
OF OVERDRAFT_LIMIT,
   overdraft_ban
ON BO.T_CLIENT REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
 WHEN (
new.overdraft_limit <> old.overdraft_limit or new.overdraft_ban <> old.overdraft_ban
) BEGIN
   INSERT INTO bo.t_overdraft_history
               (client_id,  end_dt, overdraft_limit, overdraft_ban
               )
        VALUES (:OLD.ID, SYSDATE, :OLD.OVERDRAFT_LIMIT, :OLD.overdraft_ban
               );

   :NEW.dt := SYSDATE;
END;
/
ALTER TRIGGER "BO"."TR_CLIENT_UPDO" ENABLE;

--changeset nebaruzdin:BALANCE-23787

alter table bo.t_client add iso_currency_payment varchar2(16);

--changeset nebaruzdin:BALANCE-23787-1 endDelimiter:\\

create or replace editionable trigger bo.tr_client_upd
before update
on bo.t_client referencing new as new old as old
for each row
begin
    if (
        :new.manual_suspect_comment is not null
        and :old.manual_suspect_comment is not null
        and dbms_lob.compare (
            :new.manual_suspect_comment,
            :old.manual_suspect_comment
        ) = -1
    )
    or (
        :new.manual_suspect_comment is not null
        and :old.manual_suspect_comment is null
    )
    or (
        :new.manual_suspect_comment is null
        and :old.manual_suspect_comment is not null
    )
    or nvl(:new.name, -1) <> nvl(:old.name, -1)
    or nvl(:new.email, -1) <> nvl(:old.email, -1)
    or :new.dt <> :old.dt
    or :new.client_type_id <> :old.client_type_id
    or nvl(:new.phone, -1) <> nvl(:old.phone, -1)
    or nvl(:new.fax, -1) <> nvl(:old.fax, -1)
    or nvl(:new.url, -1) <> nvl(:old.url, -1)
    or :new.is_agency <> :old.is_agency
    or nvl(:new.person_id, -1) <> nvl (:old.person_id, -1)
    or nvl(:new.id_1c, -1) <> nvl (:old.id_1c, -1)
    or :new.internal <> :old.internal
    or nvl(:new.is_wholesaler, -1) <> nvl (:old.is_wholesaler, -1)
    or :new.full_repayment <> :old.full_repayment
    or :new.class_id <> :old.class_id
    or :new.agency_id <> :old.agency_id
    or nvl(:new.oper_id, -1) <> nvl (:old.oper_id, -1)
    or nvl(:new.creator_uid, -1) <> nvl(:old.creator_uid, -1)
    or :new.manual_suspect <> :old.manual_suspect
    or nvl(:new.is_aggregator, -1) <> nvl(:old.is_aggregator, -1)
    or :new.direct25 <> :old.direct25
    or :new.is_docs_separated <> :old.is_docs_separated
    or :new.is_docs_detailed <> :old.is_docs_detailed
    or :new.budget <> :old.budget
    or :new.overdraft_limit <> :old.overdraft_limit
    or :new.overdraft_ban <> :old.overdraft_ban
    or nvl(:new.region_id, -1) <> nvl(:old.region_id, -1)
    or :new.partner_type <> :old.partner_type
    or :new.subregion_id <> :old.subregion_id
    or :new.office_id <> :old.office_id
    or nvl(:new.iso_currency_payment, -1) <> nvl(:old.iso_currency_payment, -1)
    then
        insert into bo.t_client_history_v2 (
            client_id,
            start_dt,
            end_dt,
            client_type_id,
            name,
            email,
            phone,
            fax,
            url,
            is_agency,
            person_id,
            id_1c,
            internal,
            is_wholesaler,
            full_repayment,
            class_id,
            agency_id,
            oper_id,
            suspect,
            creator_uid,
            manual_suspect,
            is_aggregator,
            direct25,
            is_docs_separated,
            is_docs_detailed,
            manual_suspect_comment,
            budget,
            overdraft_limit,
            overdraft_ban,
            region_id,
            partner_type,
            subregion_id,
            office_id,
            iso_currency_payment
        )
        values (
            :old.id,
            :old.dt,
            sysdate,
            :old.client_type_id,
            :old.name,
            :old.email,
            :old.phone,
            :old.fax,
            :old.url,
            :old.is_agency,
            :old.person_id,
            :old.id_1c,
            :old.internal,
            :old.is_wholesaler,
            :old.full_repayment,
            :old.class_id,
            :old.agency_id,
            :old.oper_id,
            :old.suspect,
            :old.creator_uid,
            :old.manual_suspect,
            :old.is_aggregator,
            :old.direct25,
            :old.is_docs_separated,
            :old.is_docs_detailed,
            :old.manual_suspect_comment,
            :old.budget,
            :old.overdraft_limit,
            :old.overdraft_ban,
            :old.region_id ,
            :old.partner_type,
            :old.subregion_id,
            :old.office_id,
            :old.iso_currency_payment
        );

        :new.dt := sysdate;
    end if;
end;

\\

--changeset srg91:TRUST-2543

alter table bo.t_client add is_acquiring number(1,0);
alter table bo.t_client modify is_acquiring default 0;

update bo.t_client
set is_acquiring = 1
where id in (
  select client_id
  from bo.t_contract2
  where
    type = 'ACQUIRING'
);

--changeset nebaruzdin:BALANCE-28474

update /*+ parallel(8) */ bo.t_client
set iso_currency_payment = 'RUB'
where
    iso_currency_payment = 'RUR';

--changeset el-yurchito:BALANCE-30155 endDelimiter:\\
create or replace trigger BO.TR_CLIENT_REGION_ID_CHANGE
	before update of REGION_ID
	on BO.T_CLIENT
	for each row
declare
  p_has_currency_orders number;
begin
    if :old.region_id is not null and nvl(:old.region_id, -1) != nvl(:new.region_id, -1) and not (nvl(:old.region_id, -1) = 149 and nvl(:new.region_id, -1) = 225) then
        select case when exists (
            select *
            from
              bo.t_order o
              join BO.t_client_service_data csd on csd.service_id = o.service_id
            where
              csd.class_id = :old.id
              and o.service_id in (
                select id
                from bo.v_service
                where client_only = 0
              )
              and csd.iso_currency is not null
              and csd.migrate_to_currency is not null
              and csd.migrate_to_currency < sysdate
              and o.client_id = :old.id
        ) then 1 else 0 end has_currency_orders
        into p_has_currency_orders
        from dual;

        if p_has_currency_orders = 1 then
            raise_application_error(-20001, 'Can not change region_id for client ' || :old.id || '. Old is ' || :old.region_id || ', new is ' || :new.region_id);
        end if;
    end if;
end;
\\