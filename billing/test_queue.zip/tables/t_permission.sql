--liquibase formatted sql

CREATE TABLE "BO"."T_PERMITION"
    ("PERM" NUMBER,
	"NAME" VARCHAR2(128 BYTE),
	"IFACE_PLACE" VARCHAR2(64 BYTE),
	"IFACE_ITEM" VARCHAR2(64 BYTE),
	"CODE" VARCHAR2(64 BYTE) NOT NULL ENABLE,
	CONSTRAINT "T_PERMITION_PK" PRIMARY KEY ("PERM")
	USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
	STORAGE(INITIAL 524288 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
	    PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
	    BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
	TABLESPACE "YACC_KTS"  ENABLE
	) SEGMENT CREATION IMMEDIATE
    PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
    NOCOMPRESS LOGGING
    STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
	PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
	BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
    TABLESPACE "YACC_OTS" ;

CREATE OR REPLACE FORCE EDITIONABLE VIEW "BO"."T_PERMISSION" ("PERM", "NAME", "IFACE_PLACE", "IFACE_ITEM", "CODE") AS
select perm, name, iface_place, iface_item, code
from bo.t_permition;

--changeset vaclav:TRUST-2266-0

insert into bo.t_permission (perm, name, code) values (4002, 'Платежные ссылки. Сервис YDF', 'PaymentLinks152');

--changeset ashvedunov:BALANCE-23866-0
insert into bo.t_permission (perm, name, code) values (50, 'Управление архивом', 'ManageArchive');

--changeset quark:BALANCE-25015
insert into bo.t_permission (perm, name, code)
select
    52 PERM,
    'Изменение документов фирмы '||(select title from bo.t_firm where id = 112) NAME,
    'AlterFirmRUCloud' CODE
from dual;

--changeset quark:BALANCE-25302
insert into bo.t_permission (perm, name, code)
select
    54 PERM,
    'Изменение документов фирмы '||(select title from bo.t_firm where id = 113) NAME,
    'AlterFirmRUCloud' CODE
from dual;

--changeset nebaruzdin:BALANCE-25259

insert into bo.t_permition (
    perm,
    name,
    code
)
select
    53                                            as perm,
    'Изменение документов фирмы '
    ||(select title from bo.t_firm where id = 26) as name,
    'AlterFirmAMTaxi'                             as code
from dual;

--changeset dimonb:BALANCE-24783

insert into bo.t_permition (
    perm,
    name,
    code
)
select
    55                                            as perm,
    'Изменение шаблона печатной формы в договре',
    'AlterPrintTemplate'                             as code
from dual;

--changeset srg91:TRUST-3631

insert into bo.t_permission p
  (perm, name, code)
values
  (56, 'Просмотр терминала', 'TerminalView')
;

insert into bo.t_permission p
  (perm, name, code)
values
  (57, 'Редактирование терминала', 'TerminalEdit')
;

insert into bo.t_permission p
  (perm, name, code)
values
  (58, 'Редактирование клиента: простановка флага deny_cc / fraud_status', 'ClientFraudStatusEdit')
;

--changeset nebaruzdin:BALANCE-27232

insert into bo.t_permission p
    (perm, name, code)
values
    (2001, 'Директ: C ограниченным доступом', 'DirectLimited')
;

--changeset quark:BALANCE-28047

insert into bo.t_permition (perm, name, code)
select
  (select max(perm) + 1 from bo.t_permition where perm < 1000)                 PERM,
  'Изменение документов фирмы '||(select title from bo.t_firm where id = 115)  NAME,
  'AlterFirmNVTaxiuber'                                                        CODE
from dual;

--changeset dolvik:BALANCE-28144

insert into bo.t_permition (perm, name, code)
select
  64                                                                           PERM,
  'Возможность работы с новыми блоками интерфейса сайта'                       NAME,
  'NewUIEarlyAdopter'                                                          CODE
from dual;

--changeset natabers:BALANCE-28045-1
insert into bo.t_permission p
    (perm, name, code)
values
    (4003, 'Редактировать промокоды', 'EditPromoCode');
