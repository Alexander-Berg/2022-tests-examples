--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for table T_CONTRACT_COMSN_TYPE
--------------------------------------------------------------------------------

CREATE TABLE T_CONTRACT_COMSN_TYPE
(
  ID        NUMBER               NOT NULL
    CONSTRAINT T_CONTRACT_COMSN_TYPE_PK
    PRIMARY KEY,
  NAME      VARCHAR2(250)        NOT NULL,
  UPDATE_DT DATE DEFAULT sysdate NOT NULL
)
/

CREATE MATERIALIZED VIEW LOG ON T_CONTRACT_COMSN_TYPE
WITH PRIMARY KEY (ID)
INCLUDING NEW VALUES
/


--changeset natabers:BALANCE-27404-1
insert into bo.t_contract_comsn_type(id, name, update_dt) values(60, 'Казахстан', SYSDATE);
