--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_CLIENT_OVERDRAFT_HISTORY
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_CLIENT_OVERDRAFT_HISTORY"
   (	"CLIENT_ID" NUMBER,
	"START_DT" DATE,
	"END_DT" DATE,
	"OVERDRAFT_LIMIT" NUMBER,
	"SERVICE_ID" NUMBER,
	"FIRM_ID" NUMBER,
	"CURRENCY" VARCHAR2(16 BYTE)
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset nebaruzdin:BALANCE-23787

alter table bo.t_client_overdraft_history add iso_currency varchar2(16);

--changeset nebaruzdin:BALANCE-28474

declare
    batch_size constant number := 200000;
    i number;
begin
    loop
        update /*+ parallel(8) */ bo.t_client_overdraft_history
        set iso_currency = decode(upper(currency),
                                  'RUR', 'RUB',
                                  upper(currency))
        where
            iso_currency is null
            and currency is not null
            and rownum <= batch_size;

        i := sql%rowcount;
        system.simple_logger.log_add('BALANCE-28474',
                                     'bo.t_client_overdraft_history ' ||
                                     i || ' ' ||
                                     to_char(sysdate,'DD-MON-RRRR HH24:MI:SS'));
        exit when i <= 0;
        commit;
    end loop;
end;
/
