--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_SERVICE_PRICE
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_SERVICE_PRICE"
   (	"ID" NUMBER NOT NULL ENABLE,
	"SERVICE_PRODUCT_ID" NUMBER NOT NULL ENABLE,
	"DT" DATE,
	"REGION_ID" NUMBER,
	"CLID" VARCHAR2(50 BYTE),
	"PRICE" NUMBER NOT NULL ENABLE,
	"CURRENCY" VARCHAR2(16 BYTE) NOT NULL ENABLE,
	"UPDATE_DT" DATE DEFAULT sysdate,
	"RECORD_TYPE" VARCHAR2(50 BYTE) DEFAULT 'price',
	 PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE,
	 FOREIGN KEY ("SERVICE_PRODUCT_ID")
	  REFERENCES "BO"."T_SERVICE_PRODUCT" ("ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."IDX_SERVICE_PRICE_PRODUCT_ID" ON "BO"."T_SERVICE_PRICE" ("SERVICE_PRODUCT_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_ITS"
  PARALLEL 5 ;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_SERVICE_PRICE_UPD"
  BEFORE DELETE OR UPDATE
OF
  ID,
  UPDATE_DT,
  SERVICE_PRODUCT_ID,
  DT,
  REGION_ID,
  CLID,
  PRICE,
  CURRENCY
ON BO.t_service_price
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
BEGIN
  INSERT INTO BO.t_service_price_history
               (ID, start_dt, end_dt, service_product_id,
                dt, region_id, clid, price, currency)
        VALUES (:OLD.ID, :OLD.update_dt, SYSDATE, :OLD.service_product_id,
                :OLD.dt, :OLD.region_id, :OLD.clid, :OLD.price, :OLD.currency);
   IF UPDATING
   THEN
      :NEW.update_dt := SYSDATE;
   END IF;
END;
/
ALTER TRIGGER "BO"."TR_SERVICE_PRICE_UPD" ENABLE;

--changeset nebaruzdin:BALANCE-23787-1

alter table bo.t_service_price add iso_currency varchar2(16);

--changeset nebaruzdin:BALANCE-23787-2 endDelimiter:\\

create or replace editionable trigger bo.tr_service_price_upd
before delete or update of
    id,
    update_dt,
    service_product_id,
    dt,
    region_id,
    clid,
    price,
    currency,
    iso_currency
on bo.t_service_price referencing new as new old as old
for each row
begin
    insert into bo.t_service_price_history (
        id,
        start_dt,
        end_dt,
        service_product_id,
        dt,
        region_id,
        clid,
        price,
        currency,
        iso_currency
    )
    values (
        :old.id,
        :old.update_dt,
        sysdate,
        :old.service_product_id,
        :old.dt,
        :old.region_id,
        :old.clid,
        :old.price,
        :old.currency,
        :old.iso_currency
    );
    if updating
    then
        :new.update_dt := sysdate;
    end if;
end;

\\

--changeset nebaruzdin:BALANCE-28474-1

update /*+ parallel(8) */ bo.t_service_price
set
    iso_currency = decode(upper(currency), 'RUR', 'RUB', upper(currency))
where
    iso_currency is null;

--changeset nebaruzdin:BALANCE-28474-2

alter table bo.t_service_price
modify iso_currency not null enable;
