--liquibase formatted sql

--changeset vorobyov-as:completions_overhaul

create global temporary table bo.tmp_tarification_entity

    (product_id integer,
     key_num_1 integer,
     key_num_2 integer,
     key_num_3 integer,
     key_num_4 integer,
     key_num_5 integer,
     key_num_6 integer
     ) on commit delete rows;