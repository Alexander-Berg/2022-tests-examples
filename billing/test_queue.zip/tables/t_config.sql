--liquibase formatted sql


  CREATE TABLE "BO"."T_CONFIG"
   (	"ITEM" VARCHAR2(256 BYTE),
	"DESC" VARCHAR2(512 BYTE),
	"VALUE_DT" DATE DEFAULT NULL,
	"VALUE_NUM" NUMBER DEFAULT NULL,
	"VALUE_STR" VARCHAR2(256 BYTE) DEFAULT NULL,
	"VALUE_JSON" VARCHAR2(4000 CHAR) DEFAULT NULL,
	 CONSTRAINT "T_CONFIG_PK" PRIMARY KEY ("ITEM")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE,
	 CONSTRAINT "T_CONFIG_CHECK_VALUES" CHECK ((VALUE_STR IS NULL AND VALUE_DT IS NULL AND VALUE_NUM IS NULL AND VALUE_JSON IS NULL) OR (VALUE_STR IS NOT NULL AND VALUE_DT IS NULL AND VALUE_NUM IS NULL AND VALUE_JSON IS NULL) OR (VALUE_STR IS NULL AND VALUE_DT IS NOT NULL AND VALUE_NUM IS NULL AND VALUE_JSON IS NULL) OR (VALUE_STR IS NULL AND VALUE_DT IS NULL AND VALUE_NUM IS NOT NULL AND VALUE_JSON IS NULL)  OR (VALUE_STR IS NULL AND VALUE_DT IS NULL AND VALUE_NUM IS NULL AND VALUE_JSON IS NOT NULL)) ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset yanametro:BALANCE-23986
UPDATE BO.T_CONFIG
SET VALUE_JSON='[135, 101, 102, 111, 118, 120, 126, 128, 129, 131, 188, 35, 80, 98, 130, 131, 151]'
WHERE item='PARTNER_SERVICES';

-- changeset bwh1te:BALANCE-23913
UPDATE bo.t_config
SET value_json='[135, 101, 102, 111, 118, 120, 126, 128, 129, 131, 188, 35, 80, 98, 130, 131, 141, 142, 151]'
WHERE item='PARTNER_SERVICES';


-- changeset ngolovkin:BALANCE-24000
insert into bo.t_config
select 'NEW_PAYSTEP_SERVICES'                           ITEM,
'A list of service IDs that use the new paystep'        "DESC",
null                                                    VALUE_DT,
null                                                    VALUE_NUM,
null                                                    VALUE_STR,
'[]'                                                    VALUE_JSON
-- [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15, 16, 17, 23, 26, 35, 37, 42, 45, 46, 48, 49, 50, 65, 67, 70, 77, 80, 81, 82, 90, 97, 98, 99, 101, 102, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 140, 141, 142, 151, 152, 153, 154, 155, 156, 157, 167, 470, 555, 556, 560]
from dual
where not exists (select * from bo.t_config where item = 'NEW_PAYSTEP_SERVICES');


-- changeset yanametro:BALANCE-24532-1
UPDATE bo.t_config
SET value_json='[135, 101, 102, 111, 118, 120, 126, 128, 129, 131, 188, 35, 80, 98, 130, 131, 141, 142, 151, 153]'
WHERE item='PARTNER_SERVICES';

-- changeset quark:BALANCE-24794
INSERT INTO BO.T_CONFIG (ITEM, "DESC", VALUE_DT, VALUE_NUM, VALUE_STR, VALUE_JSON)
VALUES ('TAXI_RUSSIA_NO_PAYSYS_COMMISSION_START_DT', 'TAXI_RUSSIA_NO_PAYSYS_COMMISSION_START_DT ', TO_DATE('2032-07-05 14:16:20', 'YYYY-MM-DD HH24:MI:SS'), null, null, null);

--changeset yanametro:BALANCE-24704
UPDATE bo.t_config
SET value_json='[135, 101, 102, 111, 118, 120, 126, 128, 129, 131, 188, 35, 80, 98, 130, 131, 141, 142, 151, 153, 190]'
WHERE item='PARTNER_SERVICES';

--changeset yanametro:BALANCE-24893-1
UPDATE bo.t_config
SET value_json='[135, 101, 102, 111, 118, 120, 126, 128, 129, 131, 188, 35, 80, 98, 130, 131, 141, 142, 151, 153, 190, 171]'
WHERE item='PARTNER_SERVICES';

--changeset yanametro:BALANCE-25181
UPDATE bo.t_config
SET value_json='[135, 101, 102, 111, 118, 120, 126, 128, 129, 131, 188, 35, 80, 98, 130, 131, 141, 142, 151, 153, 190, 171, 170]'
WHERE item='PARTNER_SERVICES';

--changeset yanametro:BALANCE-25329
UPDATE bo.t_config
SET value_json='[23, 35, 80, 98, 101, 102, 111, 118, 120, 126, 128, 129, 130, 131, 131, 135, 141, 142, 151, 153, 170, 171, 188, 190]'
WHERE item='PARTNER_SERVICES';

--changeset yanametro:BALANCE-25341
insert into bo.t_config(item, "DESC", VALUE_NUM)
values ('PARTNER_COMPLETION_RESOURCE', 'Partner Completions with queues', 0);

-- changeset ashvedunov:BALANCE-24488-2
INSERT into bo.t_config
(item, "DESC", value_dt) values
('EDO_OFFER_STATUS', 'Last Edo offer status update date', date'2000-01-01');

--changeset yanametro:BALANCE-25479
delete from bo.t_config where item='PARTNER_SERVICES';

--changeset ngolovkin:BALANCE-25211-1
delete from (
    select * from bo.t_config where item = 'CASH_REGISTER_RECEIPT_PASSPORT_IDS'
);

--changeset ngolovkin:BALANCE-25211-2
Insert into bo.t_config (ITEM,"DESC",VALUE_DT,VALUE_NUM,VALUE_STR,VALUE_JSON)
values ('CASH_REGISTER_RECEIPT_PASSPORT_IDS','Passport ids for cash register receipts',null,null,null,'[16571028, 44637656]');


--changeset ngolovkin:BALANCE-25743-1
delete from (
    select * from bo.t_config where item = 'ALLOWED_RECEIPTS_SERVICES'
);

--changeset ngolovkin:BALANCE-25743-2
Insert into bo.t_config (ITEM,"DESC",VALUE_DT,VALUE_NUM,VALUE_STR,VALUE_JSON)
values ('ALLOWED_RECEIPTS_SERVICES','A list of service IDs that use the new paystep',null,null,null,'[129,140]');

--changeset yanametro:BALANCE-25341-1
update bo.T_CONFIG
set item='PARTNER_COMPLETIONS_RESOURCE'
where item ='PARTNER_COMPLETION_RESOURCE';

--changeset krissmacer:APIKEYS-460
UPDATE bo.t_config
SET value_json='[42,81,90,98,132,99,26,82,139,143,67,167,77,70,11,37,102,50,111,137,128,124,141,142,190,80,151,153,119,172,126,114,118,131,101,120,135,130,127,122,170,117,171,17,16,6,4,5,560,556,555,9,154,155,156,157,2,3,97,8,1,134,133,10,15,49,65,470,45,113,46,136,121,48,152,112,138,140,7,35]'
WHERE item='NEW_PAYSTEP_SERVICES';

--changeset halty:BALANCE-25241
UPDATE bo.t_config
SET value_json='[202, 42,81,90,98,132,99,26,82,139,143,67,167,77,70,11,37,102,50,111,137,128,124,141,142,190,80,151,153,119,172,126,114,118,131,101,120,135,130,127,122,170,117,171,17,16,6,4,5,560,556,555,9,154,155,156,157,2,3,97,8,1,134,133,10,15,49,65,470,45,113,46,136,121,48,152,112,138,140,7,35]'
WHERE item='NEW_PAYSTEP_SERVICES';

--changeset lightrevan:BALANCE-26200
INSERT INTO BO.T_CONFIG (ITEM, "DESC", VALUE_JSON)
VALUES ('UA_PROCESS_BY_ORDERS', 'Process UA clients by orders in parallel', '{"Client_ids": []}')
;

--changeset lightrevan:BALANCE-25392
INSERT INTO bo.t_config (item, "DESC", value_json)
VALUES ('MAILING_FRAUD_FIRMS_IDS', 'Firms ids for notification about fraud', '[1, 4, 7, 16, 111]');

--changeset lightrevan:BALANCE-24287
INSERT INTO bo.t_config (item, "DESC", value_json)
VALUES ('MAILING_FRAUD_INSTANT_PAYSYS_CCS', 'Desired instant paysys ccs for notification about fraud', '["as", "cc_sw_chf", "cc_sw_eur", "cc_sw_ur_chf", "cc_sw_ur_eur", "cc_sw_ur_usd", "cc_sw_usd", "cc_sw_yt_chf", "cc_sw_yt_eur", "cc_sw_yt_usd", "cc_ua", "cc_ur", "cc_usd_p", "cc_usd_u", "cc_yt_chf", "cc_yt_eur", "cc_yt_rur", "cc_yt_usd", "pc", "qiwi_cab", "sms", "tt_cc_rub_swytph", "tt_cc_usd_swytph", "tt_mc_rub_swytph", "tt_ym_rub_swytph", "wm_pm", "wmu", "ym_ua"]');

--changeset lightrevan:BALANCE-26371
INSERT INTO bo.t_config (item, "DESC", value_json)
VALUES ('ALLOWED_PRODUCT_CHANGES', 'Map of allowed changes of products in orders', '{"503166": []}');

--changeset halty:APIKEYS-460
UPDATE bo.t_config
SET value_json='[202,42,81,90,98,132,99,26,82,139,143,67,167,77,70,11,37,102,50,111,137,128,124,141,142,190,80,151,153,119,172,126,114,118,131,101,120,135,130,127,122,170,117,171,17,16,6,4,5,560,556,555,9,154,155,156,157,2,3,97,8,1,134,133,10,15,49,65,470,45,113,46,136,121,48,152,112,138,140,7,35,115,116,129]'
WHERE item='NEW_PAYSTEP_SERVICES';

--changeset el-yurchito:BALANCE-26014
INSERT INTO BO.T_CONFIG ("ITEM", "DESC", "VALUE_DT")
VALUES ('MARKETPLACE_NEW_DELIVERED_DT_ENABLED', 'New marketplace delivered_dt logic enabled since', TO_DATE('2020-01-31 12:00:00', 'YYYY-MM-DD HH24:MI:SS'));

--changeset lightrevan:BALANCE-24338
INSERT INTO BO.T_CONFIG ("ITEM", "DESC", "VALUE_NUM")
VALUES ('DEAL_PASSPORT_OFERT_LIMIT', 'Limit of sum of ofert invoice for clients with required deal passport', 50000);

--changeset nebaruzdin:BALANCE-26573-1
insert into bo.t_config (item, "DESC", value_json)
values ('SERVICE_TO_FIRM_TO_OVERDRAFT_PARAMS',
        'Overdrafts metadata',
        '{"7": {"1": {"thresholds": {"null": 4000, "RUB": 120000}, "start_dt": null, "end_dt": null, "turnover_firms": [1]}, "25": {"thresholds": {"null": 4980, "KZT": 600000}, "start_dt": null, "end_dt": null, "turnover_firms": [25]}, "27": {"thresholds": {"null": 3150, "BYN": 3900}, "start_dt": null, "end_dt": null, "turnover_firms": [27, 1]}}, "11": {"1": {"thresholds": {"null": 4000}, "start_dt": null, "end_dt": null, "turnover_firms": [1]}, "111": {"thresholds": {"null": 4000}, "start_dt": null, "end_dt": null, "turnover_firms": [111]}}}'
);

--changeset el-yurchito:BALANCE-27034 endDelimiter:\\
INSERT INTO bo.T_CONFIG ("ITEM", "DESC", "VALUE_DT")
VALUES ('DISABLE_HEALTH_PAYMENTS_EXPORT_SINCE', 'Payments with service_id in (153, 170, 204, 270) are not allowed to export since', TO_DATE('2017-12-28 10:00:00', 'YYYY-MM-DD HH24:MI:SS'))
\\

--changeset yanametro:BALANCE-27034
INSERT INTO bo.T_CONFIG ("ITEM", "DESC", "VALUE_NUM")
VALUES ('SB_MAIL_SENDER', 'Simple brother mail sender', 0);

--changeset lightrevan:BALANCE-27230
INSERT INTO bo.T_CONFIG ("ITEM", "DESC", "VALUE_NUM")
VALUES ('OVERDRAFT_RO_SESSION', 'Whether should use RO sessions for select in overdraft_job', 1);

--changeset lightrevan:BALANCE-25393-switch
INSERT INTO bo.t_config (item, "DESC", value_num)
VALUES ('CACHE_FIXED_MONEY_QTY', 'Switch for caching COMPLETION_FIXED_MONEY_QTY', 0);

--changeset lightrevan:BALANCE-27033
UPDATE bo.T_CONFIG
    SET value_num =  5999000
WHERE ITEM = 'DEAL_PASSPORT_OFERT_LIMIT';

--changeset akatovda:BALANCE-26949
INSERT INTO BO.T_CONFIG ("ITEM", "DESC", "VALUE_NUM")
VALUES ('AVIA_REVERSE_PARTNERS_SCHEME_ENABLED', 'Enable reverse partners scheme for Yandex.Avia', 1);

--changeset lightrevan:BALANCE-26463
INSERT INTO BO.T_CONFIG ("ITEM", "DESC", "VALUE_JSON")
VALUES ('OLD_PAYSTEP_SERVICES', 'The list of service IDs that still use old paystep', '[23, 123]');

--changeset lightrevan:BALANCE-27689
INSERT INTO BO.T_CONFIG ("ITEM", "DESC", "VALUE_JSON")
VALUES ('ALLOWED_REPAYMENT_SPLIT_COMMTYPES', 'Comission type sets that can be in single repayment', '[[[7, 37], 7]]');

--changeset akatovda:BALANCE-27799
INSERT INTO BO.T_CONFIG ("ITEM", "DESC", "VALUE_JSON")
VALUES ('STAGER_FORCE_SYNC_AGGREGATION', 'Force sync YT aggregation (WARNING: aggregation jobs may greatly slow down)', '0');

--changeset akatovda:BALANCE-27799-1
INSERT INTO BO.T_CONFIG ("ITEM", "DESC", "VALUE_JSON")
VALUES ('AVIA_PRODUCT_COMPLETIONS_ENABLED', 'Enable avia product completions (must be non-nil in base cases)', '1');

--changeset el-yurchito:BALANCE-27722 endDelimiter:\\
INSERT INTO "BO"."T_CONFIG" ("ITEM", "DESC", "VALUE_NUM")
VALUES ('WAIT_FOR_CORRECTION_NETTING_BEFORE_PROCESS_PAYMENT', 'Wait this amount of seconds during PROCESS_PAYMENTS procedure if there are any unhandled CORRECTION_NETTING OEBS payments', 5)
\\

--changeset akatovda:BALANCE-27973
UPDATE BO.T_CONFIG SET VALUE_NUM=0, VALUE_JSON=NULL WHERE ITEM='STAGER_FORCE_SYNC_AGGREGATION';

--changeset akatovda:BALANCE-27973-1
UPDATE BO.T_CONFIG SET VALUE_NUM=1, VALUE_JSON=NULL WHERE ITEM='AVIA_PRODUCT_COMPLETIONS_ENABLED';

--changeset lightrevan:BALANCE-26830
insert into bo.t_config (item, "DESC", value_json)
values ('MONTHLY_ACT_REPORT_SETTINGS', 'Payment types and regions for monthly_act_report', '[["bank", 126], ["bank", 983], ["bank", 84], ["card", 84], ["card", 983]]');

--changeset nebaruzdin:BALANCE-28006

insert into bo.t_config (item, "DESC", value_json)
values ('OVERDRAFT_FIRMS_WITH_EXPIRED_INVOICES_IGNORED',
        'Firms whose expired invoices are ignored when issuing an overdraft',
        '[3, 5]');

--changeset lightrevan:BALANCE-27810
INSERT INTO bo.t_config (item, "DESC", value_json)
VALUES (
  'CONTRACT_NOTIFY_PARTNER_CREDIT',
  'Emails for notifications about intercompany partner credit contracts',
  '["creditcontroller@yandex-team.ru"]'
);


--changeset el-yurchito:BALANCE-28141 endDelimiter:\\
INSERT INTO "BO"."T_CONFIG" ("ITEM", "DESC", "VALUE_NUM")
VALUES ('EXTENDED_PRODUCT_MAPPING', 'Extended ServiceProduct to Product mapping options', 1)
\\

--changeset halty:BALANCE-28141-2 endDelimiter:\\
UPDATE BO.T_CONFIG set VALUE_NUM = 0 where ITEM = 'EXTENDED_PRODUCT_MAPPING'
\\

--changeset lightrevan:BALANCE-28225

INSERT INTO bo.t_config (item, "DESC", value_json)
  VALUES (
    'PAYSYS_TERMINAL_LIMITS_PAYMETHODS',
    'Services and payment methods for which we check sum limits from terminals',
    '[[129, 1101]]'
  );

--changeset quark:BALANCE-28590

update bo.t_config set value_json = replace(value_json, ']',',613]')
where item = 'ALLOWED_RECEIPTS_SERVICES';

--changeset lightrevan:BALANCE-28453
INSERT INTO bo.t_config (item, "DESC", value_num)
  VALUES ('USE_NEW_INVOICE_FACTORY', 'Switch for new InvoiceFactory', 0);

--changeset sfreest:BALANCE-28638
INSERT INTO bo.t_config (item, "DESC", value_num)
  VALUES ('GENERATE_TAXI_PREPAY_ACTS_WITH_POSTPAY', 'Generate taxi (111, 128 services) and corp. taxi (clients, general ' ||
                                                    'contracts, 135 service) with same postpay contracts (the 2nd day ' ||
                                                    'of a month instead the 1st day)', 1);

--changeset el-yurchito:BALANCE-28492 endDelimiter:\\
INSERT INTO "BO"."T_CONFIG" ("ITEM", "DESC", "VALUE_STR")
VALUES ('SIDE_PAYMENTS_REGISTRY_EMAIL_ADDRESS', 'Where payments registries are to be sent to', 'mp@corpmail.co')
\\

--changeset lightrevan:BALANCE-27778-direct-payment-2
MERGE INTO bo.t_config c
  USING (
      SELECT
        'DIRECT_PAYMENT_SERVICE_REGIONS' item,
        'Services and regions with direct payment feature' description,
        '[[7, 225], [123, 225]]' value
      from dual
  ) d
ON (d.item = c.ITEM)
WHEN MATCHED THEN UPDATE SET c."DESC" = d.description, c.value_json = d.value
WHEN NOT MATCHED THEN INSERT (item, "DESC", value_json) VALUES (d.item, d.description, d.value);

--changeset lightrevan:BALANCE-27778-pp-impl
MERGE INTO bo.t_config c
  USING (
      SELECT
        'COMMON_NEW_PAY_POLICY' item,
        'Switch for new pay_policy logic for core' description,
        0 value
      from dual
  ) d
ON (d.item = c.ITEM)
WHEN MATCHED THEN UPDATE SET c."DESC" = d.description, c.VALUE_NUM = d.value
WHEN NOT MATCHED THEN INSERT (item, "DESC", VALUE_NUM) VALUES (d.item, d.description, d.value);

--changeset lightrevan:BALANCE-27778-paystep-settings
MERGE INTO bo.t_config c
  USING (
      SELECT
        'PAYSTEP_NEW_PAY_POLICY' item,
        'Switch for new pay_policy logic on paystep' description,
        0 value
      from dual
  ) d
ON (d.item = c.ITEM)
WHEN MATCHED THEN UPDATE SET c."DESC" = d.description, c.value_num = d.value, c.VALUE_JSON = null
WHEN NOT MATCHED THEN INSERT (item, "DESC", VALUE_NUM) VALUES (d.item, d.description, d.value);

--changeset el-yurchito:BALANCE-29087 endDelimiter:\\
INSERT INTO "BO"."T_CONFIG" ("ITEM", "DESC", "VALUE_JSON")
VALUES ('PROCESS_TAXI_ENQUEUE_SERVICES', 'Contracts with these services are enqueued to PROCESS_TAXI and PREPAY_ACTS',
        '[111, 128, 135, 139, 205, 601, 602]')
\\

--changeset el-yurchito:BALANCE-28987 endDelimiter:\\
UPDATE "BO"."T_CONFIG"
SET VALUE_JSON = '[111, 128, 135, 139, 205, 601, 602, 625]'
WHERE ITEM = 'PROCESS_TAXI_ENQUEUE_SERVICES'
\\

--changeset lightrevan:BALANCE-22401-switch
INSERT INTO bo.t_config (item, "DESC", value_num)
  VALUES ('USE_CALCULATOR_CREATE_INVOICE', 'Switch for new invoice calculator in invoice creation', 0);

--changeset lightrevan:BALANCE-28552-dt
INSERT INTO bo.t_config (item, "DESC", value_num)
  VALUES ('USE_CALCULATOR_PATCH_DATE', 'Switch for new invoice calculator in patch_invoice_date', 0);

--changeset lightrevan:BALANCE-28552-sum
INSERT INTO bo.t_config (item, "DESC", value_num)
  VALUES ('USE_CALCULATOR_PATCH_SUM', 'Switch for new invoice calculator in patch_invoice_sum', 0);

--changeset lightrevan:BALANCE-28552-pcp
INSERT INTO bo.t_config (item, "DESC", value_num)
  VALUES ('USE_CALCULATOR_PATCH_PCP', 'Switch for new invoice calculator in patch_invoice_paysys_person', 0);

--changeset sfreest:BALANCE-28970
delete from bo.t_config
where item = 'GENERATE_TAXI_PREPAY_ACTS_WITH_POSTPAY';

--changeset lightrevan:BALANCE-28633-cfg
MERGE INTO bo.t_config c
USING (
        SELECT
          'TRUNCATE_AUTO_OVERDRAFT' item,
          1                      value_num
        FROM dual
      ) d
ON (c.item = d.item)
WHEN MATCHED THEN UPDATE SET c.value_num = d.value_num
WHEN NOT MATCHED THEN INSERT (item, value_num) VALUES (d.item, d.value_num);

--changeset sfreest:BALANCE-29080-red-market-netting-config
update bo.t_config
set value_json = (select substr(tc.value_json, 0, instr(tc.value_json, ']') - 1)
                  from bo.t_config tc
                  where tc.item = 'PROCESS_TAXI_ENQUEUE_SERVICES') || ', 618]'
where item = 'PROCESS_TAXI_ENQUEUE_SERVICES';

--changeset el-yurchito:BALANCE-29411 endDelimiter:\\
INSERT INTO "BO"."T_CONFIG" ("ITEM", "DESC", "VALUE_JSON")
VALUES ('DUPLICATE_CONTRACT_ALLOWED_SERVICES', 'Can create duplicate GENERAL contracts with these services',
        '[116, 143, 604]')
\\

--changeset el-yurchito:BALANCE-28783 endDelimiter:\\
UPDATE "BO"."T_CONFIG"
SET VALUE_JSON = '[111, 128, 135, 139, 205, 601, 602, 618, 625, 628, 629]'
WHERE ITEM = 'PROCESS_TAXI_ENQUEUE_SERVICES'
\\

--changeset natabers:BALANCE-28045-t_config
INSERT INTO "BO"."T_CONFIG" ("ITEM", "DESC", "VALUE_NUM")
VALUES ('NOTIFY_PROMOCODE_OFF', 'Disable notification order with promocodes', 1);

--changeset lightrevan:BALANCE-29291
MERGE INTO bo.t_config c
USING (
        SELECT
          'MNCLOSE_RETRY_PARAMS' item,
          '{}'                   value
        FROM dual
      ) d
ON (d.item = c.item)
WHEN MATCHED THEN UPDATE SET c.value_json = d.value
WHEN NOT MATCHED THEN INSERT (item, value_json) VALUES (d.item, d.value);

--changeset akatovda:BALANCE-29710
INSERT INTO BO.T_CONFIG ("ITEM", "DESC", "VALUE_JSON") VALUES ('IGNORE_MISSING_SOURCE', 'Do not raise any errors if source tables not found.', '["boyscouts", "buses2"]');

--changeset akatovda:BALANCE-29710-2
UPDATE BO.T_CONFIG SET VALUE_JSON = '["boyscouts", "buses2", "taxi_stand_svo"]' WHERE ITEM = 'IGNORE_MISSING_SOURCE';

--changeset lightrevan:BALANCE-28282-add-role
INSERT INTO bo.t_config (item, "DESC", value_num)
  VALUES ('ADD_ROLE_TO_EXTERNAL', 'Add roles to passport logins', 1);

--changeset lightrevan:BALANCE-28282-add-remove-role
INSERT INTO bo.t_config (item, "DESC", value_num)
  VALUES ('REMOVE_ROLE_FROM_EXTERNAL', 'Remove roles from empty passport logins', 1);

--changeset el-yurchito:BALANCE-30188 endDelimiter:\\
DELETE FROM "BO"."T_CONFIG" WHERE ITEM = 'MARKETPLACE_NEW_DELIVERED_DT_ENABLED'
\\

--changeset sfreest:BALANCE-30260-add-max_taxi_process_completions_dt
INSERT INTO bo.t_config (item, "DESC", value_dt)
  VALUES ('MAX_TAXI_PROCESS_COMPLETIONS_DT', 'For taxi 18% -> 20% NDS change', TO_DATE('2018-12-31 23:59:59', 'YYYY-MM-DD HH24:MI:SS'));

--changeset sfreest:BALANCE-29760-new-taxi-promo-logic
insert into bo.t_config(item, "DESC", value_num)
values('NEW_TAXI_PROMO_LOGIC', 'BALANCE-29760 new taxi promocode logic (subtraction)', 1);
