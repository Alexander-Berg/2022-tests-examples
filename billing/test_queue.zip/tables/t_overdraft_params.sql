--liquibase formatted sql

--------------------------------------------------------------------------------
  -- DDL for table T_OVERDRAFT_PARAMS
--------------------------------------------------------------------------------

--changeset natabers:BALANCE-28633-t_overdraft_params-create-sequence
create sequence bo.s_overdraft_params_id;

--changeset natabers:BALANCE-28633-t_overdraft_params-create-table
create table bo.t_overdraft_params (
    id number default bo.s_overdraft_params_id.nextval not null,
    dt date default sysdate,
    client_id number not null,
    person_id number not null,
    service_id number not null,
    payment_method_cc varchar2(40) not null,
    iso_currency varchar2(10 char),
    client_limit number not null,
    hidden number,
  constraint t_overdraft_params_pk primary key (id),
  constraint t_overdraft_params_cl_fk foreign key (client_id)
    references "BO"."T_CLIENT" ("ID") enable,
  constraint t_overdraft_params_p_fk foreign key (person_id)
    references "BO"."T_PERSON" ("ID") enable,
  constraint t_overdraft_params_pm_fk foreign key (payment_method_cc)
    references "META"."T_PAYMENT_METHOD" ("CC") enable,
  constraint t_overdraft_params_service_fk foreign key (service_id)
      references "META"."T_SERVICE" ("ID") enable,
  constraint t_overdraft_params_s_cl_uq unique (service_id, client_id)
);
