--liquibase formatted sql

  CREATE TABLE "BO"."T_THIRDPARTY_SERVICE"
   (	"ID" NUMBER,
	"POSTAUTH_CHECK" NUMBER,
	"POSTAUTH_READY_CHECK" NUMBER,
	"REWARD_REFUND" NUMBER,
	"GET_COMMISSION_FROM" VARCHAR2(256 BYTE),
	"AGENT_REPORT" NUMBER,
	"FORCE_PARTNER_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;


--changeset yanametro:BALANCE-23986
INSERT INTO BO.T_THIRDPARTY_SERVICE (ID, POSTAUTH_CHECK, POSTAUTH_READY_CHECK, REWARD_REFUND, GET_COMMISSION_FROM, AGENT_REPORT, FORCE_PARTNER_ID)
VALUES (151, null, null, null, null, null, null);

--changeset yanametro:BALANCE-24188
INSERT INTO BO.T_THIRDPARTY_SERVICE (ID, POSTAUTH_CHECK, POSTAUTH_READY_CHECK, REWARD_REFUND, GET_COMMISSION_FROM, AGENT_REPORT, FORCE_PARTNER_ID)
VALUES (119, null, null, null, null, null, null);


--changeset yanametro:BALANCE-24263
delete from bo.t_thirdparty_service where id=151;
INSERT INTO BO.T_THIRDPARTY_SERVICE (ID, POSTAUTH_CHECK, POSTAUTH_READY_CHECK, REWARD_REFUND, GET_COMMISSION_FROM, AGENT_REPORT, FORCE_PARTNER_ID) VALUES (151, null, null, null, null, null, null);
ALTER TABLE bo.T_THIRDPARTY_SERVICE
ADD CONSTRAINT uc_thirdparty_service_id UNIQUE (id);

--changeset yanametro:BALANCE-24323
update bo.T_THIRDPARTY_SERVICE
set AGENT_REPORT=1, POSTAUTH_CHECK=1
where id=151;

--changeset yanametro:BALANCE-24893
INSERT INTO BO.T_THIRDPARTY_SERVICE (ID, POSTAUTH_CHECK, POSTAUTH_READY_CHECK, REWARD_REFUND, GET_COMMISSION_FROM, AGENT_REPORT, FORCE_PARTNER_ID) VALUES (171, null, null, null, null, null, null);

--changeset yanametro:BALANCE-24893-1
update bo.T_THIRDPARTY_SERVICE
set FORCE_PARTNER_ID=32550570
where id=171;


--changeset yanametro:BALANCE-25181
INSERT INTO BO.T_THIRDPARTY_SERVICE (ID, POSTAUTH_CHECK, POSTAUTH_READY_CHECK, REWARD_REFUND, GET_COMMISSION_FROM, AGENT_REPORT, FORCE_PARTNER_ID) VALUES (170, null, null, null, null, null, null);

--changeset halty:BALANCE-25294
insert into bo.t_thirdparty_service(id, agent_report) values(172, 1);


--changeset yanametro:BALANCE-25329
insert into bo.t_thirdparty_service(id) values(23);

--changeset yanametro:BALANCE-25344
insert into bo.t_thirdparty_service(id, agent_report) values(270, 1);

--changeset yanametro:BALANCE-25457
update bo.T_THIRDPARTY_SERVICE
set AGENT_REPORT=0
where id=270;

update bo.T_THIRDPARTY_SERVICE
set AGENT_REPORT=1
where id=170;


--changeset yanametro:BALANCE-26070
insert into bo.T_THIRDPARTY_SERVICE(id) values(204);

--changeset yanametro:BALANCE-25910
insert into bo.t_thirdparty_service(id) values(134);

--changeset yanametro:BALANCE-26456
insert into bo.T_THIRDPARTY_SERVICE(id, AGENT_REPORT) values(602, 1);

--changeset yanametro:BALANCE-26435
insert into bo.T_THIRDPARTY_SERVICE(id, AGENT_REPORT) values(603, 1);

--changeset yanametro:BALANCE-26682
insert into bo.t_thirdparty_service(id) values(607);

--changeset yanametro:BALANCE-27084
insert into bo.t_thirdparty_service(id) values(609);
insert into bo.t_thirdparty_service(id) values(610);

--changeset yanametro:BALANCE-27187
insert into bo.t_thirdparty_service(id, agent_report) values(611, 1);

--changeset yanametro:BALANCE-27357-1
insert into bo.t_thirdparty_service(id) values(613);

--changeset el-yurchito:BALANCE-27628 endDelimiter:\\
INSERT INTO "BO"."T_THIRDPARTY_SERVICE" ("ID") VALUES (615)
\\

--changeset yanametro:BALANCE-27610
insert into bo.t_thirdparty_service(id) values(42);

--changeset el-yurchito:BALANCE-28007 endDelimiter:\\
INSERT INTO "BO"."T_THIRDPARTY_SERVICE" ("ID", "POSTAUTH_CHECK", "POSTAUTH_READY_CHECK", "REWARD_REFUND", "GET_COMMISSION_FROM", "AGENT_REPORT")
  SELECT 617, 1, 0, 1, 'COMMISSION_CATEGORY', 1
  FROM dual
  WHERE NOT EXISTS(
    SELECT 1 FROM "BO"."T_THIRDPARTY_SERVICE" WHERE ID = 617
  )
\\

--changeset el-yurchito:BALANCE-28141 endDelimiter:\\
ALTER TABLE "BO"."T_THIRDPARTY_SERVICE"
  ADD ("PRODUCT_MAPPING_CONFIG" CLOB)
\\

--changeset yanametro:BALANCE-28228
insert into bo.t_thirdparty_service(id) values(619);

--changeset el-yurchito:BALANCE-28579 endDelimiter:\\
UPDATE "BO"."T_THIRDPARTY_SERVICE"
SET
  PRODUCT_MAPPING_CONFIG = '{"service_product_options": {"457420": "no_process", "519442": "no_process"}, "default_product_mapping": {"RUB": {"default": null}}}'
WHERE
  ID = 610
\\

--changeset el-yurchito:BALANCE-28506 endDelimiter:\\
INSERT INTO "BO"."T_THIRDPARTY_SERVICE" ("ID", "POSTAUTH_CHECK", "POSTAUTH_READY_CHECK", "REWARD_REFUND", "GET_COMMISSION_FROM", "AGENT_REPORT")
  SELECT 621, 1, 0, 1, 'COMMISSION_CATEGORY', 1
  FROM dual
  WHERE NOT EXISTS(
    SELECT 1 FROM "BO"."T_THIRDPARTY_SERVICE" WHERE ID = 621
  )
\\

--changeset el-yurchito:BALANCE-28492 endDelimiter:\\
INSERT INTO "BO"."T_THIRDPARTY_SERVICE" ("ID") VALUES (626)
\\

--changeset el-yurchito:BALANCE-28987 endDelimiter:\\
INSERT INTO "BO"."T_THIRDPARTY_SERVICE" ("ID", "AGENT_REPORT") VALUES (625, 1)
\\

--changeset sfreest:BALANCE-29373-thirdparty-service-620 endDelimiter:\\
INSERT INTO "BO"."T_THIRDPARTY_SERVICE" ("ID", "POSTAUTH_CHECK", "POSTAUTH_READY_CHECK", "REWARD_REFUND", "GET_COMMISSION_FROM", "AGENT_REPORT")
  SELECT 620, 1, 1, 0, 'COMMISSION_CATEGORY', 1
  FROM dual
  WHERE NOT EXISTS(
    SELECT 1 FROM "BO"."T_THIRDPARTY_SERVICE" WHERE ID = 620
  )
\\

--changeset el-yurchito:BALANCE-28944-1 endDelimiter:\\
INSERT INTO "BO"."T_THIRDPARTY_SERVICE" ("ID") VALUES (628)
\\

--changeset el-yurchito:BALANCE-28944-2 endDelimiter:\\
INSERT INTO "BO"."T_THIRDPARTY_SERVICE" ("ID") VALUES (629)
\\

--changeset sfreest:BALANCE-29349-s-fee-pr-mapping
UPDATE "BO"."T_THIRDPARTY_SERVICE"
SET
  AGENT_REPORT=1,
  PRODUCT_MAPPING_CONFIG = '{"service_fee_product_mapping": {"RUB": {"2": 509392, "default": null}}}'
WHERE
  ID = 171;

--changeset sfreest:BALANCE-29349-reward_refund
UPDATE "BO"."T_THIRDPARTY_SERVICE"
SET
  REWARD_REFUND=1
WHERE
  ID = 171;

--changeset el-yurchito:BALANCE-29493 endDelimiter:\\
INSERT INTO "BO"."T_THIRDPARTY_SERVICE" ("ID") VALUES (636)
\\
