--liquibase formatted sql

--------------------------------------------------------
--  DDL for Table T_OPERATION_TYPE
--------------------------------------------------------

  CREATE TABLE "BO"."T_OPERATION_TYPE" 
   (	"ID" NUMBER NOT NULL ENABLE, 
	"NAME" VARCHAR2(200 BYTE) NOT NULL ENABLE, 
	"UPDATE_DT" DATE DEFAULT sysdate NOT NULL ENABLE, 
	"CC" VARCHAR2(64 BYTE), 
	 CONSTRAINT "CS_OPERATION_TYPE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE, 
	 UNIQUE ("CC")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--------------------------------------------------------
--  DDL for Trigger TR_OPERATION_TYPE_UPD
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_OPERATION_TYPE_UPD" 
before
  insert or update on T_OPERATION_TYPE
referencing old as old new as new
for each row
begin
  :new.update_dt := sysdate;
end;
/
ALTER TRIGGER "BO"."TR_OPERATION_TYPE_UPD" ENABLE;


--changeset halty:BALANCE-24306

insert into bo.t_operation_type(id, name, cc) values(12, 'Поступление по взаимозачету', 'netting_income');
--

--changeset el-yurchito:BALANCE-27359 endDelimiter:\\
INSERT INTO "BO"."T_OPERATION_TYPE" ("ID", "NAME", "CC")
    VALUES (13, 'Корректировка взаимозачёта', 'netting_correction')
\\

--changeset lightrevan:BALANCE-28633-op-type
MERGE INTO bo.t_operation_type c
USING (
        SELECT
          14                        id,
          'Закрытие автоовердрафта' name,
          'auto_overdaft_act'       cc
        FROM dual
      ) d
ON (c.id = d.id)
WHEN NOT MATCHED THEN INSERT (id, name, cc) VALUES (d.id, d.name, d.cc);

--changeset lightrevan:BALANCE-29424-op-type
MERGE INTO bo.t_operation_type c
USING (
        SELECT
          15                        id,
          'Постановка общего счёта' name,
          'enqueue_unified_account' cc
        FROM dual

        UNION ALL

        SELECT
          16                        id,
          'Разбор общего счёта'     name,
          'process_unified_account' cc
        FROM dual

        UNION ALL

        SELECT
          17                              id,
          'Перенос откруток общего счёта' name,
          'process_ua_optimized'          cc
        FROM dual

        UNION ALL

        SELECT
          18                                 id,
          'Перенос свободного на общий счёт' name,
          'process_ua_transfer2main'         cc
        FROM dual

        UNION ALL

        SELECT
          19                                  id,
          'Перенос свободного с общего счёта' name,
          'process_ua_transfer2group'         cc
        FROM dual
      ) d
ON (c.id = d.id)
WHEN NOT MATCHED THEN INSERT (id, name, cc) VALUES (d.id, d.name, d.cc)
WHEN MATCHED THEN UPDATE SET c.name = d.name, c.cc = d.cc;
