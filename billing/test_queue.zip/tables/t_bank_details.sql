--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_BANK_DETAILS
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_BANK_DETAILS"
   (	"ID" NUMBER NOT NULL ENABLE,
	"BANK_ID" NUMBER NOT NULL ENABLE,
	"CURRENCY" VARCHAR2(16 BYTE) NOT NULL ENABLE,
	"NAME_SUFFIX" VARCHAR2(128 BYTE),
	"ACCOUNT" VARCHAR2(128 BYTE),
	"BANK" VARCHAR2(128 BYTE) NOT NULL ENABLE,
	"BANKCODE" VARCHAR2(128 BYTE),
	"BANKADDRESS" VARCHAR2(256 BYTE),
	"BANKACCOUNT" VARCHAR2(128 BYTE),
	"CORRBANK" VARCHAR2(128 BYTE),
	"CORRBANKCODE" VARCHAR2(128 BYTE),
	"CORRIBAN" VARCHAR2(128 BYTE),
	"NEEDS_ALERT" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"WEIGHT" NUMBER,
	"PREFER" NUMBER,
	"OEBS_CODE" VARCHAR2(128 BYTE),
	"FIRM_ID" NUMBER(*,0),
	"CORRBIN" VARCHAR2(128 BYTE),
	 CONSTRAINT "T_BANK_DETAILS_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE,
	 CONSTRAINT "T_BANK_DETAILS_UI" UNIQUE ("BANK_ID", "CURRENCY")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE,
	 CONSTRAINT "SYS_C002073483" FOREIGN KEY ("ID")
	  REFERENCES "BO"."T_TERMINAL" ("ID") ENABLE,
	 CONSTRAINT "SYS_C002073482" FOREIGN KEY ("BANK_ID")
	  REFERENCES "BO"."T_PROCESSING" ("ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_BANK_DETAILS_INS"
BEFORE INSERT
ON T_bank_details
REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW

DECLARE foo NUMBER;
BEGIN

IF :new.id IS NULL THEN

SELECT S_bank_details_ID.nextval INTO foo FROM dual;
:new.id := foo;

END IF;
END;
/
ALTER TRIGGER "BO"."TR_BANK_DETAILS_INS" ENABLE;

/* changeset ngolovkin:BALANCE-24054-1 */

exec dbms_mview.refresh('bo.t_processing');

/* changeset ngolovkin:BALANCE-24054-2 */

exec dbms_mview.refresh('bo.t_terminal');

--changeset nebaruzdin:BALANCE-23787

alter table bo.t_bank_details add iso_currency varchar2(16);

--changeset ngolovkin:BALANCE-24054-3

INSERT INTO bo.t_bank_details (id, bank_id, currency, account, bank, bankcode, bankaddress, bankaccount, needs_alert, weight, oebs_code, firm_id)
  select
		(SELECT id
		FROM bo.t_terminal
		WHERE processing_id = 2023
			AND currency = 'RUR'
			AND firm_id = 12
		) id,
        2023 bank_id,
        'RUR' currency,
        '40702810100001005379' account,
        'ИНГ БАНК (ЕВРАЗИЯ) АО' bank,
        '044525222' bankcode,
        '127473, Россия, Москва, ул. Краснопролетарская, 36' bankaddress,
        '301018105 0000 0000 222' bankaccount,
        1 needs_alert,
        0 weight,
        'ING' oebs_code,
        12 firm_id

    from dual
    where not exists (SELECT id
		FROM bo.t_bank_details
		WHERE bank_id = 2023
			AND currency = 'RUR'
			AND firm_id = 12);

--changeset quark:BALANCE-24080

INSERT INTO BO.T_BANK_DETAILS (ID, BANK_ID, CURRENCY, NAME_SUFFIX, ACCOUNT, BANK, BANKCODE, BANKADDRESS, BANKACCOUNT, CORRBANK, CORRBANKCODE, CORRIBAN, NEEDS_ALERT, WEIGHT, PREFER, OEBS_CODE, FIRM_ID, CORRBIN)
VALUES (603, 2022, 'UAH', null, '26003054351603', 'Южный ГРУ ПАО КБ "ПРИВАТБАНК", г. Одесса', '328704', null, null, null, null, null, 0, null, null, null, 23, null);


--changeset quark:BALANCE-25015-3

insert into bo.t_bank_details (id, bank_id, currency, account, bank, bankcode, bankaddress, bankaccount, needs_alert, oebs_code, firm_id)
values (
  (select id
   from bo.t_terminal
   where processing_id = (select id
                          from bo.t_processing
                          where cc = 'raiffeisenbank8') and currency = 'RUR' and firm_id = 112),
  (select id
   from bo.t_processing
   where cc = 'raiffeisenbank8'),
  'RUR',
  '40702810500000020796',
  'АО «Райффайзенбанк»',
  '044525700',
  '129090, Москва, ул.Троицкая, д.17, стр.1',
  30101810200000000700,
  0,
  'Райффайзенбанк',
  112
);

--changeset quark:BALANCE-25302

insert into bo.t_bank_details (id, bank_id, currency, account, bank, bankcode, bankaddress, bankaccount, needs_alert, oebs_code, firm_id)
values (
  (select id
   from bo.t_terminal
   where processing_id = (select id
                          from bo.t_processing
                          where cc = 'raiffeisenbank9') and currency = 'RUR' and firm_id = 113),
  (select id
   from bo.t_processing
   where cc = 'raiffeisenbank9'),
  'RUR',
  '40702810100000039446',
  'АО «Райффайзенбанк»',
  '044525700',
  '129090, Москва, ул.Троицкая, д.17, стр.1',
  30101810200000000700,
  0,
  'Райффайзенбанк',
  113
);

--changeset nebaruzdin:BALANCE-25259

insert into bo.t_bank_details (
    id,
    bank_id,
    currency,
    iso_currency,
    account,
    bank,
    bankcode,
    bankaddress,
    bankaccount,
    oebs_code,
    firm_id
)
select
    (select id
     from bo.t_terminal
     where processing_id = (
        select id
        from bo.t_processing
        where cc = 'vtb_am'
    ))                                       as id,
(select id
     from bo.t_processing
     where cc = 'vtb_am')                    as bank_id,
    'AMD'                                    as currency,
    'AMD'                                    as iso_currency,
    null                                     as account,
    'ЗАО «Банк ВТБ (Армения)»'               as bank,
    'VTB AM'                                 as bankcode,
    '0010, г. Ереван, ул. Налбандяна, д. 46' as bankaddress,
    null                                     as bankaccount,
    null                                     as oebs_code,
    26                                       as firm_id
from dual;

--changeset nebaruzdin:BALANCE-24905

insert into bo.t_bank_details (
    id,
    bank_id,
    currency,
    iso_currency,
    account,
    bank,
    bankcode,
    bankaddress,
    bankaccount,
    oebs_code,
    firm_id
)
select
    (select id
     from bo.t_terminal
     where processing_id = (
        select id
        from bo.t_processing
        where cc = 'alfabank_kz'
    ))                                   as id,
    (select id
     from bo.t_processing
     where cc = 'alfabank_kz')           as bank_id,
    'KZT'                                as currency,
    'KZT'                                as iso_currency,
    'KZ029470398990552940'               as account,
    'АО ДБ «Альфа-Банк»'                 as bank,
    'ALFAKZKA'                           as bankcode,
    '50012, г. Алматы, ул. Масанчи, 57A' as bankaddress,
    '941240000341'                       as bankaccount,
    'Альфа'                              as oebs_code,
    25                                   as firm_id
from dual;

--changeset yanametro:BALANCE-25379

insert into bo.t_bank_details (
    id,
    bank_id,
    currency,
    iso_currency,
    account,
    bank,
    bankcode,
    bankaddress,
    bankaccount,
    oebs_code,
    firm_id
)
select
    (select id
     from bo.t_terminal
     where processing_id = (
        select id
        from bo.t_processing
        where cc = 'alfabank_kz2'
    ))                                   as id,
    (select id
     from bo.t_processing
     where cc = 'alfabank_kz2')          as bank_id,
    'KZT'                                as currency,
    'KZT'                                as iso_currency,
    'KZ549470398990511652'               as account,
    'АО ДБ «Альфа-Банк»'                 as bank,
    'ALFAKZKA'                           as bankcode,
    '50012, г. Алматы, ул. Масанчи, 57A' as bankaddress,
    '941240000341'                       as bankaccount,
    'Альфа'                              as oebs_code,
    24                                   as firm_id
from dual;

--changeset nebaruzdin:BALANCE-25694

insert into bo.t_bank_details (
    id,
    bank_id,
    currency,
    iso_currency,
    account,
    bank,
    bankcode,
    bankaddress,
    bankaccount,
    oebs_code,
    firm_id
)
select
    (select id
     from bo.t_terminal
     where processing_id = (
        select id
        from bo.t_processing
        where cc = 'priorbank'
     ))                                                  as id,
    (select id
     from bo.t_processing
     where cc = 'priorbank')                             as bank_id,
    'BYN'                                                as currency,
    'BYN'                                                as iso_currency,
    'BY 68PJCB 3012 0532631000000933'                    as account,
    'ОАО «ПРИОРБАНК»'                                    as bank,
    'PJCB BY 2X'                                         as bankcode,
    'ЦБУ 111, г. Минск, пр-т Машерова, 40 УНП 100220190' as bankaddress,
    'BY 15PJCB 1702 643000026RZBM933'                    as bankaccount,
    'Приорбанк'                                          as oebs_code,
    27                                                   as firm_id
from dual;

--changeset el-yurchito:BALANCE-25931
insert into bo.t_bank_details (
  ID,
  BANK_ID,
  CURRENCY,
  ACCOUNT,
  BANK,
  BANKCODE,
  BANKADDRESS,
  BANKACCOUNT,
  NEEDS_ALERT,
  OEBS_CODE,
  FIRM_ID
)
SELECT
  (select id from BO.t_terminal where processing_id = (select id from BO.t_processing where cc = 'raiffeisenbank10') and currency = 'RUR' and firm_id = 28) ID,
  (select id from BO.t_processing where cc = 'raiffeisenbank10') BANK_ID,
  'RUR' CURRENCY,
  '40702810900000045708' ACCOUNT,
  'АО «Райффайзенбанк»' BANK,
  '044525700' BANKCODE,
  '129090, Москва, ул.Троицкая, д.17, стр.1' BANKADDRESS,
  '30101810200000000700' BANKACCOUNT,
  0 NEEDS_ALERT,
  'Райффайзенбанк' OEBS_CODE,
  28 FIRM_ID
FROM dual;
--changeset ashvedunov:BALANCE-25984-4
alter table bo.t_bank_details drop constraint T_BANK_DETAILS_UI;

--changeset ashvedunov:BALANCE-25984-5
alter table bo.t_bank_details add constraint T_BANK_DETAILS_UI
UNIQUE ("BANK_ID", "CURRENCY", "FIRM_ID");

--changeset ashvedunov:BALANCE-25984-6
insert into bo.t_bank_details (
    id,
    bank_id,
    currency,
    iso_currency,
    account,
    bank,
    bankcode,
    bankaddress,
    oebs_code,
    firm_id
)
select
    (select id from bo.t_terminal where firm_id = 29 and currency = 'EUR') as id,
    2009                                                        as bank_id,
    'EUR'                                                       as currency,
    'EUR'                                                       as iso_currency,
    'NL03 INGB 0662 3039 38'                                    as account,
    'ING BANK N.V.'                                             as bank,
    'INGBNL2A'                                                  as bankcode,
    'Amstelveenseweg 500, 1081 KL, Amsterdam, The Netherlands'  as bankaddress,
    'ING'                                                       as oebs_code,
    29                                                          as firm_id
from dual;

--changeset ashvedunov:BALANCE-25984-7
insert into bo.t_bank_details (
    id,
    bank_id,
    currency,
    iso_currency,
    account,
    bank,
    bankcode,
    bankaddress,
    oebs_code,
    firm_id
)
select
    (select id from bo.t_terminal where firm_id = 29 and currency = 'USD') as id,
    2009                                                        as bank_id,
    'USD'                                                       as currency,
    'USD'                                                       as iso_currency,
    'NL43 INGB 0020 0105 40'                                    as account,
    'ING BANK N.V.'                                             as bank,
    'INGBNL2A'                                                  as bankcode,
    'Amstelveenseweg 500, 1081 KL, Amsterdam, The Netherlands'  as bankaddress,
    'ING'                                                       as oebs_code,
    29                                                          as firm_id
from dual;

--changeset el-yurchito:BALANCE-26904 endDelimiter:\\
insert into bo.t_bank_details (
  ID,
  BANK_ID,
  CURRENCY,
  ACCOUNT,
  BANK,
  BANKCODE,
  BANKADDRESS,
  BANKACCOUNT,
  CORRBANK,
  CORRBANKCODE,
  OEBS_CODE,
  FIRM_ID,
  ISO_CURRENCY
)
select
  (select id from meta.t_terminal where processing_id = (select id from BO.t_processing where cc = 'raiffeisenbank12') and currency = 'RUR' and firm_id = 114) ID, -- СС
  (select id from meta.t_processing where cc = 'raiffeisenbank12') BANK_ID,
  'RUR'                                       CURRENCY,
  '40702810400000060652'                      ACCOUNT,
  'АО «Райффайзенбанк» г. Москва'             BANK,
  '044525700'                                 BANKCODE,
  '129090, Москва, ул.Троицкая, д.17, стр.1'  BANKADDRESS,
  '30101810200000000700'                      BANKACCOUNT,
  null                                        CORRBANK,
  null                                        CORRBANKCODE,
  'Райффайзенбанк'                            OEBS_CODE,
  114                                         FIRM_ID,
  'RUR'                                       ISO_CURRENCY
from dual union all
select
  (select id from meta.t_terminal where processing_id = (select id from meta.t_processing where cc = 'raiffeisenbank12') and currency = 'USD' and firm_id = 114) ID, -- СС
  (select id from meta.t_processing where cc = 'raiffeisenbank12') BANK_ID, -- СС
  'USD'                                       CURRENCY,
  '40702840700000008494'                      ACCOUNT,
  'АО «Райффайзенбанк» г. Москва'             BANK,
  'RZBM RU MM'                                BANKCODE,
  '129090, Москва, ул.Троицкая, д.17, стр.1'  BANKADDRESS,
  '021000089'                                 BANKACCOUNT,
  'Citibank'                                  CORRBANK,
  'CITIUS33'                                  CORRBANKCODE,
  'Райффайзенбанк'                            OEBS_CODE,
  114                                         FIRM_ID,
  'USD'                                       ISO_CURRENCY
from dual union all
select
  (select id from meta.t_terminal where processing_id = (select id from meta.t_processing where cc = 'raiffeisenbank12') and currency = 'EUR' and firm_id = 114) ID, -- СС
  (select id from meta.t_processing where cc = 'raiffeisenbank12') BANK_ID, -- СС
  'EUR'                                       CURRENCY,
  '40702978300000007893'                      ACCOUNT,
  'АО «Райффайзенбанк» г. Москва'             BANK,
  'RZBM RU MM'                                BANKCODE,
  '129090, Москва, ул.Троицкая, д.17, стр.1'  BANKADDRESS,
  '00155025928'                               BANKACCOUNT,
  'Raiffeisen Bank International AG'          CORRBANK,
  'RZBMRUMM'                                  CORRBANKCODE,
  'Райффайзенбанк'                            OEBS_CODE,
  114                                         FIRM_ID,
  'EUR'                                       ISO_CURRENCY
from dual
\\

--changeset el-yurchito:BALANCE-28023 endDelimiter:\\
insert into "BO"."T_BANK_DETAILS" (
  ID,
  BANK_ID,
  CURRENCY,
  ISO_CURRENCY,
  ACCOUNT,
  BANK,
  BANKCODE,
  BANKADDRESS,
  BANKACCOUNT,
  CORRBANK,
  CORRBANKCODE,
  OEBS_CODE,
  FIRM_ID
)
select
  (select id from "META"."T_TERMINAL" where processing_id = (select id from "META"."T_PROCESSING" where cc = 'alfabank_kz3') and currency = 'KZT' and firm_id = 31) ID, -- СС
  (select id from "META"."T_PROCESSING" where cc = 'alfabank_kz3') BANK_ID,
  'KZT'                                       CURRENCY,
  'KZT'                                       ISO_CURRENCY,
  'KZ119470398991063968'                      ACCOUNT,
  'ALFA BANK JSC SB'                          BANK,
  'ALFAKZKAXXX'                               BANKCODE,
  'Almaty 050012, ul. Masanchi, 57-A'         BANKADDRESS,
  '941240000341'                              BANKACCOUNT,
  null                                        CORRBANK,
  null                                        CORRBANKCODE,
  'Альфа'                                     OEBS_CODE,
  31                                          FIRM_ID
from dual
\\

--changeset el-yurchito:BALANCE-28141 endDelimiter:\\
UPDATE
  "BO"."T_BANK_DETAILS"
SET
  OEBS_CODE = 'Райф'
WHERE
  FIRM_ID = 9
\\

-- changeset quark:BALANCE-28047-5

insert into bo.t_bank_details (ID, BANK_ID, CURRENCY, NAME_SUFFIX, ACCOUNT, BANK, BANKCODE, BANKADDRESS, BANKACCOUNT, CORRBANK, CORRBANKCODE, CORRIBAN, NEEDS_ALERT, WEIGHT, PREFER, OEBS_CODE, FIRM_ID, CORRBIN, iso_currency)
select
  (select id from meta.t_terminal where processing_id = (select id from BO.t_processing where cc = 'vtb_bank') and currency = 'USD' and firm_id = 115) ID, -- СС
  (select id from meta.t_processing where cc = 'vtb_bank') BANK_ID, -- СС
  'USD'                       CURRENCY,
  null                        NAME_SUFFIX,
  'DE575 0320 0000 2076 4941 9'            ACCOUNT,
  'VTB BANK (DEUTSCHLAND) AG'              BANK,
  'OWHBDEFFXXX'               BANKCODE, -- SWIFT
  'WALTER-KOLB-STR. 13 60594 FRANKFURT AM MAIN' BANKADDRESS,
  null                        BANKACCOUNT,
  null                        CORRBANK,
  null                        CORRBANKCODE,
  'DE585 0320 0000 2076 4901 3' CORRIBAN,
  0                           NEEDS_ALERT,
  null                        WEIGHT,
  null                        PREFER,
  'VTB'                      OEBS_CODE,
  115                         FIRM_ID,
  null                        CORRBIN,
  'USD'                       iso_currency
from dual;

-- changeset dolvik:BALANCE-28393

UPDATE BO.T_BANK_DETAILS SET BANK = 'АО ДБ «Альфа-Банк»', BANKADDRESS = '050012, Казахстан, г. Алматы, Масанчи, 57а' WHERE ID = 968;


--changeset natabers:BALANCE-28330-t-bank_details
-- firm_id=111 - ООО «Яндекс.Маркет»

insert into bo.t_bank_details (
  ID, BANK_ID, CURRENCY, NAME_SUFFIX, ACCOUNT, BANK, BANKCODE, BANKADDRESS, BANKACCOUNT, CORRBANK, CORRBANKCODE,
  CORRIBAN, NEEDS_ALERT, WEIGHT, PREFER, OEBS_CODE, FIRM_ID, CORRBIN, ISO_CURRENCY
  )
select
  (select id from meta.t_terminal where processing_id = (select id from meta.t_processing where cc = 'sberbank_1')
      and currency = 'RUR' and firm_id = 111)                ID, -- СС
  (select id from meta.t_processing where cc = 'sberbank_1') BANK_ID, -- СС
  'RUR'                                                      CURRENCY,
  null                                                       NAME_SUFFIX,
  '40702810438000034726'                                     ACCOUNT,  -- р/счет
  'ПАО Сбербанк'                                             BANK,
  '044525225'                                                BANKCODE, -- БИК
  ' 117997, Россия, Москва, ул. Вавилова 19'                  BANKADDRESS,
  '30101810400000000225'                                     BANKACCOUNT,  -- к/счет
  null                                                       CORRBANK,
  null                                                       CORRBANKCODE,
  null                                                       CORRIBAN,
  0                                                          NEEDS_ALERT,
  null                                                       WEIGHT,
  null                                                       PREFER,
  'Сбербанк'                                                 OEBS_CODE,
  111                                                        FIRM_ID,
  null                                                       CORRBIN,
  'RUB'                                                      ISO_CURRENCY
from dual
union all
select
  (select id from meta.t_terminal where processing_id = (select id from meta.t_processing where cc = 'sberbank_1')
      and currency = 'USD' and firm_id = 111)                ID, -- СС
  (select id from meta.t_processing where cc = 'sberbank_1') BANK_ID, -- СС
  'USD'                                                      CURRENCY,
  null                                                       NAME_SUFFIX,
  '40702840638000014600'                                     ACCOUNT,  -- Account number
  'SBERBANK, MOSCOW'                                         BANK,  -- Beneficiary bank
  'SABRRUMM'                                                 BANKCODE, -- SWIFT
  '19 Vavilova St., 117997 Moscow, Russia'                   BANKADDRESS,
  '8900057610'                                               BANKACCOUNT,  -- Account
  'The Bank of New York Mellon, New York, NY'                CORRBANK,  -- Bank-correspondent
  'IRVTUS3N'                                                 CORRBANKCODE,  -- SWIFT
  null                                                       CORRIBAN,
  0                                                          NEEDS_ALERT,
  null                                                       WEIGHT,
  null                                                       PREFER,
  'Сбербанк'                                                 OEBS_CODE,
  111                                                        FIRM_ID,
  null                                                       CORRBIN,
  'USD'                                                      ISO_CURRENCY
from dual
union all
select
  (select id from meta.t_terminal where processing_id = (select id from meta.t_processing where cc = 'sberbank_1')
      and currency = 'EUR' and firm_id = 111)                ID, -- СС
  (select id from meta.t_processing where cc = 'sberbank_1') BANK_ID, -- СС
  'EUR'                                                      CURRENCY,
  null                                                       NAME_SUFFIX,
  '40702978138000012731'                                     ACCOUNT,  -- Account number
  'SBERBANK, MOSCOW'                                         BANK,  -- Beneficiary bank
  'SABRRUMM'                                                 BANKCODE, -- SWIFT
  '19 Vavilova St., 117997 Moscow, Russia'                   BANKADDRESS,
  '10094987261000'                                           BANKACCOUNT,  -- Account
  'Deutsche Bank AG, Frankfurt am Main'                      CORRBANK,  -- Bank-correspondent
  'DEUTDEFF'                                                 CORRBANKCODE,  -- SWIFT
  null                                                       CORRIBAN,
  0                                                          NEEDS_ALERT,
  null                                                       WEIGHT,
  null                                                       PREFER,
  'Сбербанк'                                                 OEBS_CODE,
  111                                                        FIRM_ID,
  null                                                       CORRBIN,
  'EUR'                                                      ISO_CURRENCY
from dual
union all
select
  (select id from meta.t_terminal where processing_id = (select id from meta.t_processing where cc = 'sberbank_1')
      and currency = 'KZT' and firm_id = 111)                ID, -- СС
  (select id from meta.t_processing where cc = 'sberbank_1') BANK_ID, -- СС
  'KZT'                                                      CURRENCY,
  null                                                       NAME_SUFFIX,
  '40702398038000000135'                                     ACCOUNT,  -- Account number
  'SBERBANK, MOSCOW'                                         BANK,  -- Beneficiary bank
  'SABRRUMM'                                                 BANKCODE, -- SWIFT или БИН KZ83914398111BC00006
  '19 Vavilova St., 117997 Moscow, Russia'                   BANKADDRESS,
  null                                                       BANKACCOUNT,  -- Account
  'SB Sberbank JSC, Almaty'                                  CORRBANK,  -- Bank-correspondent
  'SABRKZKA'                                                 CORRBANKCODE,  -- SWIFT
  'KZ83914398111BC00006'                                     CORRIBAN,
  0                                                          NEEDS_ALERT,
  null                                                       WEIGHT,
  null                                                       PREFER,
  'Сбербанк'                                                 OEBS_CODE,
  111                                                        FIRM_ID,
  '930740000137'                                             CORRBIN,
  'KZT'                                                      ISO_CURRENCY
from dual
union all
select
  (select id from meta.t_terminal where processing_id = (select id from meta.t_processing where cc = 'sberbank_1')
      and currency = 'BYN' and firm_id = 111)                ID, -- СС
  (select id from meta.t_processing where cc = 'sberbank_1') BANK_ID, -- СС
  'BYN'                                                      CURRENCY,
  null                                                       NAME_SUFFIX,
  '40702933938000000124'                                     ACCOUNT,  -- Account number
  'SBERBANK, MOSCOW'                                         BANK,  -- Beneficiary bank
  'SABRRUMM'                                                 BANKCODE, -- SWIFT
  ' 19 Vavilova St., 117997 Moscow, Russia'                   BANKADDRESS,
  'BY53BPSB17025812301199330000'                             BANKACCOUNT,  -- Account
  'BPS-Sberbank, Minsk'                                      CORRBANK,  -- Bank-correspondent
  'BPSBBY2X'                                                 CORRBANKCODE,  -- SWIFT
  '153001369'                                                CORRIBAN,  -- МФО
  0                                                          NEEDS_ALERT,
  null                                                       WEIGHT,
  null                                                       PREFER,
  'Сбербанк'                                                 OEBS_CODE,
  111                                                        FIRM_ID,
  null                                                       CORRBIN,
  'BYN'                                                      ISO_CURRENCY
from dual;

--changeset quark:BALANCE-29296-2
insert into bo.t_bank_details (id, bank_id, currency, account, bank, bankcode, bankaddress, bankaccount, needs_alert, oebs_code, firm_id)
values (
  (select id
   from meta.t_terminal
   where processing_id = (select id from meta.t_processing where cc = 'raiffeisenbank19')
         and currency = 'RUR'
         and firm_id = (select id from meta.t_firm where title like 'ООО «Яндекс.Заправки»')),
  (select id from bo.t_processing where cc = 'raiffeisenbank19'),
  'RUR',
  '40702810700000091538',
  'АО «Райффайзенбанк»',
  '044525700',
  '129090, Москва, ул.Троицкая, д.17, стр.1',
  '30101810200000000700',
  0,
  'Райффайзенбанк',
  (select id from meta.t_firm where title like 'ООО «Яндекс.Заправки»')
);

--changeset el-yurchito:BALANCE-28943-1 endDelimiter:\\
insert into bo.t_bank_details (
  ID,
  BANK_ID,
  CURRENCY,
  ACCOUNT,
  BANK,
  BANKCODE,
  BANKADDRESS,
  BANKACCOUNT,
  CORRBANK,
  CORRBANKCODE,
  OEBS_CODE,
  FIRM_ID,
  ISO_CURRENCY
)
select
  (select id from meta.t_terminal where processing_id = (select id from BO.t_processing where cc = 'raiffeisenbank17') and currency = 'RUR' and firm_id = 32) ID,
  (select id from meta.t_processing where cc = 'raiffeisenbank17') BANK_ID,
  'RUR'                                       CURRENCY,
  '40702810800000066366'                      ACCOUNT,
  'АО «Райффайзенбанк» г. Москва'             BANK,
  '044525700'                                 BANKCODE,
  '129090, Москва, ул.Троицкая, д.17, стр.1'  BANKADDRESS,
  '30101810200000000700'                      BANKACCOUNT,
  null                                        CORRBANK,
  null                                        CORRBANKCODE,
  'Райффайзенбанк'                            OEBS_CODE,
  32                                          FIRM_ID,
  'RUR'                                       ISO_CURRENCY
from dual union all
select
  (select id from meta.t_terminal where processing_id = (select id from meta.t_processing where cc = 'raiffeisenbank17') and currency = 'USD' and firm_id = 32) ID,
  (select id from meta.t_processing where cc = 'raiffeisenbank17') BANK_ID,
  'USD'                                       CURRENCY,
  '40702840400000009081'                      ACCOUNT,
  'АО «Райффайзенбанк» г. Москва'             BANK,
  'RZBMRUMM'                                  BANKCODE,
  '129090, Москва, ул.Троицкая, д.17, стр.1'  BANKADDRESS,
  '021000089'                                 BANKACCOUNT,
  'Citibank'                                  CORRBANK,
  'CITIUS33'                                  CORRBANKCODE,
  'Райффайзенбанк'                            OEBS_CODE,
  32                                          FIRM_ID,
  'USD'                                       ISO_CURRENCY
from dual union all
select
  (select id from meta.t_terminal where processing_id = (select id from meta.t_processing where cc = 'raiffeisenbank17') and currency = 'EUR' and firm_id = 32) ID,
  (select id from meta.t_processing where cc = 'raiffeisenbank17') BANK_ID,
  'EUR'                                       CURRENCY,
  '40702978300000008449'                      ACCOUNT,
  'АО «Райффайзенбанк» г. Москва'             BANK,
  'RZBMRUMM'                                  BANKCODE,
  '129090, Москва, ул.Троицкая, д.17, стр.1'  BANKADDRESS,
  '00155025928'                               BANKACCOUNT,
  'Raiffeisen Bank International AG'          CORRBANK,
  'RZBAATWW'                                  CORRBANKCODE,
  'Райффайзенбанк'                            OEBS_CODE,
  32                                          FIRM_ID,
  'EUR'                                       ISO_CURRENCY
from dual
\\

--changeset el-yurchito:BALANCE-28943-2 endDelimiter:\\
insert into bo.t_bank_details (
  ID,
  BANK_ID,
  CURRENCY,
  ACCOUNT,
  BANK,
  BANKCODE,
  BANKADDRESS,
  BANKACCOUNT,
  CORRBANK,
  CORRBANKCODE,
  OEBS_CODE,
  FIRM_ID,
  ISO_CURRENCY
)
select
  (select id from meta.t_terminal where processing_id = (select id from BO.t_processing where cc = 'raiffeisenbank18') and currency = 'RUR' and firm_id = 32) ID,
  (select id from meta.t_processing where cc = 'raiffeisenbank18') BANK_ID,
  'RUR'                                       CURRENCY,
  '40702810100000074294'                      ACCOUNT,
  'АО «Райффайзенбанк» г. Москва'             BANK,
  '044525700'                                 BANKCODE,
  '129090, Москва, ул.Троицкая, д.17, стр.1'  BANKADDRESS,
  '30101810200000000700'                      BANKACCOUNT,
  null                                        CORRBANK,
  null                                        CORRBANKCODE,
  'Райффайзенбанк'                            OEBS_CODE,
  32                                          FIRM_ID,
  'RUR'                                       ISO_CURRENCY
from dual
\\

--changeset el-yurchito:BALANCE-28943-3 endDelimiter:\\
insert into bo.t_bank_details (
  ID,
  BANK_ID,
  CURRENCY,
  ACCOUNT,
  BANK,
  BANKCODE,
  BANKADDRESS,
  BANKACCOUNT,
  CORRBANK,
  CORRBANKCODE,
  OEBS_CODE,
  FIRM_ID,
  ISO_CURRENCY
)
select
  (select id from meta.t_terminal where processing_id = (select id from BO.t_processing where cc = 'sberbank_2') and currency = 'RUR' and firm_id = 32) ID,
  (select id from meta.t_processing where cc = 'sberbank_2') BANK_ID,
  'RUR'                                       CURRENCY,
  '40702810138000181254'                      ACCOUNT,
  'ПАО «СберБанк»'                            BANK,
  '044525225'                                 BANKCODE,
  '117997, Россия, Москва, ул. Вавилова 19'   BANKADDRESS,
  '30101810400000000225'                      BANKACCOUNT,
  null                                        CORRBANK,
  null                                        CORRBANKCODE,
  'Сбербанк'                                  OEBS_CODE,
  32                                          FIRM_ID,
  'RUR'                                       ISO_CURRENCY
from dual
\\

--changeset el-yurchito:BALANCE-29690 endDelimiter:\\
UPDATE "BO"."T_BANK_DETAILS"
  SET "ISO_CURRENCY" = 'RUB'
  WHERE "ISO_CURRENCY" = 'RUR'
\\

--changeset quark:BALANCE-30394-2

insert into bo.t_bank_details (ID, BANK_ID, CURRENCY, NAME_SUFFIX, ACCOUNT, BANK, BANKCODE, BANKADDRESS,
                               BANKACCOUNT, CORRBANK, CORRBANKCODE, CORRIBAN, NEEDS_ALERT, WEIGHT, PREFER,
                               OEBS_CODE, FIRM_ID, CORRBIN, iso_currency)
select
  (select id from meta.t_terminal where processing_id = (select id from BO.t_processing where cc = 'vtb_bank') and currency = 'BYN' and firm_id = 115) ID, -- СС
  (select id from meta.t_processing where cc = 'vtb_bank') BANK_ID, -- СС
  'BYN'                       CURRENCY,
  null                        NAME_SUFFIX,
  'UNKNOWN'            ACCOUNT,
  'VTB BANK (DEUTSCHLAND) AG'              BANK,
  'OWHBDEFFXXX'               BANKCODE, -- SWIFT
  'WALTER-KOLB-STR. 13 60594 FRANKFURT AM MAIN' BANKADDRESS,
  null                        BANKACCOUNT,
  null                        CORRBANK,
  null                        CORRBANKCODE,
  'DE585 0320 0000 2076 4901 3' CORRIBAN,
  0                           NEEDS_ALERT,
  null                        WEIGHT,
  null                        PREFER,
  'VTB'                       OEBS_CODE,
  115                         FIRM_ID,
  null                        CORRBIN,
  'BYN'                       iso_currency
from dual;

--changeset nebaruzdin:BALANCE-29364

insert into bo.t_bank_details (
    id,
    bank_id,
    currency,
    iso_currency,
    account,
    bank,
    bankcode,
    bankaddress,
    bankaccount,
    oebs_code,
    firm_id
)
select
    (
        select id
        from meta.t_terminal
        where
            processing_id = (
                select id
                from BO.t_processing
                where cc = 'raiffeisenbank21'
            )
            and currency = 'RUR'
            and firm_id = 34
    )                                                    as id,
    (
        select id
        from meta.t_processing
        where cc = 'raiffeisenbank21'
    )                                                    as bank_id,
    'RUR'                                                as currency,
    'RUB'                                                as iso_currency,
    '40703810800001470659'                               as account,
    'АО «Райффайзенбанк»'                                as bank,
    '044525700'                                          as bankcode,
    '129090, Россия, Москва, ул. Троицкая, д.17, стр. 1' as bankaddress,
    '30101810200000000700'                               as bankaccount,
    'Райффайзенбанк'                                     as oebs_code,
    34                                                   as firm_id
from dual;
