--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_SCALE
--------------------------------------------------------------------------------

CREATE TABLE T_SCALE
(
  CODE      VARCHAR2(40) NOT NULL
    CONSTRAINT T_SCALE_PK
    PRIMARY KEY,
  TYPE      VARCHAR2(40),
  COMMENTS  VARCHAR2(256),
  X_UNIT_ID NUMBER,
  Y_UNIT_ID NUMBER
);

--changeset natabers:BALANCE-28470-t_scale

insert into bo.t_scale (code, type, comments, x_unit_id, y_unit_id)
  values ('uz_agency_discount', 'staircase', 'UzAgencyDirectDiscount scale', null, null);

--changeset sfreest:BALANCE-29064-t_scale
insert into bo.t_scale (code, type, comments, x_unit_id, y_unit_id)
  values ('addappter_common_scale', 'staircase_cost_max_cut', 'Addapter public common seller motivation scale', null, null);
