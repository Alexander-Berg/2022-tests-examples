--liquibase formatted sql

--changeset damir-kuch:TRUST-6266
create table bo.t_payment_fraud_status (
    payment_id number(*,0) not NULL CONSTRAINT t_payment_fraud_status_pkey PRIMARY KEY,
    trust_payment_id varchar2(40),
    afs_status varchar2(20),
    afs_tx_id varchar2(128),
    afs_action varchar2(20),
    afs_risk_score number,
    afs_rule_score number,
    afs_resp_desc varchar2(1024),
    afs_tags varchar2(1024),
    afs_additional_info varchar2(2048)
)partition by range (payment_id)
interval (50000000)
  (partition p_0 values less than (1010000000));

create index bo.i_payment_fraud_status_tpid on bo.t_payment_fraud_status (trust_payment_id)
