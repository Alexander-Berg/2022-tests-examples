--liquibase formatted sql

--------------------------------------------------------
--  DDL for Table T_DISTRIBUTION_PAGES
--------------------------------------------------------

  CREATE TABLE "BO"."T_DISTRIBUTION_PAGES"
   (	"PLACE_ID" NUMBER NOT NULL ENABLE,
	"PAGE_ID" NUMBER NOT NULL ENABLE,
	"DIMENSION" NUMBER DEFAULT 1 NOT NULL ENABLE,
	"RESULT_PAGE_ID" NUMBER DEFAULT 10000
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset bwh1te:BALANCE-23060-1
INSERT INTO bo.t_distribution_pages (place_id, page_id, dimension, result_page_id)
                             VALUES (10007, 10007, 1, 10007);

--changeset halty:BALANCE-23530-1
INSERT INTO bo.t_distribution_pages (place_id, page_id, dimension, result_page_id)
                             VALUES (10000, 10000, 1, 10000);

--changeset vorobyov-as:BALANCE-28075
INSERT INTO bo.t_distribution_pages (place_id, page_id, dimension, result_page_id)
                             VALUES (13002, 13002, 1, 13002);

--changeset vorobyov-as:BALANCE-28247
INSERT INTO bo.t_distribution_pages (place_id, page_id, dimension, result_page_id)
                             VALUES (13003, 13003, 1, 13003);

--changeset vorobyov-as:BALANCE-30427
INSERT INTO bo.t_distribution_pages (place_id, page_id, dimension, result_page_id)
                             VALUES (10100, 10100, 1, 10100);