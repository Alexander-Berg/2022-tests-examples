--liquibase formatted sql

  CREATE TABLE "BO"."T_PAYSYS_SERVICE"
   (	"PAYSYS_ID" NUMBER NOT NULL ENABLE,
	"SERVICE_ID" NUMBER NOT NULL ENABLE,
	"WEIGHT" NUMBER NOT NULL ENABLE,
	"EXTERN" NUMBER NOT NULL ENABLE,
	 CONSTRAINT "T_PAYSYS_SERVICE_PK" PRIMARY KEY ("PAYSYS_ID", "SERVICE_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 524288 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_KTS"  ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_OTS" ;

--changeset quark:BALANCE-23943
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN)
    values (1601046, 114, 100, 1);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN)
    values (1601087, 114, 100, 1);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN)
    values (1601066, 114, 100, 1);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN)
    values (1601081, 114, 100, 1);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN)
    values (1601043, 114, 100, 1);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN)
    values (1601084, 114, 100, 1);


--changeset ngolovkin:BALANCE-24054-5

insert into bo.t_paysys_service
select paysys_id, 99 service_id, weight, extern
from bo.t_paysys_service where service_id = 81 and paysys_id not in (select paysys_id from bo.t_paysys_service where service_id = 99);

--changeset krissmacer:BALANCE-24314

INSERT INTO BO.T_PAYSYS_SERVICE (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN)
  SELECT 1003,  129,  400,  1 FROM dual UNION ALL
  SELECT 1001,  129,  400,  1 FROM dual UNION ALL
  SELECT 1002,  129,  400,  1 FROM dual UNION ALL
  SELECT 1033,  129,  400,  1 FROM dual
;

--changeset quark:BALANCE-24562

insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2201039, 111, 0, 1);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2201040, 111, 0, 1);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2201041, 111, 0, 1);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2201042, 111, 0, 1);

--changeset quark:BALANCE-24462-1

insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (1301094, 111, 0, 0);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (1301094, 128, 0, 0);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2201116, 111, 0, 0);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2201116, 128, 0, 0);

--changeset quark:BALANCE-24610

insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2201119, 111, 0, 0);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2201119, 128, 0, 0);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2301118, 111, 0, 0);
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2301118, 128, 0, 0);

--changeset dolvik:BALANCE-25210

delete from bo.t_paysys_service where paysys_id = 1032;

--changeset nebaruzdin:BALANCE-24905

insert into bo.t_paysys_service (paysys_id, service_id, weight, extern) values ((select id from bo.t_paysys_old where cc = 'cc_kz_np'), 7, 100, 1);
insert into bo.t_paysys_service (paysys_id, service_id, weight, extern) values ((select id from bo.t_paysys_old where cc = 'cc_kz_jp'), 7, 100, 1);

--changeset krissmacer:APIKEYS-460

INSERT INTO BO.T_PAYSYS_SERVICE (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) VALUES (11101003, 129, 400, 1);
INSERT INTO BO.T_PAYSYS_SERVICE (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) VALUES (11101001, 129, 400, 1);
INSERT INTO BO.T_PAYSYS_SERVICE (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) VALUES (11101002, 129, 400, 1);
INSERT INTO BO.T_PAYSYS_SERVICE (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) VALUES (11101033, 129, 400, 1);

--changeset nebaruzdin:BALANCE-25694

insert into bo.t_paysys_service (paysys_id, service_id, weight, extern)
select (select id from bo.t_paysys where cc = 'byu'      and firm_id = 27),  7, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'byu'      and firm_id = 27), 77, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'byp'      and firm_id = 27),  7, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'byp'      and firm_id = 27), 77, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'byn_byu'  and firm_id = 27),  7, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'byn_byu'  and firm_id = 27), 77, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'byn_byp'  and firm_id = 27),  7, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'byn_byp'  and firm_id = 27), 77, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'by_jp_bc' and firm_id = 27),  7, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'by_jp_bc' and firm_id = 27), 77, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'by_np_bc' and firm_id = 27),  7, 100, 1 from dual union all
select (select id from bo.t_paysys where cc = 'by_np_bc' and firm_id = 27), 77, 100, 1 from dual;

--changeset el-yurchito:BALANCE-26558-1
insert into bo.t_paysys_service (paysys_id, service_id, weight, extern)
values (1301003, 135, 100, 1);

--changeset el-yurchito:BALANCE-26558-2
insert into bo.t_paysys_service (paysys_id, service_id, weight, extern)
values (1301094, 135, 100, 1);

--changeset halty:BALANCE-27309-1
update bo.t_paysys_service ps set weight = nvl((
		    select weight from bo.t_paysys where id = ps.paysys_id
	), ps.weight);

--changeset halty:BALANCE-27309-2
update bo.t_paysys_service set weight = 10 where service_id = 202 and paysys_id = 1033;

--changeset el-yurchito:BALANCE-28372-1 endDelimiter:\\
INSERT INTO
  "BO"."T_PAYSYS_SERVICE" ("PAYSYS_ID", "SERVICE_ID", "WEIGHT", "EXTERN")
SELECT (SELECT ID FROM "BO"."T_PAYSYS" WHERE CC = 'kzu' AND FIRM_ID = 31), 135, 100, 1 FROM dual
  UNION ALL
SELECT (SELECT ID FROM "BO"."T_PAYSYS" WHERE CC = 'co'  AND FIRM_ID = 31), 135, 100, 1 FROM dual
\\

--changeset el-yurchito:BALANCE-28372-2 endDelimiter:\\
call dbms_mview.refresh('bo.t_paysys')
\\

--changeset yanametro:BALANCE-28374
INSERT INTO BO.T_PAYSYS_SERVICE (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) VALUES (11301003, 205, 0, 0);
INSERT INTO BO.T_PAYSYS_SERVICE (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) VALUES (11301033, 205, 0, 0);

--changeset lightrevan:BALANCE-27778-paysys-service-S
DELETE FROM bo.t_paysys_service
WHERE paysys_id in (
    SELECT id FROM bo.t_paysys
    WHERE prefix = 'S'
);

--changeset quark:BALANCE-28901-2
insert into bo.t_paysys_service (PAYSYS_ID, SERVICE_ID, WEIGHT, EXTERN) values (2701101, 205, 0, 0);

--changeset el-yurchito:BALANCE-29492 endDelimiter:\\
INSERT INTO "BO"."T_PAYSYS_SERVICE"
  ("PAYSYS_ID", "SERVICE_ID", "WEIGHT", "EXTERN")
VALUES
  (
    (SELECT "ID" FROM "BO"."T_PAYSYS" WHERE CC = 'ce' and FIRM_ID = 13),
    124,
    (SELECT "WEIGHT" FROM "BO"."T_PAYSYS" WHERE CC = 'ce' and FIRM_ID = 13),
    0
  )
\\
