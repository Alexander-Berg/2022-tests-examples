--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_PAYSYS_OLD
--------------------------------------------------------------------------------


  CREATE TABLE "BO"."T_PAYSYS_OLD"
   (	"ID" NUMBER,
	"DT" DATE NOT NULL ENABLE,
	"WEIGHT" NUMBER NOT NULL ENABLE,
	"CC" VARCHAR2(16 BYTE),
	"EXTERN" NUMBER NOT NULL ENABLE,
	"NAME" VARCHAR2(256 BYTE),
	"NSP" NUMBER NOT NULL ENABLE,
	"PRIVATE" NUMBER(2,0),
	"REVERSABLE" NUMBER NOT NULL ENABLE,
	"INVOICE_SENDABLE" NUMBER NOT NULL ENABLE,
	"NDS" NUMBER NOT NULL ENABLE,
	"PERSON_TYPE_CODE" NUMBER,
	"CURRENCY" VARCHAR2(16 BYTE) NOT NULL ENABLE,
	"FOR_AGENCY" NUMBER NOT NULL ENABLE,
	"SUPPRESS_DISCOUNTS" NUMBER NOT NULL ENABLE,
	"CATEGORY" VARCHAR2(20 BYTE),
	"NDS_PCT" NUMBER NOT NULL ENABLE,
	"PREFIX" VARCHAR2(4 BYTE),
	"FIRM_ID" NUMBER,
	"INSTANT" NUMBER(1,0) NOT NULL ENABLE,
	"ALLOW_UNMODERATED" NUMBER NOT NULL ENABLE,
	"FRAUDABLE" NUMBER NOT NULL ENABLE,
	"LANG_ID" NUMBER NOT NULL ENABLE,
	"CONTRACT_NEEDED" NUMBER,
	"MONTHLY_REPORTABLE" NUMBER NOT NULL ENABLE,
	"ISO_CURRENCY" VARCHAR2(16 BYTE),
	"WAIT_PAYMENT_DAY_NUM" NUMBER,
	"WAIT_PAYMENT_DAY_TYPE" NUMBER,
	"BARTER" NUMBER(*,0),
	"CREDIT_CARD" NUMBER(*,0),
	"MOBILE" NUMBER(*,0),
	"INAPP" NUMBER NOT NULL ENABLE,
	"FIRST_LIMIT" NUMBER,
	"SECOND_LIMIT" NUMBER,
	"CERTIFICATE" NUMBER NOT NULL ENABLE,
	"PAYMENT_METHOD_ID" NUMBER(*,0)
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset quark:BALANCE-24494

INSERT INTO BO.T_PAYSYS_OLD (ID, DT, WEIGHT, CC, EXTERN, NAME, NSP, PRIVATE, REVERSABLE, INVOICE_SENDABLE, NDS, PERSON_TYPE_CODE, CURRENCY, FOR_AGENCY, SUPPRESS_DISCOUNTS, CATEGORY, NDS_PCT, PREFIX, FIRM_ID, INSTANT, ALLOW_UNMODERATED, FRAUDABLE, LANG_ID, CONTRACT_NEEDED, MONTHLY_REPORTABLE, ISO_CURRENCY, WAIT_PAYMENT_DAY_NUM, WAIT_PAYMENT_DAY_TYPE, BARTER, CREDIT_CARD, MOBILE, INAPP, FIRST_LIMIT, SECOND_LIMIT, CERTIFICATE, PAYMENT_METHOD_ID)
VALUES (2201116, TO_DATE('2016-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 700, 'ce_taxi_bv_usd', 0, 'Промокод Такси (нерезиденты, Голландия)', 0, 0, 1, 0, 0, 0, 'USD', 0, 1, 'eu_yt', 0, 'EU', 22, 0, 0, 0, 1, 0, 0, 'USD', null, 0, 0, 0, 0, 0, null, null, 1, 1505);

--changeset quark:BALANCE-24610
-- compensation paysyses taxi bv eur
INSERT INTO BO.T_PAYSYS_OLD (ID, DT, WEIGHT, CC, EXTERN, NAME, NSP, PRIVATE, REVERSABLE, INVOICE_SENDABLE, NDS, PERSON_TYPE_CODE, CURRENCY, FOR_AGENCY, SUPPRESS_DISCOUNTS, CATEGORY, NDS_PCT, PREFIX, FIRM_ID, INSTANT, ALLOW_UNMODERATED, FRAUDABLE, LANG_ID, CONTRACT_NEEDED, MONTHLY_REPORTABLE, ISO_CURRENCY, WAIT_PAYMENT_DAY_NUM, WAIT_PAYMENT_DAY_TYPE, BARTER, CREDIT_CARD, MOBILE, INAPP, FIRST_LIMIT, SECOND_LIMIT, CERTIFICATE, PAYMENT_METHOD_ID)
VALUES (2201119, TO_DATE('2016-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 700, 'ce_taxi_bv_eur', 0, 'Промокод Такси (нерезиденты, Голландия)', 0, 0, 1, 0, 0, 0, 'EUR', 0, 1, 'eu_yt', 0, 'EU', 22, 0, 0, 0, 1, 0, 0, 'EUR', null, 0, 0, 0, 0, 0, null, null, 1, 1505);

-- compensation paysyses taxi ua uah
INSERT INTO BO.T_PAYSYS_OLD (ID, DT, WEIGHT, CC, EXTERN, NAME, NSP, PRIVATE, REVERSABLE, INVOICE_SENDABLE, NDS, PERSON_TYPE_CODE, CURRENCY, FOR_AGENCY, SUPPRESS_DISCOUNTS, CATEGORY, NDS_PCT, PREFIX, FIRM_ID, INSTANT, ALLOW_UNMODERATED, FRAUDABLE, LANG_ID, CONTRACT_NEEDED, MONTHLY_REPORTABLE, ISO_CURRENCY, WAIT_PAYMENT_DAY_NUM, WAIT_PAYMENT_DAY_TYPE, BARTER, CREDIT_CARD, MOBILE, INAPP, FIRST_LIMIT, SECOND_LIMIT, CERTIFICATE, PAYMENT_METHOD_ID)
VALUES (2301118, TO_DATE('2016-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 700, 'ce_taxi_ua_uah', 0, 'Промокод Такси (Украина)', 0, 0, 1, 0, 1, -1, 'UAH', 0, 1, 'ua', 20, 'U', 23, 0, 0, 0, 2, 0, 0, 'UAH', null, 0, 0, 0, 0, 0, null, null, 1, 1505);

--changeset nebaruzdin:BALANCE-25259

insert into bo.t_paysys_old
select
    1122                          as id,
    sysdate                       as dt,
    1000                          as weight,
    'am_jp'                       as cc,
    1                             as extern,
    'Банк для юр. лиц (Армения)'  as name,
    0                             as nsp,
    0                             as private,
    1                             as reversable,
    0                             as invoice_sendable,
    1                             as nds,
    -1                            as person_type_code,
    'AMD'                         as currency,
    1                             as for_agency,
    0                             as suppress_discounts,
    'am_jp'                       as category,
    20                            as nds_pct,
    'Z'                           as prefix,
    26                            as firm_id,
    1                             as instant,
    0                             as allow_unmoderated,
    1                             as fraudable,
    1                             as lang_id,
    0                             as contract_needed,
    0                             as monthly_reportable,
    'AMD'                         as iso_currency,
    null                          as wait_payment_day_num,
    0                             as wait_payment_day_type,
    0                             as barter,
    1                             as credit_card,
    0                             as mobile,
    0                             as inapp,
    null                          as first_limit,
    null                          as second_limit,
    0                             as certificate,
    1001                          as payment_method_id
from dual
union all
select
    1123 as id,
    sysdate                       as dt,
    1000                          as weight,
    'am_np'                       as cc,
    1                             as extern,
    'Банк для физ. лиц (Армения)' as name,
    0                             as nsp,
    0                             as private,
    1                             as reversable,
    0                             as invoice_sendable,
    1                             as nds,
    -1                            as person_type_code,
    'AMD'                         as currency,
    1                             as for_agency,
    0                             as suppress_discounts,
    'am_np'                       as category,
    20                            as nds_pct,
    'AM'                          as prefix,
    26                            as firm_id,
    1                             as instant,
    0                             as allow_unmoderated,
    1                             as fraudable,
    1                             as lang_id,
    0                             as contract_needed,
    0                             as monthly_reportable,
    'AMD'                         as iso_currency,
    null                          as wait_payment_day_num,
    0                             as wait_payment_day_type,
    0                             as barter,
    1                             as credit_card,
    0                             as mobile,
    0                             as inapp,
    null                          as first_limit,
    null                          as second_limit,
    0                             as certificate,
    1001                          as payment_method_id
from dual;

--changeset nebaruzdin:BALANCE-24905

insert into bo.t_paysys_old
select
    1120                                       as id,
    sysdate                                    as dt,
    1020                                       as weight,
    'cc_kz_jp'                                 as cc,
    1                                          as extern,
    'Кредитная карта для юр. лиц (Казахстан)'  as name,
    0                                          as nsp,
    0                                          as private,
    1                                          as reversable,
    0                                          as invoice_sendable,
    1                                          as nds,
    -1                                         as person_type_code,
    'KZT'                                      as currency,
    1                                          as for_agency,
    0                                          as suppress_discounts,
    'kzu'                                      as category,
    12                                         as nds_pct,
    'Z'                                        as prefix,
    25                                         as firm_id,
    1                                          as instant,
    0                                          as allow_unmoderated,
    1                                          as fraudable,
    1                                          as lang_id,
    0                                          as contract_needed,
    0                                          as monthly_reportable,
    'KZT'                                      as iso_currency,
    null                                       as wait_payment_day_num,
    0                                          as wait_payment_day_type,
    0                                          as barter,
    1                                          as credit_card,
    0                                          as mobile,
    0                                          as inapp,
    1400000                                    as first_limit,
    1400000                                    as second_limit,
    0                                          as certificate,
    1101                                       as payment_method_id
from dual
union all
select
    1121                                       as id,
    sysdate                                    as dt,
    1120                                       as weight,
    'cc_kz_np'                                 as cc,
    1                                          as extern,
    'Кредитная карта для физ. лиц (Казахстан)' as name,
    0                                          as nsp,
    0                                          as private,
    1                                          as reversable,
    0                                          as invoice_sendable,
    1                                          as nds,
    -1                                         as person_type_code,
    'KZT'                                      as currency,
    1                                          as for_agency,
    0                                          as suppress_discounts,
    'kzp'                                      as category,
    12                                         as nds_pct,
    'Z'                                        as prefix,
    25                                         as firm_id,
    1                                          as instant,
    0                                          as allow_unmoderated,
    1                                          as fraudable,
    1                                          as lang_id,
    0                                          as contract_needed,
    0                                          as monthly_reportable,
    'KZT'                                      as iso_currency,
    null                                       as wait_payment_day_num,
    0                                          as wait_payment_day_type,
    0                                          as barter,
    1                                          as credit_card,
    0                                          as mobile,
    0                                          as inapp,
    1400000                                    as first_limit,
    1400000                                    as second_limit,
    0                                          as certificate,
    1101                                       as payment_method_id
from dual;

--changeset yanametro:BALANCE-25792-7
INSERT INTO BO.T_PAYSYS_OLD (ID, DT, WEIGHT, CC, EXTERN, NAME, NSP, PRIVATE, REVERSABLE, INVOICE_SENDABLE, NDS, PERSON_TYPE_CODE, CURRENCY, FOR_AGENCY, SUPPRESS_DISCOUNTS, CATEGORY, NDS_PCT, PREFIX, FIRM_ID, INSTANT, ALLOW_UNMODERATED, FRAUDABLE, LANG_ID, CONTRACT_NEEDED, MONTHLY_REPORTABLE, ISO_CURRENCY, WAIT_PAYMENT_DAY_NUM, WAIT_PAYMENT_DAY_TYPE, BARTER, CREDIT_CARD, MOBILE, INAPP, FIRST_LIMIT, SECOND_LIMIT, CERTIFICATE, PAYMENT_METHOD_ID) VALUES (1128, TO_DATE('2003-03-31 18:23:58', 'YYYY-MM-DD HH24:MI:SS'), 300, 'ph_wo_vat', 1, 'Банк для физических лиц без НДС', 0, 0, 1, 1, 0, 1, 'RUR', 1, 0, 'ph', 0, 'Б', 1, 0, 0, 0, 1, 0, 0, 'RUB', 9, 0, 0, 0, 0, 0, null, null, 0, 1001);

--changeset nebaruzdin:BALANCE-25694

insert into bo.t_paysys_old
select
    1125                                         as id,
    sysdate                                      as dt,
    1000                                         as weight,
    'by_jp_bc'                                   as cc,
    1                                            as extern,
    'Банковская карта (для юр. лиц, Белоруссия)' as name,
    0                                            as nsp,
    0                                            as private,
    1                                            as reversable,
    0                                            as invoice_sendable,
    1                                            as nds,
    -1                                           as person_type_code,
    'BYN'                                        as currency,
    1                                            as for_agency,
    0                                            as suppress_discounts,
    'byu'                                        as category,
    20                                           as nds_pct,
    'BLR'                                        as prefix,
    27                                           as firm_id,
    1                                            as instant,
    0                                            as allow_unmoderated,
    1                                            as fraudable,
    1                                            as lang_id,
    0                                            as contract_needed,
    0                                            as monthly_reportable,
    'BYN'                                        as iso_currency,
    null                                         as wait_payment_day_num,
    0                                            as wait_payment_day_type,
    0                                            as barter,
    1                                            as credit_card,
    0                                            as mobile,
    0                                            as inapp,
    null                                         as first_limit,
    null                                         as second_limit,
    0                                            as certificate,
    1101                                         as payment_method_id
from dual
union all
select
    1126                                          as id,
    sysdate                                       as dt,
    1000                                          as weight,
    'by_np_bc'                                    as cc,
    1                                             as extern,
    'Банковская карта (для физ. лиц, Белоруссия)' as name,
    0                                             as nsp,
    0                                             as private,
    1                                             as reversable,
    0                                             as invoice_sendable,
    1                                             as nds,
    -1                                            as person_type_code,
    'BYN'                                         as currency,
    1                                             as for_agency,
    0                                             as suppress_discounts,
    'byp'                                         as category,
    20                                            as nds_pct,
    'BLR'                                         as prefix,
    27                                            as firm_id,
    1                                             as instant,
    0                                             as allow_unmoderated,
    1                                             as fraudable,
    1                                             as lang_id,
    0                                             as contract_needed,
    0                                             as monthly_reportable,
    'BYN'                                         as iso_currency,
    null                                          as wait_payment_day_num,
    0                                             as wait_payment_day_type,
    0                                             as barter,
    1                                             as credit_card,
    0                                             as mobile,
    0                                             as inapp,
    null                                          as first_limit,
    null                                          as second_limit,
    0                                             as certificate,
    1101                                          as payment_method_id
from dual;

--changeset nebaruzdin:BALANCE-26390

insert into bo.t_paysys_old
select
    1129                       as id,
    sysdate                    as dt,
    1000                       as weight,
    'co'                       as cc,
    0                          as extern,
    'Компенсация (Белоруссия)' as name,
    0                          as nsp,
    0                          as private,
    1                          as reversable,
    0                          as invoice_sendable,
    1                          as nds,
    -1                         as person_type_code,
    'BYN'                      as currency,
    0                          as for_agency,
    0                          as suppress_discounts,
    'byu'                      as category,
    20                         as nds_pct,
    'BLR'                      as prefix,
    27                         as firm_id,
    0                          as instant,
    0                          as allow_unmoderated,
    0                          as fraudable,
    1                          as lang_id,
    0                          as contract_needed,
    0                          as monthly_reportable,
    'BYN'                      as iso_currency,
    null                       as wait_payment_day_num,
    0                          as wait_payment_day_type,
    0                          as barter,
    0                          as credit_card,
    0                          as mobile,
    0                          as inapp,
    null                       as first_limit,
    null                       as second_limit,
    1                          as certificate,
    1502                       as payment_method_id
from dual
union all
select
    1130                       as id,
    sysdate                    as dt,
    1000                       as weight,
    'ce'                       as cc,
    0                          as extern,
    'Сертификат (Белоруссия)'  as name,
    0                          as nsp,
    0                          as private,
    1                          as reversable,
    0                          as invoice_sendable,
    1                          as nds,
    -1                         as person_type_code,
    'BYN'                      as currency,
    0                          as for_agency,
    1                          as suppress_discounts,
    'byu'                      as category,
    20                         as nds_pct,
    'BLR'                      as prefix,
    27                         as firm_id,
    0                          as instant,
    0                          as allow_unmoderated,
    0                          as fraudable,
    1                          as lang_id,
    0                          as contract_needed,
    0                          as monthly_reportable,
    'BYN'                      as iso_currency,
    null                       as wait_payment_day_num,
    0                          as wait_payment_day_type,
    0                          as barter,
    0                          as credit_card,
    0                          as mobile,
    0                          as inapp,
    null                       as first_limit,
    null                       as second_limit,
    1                          as certificate,
    1504                       as payment_method_id
from dual;

--changeset yanametro:BALANCE-27995-3
INSERT INTO BO.T_PAYSYS_OLD (ID, DT, WEIGHT, CC, EXTERN, NAME, NSP, PRIVATE, REVERSABLE, INVOICE_SENDABLE, NDS, PERSON_TYPE_CODE, CURRENCY, FOR_AGENCY, SUPPRESS_DISCOUNTS, CATEGORY, NDS_PCT, PREFIX, FIRM_ID, INSTANT, ALLOW_UNMODERATED, FRAUDABLE, LANG_ID, CONTRACT_NEEDED, MONTHLY_REPORTABLE, ISO_CURRENCY, WAIT_PAYMENT_DAY_NUM, WAIT_PAYMENT_DAY_TYPE, BARTER, CREDIT_CARD, MOBILE, INAPP, FIRST_LIMIT, SECOND_LIMIT, CERTIFICATE, PAYMENT_METHOD_ID) VALUES (1131, sysdate, 1000, 'kzu', 1, 'Банк для юридических лиц, Казахстан (тенге)', 0, 0, 1, 1, 1, -1, 'KZT', 1, 0, 'kzu', 0, 'Z', 24, 0, 0, 0, 1, 0, 0, 'KZT', 1, 0, 0, 0, 0, 0, null, null, 0, 1001);
INSERT INTO BO.T_PAYSYS_OLD (ID, DT, WEIGHT, CC, EXTERN, NAME, NSP, PRIVATE, REVERSABLE, INVOICE_SENDABLE, NDS, PERSON_TYPE_CODE, CURRENCY, FOR_AGENCY, SUPPRESS_DISCOUNTS, CATEGORY, NDS_PCT, PREFIX, FIRM_ID, INSTANT, ALLOW_UNMODERATED, FRAUDABLE, LANG_ID, CONTRACT_NEEDED, MONTHLY_REPORTABLE, ISO_CURRENCY, WAIT_PAYMENT_DAY_NUM, WAIT_PAYMENT_DAY_TYPE, BARTER, CREDIT_CARD, MOBILE, INAPP, FIRST_LIMIT, SECOND_LIMIT, CERTIFICATE, PAYMENT_METHOD_ID) VALUES (1132, sysdate, 1100, 'kzp', 1, 'Банк для физических лиц, Казахстан (тенге)', 0, 0, 1, 1, 1, -1, 'KZT', 1, 0, 'kzp', 0, 'Z', 24, 0, 0, 0, 1, 0, 0, 'KZT', 1, 0, 0, 0, 0, 0, null, null, 0, 1001);

--changeset akatovda:BALANCE-27995-2
UPDATE BO.T_PAYSYS_OLD SET NDS = 1, NDS_PCT=0 WHERE ID IN (1122, 1123);

--changeset lightrevan:BALANCE-27778-legacy-paysyses-3
UPDATE bo.t_paysys_old
    SET extern = 0
WHERE cc in ('wm', 'qiwi_rit', 'qiwi_cab')
    or category like '%autoru%'
;

--changeset lightrevan:BALANCE-26114-paysys-group

ALTER TABLE bo.t_paysys_old ADD GROUP_ID NUMBER DEFAULT 0;

--changeset lightrevan:BALANCE-26114-paysys-group-vals

-- trust
UPDATE bo.T_PAYSYS_OLD
  SET group_id = 1
  WHERE cc LIKE 'tt_%'
;

-- nr_via_agency
UPDATE bo.T_PAYSYS_OLD
  set group_id = 3
  where prefix = 'S'
;

-- yt_nds
UPDATE bo.T_PAYSYS_OLD
  set group_id = 4
  where id = 11069
;

-- ofd
UPDATE bo.T_PAYSYS_OLD
  set PAYMENT_METHOD_ID = (select id from meta.T_PAYMENT_METHOD where cc = 'paid_promocode')
  where cc = 'ce_ofd'
;

--changeset lightrevan:BALANCE-27778-ph-wo-vat
UPDATE bo.t_paysys_old
    SET group_id = 4
WHERE cc = 'ph_wo_vat'
;

--changeset nebaruzdin:BALANCE-28708

update bo.t_paysys_old
set iso_currency = 'YSTBN'
where currency = 'YSTBN';

--changeset lightrevan:BALANCE-29552-ps-upd
UPDATE bo.T_PAYSYS_OLD
  set group_id = 5
  where id = 1099
;

--changeset sfreest:BALANCE-29271-t-paysys-old-red-market-hk
Insert into T_PAYSYS_OLD (ID,DT,WEIGHT,CC,EXTERN,NAME,NSP,PRIVATE,REVERSABLE,INVOICE_SENDABLE,NDS,PERSON_TYPE_CODE,CURRENCY,FOR_AGENCY,SUPPRESS_DISCOUNTS,CATEGORY,NDS_PCT,PREFIX,FIRM_ID,INSTANT,ALLOW_UNMODERATED,FRAUDABLE,LANG_ID,CONTRACT_NEEDED,MONTHLY_REPORTABLE,ISO_CURRENCY,WAIT_PAYMENT_DAY_NUM,WAIT_PAYMENT_DAY_TYPE,BARTER,CREDIT_CARD,MOBILE,INAPP,FIRST_LIMIT,SECOND_LIMIT,CERTIFICATE,PAYMENT_METHOD_ID,GROUP_ID)
values
('1143',to_date('01.02.12','DD.MM.RR'),'3040','hk_yt_usd','1','Банк для юридических лиц, доллары (нерезиденты, Гонгконг)','0','0','1','1','0','-1','USD','1','0','hk_yt','0','HK','33','0','0','0','3','0','1','USD','3','1','0','0','0','0',null,null,'0','1001','0');
Insert into T_PAYSYS_OLD (ID,DT,WEIGHT,CC,EXTERN,NAME,NSP,PRIVATE,REVERSABLE,INVOICE_SENDABLE,NDS,PERSON_TYPE_CODE,CURRENCY,FOR_AGENCY,SUPPRESS_DISCOUNTS,CATEGORY,NDS_PCT,PREFIX,FIRM_ID,INSTANT,ALLOW_UNMODERATED,FRAUDABLE,LANG_ID,CONTRACT_NEEDED,MONTHLY_REPORTABLE,ISO_CURRENCY,WAIT_PAYMENT_DAY_NUM,WAIT_PAYMENT_DAY_TYPE,BARTER,CREDIT_CARD,MOBILE,INAPP,FIRST_LIMIT,SECOND_LIMIT,CERTIFICATE,PAYMENT_METHOD_ID,GROUP_ID)
values
('1144',to_date('01.02.12','DD.MM.RR'),'3040','hk_ur_usd','1','Банк для юридических лиц, доллары (резиденты, Гонгконг)','0','0','1','1','0','-1','USD','1','0','hk_ur','0','HK','33','0','0','0','3','0','1','USD','3','1','0','0','0','0',null,null,'0','1001','0');

--changeset quark:BALANCE-30394

INSERT INTO BO.T_PAYSYS_OLD (
  ID, DT, WEIGHT, CC, EXTERN, NAME, NSP, PRIVATE, REVERSABLE, INVOICE_SENDABLE, NDS, PERSON_TYPE_CODE, CURRENCY, FOR_AGENCY, SUPPRESS_DISCOUNTS, CATEGORY, NDS_PCT,
  PREFIX, FIRM_ID, INSTANT, ALLOW_UNMODERATED, FRAUDABLE, LANG_ID, CONTRACT_NEEDED, MONTHLY_REPORTABLE, ISO_CURRENCY, WAIT_PAYMENT_DAY_NUM,
  WAIT_PAYMENT_DAY_TYPE, BARTER, CREDIT_CARD, MOBILE, INAPP, FIRST_LIMIT, SECOND_LIMIT, CERTIFICATE, PAYMENT_METHOD_ID, GROUP_ID
)
VALUES (
  (select max(id) + 1 from bo.T_PAYSYS_OLD where id < 2000), date '2019-01-01', 1000, 'eu_yt_byn', 1, 'Банк для юридических лиц бел. рубли (нерезиденты, Голландия)', 0, 0, 1, 1, 0, -1,
  'BYN', 1, 0, 'eu_yt', 0, 'EU', 115, 0, 0, 0, 3, 0, 0, 'BYN', null, 0, 0, 0, 0, 0, null, null, 0, 1001, 0
);
