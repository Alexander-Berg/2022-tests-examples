--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_EXPORT_TYPE
--------------------------------------------------------------------------------
  CREATE TABLE "BO"."T_EXPORT_TYPE"
   (	"TYPE" VARCHAR2(20 BYTE) NOT NULL ENABLE,
	"PARAMS" VARCHAR2(4000 CHAR),
	 CONSTRAINT "T_EXPORT_TYPE_PK" PRIMARY KEY ("TYPE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE,
	 CONSTRAINT "JSON_T_EXPORT_TYPE_PARAMS" CHECK (params IS JSON STRICT) ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE UNIQUE INDEX "BO"."T_EXPORT_TYPE_PK" ON "BO"."T_EXPORT_TYPE" ("TYPE")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;


--changeset akatovda:BALANCE-24291-1
DELETE BO.T_EXPORT_TYPE WHERE TYPE = 'STAT_AGGREGATOR';

--changeset akatovda:BALANCE-24291-2
INSERT INTO BO.T_EXPORT_TYPE VALUES('STAT_AGGREGATOR', '');

--changeset akatovda:BALANCE-24291-3 endDelimiter:\\
CREATE OR REPLACE TRIGGER BO.TR_EXPORT_TYPE_PARTITIONING
AFTER INSERT ON BO.T_EXPORT_TYPE FOR EACH ROW
DECLARE
    partition_count NUMBER;
    cmd_add_partition VARCHAR2(4096);
    TPL VARCHAR2(4096);
    ex  NUMBER;
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  SELECT count(partition_name) INTO partition_count FROM user_tab_partitions WHERE partition_name = :NEW.TYPE AND TABLE_NAME = 'T_EXPORT';

  IF partition_count = 0 THEN
    EXECUTE IMMEDIATE 'ALTER TABLE BO.T_EXPORT ADD PARTITION ' || :NEW.TYPE || ' VALUES (''' || :NEW.TYPE || ''')';

    SELECT 'ALTER TABLE BO.T_EXPORT_HISTORY SET SUBPARTITION TEMPLATE (' ||
             LISTAGG('SUBPARTITION ' || PARTITION_NAME || ' VALUES(''' || PARTITION_NAME || ''')', ', ' || CHR(10))
             WITHIN GROUP (ORDER BY 1) || ')' tmpl
    INTO TPL
    FROM ALL_TAB_PARTITIONS
    WHERE TABLE_NAME = 'T_EXPORT' AND TABLE_OWNER = 'BO';
    DBMS_OUTPUT.PUT_LINE(TPL);
    EXECUTE IMMEDIATE TPL;

    FOR need IN (SELECT
                       tp2.PARTITION_NAME,
                       tp1.HIGH_VALUE,
                       tp1.PARTITION_NAME PNAME
                     FROM ALL_TAB_PARTITIONS tp1
                       CROSS JOIN
                       ALL_TAB_PARTITIONS tp2
                     WHERE tp1.TABLE_NAME = 'T_EXPORT' AND tp1.TABLE_OWNER = 'BO'
                           AND tp2.TABLE_NAME = 'T_EXPORT_HISTORY' AND tp2.TABLE_OWNER = 'BO')
        LOOP
          ex := 0;
          FOR parts IN (SELECT
                          sub.PARTITION_NAME,
                          HIGH_VALUE
                        FROM ALL_TAB_SUBPARTITIONS sub
                        WHERE sub.table_name = 'T_EXPORT_HISTORY' AND sub.TABLE_OWNER = 'BO'
                              AND sub.PARTITION_NAME = need.PARTITION_NAME)
          LOOP
            IF parts.HIGH_VALUE = need.HIGH_VALUE
            THEN
              ex := 1;
              EXIT;
            END IF;
          END LOOP;

          IF ex = 0
          THEN
            TPL := 'ALTER TABLE BO.T_EXPORT_HISTORY MODIFY PARTITION ' ||
                   need.PARTITION_NAME || ' ADD SUBPARTITION ' ||
                   need.PARTITION_NAME || '_' ||
                   need.PNAME || ' VALUES (' || need.HIGH_VALUE || ')';
            DBMS_OUTPUT.PUT_LINE(TPL);
            EXECUTE IMMEDIATE TPL;
           END IF;
        END LOOP;
  END IF;
END;
\\


--changeset halty:BALANCE-24176-1
insert into bo.t_export_type(type, params) values('PROCESS_TAXI', '{"StopTimeout": 3600, "NextAttemptTimeout": 2, "ReportRate": 3, "MaxRate": 1}');

--changeset ngolovkin:BALANCE-25211-1
Insert into bo.t_export_type (TYPE, PARAMS) values ('CASH_REGISTER','{"StopTimeout": 3600, "NextAttemptTimeout": 2, "ReportRate": 3, "MaxRate": 10}');

--changeset ngolovkin:BALANCE-25670-1
update (
select  * from bo.t_export_type where type = 'CASH_REGISTER'
) set params = '{"StopTimeout": 3600, "NextAttemptTimeout": 2, "ReportRate": 3, "MaxRate": 3}';

--changeset yanametro:BALANCE-25341-2
insert into bo.t_export_type(type, params) values('PARTNER_COMPL', '{"StopTimeout": 3600, "NextAttemptTimeout": 2, "ReportRate": 3, "MaxRate": 1}');


--changeset srg91:TRUST-3274
insert into bo.t_export_type(type, params) values('REGISTER_MATCHING', '{"StopTimeout": 3600, "NextAttemptTimeout": 2, "ReportRate": 3, "MaxRate": 5}');


--changeset srg91:TRUST-3483
update bo.t_export_type
set params = replace(params, '"MaxRate": 5', '"MaxRate": 1')
where type = 'REGISTER_MATCHING'
;

--changeset halty:BALANCE-26276
insert into bo.t_export_type(type, params) values('PREPAY_ACTS', '{"StopTimeout": 3600, "NextAttemptTimeout": 2, "ReportRate": 3, "MaxRate": 10}');


--changeset yanametro:BALANCE-26246
update bo.T_EXPORT_TYPE
set params = '{"StopTimeout": 3600, "NextAttemptTimeout": 300, "ReportRate": 3, "MaxRate": 10}'
where type='PARTNER_COMPL';

--changeset natabers:BALANCE-27474

INSERT INTO BO.T_EXPORT_TYPE(type, params) VALUES('EMAIL_MESSAGE', '{"MaxRate": 10}');

--changeset akatovda:BALANCE-27799
UPDATE BO.T_EXPORT_TYPE
SET PARAMS = '{"StopTimeout": 3600, "NextAttemptTimeout": 2, "ReportRate": 3, "MaxRate": 10}'
WHERE TYPE = 'STAT_AGGREGATOR';

--changeset buyvich:TRUST-4899-1
insert into bo.t_export_type(type, params) values ('TRUST_PAYMENT_DATA', '{"StopTimeout": 3600, "NextAttemptTimeout": 120, "ReportRate": 5, "MaxRate": 10}');

--changeset natabers:BALANCE-28633-t_export_type
Insert into bo.t_export_type (TYPE, PARAMS) values ('AUTO_OVERDRAFT','{"StopTimeout": 3600, "NextAttemptTimeout": 2, "ReportRate": 3, "MaxRate": 10}');

--changeset akatovda:BALANCE-27799-01
UPDATE BO.T_EXPORT_TYPE
SET PARAMS = '{"StopTimeout": 14400, "NextAttemptTimeout": 60, "ReportRate": 3, "MaxRate": 20}'
WHERE TYPE = 'STAT_AGGREGATOR';
