--liquibase formatted sql

  CREATE TABLE "BO"."T_ROLE_NAME" 
   (    "ID" NUMBER NOT NULL ENABLE, 
    "NAME" VARCHAR2(100 BYTE) NOT NULL ENABLE, 
     CONSTRAINT "PK_T_ROLE" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset vaclav:TRUST-2266-1

insert into bo.t_role_name (id, name) values (402, 'Платежные ссылки. Сервис YDF');

--changeset ashvedunov:BALANCE-23866-1
insert into bo.t_role_name (id, name) values (40, 'Архивариус');

--changeset dimonb:BALANCE-24783
insert into bo.t_role_name (id, name) values (41, 'Бэкофис: шаблоны договоров');

--changeset srg91:TRUST-3631
insert into bo.t_role_name
values (61, 'Менеджер по фрод-мониторингу');

insert into bo.t_role_name
values (62, 'Менеджер по договорам');

--changeset nebaruzdin:BALANCE-27232

insert into bo.t_role_name
values (101, 'Директ: Ограниченный представитель клиента');

--changeset natabers:BALANCE-28045-2

insert into bo.t_role_name
values (10216, 'Редактировать промокоды');
