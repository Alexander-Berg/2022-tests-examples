--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for table T_ENUMS_TREE
--------------------------------------------------------------------------------

ALTER TABLE T_ENUMS_TREE
ADD CONSTRAINT T_ENUMS_TREE_UI UNIQUE
(
  PARENT_ID
, CODE
)
USING INDEX
(
    CREATE UNIQUE INDEX T_ENUMS_TREE_UI ON T_ENUMS_TREE (PARENT_ID ASC, CODE ASC)
    LOGGING
    TABLESPACE YACC_PERSONTS
    PCTFREE 10
    INITRANS 2
    STORAGE
    (
      INITIAL 1048576
      NEXT 1048576
      MINEXTENTS 1
      MAXEXTENTS UNLIMITED
      PCTINCREASE 0
      FREELISTS 1
      FREELIST GROUPS 1
      BUFFER_POOL DEFAULT
    )
    NOPARALLEL
)
 ENABLEALTER TABLE T_ENUMS_TREE
ADD CONSTRAINT T_ENUMS_TREE_FK FOREIGN KEY
(
  PARENT_ID
)
REFERENCES T_ENUMS_TREE
(
  ID
)
ENABLECREATE TABLE T_ENUMS_TREE
(
  ID NUMBER NOT NULL
, PARENT_ID NUMBER
, CODE VARCHAR2(255 BYTE)
, VALUE VARCHAR2(255 BYTE)
, POS NUMBER
, CONSTRAINT T_ENUMS_TREE_PK PRIMARY KEY
  (
    ID
  )
  USING INDEX
  (
      CREATE UNIQUE INDEX T_ENUMS_TREE_PK ON T_ENUMS_TREE (ID ASC)
      LOGGING
      TABLESPACE YACC_PERSONTS
      PCTFREE 10
      INITRANS 2
      STORAGE
      (
        INITIAL 1048576
        NEXT 1048576
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        FREELISTS 1
        FREELIST GROUPS 1
        BUFFER_POOL DEFAULT
      )
      NOPARALLEL
  )
  ENABLE
)
LOGGING
TABLESPACE YACC_PERSONTS
PCTFREE 10
PCTUSED 40
INITRANS 1
STORAGE
(
  INITIAL 1048576
  NEXT 1048576
  MINEXTENTS 1
  MAXEXTENTS UNLIMITED
  PCTINCREASE 0
  FREELISTS 1
  FREELIST GROUPS 1
  BUFFER_POOL DEFAULT
)
NOCOMPRESS
NOPARALLEL


--changeset ngolovkin:BALANCE-24102

insert into bo.t_enums_tree (id,parent_id,code,value,pos) values (bo.s_enums_tree.nextval,(select id from bo.t_enums_tree where code = 'contracts'),'14','ОФД: Без уч. в расчетах',3);

--changeset yanametro:BALANCE-24188

INSERT INTO BO.T_ENUMS_TREE (ID, PARENT_ID, CODE, VALUE, POS) VALUES (1104, 1100, '89', 'Маркетинг. Маркет', 4);

--changeset halty:BALANCE-24465

INSERT INTO BO.T_ENUMS_TREE (ID, PARENT_ID, CODE, VALUE, POS) VALUES (1432, 1400, '72', 'Лицензионный', 72);

--changeset quark:BALANCE-25031

insert into bo.t_enums_tree (ID, PARENT_ID, CODE, VALUE, POS) values (1433, 1400, '9', 'Оферта', 73);

--changeset quark:BALANCE-25031-2

update bo.t_enums_tree set value = 'Договор-оферта' where id = 1433;

--changeset ngolovkin:BALANCE-24882-1

update bo.t_enums_tree set value = 'Нет' where code = 0 and parent_id = 1500;

--changeset ngolovkin:BALANCE-24882-2

Insert into bo.t_enums_tree (ID,PARENT_ID,CODE,VALUE,POS) values (bo.s_enums_tree.nextval,1500,'23','Маркет Белоруссия',11);

--changeset halty:BALANCE-25146

Insert into BO.T_ENUMS_TREE (ID,PARENT_ID,CODE,VALUE,POS) values ('4000',null,'paysys_types',null,null);
Insert into BO.T_ENUMS_TREE (ID,PARENT_ID,CODE,VALUE,POS) values ('4001','4000', null, 'выберите...', 1);
Insert into BO.T_ENUMS_TREE (ID,PARENT_ID,CODE,VALUE,POS) values ('4002','4000','yamoney','yamoney', 2);
Insert into BO.T_ENUMS_TREE (ID,PARENT_ID,CODE,VALUE,POS) values ('4003','4000','wallet1','wallet1', 3);
Insert into BO.T_ENUMS_TREE (ID,PARENT_ID,CODE,VALUE,POS) values ('4004','4000','alfa','alfa', 4);

--changeset nebaruzdin:BALANCE-24905

insert into bo.t_enums_tree
select
    (select max(id) + 1
     from bo.t_enums_tree
     where id < 1500)                     as id,
    (select id
     from bo.t_enums_tree
     where code = 'contracts')            as parent_id,
    300                                   as code,
    'Яндекс.Казахстан: Не агентский'      as value,
    81                                    as pos
from dual
union all
select
    (select max(id) + 2
     from bo.t_enums_tree
     where id < 1500)                     as id,
    (select id
     from bo.t_enums_tree
     where code = 'contracts')            as parent_id,
    306                                   as code,
    'Яндекс.Казахстан: Оптовый агентский' as value,
    82                                    as pos
from dual;


--changeset yanametro:BALANCE-25759-2

insert into bo.t_enums_tree (id, parent_id, code, value, pos)
    values (bo.s_enums_tree.nextval, 73, 666, 'выберите', 0);

--changeset yanametro:BALANCE-25910
insert into bo.T_ENUMS_TREE
(id, parent_id, code, value, pos)
		values (bo.S_ENUMS_TREE.nextval, (select id from bo.t_enums_tree where code='spendablectype'), 35, 'Дзен', 5);

--changeset yanametro:BALANCE-25979
insert into bo.t_enums_tree (id, parent_id, code, value, pos) values (10142, 73, -1, 'Без НДС', 5);

--changeset nebaruzdin:BALANCE-25694

insert into bo.t_enums_tree
select
    (select max(id) + 1
     from bo.t_enums_tree
     where id < 1500)                   as id,
    (select id
     from bo.t_enums_tree
     where code = 'contracts')          as parent_id,
    400                                 as code,
    'Яндекс.Реклама: Не агентский'      as value,
    91                                  as pos
from dual
union all
select
    (select max(id) + 2
     from bo.t_enums_tree
     where id < 1500)                   as id,
    (select id
     from bo.t_enums_tree
     where code = 'contracts')          as parent_id,
    404                                 as code,
    'Яндекс.Реклама: Прямой агентский'  as value,
    92                                  as pos
from dual
union all
select
    (select max(id) + 3
     from bo.t_enums_tree
     where id < 1500)                   as id,
    (select id
     from bo.t_enums_tree
     where code = 'contracts')          as parent_id,
    406                                 as code,
    'Яндекс.Реклама: Оптовый агентский' as value,
    93                                  as pos
from dual;

-- changeset el-yurchito:BALANCE-26581
UPDATE BO.T_ENUMS_TREE
SET
  POS = POS + 1
WHERE
  PARENT_ID IN (SELECT ID FROM BO.T_ENUMS_TREE WHERE CODE = 'fixed_discounts')
    AND
  CODE <> '0';

INSERT INTO BO.T_ENUMS_TREE (ID, PARENT_ID, CODE, VALUE, POS)
SELECT
  BO.S_ENUMS_TREE.nextval                                           ID,
  (SELECT ID FROM BO.T_ENUMS_TREE WHERE CODE = 'fixed_discounts')   PARENT_ID,
  '1'                                                               CODE,
  'Скидка 1%'                                                       VALUE,
  0                                                                 POS
FROM dual;

--changeset quark:BALANCE-26906
alter table bo.t_enums_tree add constraint c_enums_tree_paysys_types check (parent_id != 4000 or parent_id = 4000 and length(code) <= 20);

--changeset shorrty:BALANCE-27276
insert into bo.t_enums_tree (id, parent_id, code, value, pos)
select bo.s_enums_tree.nextval       as id,
       t.id                          as parent_id,
       '20'                          as code,
       'Премии Беларусь'             as value,
       null                          as pos
  from bo.t_enums_tree    t
 where code = 'wholesale_agent_premium_awards_scale';

--changeset lightrevan:BALANCE-27279
insert into bo.t_enums_tree
select
    bo.S_ENUMS_TREE.nextval id,
    (select id from bo.t_enums_tree where code = 'contracts') parent_id,
    62 code,
    'Яндекс.Реклама: Оптовый агентский, премия' value,
    94 pos
from dual
;

--changeset shorrty:BALANCE-27411
insert into bo.t_enums_tree (id, parent_id, code, value, pos)
select bo.s_enums_tree.nextval       as id,
       t.id                          as parent_id,
       '21'                          as code,
       'Базовая СПб'                 as value,
       null                          as pos
  from bo.t_enums_tree    t
 where code = 'wholesale_agent_premium_awards_scale'
;

-- changeset el-yurchito:BALANCE-27540-1 endDelimiter:\\
UPDATE
  "BO"."T_ENUMS_TREE"
SET
  POS = POS + 1
WHERE
  PARENT_ID = (SELECT ID FROM "BO"."T_ENUMS_TREE" WHERE CODE = 'fixed_discounts')
    AND
  POS > 2
\\

-- changeset el-yurchito:BALANCE-27540-2 endDelimiter:\\
INSERT INTO  "BO"."T_ENUMS_TREE" (ID, PARENT_ID, CODE, VALUE, POS)
SELECT
  "BO"."S_ENUMS_TREE" .nextval                                           ID,
  (SELECT ID FROM  "BO"."T_ENUMS_TREE" WHERE CODE = 'fixed_discounts')   PARENT_ID,
  '17'                                                                   CODE,
  'Скидка 17%'                                                           VALUE,
  2                                                                      POS
FROM dual
\\

--changeset natabers:BALANCE-27404
insert into bo.t_enums_tree
select
    bo.S_ENUMS_TREE.nextval id,
    (select id from bo.t_enums_tree where code = 'contracts') parent_id,
    301 code,
    'Яндекс.Казахстан: комиссионный' value,
    95 pos
from dual
;

--changeset vorobyov-as:BALANCE-27748
insert into bo.t_enums_tree
       (id,  parent_id, code, value,    pos)
values (506, 500,       6,    'Оферта', 6)
;

--changeset quark:BALANCE-28177

insert into bo.t_enums_tree (id, parent_id, code, value, pos) values (605, 600, 5, 'Реестр Тинькофф', 4);


--changeset lightrevan:BALANCE-28011-enums-types
INSERT INTO bo.t_enums_tree (id, code)
  SELECT
    bo.s_enums_tree.nextval,
    code
  FROM (
    SELECT 'reward_cons_type' code FROM dual
    UNION ALL
    SELECT 'reward_cons_period' code FROM dual
  );

--changeset lightrevan:BALANCE-28011-enums-vals
INSERT INTO bo.t_enums_tree
  SELECT
    bo.s_enums_tree.nextval id,
    (SELECT id
     FROM bo.t_enums_tree
     WHERE code = d.code)   parent_id,
    d.id                    code,
    d.value                 value,
    d.id                    pos
  FROM (

         SELECT
           'reward_cons_type'        code,
           1                         id,
           'Пропорционально обороту' value
         FROM dual
         UNION ALL

         SELECT
           'reward_cons_type'   code,
           2                    id,
           'На главный договор' value
         FROM dual
         UNION ALL

         SELECT
           'reward_cons_period' code,
           2                    id,
           'Квартальная'        value
         FROM dual
         UNION ALL

         SELECT
           'reward_cons_period' code,
           3                    id,
           'Полугодовая'        value
         FROM dual
         UNION ALL

         SELECT
           'reward_cons_period' code,
           4                    id,
           'Годовая'            value
         FROM dual
       ) d;

-- changeset el-yurchito:BALANCE-27811-1 endDelimiter:\\
UPDATE
  "BO"."T_ENUMS_TREE"
SET
  POS = POS + 1
WHERE
  PARENT_ID IN (SELECT ID FROM  "BO"."T_ENUMS_TREE" WHERE CODE = 'ndsreal')
    AND
  CODE = '-1'
\\

-- changeset el-yurchito:BALANCE-27811-2 endDelimiter:\\
INSERT INTO  "BO"."T_ENUMS_TREE" (ID, PARENT_ID, CODE, VALUE, POS)
SELECT
  "BO"."S_ENUMS_TREE" .nextval                                           ID,
  (SELECT ID FROM  "BO"."T_ENUMS_TREE" WHERE CODE = 'ndsreal')           PARENT_ID,
  '12'                                                                   CODE,
  'НДС 12%'                                                              VALUE,
  5                                                                      POS
FROM dual
\\

-- changeset el-yurchito:BALANCE-27811-3 endDelimiter:\\
INSERT INTO  "BO"."T_ENUMS_TREE" (ID, PARENT_ID, CODE, VALUE, POS)
SELECT
  "BO"."S_ENUMS_TREE" .nextval                                           ID,
  (SELECT ID FROM  "BO"."T_ENUMS_TREE" WHERE CODE = 'partnercurrency')   PARENT_ID,
  '398'                                                                  CODE,
  'Тенге (KZT)'                                                          VALUE,
  6                                                                      POS
FROM dual
\\

--changeset natabers:BALANCE-28470-t_enums_tree

insert into bo.t_enums_tree (id, parent_id, code, value, pos)
  values(bo.s_enums_tree.nextval, 1500, '24', 'Узбекистан', 13);

--changeset vorobyov-as:BALANCE-28343-1
insert into bo.t_enums_tree (id,  parent_id, code, value,         pos)
                     values (507, 500,       7,    'Group offer', 7);

--changeset vorobyov-as:BALANCE-28343-2
insert into bo.t_enums_tree (id,  parent_id, code, value,         pos)
                     values (508, 500,       8,    'Child offer', 8);

--changeset lightrevan:BALANCE-28928-et
MERGE INTO bo.t_enums_tree et
USING (
        SELECT
          3000  parent_id,
          0     code,
          'Нет' value
        FROM dual
      ) d
ON (et.parent_id = d.parent_id AND et.code = d.code)
WHEN NOT MATCHED THEN INSERT (id, parent_id, code, value)
VALUES (bo.s_enums_tree.nextval, d.parent_id, d.code, d.value);

--changeset quark:BALANCE-28901
insert into bo.t_enums_tree (ID, PARENT_ID, CODE, VALUE, POS) values (s_enums_tree.nextval, 400, 933, 'Белорусские рубли (BYN)', 8);

-- changeset el-yurchito:BALANCE-29125-1 endDelimiter:\\
UPDATE "BO"."T_ENUMS_TREE"
SET POS = POS + 1
WHERE
  PARENT_ID IN (SELECT ID FROM "BO"."T_ENUMS_TREE" WHERE CODE = 'fixed_discounts')
  AND CODE NOT IN ('0', '1')
\\

-- changeset el-yurchito:BALANCE-29125-2 endDelimiter:\\
INSERT INTO  "BO"."T_ENUMS_TREE" (ID, PARENT_ID, CODE, VALUE, POS)
SELECT
  "BO"."S_ENUMS_TREE" .nextval                                           ID,
  (SELECT ID FROM  "BO"."T_ENUMS_TREE" WHERE CODE = 'fixed_discounts')   PARENT_ID,
  '10'                                                                   CODE,
  'Скидка 10%'                                                           VALUE,
  1                                                                      POS
FROM dual
\\

--changeset vorobyov-as:BALANCE-25434
insert into bo.t_enums_tree (id,  parent_id, code, value,      pos)
                     values (807, 60,        10,   'Лицензия', 10);

--changeset natabers:BALANCE-29652-t_enums_tree
INSERT INTO BO.T_ENUMS_TREE (ID, PARENT_ID, CODE, VALUE, POS) VALUES(bo.s_enums_tree.nextval, 3000, '23', 'Базовая лайт', NULL);

--changeset dolvik:BALANCE-29315-1
INSERT INTO BO.T_ENUMS_TREE (ID, PARENT_ID, CODE, VALUE, POS)
  SELECT bo.s_enums_tree.nextval, 400, NULL, 'не выбрана', 0
    FROM DUAL
    WHERE NOT EXISTS(SELECT 1 FROM BO.T_ENUMS_TREE WHERE PARENT_ID = 400 AND CODE IS NULL);

--changeset vorobyov-as:BALANCE-30114-1
update bo.t_enums_tree set value='РФ, стандартный НДС' where id=74;
--changeset vorobyov-as:BALANCE-30114-2
update bo.t_enums_tree set value='НДС 0' where id=75;
--changeset vorobyov-as:BALANCE-30114-3
update bo.t_enums_tree set value='Украина, стандартный НДС' where id=76;
--changeset vorobyov-as:BALANCE-30114-4
update bo.t_enums_tree set value='Швейцария, стандартный НДС' where id=903;
--changeset vorobyov-as:BALANCE-30114-5
update bo.t_enums_tree set value='Казахстан, стандартный НДС' where id=10321;