--liquibase formatted sql

--------------------------------------------------------
--  DDL for Table T_PAY_POLICY_FIRM
--------------------------------------------------------

  CREATE TABLE "BO"."T_PAY_POLICY_FIRM"
   (	"CATEGORY" VARCHAR2(20 CHAR),
	"PAY_POLICY_ID" NUMBER(*,0),
	"FIRM_ID" NUMBER(*,0)
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;
--------------------------------------------------------
--  DDL for Index IDX_PAY_POLICY_FIRM_FIRM_ID
--------------------------------------------------------

  CREATE INDEX "BO"."IDX_PAY_POLICY_FIRM_FIRM_ID" ON "BO"."T_PAY_POLICY_FIRM" ("FIRM_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;
--------------------------------------------------------
--  DDL for Index IDX_PAY_POLICY_FIRM_PP_ID
--------------------------------------------------------

  CREATE INDEX "BO"."IDX_PAY_POLICY_FIRM_PP_ID" ON "BO"."T_PAY_POLICY_FIRM" ("PAY_POLICY_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;
--------------------------------------------------------
--  DDL for Index IDX_PAY_POLICY_FIRM_CATEGORY
--------------------------------------------------------

  CREATE INDEX "BO"."IDX_PAY_POLICY_FIRM_CATEGORY" ON "BO"."T_PAY_POLICY_FIRM" ("CATEGORY")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;
--------------------------------------------------------
--  DDL for Index T_PAY_POLICY_FIRM_UNIQUE
--------------------------------------------------------

  CREATE UNIQUE INDEX "BO"."T_PAY_POLICY_FIRM_UNIQUE" ON "BO"."T_PAY_POLICY_FIRM" ("PAY_POLICY_ID", "CATEGORY")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;
--------------------------------------------------------
--  DDL for Index SYS_C002152043
--------------------------------------------------------

  CREATE UNIQUE INDEX "BO"."SYS_C002152043" ON "BO"."T_PAY_POLICY_FIRM" ("PAY_POLICY_ID", "CATEGORY", "FIRM_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;
--------------------------------------------------------
--  Constraints for Table T_PAY_POLICY_FIRM
--------------------------------------------------------

  ALTER TABLE "BO"."T_PAY_POLICY_FIRM" ADD CONSTRAINT "T_PAY_POLICY_FIRM_UNIQUE" UNIQUE ("PAY_POLICY_ID", "CATEGORY")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE;
  ALTER TABLE "BO"."T_PAY_POLICY_FIRM" ADD PRIMARY KEY ("PAY_POLICY_ID", "CATEGORY", "FIRM_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE;
  ALTER TABLE "BO"."T_PAY_POLICY_FIRM" MODIFY ("FIRM_ID" NOT NULL ENABLE);
  ALTER TABLE "BO"."T_PAY_POLICY_FIRM" MODIFY ("PAY_POLICY_ID" NOT NULL ENABLE);
  ALTER TABLE "BO"."T_PAY_POLICY_FIRM" MODIFY ("CATEGORY" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table T_PAY_POLICY_FIRM
--------------------------------------------------------

  ALTER TABLE "BO"."T_PAY_POLICY_FIRM" ADD FOREIGN KEY ("CATEGORY")
	  REFERENCES "BO"."T_PERSON_CATEGORY" ("CATEGORY") ENABLE;
  ALTER TABLE "BO"."T_PAY_POLICY_FIRM" ADD FOREIGN KEY ("PAY_POLICY_ID")
	  REFERENCES "BO"."T_PAY_POLICY" ("ID") ENABLE;


--changeset ngolovkin:BALANCE-24213-1

delete from bo.t_pay_policy_firm where pay_policy_id in (1400, 1410) and firm_id = 7;
delete from bo.t_pay_policy_firm where pay_policy_id in (600) and firm_id = 6;

--changeset ngolovkin:BALANCE-24213-2

alter table bo.t_pay_policy_firm ADD CONSTRAINT t_pay_policy_firm_unique UNIQUE (pay_policy_id, category);

--changeset quark:BALANCE-24080

insert into bo.T_PAY_POLICY_FIRM (CATEGORY, PAY_POLICY_ID, FIRM_ID) values ('ua', 2310, 23);

--changeset nebaruzdin:BALANCE-25259

insert into bo.t_pay_policy_firm
select
    'am_jp' as category,
    2610    as pay_policy_id,
    26      as firm_id
from dual
union all
select
    'am_np' as category,
    2610    as pay_policy_id,
    26      as firm_id
from dual;

--changeset nebaruzdin:BALANCE-24905

insert into bo.t_pay_policy_firm
select
    'kzp' as category,
    2510  as pay_policy_id,
    25    as firm_id
from dual
union all
select
    'kzu' as category,
    2510  as pay_policy_id,
    25    as firm_id
from dual;

--changeset nebaruzdin:BALANCE-25694

insert into bo.t_pay_policy_firm
select
    'byp' as category,
    2710  as pay_policy_id,
    27    as firm_id
from dual
union all
select
    'byu' as category,
    2710  as pay_policy_id,
    27    as firm_id
from dual;

--changeset sfreest:BALANCE-29271-paypolicy-firm
insert into bo.t_pay_policy_firm
select
  'hk_yt' category,
  700 pay_policy_id,
  33 firm_id
from dual
union all
select
  'hk_ur' category,
  700 pay_policy_id,
  33 firm_id
from dual;
