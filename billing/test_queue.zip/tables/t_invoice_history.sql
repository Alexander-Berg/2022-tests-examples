--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for table T_INVOICE_HISTORY
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_INVOICE_HISTORY"
   (    "INVOICE_ID" NUMBER,
    "DT" DATE,
    "END_DT" DATE,
    "PASSPORT_ID" NUMBER,
    "REQUEST_ID" NUMBER,
    "REQUEST_SEQ" NUMBER,
    "PAYSYS_ID" NUMBER,
    "RUR_SUM" NUMBER,
    "STATUS_ID" NUMBER,
    "HIDDEN" NUMBER,
    "EFFECTIVE_SUM" NUMBER,
    "CLIENT_ID" NUMBER,
    "PERSON_ID" NUMBER,
    "CONTACT_ID" NUMBER,
    "EXTERNAL_ID" VARCHAR2(256 BYTE),
    "CONTRACT_ID" NUMBER,
    "TOTAL_SUM" NUMBER,
    "MANAGER_CODE" NUMBER,
    "CURRENCY" VARCHAR2(16 BYTE),
    "NDS" NUMBER,
    "NDS_PCT" NUMBER,
    "CURRENCY_RATE" NUMBER,
    "INTERNAL_RATE" NUMBER,
    "USD_RATE" NUMBER,
    "CREDIT" NUMBER,
    "OVERDRAFT" NUMBER,
    "MARKET_POSTPAY" NUMBER,
    "UPD_CONTRACT_DT" DATE,
    "AGENCY_DISCOUNT_PCT" NUMBER,
    "BANK_ID" NUMBER,
    "EXTERN" NUMBER(1,0),
    "PAYMENT_TERM_ID" NUMBER,
    "UNILATERAL" NUMBER(1,0),
    "PROMO_CODE_ID" NUMBER,
    "ADJUST_QTY" NUMBER,
    "COMMISSION_TYPE" NUMBER,
    "CONSUME_SUM" NUMBER,
    "DISCOUNT_TYPE" NUMBER,
    "EXTERNAL" NUMBER,
    "FAST_PAYMENT" NUMBER,
    "FULL_RENDER" NUMBER,
    "IS_DOCS_DETAILED" NUMBER,
    "IS_DOCS_SEPARATED" NUMBER,
    "LOYAL_CLIENTS" NUMBER,
    "NEED_PROCESSING" NUMBER,
    "PARENT_TEMPLATE_ID" NUMBER,
    "PAYMENT_DATE" DATE,
    "PAYMENT_NUMBER" VARCHAR2(64 BYTE),
    "PAYMENT_TERM_DT" DATE,
    "POSTPAY" NUMBER,
    "RECEIPTS_COUNT" NUMBER,
    "RECEIPT_DT" DATE,
    "RECEIPT_DT_1C" DATE,
    "RECEIPT_SUM" NUMBER,
    "RECEIPT_SUM_1C" NUMBER,
    "TOTAL_ACT_SUM" NUMBER,
    "TRANSFER_ACTED" NUMBER,
    "TURN_ON_DT" DATE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset nebaruzdin:BALANCE-23787

alter table bo.t_invoice_history add iso_currency varchar2(16);

--changeset lightrevan:BALANCE-26114-inv-hist-pm

alter table bo.t_invoice_history add payment_method_id number;

--changeset lightrevan:BALANCE-26114-inv-hist-ur

alter table bo.t_invoice_history add legal_entity number;

--changeset lightrevan:BALANCE-26114-inv-hist-res

alter table bo.t_invoice_history add resident number;

--changeset nebaruzdin:BALANCE-28474

declare
    batch_size constant number := 200000;
    i number;
begin
    loop
        update /*+ parallel(8) */ bo.t_invoice_history
        set iso_currency = decode(upper(currency),
                                  'RUR', 'RUB',
                                  upper(currency))
        where
            iso_currency is null
            and currency is not null
            and rownum <= batch_size;

        i := sql%rowcount;
        system.simple_logger.log_add('BALANCE-28474',
                                     'bo.t_invoice_history ' ||
                                     i || ' ' ||
                                     to_char(sysdate,'DD-MON-RRRR HH24:MI:SS'));
        exit when i <= 0;
        commit;
    end loop;
end;
/
