--liquibase formatted sql


--------------------------------------------------------
--  DDL for table t_payment_register_line
--------------------------------------------------------

create table BO.T_PAYMENT_REGISTER_LINE
(
	ID NUMBER not null
		constraint PK_PAY_REG_LINE
			primary key,
	REGISTER_ID NUMBER not null
		constraint FK_PAY_REG_LINE_REGISTER
			references T_PAYMENT_REGISTER,
	PAYSYS_CODE VARCHAR2(20) not null
		constraint FK_PAY_REG_LINE_PAYSYS_CODE
			references T_INSTANT_PAYSYS (CODE),
	PAYMENT_DT DATE,
	AMOUNT NUMBER,
	COMMISSION NUMBER
)
;

create index IDX_PAY_REG_LINE_REGISTER_ID
	on T_PAYMENT_REGISTER_LINE (REGISTER_ID)
;

create index IDX_PAY_REG_LINE_PAYSYS_CODE
	on T_PAYMENT_REGISTER_LINE (PAYSYS_CODE)
;


--changeset srg91:TRUST-3274
alter table bo.t_payment_register_line
  add (
    raw_register_line_id number,
    payment_id number,
    constraint fk_reg_line_raw_reg_line_id foreign key (raw_register_line_id)
      references bo.t_raw_register_line (id) enable novalidate,
    constraint fk_reg_line_payment_id foreign key (payment_id)
      references bo.t_payment (id) enable novalidate
  )
;

alter table bo.t_payment_register_line
  modify constraint fk_reg_line_raw_reg_line_id enable validate
;

alter table bo.t_payment_register_line
  modify constraint fk_reg_line_payment_id enable validate
;


--changeset srg91:TRUST-3385
alter table bo.t_payment_register_line modify (register_id null);


