--liquibase formatted sql

--------------------------------------------------------------------------------
  -- DDL for table T_OVERDRAFT_PARAMS_HISTORY
--------------------------------------------------------------------------------

--changeset natabers:BALANCE-28633-t_overdraft_params_history-create-sequence
create sequence bo.s_overdraft_params_history_id;

--changeset natabers:BALANCE-28633-t_overdraft_params_history-create-table
create table bo.t_overdraft_params_history (
    id number default bo.s_overdraft_params_history_id.nextval not null,
    dt date,
    end_dt date default sysdate,
    overdraft_params_id number,
    client_id number,
    person_id number,
    service_id number,
    payment_method_cc varchar2(40),
    iso_currency varchar2(10 char),
    client_limit number,
  constraint t_overdraft_params_history_pk primary key (id)
);
