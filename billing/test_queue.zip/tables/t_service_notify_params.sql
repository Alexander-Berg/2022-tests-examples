--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_SERVICE
--------------------------------------------------------------------------------

CREATE TABLE T_SERVICE_NOTIFY_PARAMS
(
  SERVICE_ID NUMBER           NOT NULL
    CONSTRAINT T_SERVICE_NOTIFY_PARAMS_PK
    PRIMARY KEY,
  HIDDEN     NUMBER DEFAULT 0 NOT NULL,
  URL        VARCHAR2(512)    NOT NULL,
  VERSION    NUMBER           NOT NULL,
  PROTOCOL   VARCHAR2(512)    NOT NULL
);

--changeset natabers:BALANCE-27371

update bo.t_service_notify_params
  set url='http://intapi.direct.yandex.ru',
      protocol='json-rest'
  where url='http://intapi.direct.yandex.ru/xmlrpc';

--changeset el-yurchito:BALANCE-30058 endDelimiter:\\
ALTER TABLE  "BO"."T_SERVICE_NOTIFY_PARAMS"
  ADD (
    "IFACE_VERSION" NUMBER,
    "PATH" VARCHAR2(256)
  )
\\

--changeset el-yurchito:BALANCE-30155-1 endDelimiter:\\
UPDATE (
  SELECT
    TS.IFACE_VERSION IFACE_VERSION_SRC,
    TS.PATH PATH_SRC,
    TSNP.IFACE_VERSION IFACE_VERSION_DST,
    TSNP.PATH PATH_DST
  FROM
    "BO"."T_SERVICE_NOTIFY_PARAMS" TSNP
      INNER JOIN
    "META"."T_SERVICE" TS
        ON TSNP.SERVICE_ID = TS.ID
)
SET
  IFACE_VERSION_DST = IFACE_VERSION_SRC,
  PATH_DST = PATH_SRC
\\

--changeset el-yurchito:BALANCE-30155-2 endDelimiter:\\
ALTER TABLE "BO"."T_SERVICE_NOTIFY_PARAMS"
  MODIFY "IFACE_VERSION" NUMBER NOT NULL
\\

