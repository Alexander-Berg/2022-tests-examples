--liquibase formatted sql


--changeset yanametro:BALANCE-28558
create sequence bo.s_partner_page_id;

create table bo.t_partner_page
(
  id                   number        default bo.s_partner_page_id.nextval,
  service_id           number        not null,
  payment_type         varchar2(256),
  page_id              number REFERENCES bo.T_PAGE_DATA(page_id)
);

alter table bo.t_partner_page
add CONSTRAINT partner_page_unique UNIQUE (service_id, payment_type);

INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'subsidy', 10800);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'coupon', 10700);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'compensation', 10801);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 204, 'coupon', 10701);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 609, 'subsidy', 10901);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 601, 'subsidy', 10802);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 619, 'scout', 11003);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 615, 'subsidy', 10902);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 135, null, 10600);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 119, null, 10900);

--changeset yanametro:BALANCE-28558-1
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'branding_subsidy', 10803);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'guarantee_fee', 10804);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'trip_bonus', 10805);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'personnel_bonus', 10806);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'discount_taxi', 10807);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'support_coupon', 10808);
INSERT INTO BO.T_PARTNER_PAGE (ID, SERVICE_ID, PAYMENT_TYPE, PAGE_ID) VALUES (bo.s_partner_page_id.nextval, 137, 'booking_subsidy', 10809);
