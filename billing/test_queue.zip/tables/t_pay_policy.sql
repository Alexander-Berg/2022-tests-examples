--liquibase formatted sql

--------------------------------------------------------
-- DDL for table T_PAY_POLICY
--------------------------------------------------------

 CREATE TABLE "BO"."T_PAY_POLICY"
   (	"ID" NUMBER(*,0) NOT NULL ENABLE,
	"DESCRIPTION" VARCHAR2(256 CHAR),
	 PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset quark:BALANCE-24080

insert into bo.t_pay_policy (ID, DESCRIPTION) values (2310, 'Резиденты Украины Яндекс.Такси');

--changeset nebaruzdin:BALANCE-25259

insert into bo.t_pay_policy (
    id,
    description
)
values (
    2610,
    'Резиденты Армении для Яндекс.Такси'
);

--changeset nebaruzdin:BALANCE-24905

insert into bo.t_pay_policy (
    id,
    description
)
values (
    2510,
    'Резиденты Казахстана для Яндекс.Казахстан'
);

--changeset nebaruzdin:BALANCE-25694

insert into bo.t_pay_policy (id, description) values (2710, 'Резиденты Белоруссии для Яндекс.Реклама');

--changeset sfreest:BALANCE-29271-pay-policy endDelimiter:\\
BEGIN
  Insert into bo.t_pay_policy (ID,DESCRIPTION)
  values (3310, 'Резиденты Гонконга для Yandex E-commerce Limited');
  Insert into bo.t_pay_policy (ID,DESCRIPTION)
  values (3300, 'Нерезиденты Гонконга для Yandex E-commerce Limited');
END;
\\
