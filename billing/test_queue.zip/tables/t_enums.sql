--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_ENUMS
--------------------------------------------------------------------------------

CREATE TABLE T_ENUMS
(
  CODE VARCHAR2(40) NOT NULL,
  ID   VARCHAR2(20) NOT NULL,
  VAL  VARCHAR2(80),
  POS  NUMBER,
  CONSTRAINT T_ENUMS_PK
  PRIMARY KEY (CODE, ID)
);

--changeset natabers:BALANCE-28470-t_enums

insert into bo.t_enums (code, id, val, pos)
  values ('discount_policies', 24, 'Узбекистан', 13);
