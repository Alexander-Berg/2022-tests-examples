--liquibase formatted sql

--changeset lightrevan:BALANCE-27778-ppr
CREATE TABLE bo.t_pay_policy_routing (
  service_id NUMBER REFERENCES bo.t_service (id),
  region_id NUMBER REFERENCES bo.t_country (region_id),
  is_agency NUMBER,
  is_contract NUMBER,
  pay_policy_part_id NUMBER REFERENCES bo.t_pay_policy_part(id),
  CONSTRAINT u_pay_policy_routing UNIQUE (service_id, region_id, is_agency, is_contract, pay_policy_part_id)
);

--changeset lightrevan:BALANCE-27778-ppr-pp-idx
CREATE INDEX bo.idx_pay_policy_routing_part ON bo.t_pay_policy_routing (pay_policy_part_id);

--changeset lightrevan:BALANCE-27778-ppr-reg-idx
CREATE INDEX bo.idx_pay_policy_routing_reg ON bo.t_pay_policy_routing (region_id, service_id);

--changeset sfreest:BALANCE-29271-pay-policy-routing endDelimiter:\\
BEGIN
  INSERT INTO bo.t_pay_policy_routing (pay_policy_part_id) VALUES ((select id from bo.t_pay_policy_part where description='Common pay policy for Yandex E-commerce Limited'));
  INSERT INTO bo.t_pay_policy_routing (pay_policy_part_id, service_id, is_contract) VALUES ((select id from bo.t_pay_policy_part where description='Contract-service pay policy for Yandex E-commerce Limited'), 618, 1);
  INSERT INTO bo.t_pay_policy_routing (pay_policy_part_id, service_id, is_contract) VALUES ((select id from bo.t_pay_policy_part where description='Contract-service pay policy for Yandex E-commerce Limited'), 620, 1);
END;
\\

--changeset nebaruzdin:BALANCE-29364

insert into bo.t_pay_policy_routing
values (35, null, null, null, (select id from bo.t_pay_policy_part where firm_id = 34 and category = 'ph'));
insert into bo.t_pay_policy_routing
values (35, null, null, null, (select id from bo.t_pay_policy_part where firm_id = 34 and category = 'ur'));
insert into bo.t_pay_policy_routing
values (35, null, null, null, (select id from bo.t_pay_policy_part where firm_id = 34 and category = 'yt'));
