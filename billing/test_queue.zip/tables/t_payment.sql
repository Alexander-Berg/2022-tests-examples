--liquibase formatted sql

--changeset skydreamer:TRUST-2598-1

ALTER TABLE bo.t_payment
ADD (TRUST_PAYMENT_ID VARCHAR2(100),
     PURCHASE_TOKEN VARCHAR2(40));


--changeset skydreamer:TRUST-2598-3

CREATE INDEX bo.i_payment_transaction_id ON bo.t_payment (transaction_id) PARALLEL 8 ONLINE;
ALTER INDEX bo.i_payment_transaction_id NOPARALLEL;

CREATE INDEX bo.i_payment_postauth_dt ON bo.t_payment (postauth_dt) PARALLEL 8 ONLINE;
ALTER INDEX bo.i_payment_postauth_dt NOPARALLEL;

CREATE INDEX bo.i_payment_user_account ON bo.t_payment (user_account) PARALLEL 8 ONLINE;
ALTER INDEX bo.i_payment_user_account NOPARALLEL;

CREATE INDEX bo.i_payment_card_holder ON bo.t_payment (card_holder) PARALLEL 8 ONLINE;
ALTER INDEX bo.i_payment_card_holder NOPARALLEL;

CREATE INDEX bo.i_payment_approval_code ON bo.t_payment (approval_code) PARALLEL 8 ONLINE;
ALTER INDEX bo.i_payment_approval_code NOPARALLEL;

CREATE INDEX bo.i_payment_rrn ON bo.t_payment (rrn) PARALLEL 8 ONLINE;
ALTER INDEX bo.i_payment_rrn NOPARALLEL;

CREATE INDEX bo.i_payment_trust_payment_id ON bo.t_payment (trust_payment_id) PARALLEL 8 ONLINE;
ALTER INDEX bo.i_payment_trust_payment_id NOPARALLEL;

CREATE INDEX bo.i_payment_purchase_token ON bo.t_payment (purchase_token) PARALLEL 8 ONLINE;
ALTER INDEX bo.i_payment_purchase_token NOPARALLEL;


--changeset el-yurchito:BALANCE-26014
ALTER TABLE "BO"."T_PAYMENT"
  ADD "DELIVERED_DT" DATE;


--changeset srg91:TRUST-3986
CREATE INDEX bo.i_payment_creator_uid ON bo.t_payment (creator_uid) PARALLEL 8 ONLINE;
ALTER INDEX bo.i_payment_creator_uid NOPARALLEL;


--changeset el-yurchito:BALANCE-26014-1 endDelimiter:\\
ALTER TABLE "BO"."T_PAYMENT"
  ADD ("PAYOUT_READY_DT" DATE)
\\

--changeset akatovda:BALANCE-27462
ALTER TABLE "BO"."T_PAYMENT"
  ADD ("ACS_REDIRECT_URL" VARCHAR2(2048));


--changeset buyvich:TRUST-4899-1
alter table bo.t_payment add (payment_rows clob, export_from_trust date);

--changeset buyvich:TRUST-7018
alter table bo.t_payment modify resp_desc varchar2(4000);
