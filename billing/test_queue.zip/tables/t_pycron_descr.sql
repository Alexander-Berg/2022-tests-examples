--liquibase formatted sql

CREATE TABLE "BO"."T_PYCRON_DESCR"
   (	"NAME" VARCHAR2(128 CHAR) NOT NULL ENABLE,
	"COMMAND" VARCHAR2(1024 CHAR),
	"TIMEOUT" NUMBER(20,2),
	"DESCRIPTION" VARCHAR2(256 CHAR),
	"TERMINATE" NUMBER(*,0),
	"OWNER_LOGIN" VARCHAR2(128 BYTE),
	"COUNT_PER_HOST" NUMBER,
	 PRIMARY KEY ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;


--changeset quark:BALANCE-26104-1
update bo.t_pycron_descr set count_per_host = 3 where name = 'process_thirdparty_transactions';

--changeset akatovda:BALANCE-26562
UPDATE BO.T_PYCRON_DESCR SET COUNT_PER_HOST = 8 WHERE NAME = 'stat_aggregator-processor';

--changeset yanametro:BALANCE-27110 endDelimiter:\\
begin
  bo.create_pycron_task( 'enqueue-partner-acts'
                       , 'yb-python -pysupport cluster_tools/generate_partner_acts.py --with-mnclose'
                       , 'Enqueuer for partner acts'
                       , 'yanametro@yandex-team.ru'
                       , '*/15 * * * *'
   );
end;
\\


--changeset damir-kuch:TRUST-4397 endDelimiter:\\
begin
  bo.create_pycron_task( 'receipt_cleaner_crontask'
                       , 'yb-balance-paysys-tools-runner.sh receipt_cleaner_crontask'
                       , 'Регламентная очистка старых партиций в таблице t_filscal_receipt_data'
                       , 'damir-kuch'
                       , '0 9,17 * * *'
                       , d_timeout => 1200
                       , r_email => 'damir-kuch@yandex-team.ru'
                       );
end;
\\

--changeset lightrevan:BALANCE-27390-pycron endDelimiter:\\
BEGIN
  bo.DELETE_PYCRON_TASK('calculate-direct-discount');
  bo.DELETE_PYCRON_TASK('calculate_direct_budget');
  bo.DELETE_PYCRON_TASK('calculate_direct_budget_enqueue');
END;
\\


--changeset yanametro:BALANCE-27827-1 endDelimiter:\\
begin
  bo.create_pycron_task( 'sync_collateral_types'
                       , 'YANDEX_XML_CONFIG=/etc/yandex/balance-common/main.cfg.xml yb-python -pysupport balance/sync_collateral_types.py'
                       , 'Выгрузка collateral_types в bo.t_contract_collateral_types для Сверок/Отчетов'
                       , 'yanametro'
                       , '*/60 * * * *'
                       , d_timeout => 1200
                       , r_email => 'yanametro@yandex-team.ru'
                       );
end;
\\

--changeset quark:BALANCE-28723-1 endDelimiter:\\
begin
  bo.create_pycron_task( 'receipts_enqueuer'
                       , 'YANDEX_XML_CONFIG=/etc/yandex/balance-common/main.cfg.xml yb-python -pysupport cluster_tools/receipts_enqueuer.py'
                       , 'Простановка платежей в очередь печати чеков'
                       , 'quark'
                       , '*/10 * * * *'
                       , d_timeout => 360
                       , r_email => 'quark@yandex-team.ru'
                       );
end;
\\

--changeset el-yurchito:BALANCE-28492 endDelimiter:\\
begin
  bo.create_pycron_task( 'compose_side_payments_registry'
                       , 'yb-python -pysupport balance/compose_side_payments_registry.py'
                       , 'Формирование реестров платежей по Яндекс.Такси: Шереметьево'
                       , 'el-yurchito'
                       , '20 4 * * *'
                       , d_timeout => 1200
                       , r_email => 'el-yurchito@yandex-team.ru'
                       );
end;
\\


--changeset halty:BALANCE-28492-2 endDelimiter:\\
update bo.t_pycron_descr set command = 'YANDEX_XML_CONFIG=/etc/yandex/balance-scripts/client_batch.cfg.xml yb-python -pysupport balance/compose_side_payments_registry.py' where name='compose_side_payments_registry'
\\

--changeset natabers:BALANCE-28045-pycron-3 endDelimiter:\\
begin
  bo.create_pycron_task( 'generate_auto_overdraft_acts'
                       , 'yb-python -pysupport cluster_tools/generate_acts.py --task monthly_auto_overdraft --month current'
                       , 'Закрытие перекруток автоовердрафтами'
                       , 'natabers'
                       , '*/5 * * * *'
                       , d_timeout => 21600
                       , r_email => 'natabers@yandex-team.ru'
                       );
end;
\\

--changeset natabers:BALANCE-28045-pycron-4 endDelimiter:\\
begin
  bo.create_pycron_task( 'generate_auto_overdraft_acts_check'
                       , 'yb-python -pysupport cluster_tools/generate_acts.py --task monthly_auto_overdraft_done --month current'
                       , 'Закрытие перекруток автоовердрафтами. Проверка завершения.'
                       , 'natabers'
                       , '*/5 * * * *'
                       , d_timeout => 21600
                       , r_email => 'natabers@yandex-team.ru'
                       );
end;
\\

--changeset natabers:BALANCE-29671-t_pycron_descr

update bo.t_pycron_descr set command='YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor.cfg.xml yb-python -pysupport balance/queue_processor.py EMAIL_MESSAGE'
where name='email_message_processor';

--changeset halty:BALANCE-29987-1 endDelimiter:\\
begin
  bo.create_pycron_task( 'update_distribution_cache'
                       , 'YANDEX_XML_CONFIG=/etc/yandex/balance-common/main.cfg.xml yb-python -pysupport cluster_tools/do_action.py DistrCacheUpdate'
                       , 'Перестроение кэша для дистрибуционных договоров со шкалами.'
                       , 'halty'
                       , '*/30 * * * *'
                       , d_timeout => 21600
                       , r_email => 'halty@yandex-team.ru'
                       );
end;
\\

--changeset halty:BALANCE-30159-1 endDelimiter:\\
begin
  bo.create_pycron_task( 'gpa_update_distribution_cache'
                       , 'yb-python -pysupport cluster_tools/generate_partner_acts.py --task update_distribution_cache'
                       , 'Генерация партнёрских актов: update_distribution_cache'
                       , 'halty'
                       , '*/15 * * * *'
                       , d_timeout => 21600
                       , r_email => 'halty@yandex-team.ru'
                       );
end;
\\

--changeset lightrevan:BALANCE-30295
UPDATE bo.t_pycron_schedule
SET
  crontab = '0 */12 * * *'
WHERE
  name = 'fias_updater';
