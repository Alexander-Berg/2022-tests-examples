--liquibase formatted sql

--changeset srg91:TRUST-3022-bo-ecommpay

insert into bo.t_processing (id,dt,cc,name,env_type,passport_type,web_payment,api_payment,direct_card_payment,module)
values (10151,sysdate,'ecommpay','Ecompay','prod',null,1,null,null,'ecommpay');


--changeset srg91:TRUST-3274
alter table bo.t_processing add oebs_register_type varchar2(20);


--changeset skydreamer:BALANCE-26340
INSERT INTO BO.T_PROCESSING (ID, DT, CC, NAME, ENV_TYPE, PASSPORT_TYPE, WEB_PAYMENT, API_PAYMENT, DIRECT_CARD_PAYMENT, MODULE, API_VARIANT_ID)
VALUES (10181, TO_DATE('2017-09-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'sberbank_h2h_test', 'Sberbank of Russia Test', 'test', null, null, 1, 1, 'sberbank_cardapi', 'sberbank_ru');


--changeset buyvich:BALANCE-26524
insert into bo.t_processing (id, dt, cc, name, env_type, passport_type, web_payment, api_payment, direct_card_payment, module, api_variant_id, oebs_register_type)
  select 10152, sysdate, 'ecommpay_h2h', 'ecommpay host2host', 'prod', null, null, 1, 1, 'ecommpay_cardapi', null, null
from dual
where not exists (select 1 from bo.t_processing where id=10152);
