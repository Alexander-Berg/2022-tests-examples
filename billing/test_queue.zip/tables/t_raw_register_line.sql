--liquibase formatted sql


--changeset srg91:TRUST-3274
create table bo.t_raw_register_line (
  id number not null,
  raw_register_id number not null,
  dt date default sysdate not null,
  transaction_dt date,
  balance_payment_id number,
  trust_payment_id varchar2(100),
  transaction_id varchar2(50),
  amount number not null,
  commission number not null,
  currency varchar2(16),
  other_fields varchar2(1024),
  constraint pk_raw_register_line_id primary key (id),
  constraint fk_raw_register_id foreign key (raw_register_id) references bo.t_raw_register (id)
);


create index bo.i_raw_reg_line_reg_id on bo.t_raw_register_line (raw_register_id);


