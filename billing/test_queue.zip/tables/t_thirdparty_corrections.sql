--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_THIRDPARTY_CORRECTIONS
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_THIRDPARTY_CORRECTIONS"
   (	"ID" NUMBER NOT NULL ENABLE,
	"PAYMENT_ID" NUMBER NOT NULL ENABLE,
	"TRUST_ID" VARCHAR2(100 BYTE) NOT NULL ENABLE,
	"TRUST_PAYMENT_ID" VARCHAR2(100 BYTE),
	"CONTRACT_ID" NUMBER NOT NULL ENABLE,
	"PERSON_ID" NUMBER NOT NULL ENABLE,
	"PARTNER_COMMISSION_PCT" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"TRANSACTION_TYPE" VARCHAR2(32 BYTE) NOT NULL ENABLE,
	"PARTNER_ID" NUMBER NOT NULL ENABLE,
	"DT" DATE DEFAULT SYSDATE NOT NULL ENABLE,
	"SERVICE_ID" NUMBER NOT NULL ENABLE,
	"ORDER_ID" NUMBER NOT NULL ENABLE,
	"INVOICE_ID" NUMBER,
	"INVOICE_COMMISSION_SUM" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"ROW_PAYSYS_COMMISSION_SUM" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"COMMISSION_CURRENCY" VARCHAR2(16 BYTE) DEFAULT 'RUR' NOT NULL ENABLE,
	"CURRENCY" VARCHAR2(16 BYTE) DEFAULT 'RUR' NOT NULL ENABLE,
	"YM_SHOP_ID" NUMBER,
	"CAMPAIGN_SERVICE_ORDER_ID" VARCHAR2(100 BYTE),
	"PAYSYS_TYPE_CC" VARCHAR2(32 BYTE) DEFAULT 'yandex' NOT NULL ENABLE,
	"PAYMENT_TYPE" VARCHAR2(32 BYTE) DEFAULT 'correction' NOT NULL ENABLE,
	"PAYSYS_PARTNER_ID" NUMBER,
	"TRANSACTION_DT" DATE DEFAULT SYSDATE NOT NULL ENABLE,
	"REGISTER_ID" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"TOTAL_SUM" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"AMOUNT" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"AMOUNT_FEE" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"YANDEX_REWARD_WO_NDS" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"YANDEX_REWARD" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"PARTNER_CURRENCY" VARCHAR2(16 BYTE) DEFAULT 'RUR' NOT NULL ENABLE,
	"STARTRACK_ID" VARCHAR2(64 BYTE) NOT NULL ENABLE,
	"COMMENTS" VARCHAR2(512 BYTE),
	"CLIENT_ID" NUMBER,
	"CLIENT_AMOUNT" NUMBER,
	"INTERNAL" NUMBER,
	"BATCH_ID" NUMBER,
	"OEBS_ORG_ID" NUMBER,
	 CONSTRAINT "T_THIRDPARTY_CORRECTIONS_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."I_TP_CORR_BATCH_ID" ON "BO"."T_THIRDPARTY_CORRECTIONS" ("BATCH_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_THIRDPARTY_CORRECTIONS_UPD"
before insert or update or delete on bo.t_thirdparty_corrections
referencing new as new old as old
for each row
declare
    p_order_service_id number;
begin
    begin
      select service_id
        into p_order_service_id
      from bo.t_order
      where id=:new.order_id;
      exception when NO_DATA_FOUND then
        raise_application_error(-20204, 'Order with id=' || :new.order_id || ' not found');
    end;
    if p_order_service_id <> :new.service_id then
        raise_application_error(-20203, 'Order id = ' || :new.order_id || ' with service_id = ' || p_order_service_id || ' mismatch requested service_id = ' || :new.service_id);
    end if;
    if :new.transaction_type = 'refund' and :new.trust_payment_id is null then
        raise_application_error(-20202, 'Attempt to create refund correction without trust_payment_id provided');
    end if;
    if :new.id is null then
      SELECT s_request_order_id.nextval INTO :new.id FROM dual;
    end if;
    if :new.payment_id is null then
      SELECT s_payment_id.nextval INTO :new.payment_id FROM dual;
    end if;
    if :new.trust_id is null then
        select lower(rawtohex(dbms_obfuscation_toolkit.md5(
                                input_string =>  host_name || to_char(SYSTIMESTAMP, 'SSSSS.FF') || :new.id)))
          into :new.trust_id from v$instance;
    end if;
    begin
        if :new.partner_id is null or :new.person_id is null then
            select client_id, person_id
              into :new.partner_id, :new.person_id
              from bo.t_contract2 where id = :new.contract_id;
        end if;
        exception when NO_DATA_FOUND then
            raise_application_error(-20201, 'Contract with id=' || :new.id || ' not found');
    end;
end;
/
ALTER TRIGGER "BO"."TR_THIRDPARTY_CORRECTIONS_UPD" ENABLE;

--changeset nebaruzdin:BALANCE-23787

alter table bo.t_thirdparty_corrections add commission_iso_currency varchar2(16);
alter table bo.t_thirdparty_corrections add iso_currency            varchar2(16);
alter table bo.t_thirdparty_corrections add partner_iso_currency    varchar2(16);

--changeset halty:BALANCE-24306

alter table bo.t_thirdparty_corrections add (auto number default 0 not null, invoice_eid varchar2(64));
alter table bo.t_thirdparty_corrections modify(order_id null, register_id null, startrack_id null);

--changeset el-yurchito:BALANCE-26014 endDelimiter:\\
ALTER TABLE "BO"."T_THIRDPARTY_CORRECTIONS"
  ADD ("PAYOUT_READY_DT" DATE)
\\

--changeset quark:BALANCE-26906
alter table bo.t_thirdparty_corrections modify paysys_type_cc varchar(20);

--changeset nebaruzdin:BALANCE-28474-1

update /*+ parallel(8) */ bo.t_thirdparty_corrections
set
    iso_currency            = decode(upper(currency),
                                     'RUR', 'RUB',
                                     upper(currency)),
    partner_iso_currency    = decode(upper(partner_currency),
                                     'RUR', 'RUB',
                                     upper(partner_currency)),
    commission_iso_currency = decode(upper(commission_currency),
                                     'RUR', 'RUB',
                                     upper(commission_currency))
where
    iso_currency is null
    or partner_iso_currency is null
    or commission_iso_currency is null;

--changeset nebaruzdin:BALANCE-28474-2

alter table bo.t_thirdparty_corrections
modify (
    iso_currency default 'RUB' not null enable,
    partner_iso_currency default 'RUB' not null enable,
    commission_iso_currency default 'RUB' not null enable
);

--changeset el-yurchito:BALANCE-29951-1 endDelimiter:\\
ALTER TABLE "BO"."T_THIRDPARTY_CORRECTIONS"
  ADD "PRODUCT_ID" NUMBER
\\

--changeset el-yurchito:BALANCE-29951-2 endDelimiter:\\
CREATE INDEX "BO"."IDX_THIRDPARTY_CORR_PROD_ID"
  ON "BO"."T_THIRDPARTY_CORRECTIONS" ("PRODUCT_ID")
  ONLINE
\\
