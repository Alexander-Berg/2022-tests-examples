--liquibase formatted sql

--------------------------------------------------------
--  DDL for table t_payment_register
--------------------------------------------------------

create table BO.T_PAYMENT_REGISTER
(
	ID NUMBER not null
		constraint PK_PAY_REGISTER
			primary key,
	DT DATE default sysdate not null,
	PAYSYS_CODE VARCHAR2(20) not null
		constraint FK_PAY_REGISTER_PAYSYS_CODE
			references T_INSTANT_PAYSYS (CODE),
	REGISTER_DT DATE not null,
	AMOUNT NUMBER not null,
	COMMISSION NUMBER not null,
	FILE_NAME VARCHAR2(200),
	INCOMING_MAIL_ID NUMBER
		constraint FK_PAY_REGISTER_MAIL_ID
			references T_INCOMING_MAIL,
	SERVICE_ID NUMBER,
	YM_SHOP_ID NUMBER,
	CURRENCY VARCHAR2(16),
	PAYMENT_TYPE VARCHAR2(40),
	OEBS_FIRM_ID NUMBER,
	CONTRACT_ID NUMBER,
	TERMINAL_ID NUMBER
)
;

create index IDX_PAY_REGISTER_PAYSYS_CODE
	on T_PAYMENT_REGISTER (PAYSYS_CODE)
;

create index T_PREGISTER_INCOMING_MLID_IDX
	on T_PAYMENT_REGISTER (INCOMING_MAIL_ID)
;


--changeset srg91:TRUST-3274
alter table bo.t_payment_register
  add (
    raw_register_id number,
    constraint fk_pay_reg_raw_reg_id foreign key (raw_register_id)
      references bo.t_raw_register (id) enable novalidate
  )
;

alter table bo.t_payment_register
  modify constraint fk_pay_reg_raw_reg_id enable validate
;


