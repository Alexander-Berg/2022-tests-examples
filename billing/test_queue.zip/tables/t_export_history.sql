--liquibase formatted sql

create table t_export_history (
  classname   varchar2(64),
  object_id   number,
  start_dt    date,
  end_dt      date,
  rate        number,
  state       number,
  error       varchar2(1024),
  export_dt   date,
  type        varchar2(20),
  next_export date,
  hostname    varchar2(512),
  input       blob,
  output      clob,
  priority    number,
  traceback   clob,
  reason      varchar2(128 char) default null
);

--changeset azurkin:BALANCE-29575-add-history-enqueue_dt
ALTER TABLE BO.t_export_history ADD enqueue_dt date;
