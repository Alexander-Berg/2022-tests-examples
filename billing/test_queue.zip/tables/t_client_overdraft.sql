--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_CLIENT_OVERDRAFT
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_CLIENT_OVERDRAFT"
   (	"CLIENT_ID" NUMBER,
	"SERVICE_ID" NUMBER,
	"OVERDRAFT_LIMIT" NUMBER,
	"FIRM_ID" NUMBER(*,0) DEFAULT 1,
	"START_DT" DATE,
	"UPDATE_DT" DATE,
	"CURRENCY" VARCHAR2(16 BYTE),
	 CONSTRAINT "T_CL_OVERDRAFT_PK" PRIMARY KEY ("CLIENT_ID", "SERVICE_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE,
	 CONSTRAINT "T_CL_OVERDRAFT_FK1" FOREIGN KEY ("CLIENT_ID")
	  REFERENCES "BO"."T_CLIENT" ("ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_CLI_OVER_INS"
   BEFORE INSERT
   ON BO.T_CLIENT_OVERDRAFT
   REFERENCING NEW AS NEW OLD AS OLD
   FOR EACH ROW
BEGIN
   :NEW.START_DT := SYSDATE;

   :NEW.UPDATE_DT := SYSDATE;
END;
/
ALTER TRIGGER "BO"."TR_CLI_OVER_INS" ENABLE;

  CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_CLI_OVER_UPDO"
BEFORE UPDATE
OF OVERDRAFT_LIMIT,
   currency,
   firm_id,
   service_id
ON BO.T_CLIENT_OVERDRAFT REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
 WHEN (
new.overdraft_limit <> old.overdraft_limit or new.firm_id <> old.firm_id  or
new.service_id <> old.service_id or new.currency <> old.currency
      ) BEGIN
   INSERT INTO bo.T_CLIENT_OVERDRAFT_HISTORY
               (client_id, start_dt, end_dt, overdraft_limit, currency, service_id, firm_id
               )
        VALUES ( :OLD.CLIENT_ID, :OLD.UPDATE_DT,  SYSDATE, :OLD.OVERDRAFT_LIMIT, :OLD.currency, :OLD.service_id, :OLD.firm_id
               );
    :NEW.UPDATE_DT := SYSDATE;
END;
/
ALTER TRIGGER "BO"."TR_CLI_OVER_UPDO" ENABLE;

--changeset nebaruzdin:BALANCE-23787

alter table bo.t_client_overdraft add iso_currency varchar2(16);

--changeset nebaruzdin:BALANCE-23787-2 endDelimiter:\\

create or replace editionable trigger bo.tr_cli_over_updo
before update of
    overdraft_limit,
    currency,
    iso_currency,
    firm_id,
    service_id
on bo.t_client_overdraft referencing new as new old as old
for each row
when (
    new.overdraft_limit <> old.overdraft_limit
    or new.firm_id <> old.firm_id
    or new.service_id <> old.service_id
    or new.currency <> old.currency
    or new.iso_currency <> old.iso_currency
)
begin
    insert into bo.t_client_overdraft_history (
        client_id,
        start_dt,
        end_dt,
        overdraft_limit,
        currency,
        iso_currency,
        service_id,
        firm_id
    )
    values (
        :old.client_id,
        :old.update_dt,
        sysdate,
        :old.overdraft_limit,
        :old.currency,
        :old.iso_currency,
        :old.service_id,
        :old.firm_id
    );
    :new.update_dt := sysdate;
end;

\\

--changeset gavrilovp:BALANCE-24313
ALTER TABLE bo.t_client_overdraft
  DROP CONSTRAINT T_CL_OVERDRAFT_PK
;

ALTER TABLE bo.t_client_overdraft
  ADD CONSTRAINT t_client_overdraft_pk PRIMARY KEY (client_id, service_id, firm_id)
;
