--liquibase formatted sql

--changeset buyvich:TRUST-4899-0

create sequence bo.s_trust_payment_data start with 100001;

create table bo.t_trust_payment_data(
  id number(*,0),
  upload_dt date default sysdate,
  raw_data clob,
  primary key (id)
)
partition by range (id)
interval (100000)
  (partition tpd_0 values less than (100000))
  ;
