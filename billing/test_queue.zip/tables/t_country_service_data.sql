--liquibase formatted sql

-------------------------------------------------------
-- DDL for table T_COUNTRY_SERVICE_DATA
--------------------------------------------------------

CREATE TABLE "BO"."T_COUNTRY_SERVICE_DATA"
   (	"REGION_ID" NUMBER(*,0) NOT NULL ENABLE,
	"SERVICE_ID" NUMBER(*,0) NOT NULL ENABLE,
	"UPDATE_DT" DATE DEFAULT sysdate NOT NULL ENABLE,
	"PAY_POLICY_ID" NUMBER(*,0),
	"AGENCY" NUMBER(*,0) DEFAULT -1,
	"DIRECT_PAYMENT" NUMBER DEFAULT 0 NOT NULL ENABLE,
	 PRIMARY KEY ("REGION_ID", "SERVICE_ID", "AGENCY")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE,
	 CONSTRAINT "T_COUNTRY_SERVICE_DATA_POLICY" FOREIGN KEY ("PAY_POLICY_ID")
	  REFERENCES "BO"."T_PAY_POLICY" ("ID") ENABLE,
	 CONSTRAINT "SYS_C001075919" FOREIGN KEY ("REGION_ID")
	  REFERENCES "BO"."T_COUNTRY" ("REGION_ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."T_COUNTRY_SDATA_PPOLICYID" ON "BO"."T_COUNTRY_SERVICE_DATA" ("PAY_POLICY_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

-- changeset quark:BALANCE-23943
delete from bo.t_country_service_data where service_id = 114;

--changeset ngolovkin:BALANCE-24054-4

update (
select * from bo.t_country_service_data where service_id = 99
) set pay_policy_id = 1210;

--changeset nebaruzdin:BALANCE-25259

update bo.t_country_service_data
set
    update_dt = sysdate,
    pay_policy_id = 2610
where
    region_id = 168
    and service_id = 124;

--changeset nebaruzdin:BALANCE-24905

insert into bo.t_country_service_data
select
    159     as region_id,
    7       as service_id,
    sysdate as update_dt,
    2510    as pay_policy_id,
    -1      as agency,
    0       as direct_payment
from dual;

--changeset krissmacer:APIKEYS-460

INSERT INTO BO.T_COUNTRY_SERVICE_DATA
  (REGION_ID, SERVICE_ID, UPDATE_DT, PAY_POLICY_ID, AGENCY, DIRECT_PAYMENT)
VALUES
  (225, 129, SYSDATE, NULL , -1, 0);
  
--changeset nebaruzdin:BALANCE-25694

insert into bo.t_country_service_data
select
    149     as region_id,
    7       as service_id,
    sysdate as update_dt,
    2710    as pay_policy_id,
    -1      as agency,
    0       as direct_payment
from dual
union all
select
    149     as region_id,
    77      as service_id,
    sysdate as update_dt,
    2710    as pay_policy_id,
    -1      as agency,
    0       as direct_payment
from dual;

