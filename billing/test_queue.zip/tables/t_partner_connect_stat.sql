--liquibase formatted sql

--changeset quark:BALANCE-25725-2
create table bo.t_partner_connect_stat
    (
        dt date not NULL,
        product_id number not NULL,
        client_id number not NULL,
        qty number not NULL
     );
