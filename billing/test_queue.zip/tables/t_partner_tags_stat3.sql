--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_PARTNER_TAGS_STAT3
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_PARTNER_TAGS_STAT3"
   (	"DT" DATE,
	"PLACE_ID" NUMBER NOT NULL ENABLE,
	"TAG_ID" NUMBER NOT NULL ENABLE,
	"PAGE_ID" NUMBER NOT NULL ENABLE,
	"SHOWS" NUMBER,
	"CLICKS" NUMBER,
	"BUCKS" NUMBER,
	"COMPLETION_TYPE" NUMBER,
	"VID" NUMBER,
	"TYPE" NUMBER,
	"SOURCE_ID" NUMBER,
	"ORDERS" NUMBER,
	"BUCKS_RS" NUMBER(*,0)
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset bwh1te:BALANCE-24113-1
update bo.t_partner_tags_stat3
  set source_id = 14
  where source_id in (141, 144);

--changeset bwh1te:BALANCE-24113-2
update bo.t_partner_tags_stat3
  set source_id = 13
  where source_id = 134;

--changeset bwh1te:BALANCE-24754 endDelimiter:\\
declare
  i number;
begin
  loop
    update bo.t_partner_tags_stat3
      set source_id = 14
      where source_id in (141, 142, 144, 145) and rownum<100000;
    i := sql%rowcount;
    exit when i <= 0;
    commit;
  end loop;
end;
\\

--changeset vorobyov-as:BALANCE-25353
alter table bo.t_partner_tags_stat3 add clicksa number;

--changeset quark:BALANCE-26118
create index bo.IPARTNER_TAGS_TAG_ID on bo.T_PARTNER_TAGS_STAT3(TAG_ID) local tablespace bo_dts parallel 16 online;
alter index bo.IPARTNER_TAGS_TAG_ID noparallel;

--changeset vorobyov-as:BALANCE-28327
alter table T_PARTNER_TAGS_STAT3
set SUBPARTITION TEMPLATE (
        SUBPARTITION tags3 VALUES (11),
        SUBPARTITION taxi_medium VALUES (12),
        SUBPARTITION rs_market VALUES (13),
        SUBPARTITION rs_market_cpa VALUES (14),
        SUBPARTITION avia_rs VALUES (15),
        SUBPARTITION rtb_distr VALUES (16),
        SUBPARTITION taxi_distr VALUES (17),
        SUBPARTITION video_distr VALUES (18)
    )
;

--changeset vorobyov-as:BALANCE-30427
alter table T_PARTNER_TAGS_STAT3
set SUBPARTITION TEMPLATE (
        SUBPARTITION tags3 VALUES (11),
        SUBPARTITION taxi_medium VALUES (12),
        SUBPARTITION rs_market VALUES (13),
        SUBPARTITION rs_market_cpa VALUES (14),
        SUBPARTITION avia_rs VALUES (15),
        SUBPARTITION rtb_distr VALUES (16),
        SUBPARTITION taxi_distr VALUES (17),
        SUBPARTITION video_distr VALUES (18),
        SUBPARTITION zen_distr VALUES (19)
    )
;