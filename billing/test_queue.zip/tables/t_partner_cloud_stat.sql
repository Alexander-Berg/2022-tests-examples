--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_PARTNER_CLOUD_STAT
--------------------------------------------------------------------------------

--changeset quark:BALANCE-25752-00
CREATE TABLE BO.T_PARTNER_CLOUD_STAT
    (
        DT DATE NOT NULL,
        CONTRACT_ID NUMBER NOT NULL,
        PRODUCT_ID NUMBER NOT NULL,
        AMOUNT NUMBER NOT NULL,
        PROJECT_UUID VARCHAR2(64 BYTE)
    )
    PARTITION BY RANGE (DT) INTERVAL(NUMTODSINTERVAL(1, 'DAY'))
    (
        PARTITION P0 VALUES LESS THAN (TO_DATE('2017-12-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS'))
    );
--changeset akatovda:BALANCE-25752-0
CREATE INDEX I_PARTNER_CLOUD_STAT_DT ON bo.t_partner_cloud_stat(DT) LOCAL PARALLEL 7 ONLINE;
--changeset akatovda:BALANCE-25752-1
CREATE INDEX I_PARTNER_CLOUD_CID ON bo.t_partner_cloud_stat(CONTRACT_ID) LOCAL PARALLEL 7 ONLINE;
--changeset akatovda:BALANCE-25752-2
CREATE INDEX I_PARTNER_CLOUD_PID ON bo.t_partner_cloud_stat(PRODUCT_ID) LOCAL PARALLEL 7 ONLINE;
