--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114-t_nds_map-1
create table bo.t_nds_map (

  ndsreal_id number,
  tax_policy_id number
);

--changeset vorobyov-as:BALANCE-30114-t_nds_map-2
insert into bo.t_nds_map
    select 18, 1   from dual union all
    select 0,  2   from dual union all
    select 20, 3   from dual union all
    select 8,  6   from dual union all
    select 12, 141 from dual ;