--liquibase formatted sql

--changeset vorobyov-as:completions_overhaul

create table bo.t_entity_completion
    (dt date,
     product_id integer,
     entity_id integer,
     src_id integer,
     val_num_1 number,
     val_num_2 number,
     val_num_3 number,
     val_num_4 number
    )
    partition by range (dt) interval (numtodsinterval(1,'DAY'))
        subpartition BY list (src_id)
        subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18)
        )

    (partition "P0" values less than (to_date(' 2008-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')))
    ;

--changeset vorobyov-as:completions_overhaul_int

create table bo.t_entity_completion_int
    (dt date,
     product_id integer,
     entity_id integer,
     src_id integer,
     val_num_1 number,
     val_num_2 number,
     val_num_3 number,
     val_num_4 number
    )
    partition by range (dt) interval (numtodsinterval(1,'DAY'))
        subpartition BY list (src_id)
        subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18)
        )

    (partition "P0" values less than (to_date(' 2008-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')))
    ;

--changeset vorobyov-as:completions_overhaul_swap

create table bo.t_entity_completion_swap
    (dt date,
     product_id integer,
     entity_id integer,
     src_id integer,
     val_num_1 number,
     val_num_2 number,
     val_num_3 number,
     val_num_4 number
    );

--changeset vorobyov-as:completions_overhaul-add_rtb_distr
alter table bo.t_entity_completion
set subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18),
            subpartition rtb_distr values (16)
        );

--changeset vorobyov-as:completions_overhaul-add_rtb_distr-int
alter table bo.t_entity_completion_int
set subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18),
            subpartition rtb_distr values (16)
        );

--changeset vorobyov-as:completions_overhaul-add_taxi_distr
alter table bo.t_entity_completion
set subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18),
            subpartition rtb_distr values (16),
            subpartition taxi_distr values (17)
        );

--changeset vorobyov-as:completions_overhaul-add_taxi_distr_int
alter table bo.t_entity_completion_int
set subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18),
            subpartition rtb_distr values (16),
            subpartition taxi_distr values (17)
        );

--changeset vorobyov-as:completions_overhaul-add_taxi_medium
alter table bo.t_entity_completion
set subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18),
            subpartition rtb_distr values (16),
            subpartition taxi_distr values (17),
            subpartition taxi_medium values (12)
        );

--changeset vorobyov-as:completions_overhaul-add_taxi_medium_int
alter table bo.t_entity_completion_int
set subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18),
            subpartition rtb_distr values (16),
            subpartition taxi_distr values (17),
            subpartition taxi_medium values (12)
        );

--changeset vorobyov-as:BALANCE-30427--1
alter table bo.t_entity_completion
set subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition avia_rs values (15),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18),
            subpartition rtb_distr values (16),
            subpartition taxi_distr values (17),
            subpartition taxi_medium values (12),
            subpartition zen_distr values (19)
        );

--changeset vorobyov-as:BALANCE-30427--2
alter table bo.t_entity_completion_int
set subpartition template (
            subpartition advisor_market values (7),
            subpartition rs_market values (13),
            subpartition rs_market_cpa values (14),
            subpartition avia_rs values (15),
            subpartition activations values (8),
            subpartition serphits values (6),
            subpartition d_installs values (4),
            subpartition addapter_ret_ds values (23),
            subpartition addapter_ret_com values (24),
            subpartition addapter_dev_ds values (25),
            subpartition addapter_dev_com values (26),
            subpartition bk values (1),
            subpartition direct_rs values (31),
            subpartition zen values (32),
            subpartition partner_tag_products values (33),
            subpartition partner_stat_id values (34),
            subpartition dsp_rtb values (41),
            subpartition partner_rtb values (42),
            subpartition api_market values (5),
            subpartition blue_market values (51),
            subpartition video_distr values (18),
            subpartition rtb_distr values (16),
            subpartition taxi_distr values (17),
            subpartition taxi_medium values (12),
            subpartition zen_distr values (19)
        );