--liquibase formatted sql

--changeset lightrevan:BALANCE-27778-ppp
CREATE TABLE bo.t_pay_policy_part (
  id NUMBER PRIMARY KEY,
  firm_id NUMBER NOT NULL REFERENCES bo.t_firm (id),
  legal_entity NUMBER,
  category VARCHAR2(20) REFERENCES bo.t_person_category(category),
  is_atypical NUMBER DEFAULT 0 NOT NULL,
  description VARCHAR2(256)
);

--changeset lightrevan:BALANCE-27778-ppp-seq
CREATE SEQUENCE bo.s_pay_policy_part_id;

--changeset lightrevan:BALANCE-27778-ppp-firm-idx
CREATE INDEX bo.idx_pay_policy_part_firm ON bo.t_pay_policy_part (firm_id);

--changeset sfreest:BALANCE-29271-pay-policy-part endDelimiter:\\
BEGIN
  INSERT INTO bo.t_pay_policy_part (id, firm_id, legal_entity, description)
    VALUES (bo.s_pay_policy_part_id.nextval, 33, null, 'Common pay policy for Yandex E-commerce Limited');
  INSERT INTO bo.t_pay_policy_part (id, firm_id, legal_entity, description)
    VALUES (bo.s_pay_policy_part_id.nextval, 33, null, 'Contract-service pay policy for Yandex E-commerce Limited');
END;
\\

--changeset nebaruzdin:BALANCE-29364

insert into bo.t_pay_policy_part values (bo.s_pay_policy_part_id.nextval, 34, 0, 'ph', 1, 'bank|RUB|0');
insert into bo.t_pay_policy_part values (bo.s_pay_policy_part_id.nextval, 34, 1, 'ur', 1, 'bank|RUB|0');
insert into bo.t_pay_policy_part values (bo.s_pay_policy_part_id.nextval, 34, 1, 'yt', 1, 'bank|RUB|0');
