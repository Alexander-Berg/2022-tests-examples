--liquibase formatted sql

--changeset yanametro:BALANCE-26559-2
CREATE TABLE bo.t_contract_prefix
(
    PREFIX VARCHAR(8),
    SERVICE_ID INTEGER,
    CONTRACT_TYPE VARCHAR(16),
    FIRM_ID INTEGER,
    IS_OFFER INTEGER
);

--changeset el-yurchito:BALANCE-28059 endDelimiter:\\
INSERT INTO "BO"."T_CONTRACT_PREFIX"
SELECT
    'YAM'       PREFIX,
    615         SERVICE_ID,
    'SPENDABLE' CONTRACT_TYPE,
    7           FIRM_ID,
    1           IS_OFFER
FROM dual
\\

--changeset quark:BALANCE-28160
INSERT INTO "BO"."T_CONTRACT_PREFIX"
SELECT
    'OF'       PREFIX,
    137         SERVICE_ID,
    'SPENDABLE' CONTRACT_TYPE,
    115           FIRM_ID,
    1           IS_OFFER
FROM dual;

--changeset sfreest:BALANCE-29271-contract-prefix
INSERT INTO "BO"."T_CONTRACT_PREFIX"
SELECT
    'HKRAS'       PREFIX,
    615         SERVICE_ID,
    'SPENDABLE' CONTRACT_TYPE,
    33           FIRM_ID,
    0           IS_OFFER
FROM dual;
INSERT INTO "BO"."T_CONTRACT_PREFIX"
SELECT
    'HKOF'       PREFIX,
    615         SERVICE_ID,
    'SPENDABLE' CONTRACT_TYPE,
    33           FIRM_ID,
    1           IS_OFFER
FROM dual;
