--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for table T_FIRM
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_FIRM"
   (    "ID" NUMBER NOT NULL ENABLE,
    "TITLE" VARCHAR2(80 BYTE),
    "EXPORT_TYPE" VARCHAR2(20 BYTE),
    "OEBS_ORG_ID" NUMBER,
    "OEBS_USER_ID" NUMBER,
    "DEFAULT_CURRENCY" VARCHAR2(16 BYTE),
    "CONTRACT_ID" NUMBER,
    "UNILATERAL" NUMBER(1,0),
    "INVOICE_PAYSYS_ID" NUMBER,
    "POSTPAY" NUMBER(1,0),
    "NDS_PCT" NUMBER,
    "EMAIL" VARCHAR2(512 CHAR) NOT NULL ENABLE,
    "PHONE" VARCHAR2(512 CHAR) NOT NULL ENABLE,
    "PAYMENT_INVOICE_EMAIL" VARCHAR2(512 CHAR) NOT NULL ENABLE,
    "ALTER_PERMITION_CODE" VARCHAR2(64 BYTE) NOT NULL ENABLE,
    "PA_PREFIX" VARCHAR2(20 BYTE),
    "REGION_ID" NUMBER,
    "CONFIG" VARCHAR2(4000 CHAR),
     CONSTRAINT "SYS_C_SNAP$_6543T_FIRM_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "BO_APEX_DTS"  ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "BO_APEX_DTS" ;

--changeset quark:BALANCE-25015-1
Insert into meta.t_firm (ID,TITLE,DEFAULT_CURRENCY,CONTRACT_ID,UNILATERAL,INVOICE_PAYSYS_ID,POSTPAY,EMAIL,PHONE,PAYMENT_INVOICE_EMAIL,ALTER_PERMITION_CODE,PA_PREFIX,REGION_ID,CONFIG)
select
    112 ID,
    'ООО «Облачные Технологии Яндекс»' TITLE,
    'RUR' DEFAULT_CURRENCY,
    null CONTRACT_ID,
    1 UNILATERAL,
    null INVOICE_PAYSYS_ID,
    0 POSTPAY,
    'info@balance.yandex.ru' EMAIL,
    '+7 495 739-70-00' PHONE,
    'payment-invoice@yandex-team.ru' PAYMENT_INVOICE_EMAIL,
    'AlterFirmRUCloud' ALTER_PERMITION_CODE,
    null PA_PREFIX,
    225 REGION_ID,
    '{"mnclose_close_tasks": ["monthly_close_firms"]}' CONFIG
from dual;

--changeset quark:BALANCE-25302

Insert into meta.t_firm (ID,TITLE,DEFAULT_CURRENCY,CONTRACT_ID,UNILATERAL,INVOICE_PAYSYS_ID,POSTPAY,EMAIL,PHONE,PAYMENT_INVOICE_EMAIL,ALTER_PERMITION_CODE,PA_PREFIX,REGION_ID,CONFIG)
select
    113 ID,
    'ООО «Яндекс.Автобусы»' TITLE,
    'RUR' DEFAULT_CURRENCY,
    null CONTRACT_ID,
    1 UNILATERAL,
    null INVOICE_PAYSYS_ID,
    0 POSTPAY,
    'info@balance.yandex.ru' EMAIL,
    '+7 495 739-70-00' PHONE,
    'payment-invoice@yandex-team.ru' PAYMENT_INVOICE_EMAIL,
    'AlterFirmRUBuses' ALTER_PERMITION_CODE,
    null PA_PREFIX,
    225 REGION_ID,
    '{"mnclose_close_tasks": ["monthly_close_firms"]}' CONFIG
from dual;

--changeset nebaruzdin:BALANCE-25259

insert into meta.t_firm
select
    26                                  as id,
    'ООО «Яндекс.Такси Армения»'        as title,
    null                                as export_type,
    null                                as oebs_org_id,
    null                                as oebs_user_id,
    'AMD'                               as default_currency,
    null                                as contract_id,
    0                                   as unilateral,
    null                                as invoice_paysys_id,
    0                                   as postpay,
    null                                as nds_pct,
    'info@balance.yandex.ru'            as email,
    '(495) 739-70-00'                   as phone,
    'payment-invoice@yandex-team.ru'    as payment_invoice_email,
    'AlterFirmAMTaxi'                   as alter_permission_code,
    'LST'                               as pa_prefix,
    168                                 as region_id,
    null                                as config
from dual;

--changeset nebaruzdin:BALANCE-24905

insert into meta.t_firm
select
    25                                  as id,
    'ТОО «Яндекс.Казахстан»'            as title,
    'OEBS'                              as export_type,
    97308                               as oebs_org_id,
    null                                as oebs_user_id,
    'KZT'                               as default_currency,
    null                                as contract_id,
    0                                   as unilateral,
    null                                as invoice_paysys_id,
    0                                   as postpay,
    null                                as nds_pct,
    'info@balance.yandex.ru'            as email,
    '(495) 739-70-00'                   as phone,
    'payment-invoice@yandex-team.ru'    as payment_invoice_email,
    'AlterFirmRU'                       as alter_permission_code,
    null                                as pa_prefix,
    159                                 as region_id,
    null                                as config
from dual;

--changeset nebaruzdin:BALANCE-25259-1

update meta.t_firm
set title = 'Yandex.Taxi AM LLP'
where id = 26;

--changeset nebaruzdin:BALANCE-24557

alter table meta.t_firm add currency_rate_src varchar2(16);

update meta.t_firm
set currency_rate_src =
    case region_id
        when 84  then 'ecb'
        when 118 then 'ecb'
        when 126 then 'ecb'
        when 149 then 'nbrb'
        when 159 then 'nbkz'
        when 168 then 'cba'
        when 187 then 'nbu'
        when 225 then 'cbr'
        when 983 then 'tcmb'
        else null
    end;

--changeset ngolovkin:BALANCE-25211-1

 alter table meta.t_firm add (inn varchar2(32));

--changeset ngolovkin:BALANCE-25211-2

 update meta.t_firm
 set inn = decode(id, 1,'7736207543',12,'7704340327',13,'7704340310',111,'7704357909',112,'7704355605',113,'7704402904');

--changeset quark:BALANCE-25724

alter table meta.t_firm add tax_policy_id number;

update meta.t_firm set
    tax_policy_id = (select id from bo.t_tax_policy where name LIKE 'Резидент Казахстан, НДС не облагается')
    where id = 24;

--changeset nebaruzdin:BALANCE-25694

insert into meta.t_firm
select
    27                                  as id,
    'ООО «Яндекс.Реклама»'              as title,
    null                                as export_type,
    null                                as oebs_org_id,
    null                                as oebs_user_id,
    'BYN'                               as default_currency,
    null                                as contract_id,
    0                                   as unilateral,
    null                                as invoice_paysys_id,
    0                                   as postpay,
    null                                as nds_pct,
    'info@balance.yandex.ru'            as email,
    '(495) 739-70-00'                   as phone,
    'payment-invoice@yandex-team.ru'    as payment_invoice_email,
    'AlterFirmRU'                       as alter_permission_code,
    'BL'                                as pa_prefix,
    149                                 as region_id,
    null                                as config,
    'nbrb'                              as currency_rate_src,
    null                                as inn,
    null                                as tax_policy_id
from dual;

--changeset ashvedunov:BALANCE-25984-0

insert into meta.t_firm (
  id, title, postpay,
  email, phone, payment_invoice_email,
  alter_permition_code, region_id, currency_rate_src
) values (
  29, 'Yandex Europe N.V.', 1,
  'info@balance.yandex.ru', '+31(0)202066970', 'payment-invoice@yandex-team.ru',
  'AlterFirmSW', 118, 'ecb'
);


--changeset el-yurchito:BALANCE-25931
INSERT INTO meta.t_firm (ID, TITLE, DEFAULT_CURRENCY, CONTRACT_ID, UNILATERAL, INVOICE_PAYSYS_ID, POSTPAY, EMAIL, PHONE, PAYMENT_INVOICE_EMAIL, ALTER_PERMITION_CODE, PA_PREFIX, REGION_ID, CONFIG, CURRENCY_RATE_SRC, INN)
SELECT
  28                                                  ID,
  'ООО «Дзен.Платформа»'                              TITLE,
  'RUR'                                               DEFAULT_CURRENCY,
  NULL                                                CONTRACT_ID,
  1                                                   UNILATERAL,
  NULL                                                INVOICE_PAYSYS_ID,
  0                                                   POSTPAY,
  'info@balance.yandex.ru'                            EMAIL,
  '+7 (495) 739-70-00'                                PHONE,
  'payment-invoice@yandex-team.ru'                    PAYMENT_INVOICE_EMAIL,
  'AlterFirmRU'                                       ALTER_PERMITION_CODE,
  NULL                                                PA_PREFIX,
  225                                                 REGION_ID,
  '{"mnclose_close_tasks": ["monthly_close_firms"]}'  CONFIG,
  'cbr'                                               CURRENCY_RATE_SRC,
  '7704431373'                                        INN
FROM dual;


--changeset el-yurchito:BALANCE-25614
ALTER TABLE meta.t_firm
ADD (
  KPP VARCHAR2(9),
  LEGALADDRESS VARCHAR2(512)
);

UPDATE
  meta.t_firm
SET
  kpp = decode(
      id, 1,    '997750001',
          9,    '770401001',
          12,   '997750001',
          13,   '997750001',
          111,  '997750001',
          112,  '770401001',
          113,  '770401001'
  );

UPDATE
  meta.t_firm
SET
  LEGALADDRESS = decode(
      id, 1,    '19021, Россия, г. Москва, ул. Льва Толстого, д. 16',
          9,    '119021, Россия, г. Москва, ул. Тимура Фрунзе, д. 11, строение 44',
          12,   '119021, Россия, г. Москва, ул. Льва Толстого, д. 16',
          13,   '119021, Россия, г. Москва, ул. Льва Толстого, д. 16',
          111,  '119021, Россия, г. Москва, ул. Льва Толстого, д. 16',
          112,  '119034, Россия, г. Москва, ул. Льва Толстого, д. 16',
          113,  '119034, Россия, г. Москва, ул. Тимура Фрунзе, дом 11, корпус 2'
  );

--changeset akatovda:BALANCE-26621
UPDATE BO.T_FIRM SET PA_PREFIX = 'ЛС' where ID = 112;
