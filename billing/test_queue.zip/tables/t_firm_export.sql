--liquibase formatted sql

  CREATE TABLE "BO"."T_FIRM_EXPORT"
   (	"FIRM_ID" NUMBER NOT NULL ENABLE,
	"EXPORT_TYPE" VARCHAR2(20 BYTE),
	"OEBS_ORG_ID" NUMBER,
	"OEBS_USER_ID" NUMBER,
	"OEBS_PERM_ID" NUMBER(*,0),
	"OEBS_APP_ID" NUMBER(*,0),
	"OEBS_SKIP_ORG_SUFFIX" NUMBER DEFAULT 1,
	"OEBS_COUNTRY_CODE" VARCHAR2(16 BYTE),
	 CONSTRAINT "T_FIRM_EXPORT_PK" PRIMARY KEY ("FIRM_ID", "EXPORT_TYPE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;


--changeset quark:BALANCE-24080

INSERT INTO BO.T_FIRM_EXPORT (FIRM_ID, EXPORT_TYPE, OEBS_ORG_ID, OEBS_USER_ID, OEBS_PERM_ID, OEBS_APP_ID, OEBS_SKIP_ORG_SUFFIX, OEBS_COUNTRY_CODE)
VALUES (23, 'OEBS', 89471, 0, 59712, 222, 1, 'UA');

--changeset quark:BALANCE-25015
insert into bo.t_firm_export
select
    112 FIRM_ID,
    'OEBS' EXPORT_TYPE,
    80954 OEBS_ORG_ID,
    0 OEBS_USER_ID,
    58731 OEBS_PERM_ID,
    222 OEBS_APP_ID,
    1 OEBS_SKIP_ORG_SUFFIX,
    'RU' OEBS_COUNTRY_CODE
from dual;

--changeset quark:BALANCE-25302
insert into bo.t_firm_export
select
    113 FIRM_ID,
    'OEBS' EXPORT_TYPE,
    99766 OEBS_ORG_ID,
    0 OEBS_USER_ID,
    60465 OEBS_PERM_ID,
    222 OEBS_APP_ID,
    1 OEBS_SKIP_ORG_SUFFIX,
    'RU' OEBS_COUNTRY_CODE
from dual;

--changeset nebaruzdin:BALANCE-24905

insert into bo.t_firm_export
select
    25      as firm_id,
    'OEBS'  as export_type,
    97308   as oebs_org_id,
    null    as oebs_user_id,
    60220   as oebs_perm_id,
    222     as oebs_app_id,
    1       as oebs_skip_org_suffix,
    'KZ'    as oebs_country_code
from dual;

--changeset nebaruzdin:BALANCE-25445

insert into bo.t_firm_export
select
    26      as firm_id,
    'OEBS'  as export_type,
    100110  as oebs_org_id,
    0       as oebs_user_id,
    60550   as oebs_perm_id,
    222     as oebs_app_id,
    1       as oebs_skip_org_suffix,
    'AM'    as oebs_country_code
from dual;

--changeset nebaruzdin:BALANCE-24905-1

update bo.t_firm_export
set oebs_user_id = 0
where firm_id = 25

--changeset ashvedunov:BALANCE-25984-1
insert into bo.t_firm_export (
  firm_id, export_type,
  oebs_org_id, oebs_user_id, oebs_perm_id, oebs_app_id,
  OEBS_SKIP_ORG_SUFFIX, OEBS_COUNTRY_CODE
) values (
  29, 'OEBS',
  202, 0, 52125, 222,
  1, 'NL'
);

--changeset nebaruzdin:BALANCE-25694

insert into bo.t_firm_export
select
    27      as firm_id,
    'OEBS'  as export_type,
    107441  as oebs_org_id,
    0       as oebs_user_id,
    60853   as oebs_perm_id,
    222     as oebs_app_id,
    1       as oebs_skip_org_suffix,
    'BY'    as oebs_country_code
from dual;

--changeset el-yurchito:BALANCE-25931
INSERT INTO bo.t_firm_export
SELECT
  28        FIRM_ID,
  'OEBS'    EXPORT_TYPE,
  108190    OEBS_ORG_ID,
  0         OEBS_USER_ID,
  60956     OEBS_PERM_ID,
  222       OEBS_APP_ID,
  1         OEBS_SKIP_ORG_SUFFIX,
  'RU'      OEBS_COUNTRY_CODE
FROM dual;

--changeset el-yurchito:BALANCE-25931-1
call dbms_mview.refresh('bo.t_paysys');

--changeset el-yurchito:BALANCE-26904-1 endDelimiter:\\
INSERT INTO bo.t_firm_export
SELECT
  114       FIRM_ID,
  'OEBS'    EXPORT_TYPE,
  119318    OEBS_ORG_ID,
  0         OEBS_USER_ID,
  61922     OEBS_PERM_ID,
  222       OEBS_APP_ID,
  1         OEBS_SKIP_ORG_SUFFIX,
  'RU'      OEBS_COUNTRY_CODE
FROM dual
\\

--changeset el-yurchito:BALANCE-26904-2 endDelimiter:\\
call dbms_mview.refresh('bo.t_paysys')
\\

--changeset el-yurchito:BALANCE-26964-1 endDelimiter:\\
INSERT INTO bo.t_firm_export
SELECT
  30        FIRM_ID,
  'OEBS'    EXPORT_TYPE,
  118724    OEBS_ORG_ID,
  0         OEBS_USER_ID,
  61913     OEBS_PERM_ID,
  222       OEBS_APP_ID,
  1         OEBS_SKIP_ORG_SUFFIX,
  'RU'      OEBS_COUNTRY_CODE
FROM dual
\\

--changeset el-yurchito:BALANCE-26964-2 endDelimiter:\\
call dbms_mview.refresh('bo.t_paysys')
\\

--changeset yanametro:BALANCE-27683
INSERT INTO bo.t_firm_export
SELECT
  120        FIRM_ID,
  'OEBS'    EXPORT_TYPE,
  201       OEBS_ORG_ID,
  0         OEBS_USER_ID,
  52121     OEBS_PERM_ID,
  222       OEBS_APP_ID,
  1         OEBS_SKIP_ORG_SUFFIX,
  'RU'      OEBS_COUNTRY_CODE
FROM dual;

--changeset el-yurchito:BALANCE-28023-1 endDelimiter:\\
INSERT INTO bo.t_firm_export
SELECT
  31        FIRM_ID,
  'OEBS'    EXPORT_TYPE,
  114867    OEBS_ORG_ID,
  0         OEBS_USER_ID,
  61627     OEBS_PERM_ID,
  222       OEBS_APP_ID,
  1         OEBS_SKIP_ORG_SUFFIX,
  'KZ'      OEBS_COUNTRY_CODE
FROM dual
\\

--changeset el-yurchito:BALANCE-28023-2 endDelimiter:\\
call dbms_mview.refresh('bo.t_paysys')
\\
--changeset quark:BALANCE-28047

INSERT INTO bo.t_firm_export
SELECT
  115       FIRM_ID,
  'OEBS'    EXPORT_TYPE,
  115098    OEBS_ORG_ID,
  0         OEBS_USER_ID,
  61639     OEBS_PERM_ID,
  222       OEBS_APP_ID,
  1         OEBS_SKIP_ORG_SUFFIX,
  'NL'      OEBS_COUNTRY_CODE
FROM dual;

--changeset quark:BALANCE-28047-2 endDelimiter:\\
call dbms_mview.refresh('bo.t_paysys')
\\

--changeset quark:BALANCE-29296
insert into bo.t_firm_export
select
    (select id from meta.t_firm where title like 'ООО «Яндекс.Заправки»') FIRM_ID,
    'OEBS' EXPORT_TYPE,
    150405 OEBS_ORG_ID,
    0 OEBS_USER_ID,
    63383 OEBS_PERM_ID,
    222 OEBS_APP_ID,
    1 OEBS_SKIP_ORG_SUFFIX,
    'RU' OEBS_COUNTRY_CODE
from dual;

--changeset el-yurchito:BALANCE-28943-1 endDelimiter:\\
INSERT INTO bo.t_firm_export
SELECT
  32        FIRM_ID,
  'OEBS'    EXPORT_TYPE,
  127556    OEBS_ORG_ID,
  0         OEBS_USER_ID,
  62158     OEBS_PERM_ID,
  222       OEBS_APP_ID,
  1         OEBS_SKIP_ORG_SUFFIX,
  'RU'      OEBS_COUNTRY_CODE
FROM dual
\\

--changeset el-yurchito:BALANCE-28943-2 endDelimiter:\\
begin
  dbms_mview.refresh('bo.t_paysys');
end;
\\

--changeset nebaruzdin:BALANCE-29364

insert into bo.t_firm_export (
    firm_id,
    export_type,
    oebs_org_id,
    oebs_user_id,
    oebs_perm_id,
    oebs_app_id,
    oebs_skip_org_suffix,
    oebs_country_code
)
select
    34     as firm_id,
    'OEBS' as export_type,
    55562  as oebs_org_id,
    0      as oebs_user_id,
    55850  as oebs_perm_id,
    222    as oebs_app_id,
    1      as oebs_skip_org_suffix,
    'RU'   as oebs_country_code
from dual;
