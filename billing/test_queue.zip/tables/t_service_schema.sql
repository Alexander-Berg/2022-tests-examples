--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_SERVICE_SCHEMA
--------------------------------------------------------------------------------

--changeset vaclav:TRUST-4167-7

CREATE SYNONYM BO.T_SERVICE_SCHEMA FOR META.T_SERVICE_SCHEMA;


