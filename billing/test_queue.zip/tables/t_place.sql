--liquibase formatted sql

CREATE TABLE T_PLACE
(
    ID NUMBER(*) NOT NULL,
    CLIENT_ID NUMBER(*) NOT NULL,
    URL VARCHAR2(512),
    DT DATE NOT NULL,
    PASSPORT_ID NUMBER(*),
    MCB_FLAG NUMBER(*) DEFAULT 0 NOT NULL,
    TYPE NUMBER(*) DEFAULT 0  NOT NULL,
    INTERNAL_TYPE NUMBER(*) DEFAULT 0  NOT NULL,
    MKB_CATEGORY_ID NUMBER(*),
    SEARCH_ID NUMBER(*),
    CLID_TYPE NUMBER(*),
    PAYMENT_TYPE NUMBER(*),
    TAG_ID NUMBER(*)
);
CREATE UNIQUE INDEX PK_T_PLACE ON T_PLACE (ID);
CREATE UNIQUE INDEX C_PLACE_SEARCH_ID ON T_PLACE (SEARCH_ID);
CREATE INDEX C_T_PLACE_CLIENT_ID_IDX ON T_PLACE (CLIENT_ID);
CREATE INDEX C_T_PLACE_CLID_TYPE_IDX ON T_PLACE (CLID_TYPE);
CREATE INDEX IDX_PLACE_PAY_TYPE ON T_PLACE (PAYMENT_TYPE);
CREATE INDEX IDX_T_PLACE_TAG_ID ON T_PLACE (TAG_ID);

--changeset yanametro:BALANCE-25910

create SEQUENCE bo.S_PLACE_ID
START WITH 67108864
INCREMENT BY 1
MAXVALUE 134217728;

--changeset lightrevan:BALANCE-26737-trigger endDelimiter:\\

CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_PLACE_UPDB"
BEFORE UPDATE OF DT
   ,CLIENT_ID
   ,PASSPORT_ID
   ,URL
   ,MCB_FLAG
   ,TYPE
   ,INTERNAL_TYPE
   ,MKB_CATEGORY_ID
   ,SEARCH_ID
   ,CLID_TYPE
   ,PAYMENT_TYPE
   ,TAG_ID
ON bo.T_PLACE
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW

DECLARE
   p_now DATE;
BEGIN
   p_now := SYSDATE;
   INSERT INTO bo.t_place_history (
      place_id, start_dt, end_dt, passport_id, client_id, url, mcb_flag, type,
    internal_type, mkb_category_id, search_id, clid_type, payment_type, tag_id
    )  VALUES (
      :OLD.id, :OLD.dt, p_now, :OLD.passport_id, :OLD.client_id,
      :OLD.url, :OLD.mcb_flag, :OLD.type, :OLD.internal_type,
    :OLD.mkb_category_id, :OLD.search_id, :OLD.clid_type, :OLD.payment_type, :OLD.tag_id
   );
   :NEW.dt := p_now;
END;

\\

--changeset yanametro:BALANCE-27233
alter table bo.T_PARTNER_TAXI_STAT_PART
	drop constraint SYS_C001337728;

--changeset yanametro:BALANCE-27233-3

create unique INDEX c_place_search_id ON bo.t_place
  (CASE WHEN search_id is not null THEN search_id + 1000000000000 * type
   else null
   END);

