--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for table T_PERSON_CATEGORY
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_PERSON_CATEGORY"
   (    "CATEGORY" VARCHAR2(20 BYTE) NOT NULL ENABLE,
    "FIRM_ID" NUMBER NOT NULL ENABLE,
    "UR" NUMBER NOT NULL ENABLE,
    "ADMIN_ONLY" NUMBER(*,0),
    "AUTO_ONLY" NUMBER(*,0),
    "PERSON_FIRM_ID" NUMBER NOT NULL ENABLE,
    "PARTNERABLE" NUMBER DEFAULT 0 NOT NULL ENABLE,
    "NAME" VARCHAR2(128 BYTE),
    "CAPTION" VARCHAR2(128 BYTE),
    "PAY_POLICY_ID" NUMBER(*,0),
    "RESIDENT" NUMBER(*,0),
    "REGION_ID" NUMBER,
    "OEBS_COUNTRY_CODE" VARCHAR2(2 BYTE) NOT NULL ENABLE,
     CONSTRAINT "T_PERSON_CATEGORY_PK" PRIMARY KEY ("CATEGORY")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE,
     CONSTRAINT "T_PERSON_CATEGORY_PAY_POLICY" FOREIGN KEY ("PAY_POLICY_ID")
      REFERENCES "BO"."T_PAY_POLICY" ("ID") ENABLE,
     CONSTRAINT "T_PERSON_CATEGORY_R09REG" FOREIGN KEY ("REGION_ID")
      REFERENCES "META"."T_COUNTRY" ("REGION_ID") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."T_PERSON_CATEGORY_PPID" ON "BO"."T_PERSON_CATEGORY" ("PAY_POLICY_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."T_PERSON_CATEGORY_REGION_IDX" ON "BO"."T_PERSON_CATEGORY" ("REGION_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset nebaruzdin:BALANCE-25259

insert into bo.t_person_category
select
    'am_jp'              as category,
    26                   as firm_id,
    1                    as ur,
    null                 as admin_only,
    0                    as auto_only,
    26                   as person_firm_id,
    0                    as partnerable,
    'ID_Legal_entity_AM' as name,
    'ID_Legal_entity'    as caption,
    2610                 as pay_policy_id,
    1                    as resident,
    168                  as region_id,
    'AM'                 as oebs_country_code
from dual
union all
select
    'am_np'              as category,
    26                   as firm_id,
    0                    as ur,
    null                 as admin_only,
    0                    as auto_only,
    26                   as person_firm_id,
    0                    as partnerable,
    'ID_Individual_AM'   as name,
    'ID_Individual_ex'   as caption,
    2610                 as pay_policy_id,
    1                    as resident,
    168                  as region_id,
    'AM'                 as oebs_country_code
from dual;


--changeset el-yurchito:BALANCE-27811 endDelimiter:\\
UPDATE "BO"."T_PERSON_CATEGORY"
SET
  PARTNERABLE = 1
WHERE
  CATEGORY IN ('kzu', 'yt_kzu')
\\

--changeset akatovda:BALANCE-26610
UPDATE BO.T_PERSON_CATEGORY SET admin_only = 0 WHERE admin_only IS NULL;
UPDATE BO.T_PERSON_CATEGORY SET auto_only = 0 WHERE auto_only IS NULL;

--changeset lightrevan:BALANCE-27778-pc-firm
ALTER TABLE BO.T_PERSON_CATEGORY MODIFY FIRM_ID NUMBER NULL;

--changeset lightrevan:BALANCE-27778-pc-person-firm
ALTER TABLE BO.T_PERSON_CATEGORY MODIFY PERSON_FIRM_ID NUMBER NULL;

--changeset lightrevan:BALANCE-27778-pc-regional
ALTER TABLE BO.T_PERSON_CATEGORY ADD IS_DEFAULT NUMBER DEFAULT 1 NOT NULL;

--changeset lightrevan:BALANCE-27778-pc-regional-values
UPDATE BO.T_PERSON_CATEGORY
  SET IS_DEFAULT=0
  WHERE CATEGORY IN (
    'by_ytph', 'yt_kzp', 'yt_kzu',
    'endbuyer_ph', 'endbuyer_ur', 'endbuyer_yt',
    'ph_autoru', 'ur_autoru'
  );

--changeset quark:BALANCE-28901
update bo.t_person_category set partnerable = 1 where category = 'byu';

--changeset sfreest:BALANCE-29271-person-category endDelimiter:\\
BEGIN
  insert into bo.t_person_category(CATEGORY, FIRM_ID, UR, ADMIN_ONLY, AUTO_ONLY, PERSON_FIRM_ID, PARTNERABLE, NAME,                 CAPTION,           PAY_POLICY_ID, RESIDENT, REGION_ID, OEBS_COUNTRY_CODE, IS_DEFAULT)
  values                          ('hk_ur',  33,      1,  0,          0,         33,             1,           'ID_Legal_entity_HK', 'ID_Legal_entity', 3310,          1,        10584,     'HK',              1);
  insert into bo.t_person_category(CATEGORY, FIRM_ID, UR, ADMIN_ONLY, AUTO_ONLY, PERSON_FIRM_ID, PARTNERABLE, NAME,                 CAPTION,           PAY_POLICY_ID, RESIDENT, REGION_ID, OEBS_COUNTRY_CODE, IS_DEFAULT)
  values                          ('hk_yt',  33,      1,  0,          0,         33,             1,           'ID_Nonresident_HK',  'ID_Legal_entity', 3300,          0,        10584,     'HK',              1);
END;
\\
