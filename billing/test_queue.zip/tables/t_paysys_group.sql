--liquibase formatted sql

--changeset lightrevan:BALANCE-26114-group-table

CREATE TABLE BO.T_PAYSYS_GROUP (
  ID NUMBER PRIMARY KEY,
  NAME VARCHAR2(128 CHAR)
);

--changeset lightrevan:BALANCE-26114-group-data
INSERT INTO BO.T_PAYSYS_GROUP VALUES (0, 'default');
INSERT INTO BO.T_PAYSYS_GROUP VALUES (1, 'trust');
INSERT INTO BO.T_PAYSYS_GROUP VALUES (2, 'auto_trust');
INSERT INTO BO.T_PAYSYS_GROUP VALUES (3, 'nr_via_agency');
INSERT INTO BO.T_PAYSYS_GROUP VALUES (4, 'yt_nds');

--changeset lightrevan:BALANCE-27778-paysys-group-cc
UPDATE bo.t_paysys_group
    SET name = 'nds_specific'
WHERE id = 4
;

--changeset lightrevan:BALANCE-29552-group
INSERT INTO BO.T_PAYSYS_GROUP VALUES (5, 'toloka_specific');
