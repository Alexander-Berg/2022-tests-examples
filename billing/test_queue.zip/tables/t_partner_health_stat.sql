--liquibase formatted sql

-- changeset yanametro:BALANCE-24532
CREATE TABLE bo.T_PARTNER_HEALTH_STAT
(
  dt DATE,
  appointment_id NUMBER,
  client_id NUMBER,
  price NUMBER,
  service_type VARCHAR2(512)
);

ALTER TABLE bo.T_PARTNER_HEALTH_STAT
ADD CONSTRAINT pk_appointment_id PRIMARY KEY (appointment_id);