--liquibase formatted sql

create table BO.T_ACT_INTERNAL
(
	ID NUMBER not null
		constraint T_ACT_PK
			primary key,
	DT DATE not null,
	CLIENT_ID NUMBER not null,
	INVOICE_ID NUMBER not null
		constraint T_ACT_INVOICE_FK
			references BO.T_INVOICE,
	RUR_SUM_A NUMBER default 0 not null,
	RUR_SUM_B NUMBER default 0 not null,
	RUR_SUM_C NUMBER default 0 not null,
	RUR_SUM_D NUMBER default 0 not null,
	RUR_SUM_E NUMBER default 0 not null,
	USD_RATE NUMBER not null,
	HIDDEN NUMBER default 0 not null,
	USD_SUM_C NUMBER default 0 not null,
	AMOUNT NUMBER,
	AMOUNT_NDS NUMBER,
	AMOUNT_NSP NUMBER,
	EXTERNAL_ID VARCHAR2(32),
	PAID_AMOUNT NUMBER,
	FACTURA VARCHAR2(20),
	UPDATE_DT DATE default SYSDATE,
	UNILATERAL NUMBER(1)
		constraint T_ACT_UL
			check ("UNILATERAL" <= 1   or "UNILATERAL" is null),
	JIRA_ID VARCHAR2(256),
	GOOD_DEBT NUMBER(1) default 0 not null,
	CURRENCY_RATE NUMBER default NULL not null,
	IS_DOCS_SEPARATED NUMBER default 0 not null,
	IS_DOCS_DETAILED NUMBER default 0 not null,
	ACT_SUM NUMBER not null,
	PAYMENT_TERM_DT DATE,
	IS_LOYAL NUMBER,
	IS_TRP NUMBER,
	MONTH_DT DATE default NULL
		constraint T_ACT_C19
			check (MONTH_DT is NULL or MONTH_DT = ROUND(MONTH_DT, 'MONTH')),
	OPERATION_ID NUMBER,
	LABEL VARCHAR2(512),
	TYPE VARCHAR2(128) not null,
	MEMO CLOB,
	STATE_ID NUMBER
		constraint T_ACT_STATE_FK
			references BO.T_ACT_STATE
);

create index BO.T_ACT_INVOICE_ID_IDX
	on BO.T_ACT_INTERNAL (INVOICE_ID);

create index BO.DT_INDEX_T_ACT
	on BO.T_ACT_INTERNAL (DT);

create index BO.T_ACT_EXTERNAL_ID_IDX
	on BO.T_ACT_INTERNAL (EXTERNAL_ID);

create index BO.T_ACT_CLIENT_ID_IDX
	on BO.T_ACT_INTERNAL (CLIENT_ID);

create index BO.IDX_ACT_FACTURA
	on BO.T_ACT_INTERNAL (FACTURA);

create index BO.T_ACT_OPER_ID
	on BO.T_ACT_INTERNAL (OPERATION_ID);

create index BO.T_ACT_STATE_IDX
	on BO.T_ACT_INTERNAL (STATE_ID);

--changeset lightrevan:BALANCE-29737
ALTER TABLE bo.t_act_internal ADD tax_policy_pct_id NUMBER;
