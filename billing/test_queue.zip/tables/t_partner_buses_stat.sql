--liquibase formatted sql

-- changeset yanametro:BALANCE-26457-4
CREATE TABLE bo.T_PARTNER_BUSES_STAT
(
  dt DATE,
  transaction_id VARCHAR(256),
  client_id INTEGER,
  price NUMBER
);

ALTER TABLE bo.T_PARTNER_BUSES_STAT
ADD CONSTRAINT pk_buses_transaction_id PRIMARY KEY (transaction_id);
