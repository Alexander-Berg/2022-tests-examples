--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_TRUST_SERVICE
--------------------------------------------------------------------------------

--changeset vaclav:TRUST-4167-8

CREATE SYNONYM BO.T_TRUST_SERVICE FOR META.T_TRUST_SERVICE;


