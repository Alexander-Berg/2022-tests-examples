--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for table T_CONTRACT_COMSN_TYPE_RATE
--------------------------------------------------------------------------------

CREATE TABLE T_CONTRACT_COMSN_TYPE_RATE
(
  ID                 NUMBER               NOT NULL
    CONSTRAINT T_CONTRACT_COMSN_TYPE_RATE_PK
    PRIMARY KEY,
  COMMISSION_TYPE_ID NUMBER               NOT NULL
    CONSTRAINT T_CONTRACT_COMSN_TYPE_RATE_FK
    REFERENCES T_CONTRACT_COMSN_TYPE,
  START_DT           DATE                 NOT NULL,
  PERCENT            NUMBER(5, 2)         NOT NULL
    CONSTRAINT T_CONTRACT_COMSN_TYPE_RATE_PCT
    CHECK (percent BETWEEN 0.0 AND 100.0),
  UPDATE_DT          DATE DEFAULT sysdate NOT NULL
)
/

CREATE UNIQUE INDEX T_CONTRACT_COMSN_TYPE_RATE_UK
  ON T_CONTRACT_COMSN_TYPE_RATE (COMMISSION_TYPE_ID, START_DT)
/



--changeset natabers:BALANCE-27404-2
insert into t_contract_comsn_type_rate(id, commission_type_id, start_dt, percent, update_dt)
    values(60, 60, SYSDATE, 0, SYSDATE);
