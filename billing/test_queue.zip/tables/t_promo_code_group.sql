--liquibase formatted sql

--changeset lightrevan:BALANCE-28416-seq
create sequence bo.s_promo_code_group_id;

--changeset lightrevan:BALANCE-28416-tbl-group
create table bo.t_promo_code_group
(
  id                    number           not null primary key,
  start_dt              date             not null,
  end_dt                date             not null,
  calc_class_name       varchar2(125)    not null,
  calc_params           varchar2(4000),
  minimal_amounts       varchar2(4000),
  service_ids           varchar2(4000),
  event_id              number,
  firm_id               number           not null,
  reservation_days      number,
  ticket_id             varchar2(25 char),
  new_clients_only      number,
  valid_until_paid      number,
  is_global_unique      number,
  need_unique_urls      number,
  skip_reservation_check number,
  constraint t_pcg_calc_params_json check (calc_params is json),
  constraint t_pcg_minimal_qty_json check (minimal_amounts is json),
  constraint t_pcg_service_ids_json check (service_ids is json),
  constraint t_pcg_event_fk foreign key (event_id) references bo.t_promo_code_event (id),
  constraint t_pcg_firm_fk foreign key (firm_id) references meta.t_firm (id)
);

--changeset lightrevan:BALANCE-29691
ALTER TABLE bo.t_promo_code_group MODIFY firm_id NULL;
