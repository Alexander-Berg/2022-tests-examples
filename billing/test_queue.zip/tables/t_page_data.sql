--liquibase formatted sql

--------------------------------------------------------
--  DDL for Table T_PAGE_DATA
--------------------------------------------------------

  CREATE TABLE "BO"."T_PAGE_DATA"
   (	"PAGE_ID" NUMBER NOT NULL ENABLE,
	"DT" DATE DEFAULT (SYSDATE) NOT NULL ENABLE,
	"RUR_CLICK_PRICE" NUMBER,
	"DESC" VARCHAR2(256 BYTE),
	"CLICK_PRICE" NUMBER,
	"TYPE_ID" NUMBER,
	"NDS" NUMBER DEFAULT 0 NOT NULL ENABLE,
	"SERVICE_ID" NUMBER,
	"CONTRACT_TYPE" VARCHAR2(64 BYTE),
	"TAILABLE" NUMBER DEFAULT null,
	"PAYMENT_TYPE" NUMBER,
	"IS_ACTIVE" NUMBER DEFAULT 1,
	"UNIT_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_ORITS" ;

--------------------------------------------------------
--  DDL for Index T_PAGE_DATA_IDX
--------------------------------------------------------

  CREATE INDEX "BO"."T_PAGE_DATA_IDX" ON "BO"."T_PAGE_DATA" ("PAGE_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  STORAGE(INITIAL 524288 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_ITS" ;

--changeset bwh1te:BALANCE-24098

UPDATE bo.t_page_data pd
SET pd."DESC" = 'Дистрибуция.Адаптер Ритейлер'
WHERE page_id = 4009;

UPDATE bo.t_page_data pd
SET pd."DESC" = 'Дистрибуция.Адаптер Девелопер'
WHERE page_id = 4011;


--changeset yanametro:BALANCE-24289
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (10900, current_date, null, 'Маркет. Маркетинговые услуги', null, null, 0, 119, 'SPENDABLE', null, null, 1, null);

--changeset bwh1te:BALANCE-23060-2
INSERT INTO bo.t_page_data (page_id, dt, "DESC", type_id, service_id, contract_type, tailable)
                    VALUES (10007, sysdate, 'Дистрибуция.Разделение доходов Авиа', 4, null, 'DISTRIBUTION', null);

--changeset yanametro:BALANCE-24600
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (10801, current_date, null, 'Яндекс Такси. Украина: выплата водителям', null, 6, 0, null, 'SPENDABLE', null, null, 1, null);

--changeset yanametro:BALANCE-25910-1
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (11000, current_date, null, 'Дзен. Начисления', null, 4, 0, 134, 'SPENDABLE', null, null, 1, null);

--changeset yanametro:BALANCE-25910-2
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (11001, current_date, null, 'Дзен. Выплаты', null, 4, 0, 134, 'SPENDABLE', null, null, 1, null);

--changeset vorobyov-as:BALANCE-26289-1
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (2090, current_date, null, 'Срезы РСЯ', null, 4, 0, null, 'PARTNERS', null, null, 1, null);

--changeset vorobyov-as:BALANCE-26289-2
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (100006, current_date, null, 'РТБ для ДСП', null, 4, 0, null, 'PARTNERS', null, null, 1, null);

--changeset yanametro:BALANCE-26341-1
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (10802, current_date, null, 'Яндекс Автобусы. Субсидии', null, 6, 0, null, 'SPENDABLE', null, null, 1, null);

--changeset yanametro:BALANCE-26070-1
update bo.T_PAGE_DATA
set bo.t_page_data."DESC"='Яндекс. Компенсации' where page_id=10700;

--changeset yanametro:BALANCE-26454
update bo.T_PAGE_DATA
set bo.t_page_data."DESC"='Яндекс Такси. Компенсации водителям' where page_id=10700;

--changeset yanametro:BALANCE-26454-1
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (10701, current_date, null, 'Яндекс Телемедицина. Компенсации', null, 6, 0, null, 'SPENDABLE', null, null, 1, null);

--changeset vorobyov-as:BALANCE-26629
insert into bo.t_page_data (page_id, dt, "DESC", type_id, nds, contract_type, is_active) values (10008, sysdate, 'Услуги DMP', 6, 0, 'SPENDABLE', 1);

--changeset yanametro:BALANCE-26341-2
ALTER TABLE bo.T_PAGE_DATA
ADD CONSTRAINT pk_page_data_page_id PRIMARY KEY (page_id);

--changeset yanametro:BALANCE-27084
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (10901, current_date, null, 'Синий маркет. Субсидии', null, 6, 0, null, 'SPENDABLE', null, null, 1, null);

--changeset yanametro:BALANCE-27610
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (11002, current_date, null, 'Толока. Выплаты', null, 4, 0, 611, 'SPENDABLE', null, null, 1, null);


--changeset el-yurchito:BALANCE-27628 endDelimiter:\\
INSERT INTO "BO"."T_PAGE_DATA" ("PAGE_ID", "DT", "RUR_CLICK_PRICE", "DESC", "CLICK_PRICE", "TYPE_ID", "NDS", "SERVICE_ID", "CONTRACT_TYPE", "TAILABLE", "PAYMENT_TYPE", "IS_ACTIVE", "UNIT_ID")
  VALUES (10902, SYSDATE, NULL, 'Красный маркет. Субсидии', NULL, 6, 0, 615, 'SPENDABLE', NULL , NULL , 1, NULL)
\\

--changeset vorobyov-as:BALANCE-28250
update bo.T_PAGE_DATA set service_id = 111 where page_id = 13002;

--changeset yanametro:BALANCE-28228
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, RUR_CLICK_PRICE, "DESC", CLICK_PRICE, TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, TAILABLE, PAYMENT_TYPE, IS_ACTIVE, UNIT_ID) VALUES (11003, current_date, null, 'Яндекс.Такси: Скауты. Начисления', null, 4, 0, 619, 'SPENDABLE', null, null, 1, null);

--changeset vorobyov-as:BALANCE-28247-fixed
insert into bo.t_page_data (page_id, dt, "DESC", type_id, contract_type, payment_type)
values (13003, sysdate, 'Видеореклама на площадке', 4, 'DISTRIBUTION', 19)
;

--changeset yanametro:BALANCE-28558
insert into bo.t_page_data (page_id, dt, "DESC", type_id, contract_type) values (10803, sysdate, 'Branding subsidy', 6, 'SPENDABLE');
insert into bo.t_page_data (page_id, dt, "DESC", type_id, contract_type) values (10804, sysdate, 'Guarantee fee', 6, 'SPENDABLE');
insert into bo.t_page_data (page_id, dt, "DESC", type_id, contract_type) values (10805, sysdate, 'Trip bonus', 6, 'SPENDABLE');
insert into bo.t_page_data (page_id, dt, "DESC", type_id, contract_type) values (10806, sysdate, 'Personnel bonus', 6, 'SPENDABLE');
insert into bo.t_page_data (page_id, dt, "DESC", type_id, contract_type) values (10807, sysdate, 'Discount taxi', 6, 'SPENDABLE');
insert into bo.t_page_data (page_id, dt, "DESC", type_id, contract_type) values (10808, sysdate, 'Support coupon', 6, 'SPENDABLE');
insert into bo.t_page_data (page_id, dt, "DESC", type_id, contract_type) values (10809, sysdate, 'Booking subsidy', 6, 'SPENDABLE');

--changeset sfreest:BALANCE-29064-add-page-data
INSERT INTO BO.T_PAGE_DATA (PAGE_ID, DT, "DESC", TYPE_ID, NDS, SERVICE_ID, CONTRACT_TYPE, IS_ACTIVE)
VALUES (63001, sysdate, 'Мотивация продавцов: установки', 5, 0, 630, 'SPENDABLE', 1);

--changeset vorobyov-as:BALANCE-30427
update bo.t_page_data set service_id=7 where page_id=10100;
