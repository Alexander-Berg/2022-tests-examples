--liquibase formatted sql

create table bo.t_currency_matching
(
    id          number not null
        constraint pk_currency_matching_id
        primary key,
    base_cc     number not null,
    trade_with  number not null,
    rate_src_id number
);

--changeset nebaruzdin:BALANCE-28708

alter table bo.t_currency_matching add (
    base_iso_currency       varchar2(16),
    trade_with_iso_currency varchar2(16),
    rate_src                varchar2(16)
);

--changeset nebaruzdin:BALANCE-28708-1

merge into bo.t_currency_matching cm
using bo.t_currency c
on (cm.base_cc = c.iso_num_code)
when matched then update set
    cm.base_iso_currency = c.iso_code;

--changeset nebaruzdin:BALANCE-28708-2

merge into bo.t_currency_matching cm
using bo.t_currency c
on (cm.trade_with = c.iso_num_code)
when matched then update set
    cm.trade_with_iso_currency = c.iso_code;

--changeset nebaruzdin:BALANCE-28708-3

merge into bo.t_currency_matching cm
using bo.t_currency_rate_src crs
on (cm.rate_src_id = crs.id)
when matched then update set
    cm.rate_src = crs.cc;

--changeset nebaruzdin:BALANCE-28708-4

alter table bo.t_currency_matching modify (
    base_iso_currency       not null,
    trade_with_iso_currency not null
);
