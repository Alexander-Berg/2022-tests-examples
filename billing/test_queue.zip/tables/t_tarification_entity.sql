--liquibase formatted sql

--changeset vorobyov-as:completions_overhaul-1

create table bo.t_tarification_entity

    (id integer not null enable,
     product_id integer not null enable,
     key_num_1 integer not null enable,
     key_num_2 integer not null enable,
     key_num_3 integer not null enable,
     key_num_4 integer not null enable,
     key_num_5 integer not null enable,
     key_num_6 integer not null enable
     )
    ;


--changeset vorobyov-as:completions_overhaul-2 endDelimiter:\\
create unique index bo.idx_completion_entity_key
    on bo.t_tarification_entity
    (product_id, key_num_1, key_num_2, key_num_3, key_num_4, key_num_5, key_num_6)
\\


--changeset vorobyov-as:completions_overhaul-3

create sequence bo.s_tarification_entity
    start with 1000
    increment by 1
;

--changeset vorobyov-as:completions_overhaul-4 endDelimiter:\\

create or replace editionable trigger bo.tr_tarification_entity_id

    before insert on bo.t_tarification_entity
    for each row

        begin <<COLUMN_SEQUENCES>>

            begin if inserting and :new.id is null then
                select bo.s_tarification_entity.nextval into :new.id from sys.dual;
            end if;

        end COLUMN_SEQUENCES;

    end;
\\