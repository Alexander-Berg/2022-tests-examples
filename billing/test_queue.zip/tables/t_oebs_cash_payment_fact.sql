--liquibase formatted sql

--------------------------------------------------------
--  DDL for Table T_OEBS_CASH_PAYMENT_FACT
--------------------------------------------------------

CREATE TABLE "BO"."T_OEBS_CASH_PAYMENT_FACT"
(
	"XXAR_CASH_FACT_ID" NUMBER not null,
	"AMOUNT" NUMBER not null,
	"RECEIPT_NUMBER" VARCHAR2(90 char) not null,
	"RECEIPT_DATE" DATE not null,
	"LAST_UPDATED_BY" NUMBER(15) not null,
	"LAST_UPDATE_DATE" DATE not null,
	"LAST_UPDATE_LOGIN" NUMBER(15),
	"CREATED_BY" NUMBER(15) not null,
	"CREATION_DATE" DATE not null,
	"CASH_RECEIPT_NUMBER" VARCHAR2(90 char),
	"ACC_NUMBER" VARCHAR2(90),
	"PAYMENT_NUMBER" VARCHAR2(90),
	"PAYMENT_DATE" DATE,
	"OPERATION_TYPE" VARCHAR2(150),
	"SOURCE_TYPE" VARCHAR2(450 char),
	"COMISS_DATE" DATE,
	"ORIG_ID" NUMBER
);

--------------------------------------------------------
--  DDL for Index OEBS_CASH_PAYMENT_FACT_XXAR_ID
--------------------------------------------------------

CREATE UNIQUE INDEX "BO"."OEBS_CASH_PAYMENT_FACT_XXAR_ID"
  ON "BO"."T_OEBS_CASH_PAYMENT_FACT" ("XXAR_CASH_FACT_ID");

--------------------------------------------------------
--  DDL for Index T_OCPF_RN_IDX
--------------------------------------------------------

CREATE INDEX "BO"."T_OCPF_RN_IDX"
	ON "BO"."T_OEBS_CASH_PAYMENT_FACT" ("RECEIPT_NUMBER");

--------------------------------------------------------
--  DDL for Index IDX_OEBS_CASH_PAYMENT_FACT_RDT
--------------------------------------------------------

CREATE INDEX "BO"."IDX_OEBS_CASH_PAYMENT_FACT_RDT"
	ON "BO"."T_OEBS_CASH_PAYMENT_FACT" ("RECEIPT_DATE");

--------------------------------------------------------
--  DDL for Index T_OEBS_CASH_P_F_LAST_UD_IDX
--------------------------------------------------------

CREATE INDEX "BO"."T_OEBS_CASH_P_F_LAST_UD_IDX"
	ON "BO"."T_OEBS_CASH_PAYMENT_FACT" ("LAST_UPDATE_DATE");

--------------------------------------------------------
--  DDL for Trigger TR_OEBS_CP_FACT_CHANGE
--------------------------------------------------------

CREATE OR REPLACE TRIGGER "BO"."TR_OEBS_CP_FACT_CHANGE"
	AFTER INSERT OR UPDATE OR DELETE
	ON "BO"."T_OEBS_CASH_PAYMENT_FACT"
	FOR EACH ROW
DECLARE
  p_delta NUMBER;
  p_operation_type VARCHAR2(40);
  p_invoice_eid VARCHAR2(40);
  p_invoice_id NUMBER;
  p_count NUMBER;
  p_timestamp DATE;
  p_timestamp_new DATE;
  p_payment_number VARCHAR2(64);
  p_payment_date DATE;
  p_payment_invoice_id NUMBER;
  p_payment_invoice_type VARCHAR2(128);
BEGIN
  p_operation_type := nvl(nvl(:new.operation_type, :old.operation_type), 'INSERT');
  IF p_operation_type <> 'SF_AVANS' THEN
    p_invoice_eid := nvl(:new.receipt_number, :old.receipt_number);
    p_payment_number := nvl(:new.payment_number, :old.payment_number);
    p_payment_date := nvl(:new.payment_date, :old.payment_date);
    p_delta := nvl(:new.amount, 0) - nvl(:old.amount, 0);

    SELECT receipt_dt_1c, id
    INTO p_timestamp, p_invoice_id
    FROM "BO"."T_INVOICE"
    WHERE external_id = p_invoice_eid;

    IF p_delta <> 0 THEN
      p_timestamp_new := nvl(:new.last_update_date, sysdate);
      IF p_timestamp IS NULL OR p_timestamp_new > p_timestamp THEN
        p_timestamp := p_timestamp_new;
      END IF;

      UPDATE "BO"."T_INVOICE"
      SET
        receipt_sum_1c = nvl(receipt_sum_1c, 0) + p_delta,
        receipt_dt_1c = p_timestamp
      WHERE
        external_id = p_invoice_eid;

      IF :new.orig_id IS NOT NULL THEN
        pk_accounts.update_payment(:new.orig_id, p_delta);
      END IF;

      pk_export_queue.enqueue(
          p_invoice_id,
          'Invoice',
          'PROCESS_PAYMENTS'
      );
    END IF;

    UPDATE
      "BO"."T_INVOICE"
    SET
      payment_number  = p_payment_number,
      payment_date    = p_payment_date
    WHERE
      external_id = p_invoice_eid;
  END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN NULL;
END;

--------------------------------------------------------
--  DDL for Materialized view log
--------------------------------------------------------

CREATE MATERIALIZED VIEW LOG ON "BO"."T_OEBS_CASH_PAYMENT_FACT"
	WITH ROWID;


--changeset el-yurchito:BALANCE-27359 endDelimiter:\\
CREATE OR REPLACE TRIGGER "BO"."TR_OEBS_CP_FACT_CHANGE"
	AFTER INSERT OR UPDATE OR DELETE
	ON "BO"."T_OEBS_CASH_PAYMENT_FACT"
	FOR EACH ROW
DECLARE
  p_delta NUMBER;
  p_operation_type VARCHAR2(40);
  p_invoice_eid VARCHAR2(40);
  p_invoice_id NUMBER;
  p_count NUMBER;
  p_timestamp DATE;
  p_timestamp_new DATE;
  p_payment_number VARCHAR2(64);
  p_payment_date DATE;
  p_payment_invoice_id NUMBER;
  p_payment_invoice_type VARCHAR2(128);
BEGIN
  p_delta := nvl(:new.amount, 0) - nvl(:old.amount, 0);
  p_operation_type := nvl(nvl(:new.operation_type, :old.operation_type), 'INSERT');

  IF p_operation_type not in ('CORRECTION_NETTING', 'SF_AVANS') THEN
    p_invoice_eid := nvl(:new.receipt_number, :old.receipt_number);
    p_payment_number := nvl(:new.payment_number, :old.payment_number);
    p_payment_date := nvl(:new.payment_date, :old.payment_date);

    SELECT receipt_dt_1c, id
    INTO p_timestamp, p_invoice_id
    FROM "BO"."T_INVOICE"
    WHERE external_id = p_invoice_eid;

    IF p_delta <> 0 THEN
      p_timestamp_new := nvl(:new.last_update_date, sysdate);
      IF p_timestamp IS NULL OR p_timestamp_new > p_timestamp THEN
        p_timestamp := p_timestamp_new;
      END IF;

      UPDATE "BO"."T_INVOICE"
      SET
        receipt_sum_1c = nvl(receipt_sum_1c, 0) + p_delta,
        receipt_dt_1c = p_timestamp
      WHERE
        external_id = p_invoice_eid;

      IF :new.orig_id IS NOT NULL THEN
        pk_accounts.update_payment(:new.orig_id, p_delta);
      END IF;

      pk_export_queue.enqueue(
          p_invoice_id,
          'Invoice',
          'PROCESS_PAYMENTS'
      );
    END IF;

    UPDATE
      "BO"."T_INVOICE"
    SET
      payment_number  = p_payment_number,
      payment_date    = p_payment_date
    WHERE
      external_id = p_invoice_eid;
  END IF;

  IF p_operation_type = 'CORRECTION_NETTING' AND p_delta <> 0 THEN
    pk_export_queue.enqueue(
        :new.xxar_cash_fact_id,
        'OebsCashPaymentFact',
        'THIRDPARTY_TRANS'
    );
  END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN NULL;
END;
\\

--changeset el-yurchito:BALANCE-27359-1 endDelimiter:\\
ALTER TABLE "BO"."T_OEBS_CASH_PAYMENT_FACT"
  ADD ("SOURCE_ID" NUMBER)
\\

--changeset halty:BALANCE-28934-1
CREATE INDEX  bo.t_oebs_cash_fact_orig_id_idx ON bo.t_oebs_cash_payment_fact(orig_id) ONLINE;

--changeset el-yurchito:BALANCE-29493 endDelimiter:\\
CREATE OR REPLACE TRIGGER "BO"."TR_OEBS_CP_FACT_CHANGE"
	AFTER INSERT OR UPDATE OR DELETE
	ON "BO"."T_OEBS_CASH_PAYMENT_FACT"
	FOR EACH ROW
DECLARE
  p_delta NUMBER;
  p_operation_type VARCHAR2(40);
  p_invoice_eid VARCHAR2(40);
  p_invoice_id NUMBER;
  p_count NUMBER;
  p_timestamp DATE;
  p_timestamp_new DATE;
  p_payment_number VARCHAR2(64);
  p_payment_date DATE;
  p_payment_invoice_id NUMBER;
  p_payment_invoice_type VARCHAR2(128);
BEGIN
  p_delta := nvl(:new.amount, 0) - nvl(:old.amount, 0);
  p_operation_type := nvl(nvl(:new.operation_type, :old.operation_type), 'INSERT');

  IF p_operation_type not in ('CORRECTION_NETTING', 'SF_AVANS', 'INSERT_FUEL_HOLD_RETURN',
                              'CANCEL_FUEL_HOLD_RETURN', 'DEBIT_FUEL_HOLD_RETURN', 'CORRECTION_FUEL_HOLD')
  THEN
    p_invoice_eid := nvl(:new.receipt_number, :old.receipt_number);
    p_payment_number := nvl(:new.payment_number, :old.payment_number);
    p_payment_date := nvl(:new.payment_date, :old.payment_date);

    SELECT receipt_dt_1c, id
    INTO p_timestamp, p_invoice_id
    FROM "BO"."T_INVOICE"
    WHERE external_id = p_invoice_eid;

    IF p_delta <> 0 THEN
      p_timestamp_new := nvl(:new.last_update_date, sysdate);
      IF p_timestamp IS NULL OR p_timestamp_new > p_timestamp THEN
        p_timestamp := p_timestamp_new;
      END IF;

      UPDATE "BO"."T_INVOICE"
      SET
        receipt_sum_1c = nvl(receipt_sum_1c, 0) + p_delta,
        receipt_dt_1c = p_timestamp
      WHERE
        external_id = p_invoice_eid;

      IF :new.orig_id IS NOT NULL THEN
        pk_accounts.update_payment(:new.orig_id, p_delta);
      END IF;

      pk_export_queue.enqueue(
          p_invoice_id,
          'Invoice',
          'PROCESS_PAYMENTS'
      );
    END IF;

    UPDATE
      "BO"."T_INVOICE"
    SET
      payment_number  = p_payment_number,
      payment_date    = p_payment_date
    WHERE
      external_id = p_invoice_eid;
  END IF;

  IF p_operation_type = 'CORRECTION_NETTING' AND p_delta <> 0 THEN
    pk_export_queue.enqueue(
        :new.xxar_cash_fact_id,
        'OebsCashPaymentFact',
        'THIRDPARTY_TRANS'
    );
  END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN NULL;
END;
\\
