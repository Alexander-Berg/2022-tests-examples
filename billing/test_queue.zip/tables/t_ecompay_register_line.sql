--liquibase formatted sql

--changeset retard:TRUST-2450

CREATE TABLE t_ecompay_register_line
(
    ID NUMBER(*) PRIMARY KEY NOT NULL,
    ecom_id number(*),
    parent_transaction_id number(*),
    payment_type_id number(*),
    external_id varchar(64),
    type_id number(*),
    status_id number(*),
    customer_ip varchar(128),
    acquirer_id number(*),
    created_at date,
    amount number(*, 4),
    currency varchar2(10),
    real_amount number(*, 4),
    real_currency varchar2(10),
    customer_purse varchar2(64),
    transaction_comment varchar2(512),
    completed_at Date,
    processor_date Date,
    CONSTRAINT t_ecompay_regline_id_fk FOREIGN KEY (ID) REFERENCES T_PAYMENT_REGISTER_LINE (ID)
    -- CONSTRAINT t_ecompay_regline_pid_fk FOREIGN KEY (PAYMENT_ID) REFERENCES t_payment (id)
);
-- CREATE INDEX IDX_t_ecom_regline_payment_id ON t_ecompay_register_line (PAYMENT_ID);
