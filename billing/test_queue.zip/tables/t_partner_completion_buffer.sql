--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_PARTNER_COMPLETION_BUFFER
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_PARTNER_COMPLETION_BUFFER"
   (	"PLACE_ID" NUMBER NOT NULL ENABLE,
	"PAGE_ID" NUMBER NOT NULL ENABLE,
	"DT" DATE NOT NULL ENABLE,
	"TYPE" NUMBER NOT NULL ENABLE,
	"SHOWS" NUMBER,
	"CLICKS" NUMBER,
	"BUCKS" NUMBER,
	"MBUCKS" NUMBER,
	"COMPLETION_TYPE" NUMBER NOT NULL ENABLE,
	"HITS" NUMBER,
	"SOURCE_ID" NUMBER NOT NULL ENABLE,
	"TEXT" VARCHAR2(512 BYTE),
	"OBJECT_TYPE" VARCHAR2(64 BYTE),
	"UNITS" NUMBER,
	"MONEY" NUMBER,
	"VID" NUMBER
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

--changeset bwh1te:BALANCE-24113-1
update bo.t_partner_completion_buffer
  set source_id = 5
  where source_id = 55;

--changeset bwh1te:BALANCE-24113-2
update bo.t_partner_completion_buffer
  set source_id = 74
  where source_id = 7;

--changeset bwh1te:BALANCE-24754 endDelimiter:\\
declare
  i number;
begin
  loop
    update bo.t_partner_completion_buffer
      set source_id = 7
      where source_id = 74 and rownum<100000;
    i := sql%rowcount;
    exit when i <= 0;
    commit;
  end loop;
end;
\\

--changeset vorobyov-as:BALANCE-25353
alter table bo.t_partner_completion_buffer add clicksa number;