--liquibase formatted sql

--------------------------------------------------------------------------------
-- DDL for table T_SERVICE_PRICE_HISTORY
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_SERVICE_PRICE_HISTORY"
   (    "ID" NUMBER NOT NULL ENABLE,
    "START_DT" DATE,
    "END_DT" DATE NOT NULL ENABLE,
    "SERVICE_PRODUCT_ID" NUMBER NOT NULL ENABLE,
    "DT" DATE,
    "REGION_ID" NUMBER,
    "CLID" VARCHAR2(50 BYTE),
    "PRICE" NUMBER NOT NULL ENABLE,
    "CURRENCY" VARCHAR2(16 BYTE) NOT NULL ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."IDX_SERVICE_PRICE_HIST_ID" ON "BO"."T_SERVICE_PRICE_HISTORY" ("ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"
  PARALLEL 5 ;

--changeset nebaruzdin:BALANCE-23787

alter table bo.t_service_price_history add iso_currency varchar2(16);

--changeset nebaruzdin:BALANCE-28474

declare
    batch_size constant number := 200000;
    i number;
begin
    loop
        update /*+ parallel(8) */ bo.t_service_price_history
        set iso_currency = decode(upper(currency),
                                  'RUR', 'RUB',
                                  upper(currency))
        where
            iso_currency is null
            and currency is not null
            and rownum <= batch_size;

        i := sql%rowcount;
        system.simple_logger.log_add('BALANCE-28474',
                                     'bo.t_service_price_history ' ||
                                     i || ' ' ||
                                     to_char(sysdate,'DD-MON-RRRR HH24:MI:SS'));
        exit when i <= 0;
        commit;
    end loop;
end;
/
