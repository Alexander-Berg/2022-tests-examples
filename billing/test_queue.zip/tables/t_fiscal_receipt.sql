--liquibase formatted sql

--changeset sage:TRUST-2981-1

CREATE SEQUENCE bo.s_fiscal_receipt_id;

CREATE TABLE bo.t_fiscal_receipt (
    id NUMBER(*,0) NOT NULL,
    dt DATE NOT NULL,
    payment_id NUMBER(*,0) NOT NULL,
    receipt_dt DATE NOT NULL,
    receipt_amount NUMBER NOT NULL,
    receipt_kkt VARCHAR2(16) NOT NULL,
    receipt_fn VARCHAR2(16) NOT NULL,
    receipt_fd VARCHAR2(10) NOT NULL,
    receipt_fpd VARCHAR2(10) NOT NULL,
    receipt_data CLOB NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_fiscal_pay_id FOREIGN KEY (payment_id) REFERENCES bo.t_payment(id)
);

CREATE UNIQUE INDEX bo.i_fiscal_payment_id ON bo.t_fiscal_receipt(payment_id);

--changeset isupov:BALANCE-27366-1

COMMENT ON COLUMN BO.T_FISCAL_RECEIPT.RECEIPT_KKT IS 'kkt rnm';

COMMENT ON COLUMN BO.T_FISCAL_RECEIPT.RECEIPT_FN IS 'fn sn';

COMMENT ON COLUMN BO.T_FISCAL_RECEIPT.RECEIPT_FD IS 'doc id';

COMMENT ON COLUMN BO.T_FISCAL_RECEIPT.RECEIPT_FPD IS 'doc sign';

ALTER TABLE BO.T_FISCAL_RECEIPT ADD (receipt_type  VARCHAR2(32 BYTE));

ALTER TABLE BO.T_FISCAL_RECEIPT MODIFY (RECEIPT_DATA  NULL);

CREATE INDEX bo.i_fiscal_receipt_dt ON bo.t_fiscal_receipt(receipt_dt) online;

--ALTER TABLE BO.T_FISCAL_RECEIPT ADD (
--  CONSTRAINT T_FISCAL_RECEIPT_U01
--  UNIQUE (RECEIPT_FN, RECEIPT_FD)
--  NOVALIDATE);
--
--
--ALTER TABLE BO.T_FISCAL_RECEIPT MODIFY (
--  CONSTRAINT T_FISCAL_RECEIPT_U01 ENABLE VALIDATE);
--
--
--CREATE UNIQUE INDEX bo.i_fiscal_payment_u01 ON bo.t_fiscal_receipt(receipt_fn, receipt_fd);
