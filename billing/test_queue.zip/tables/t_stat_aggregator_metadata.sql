--liquibase formatted sql

--changeset akatovda:BALANCE-24291-1 endDelimiter:\\
--------------------------------------------------------------------------------
--  DDL for table T_STAT_AGGREGATOR_METADATA
--------------------------------------------------------------------------------
DECLARE
TABLE_CREATE_STATEMENT LONG;
BEGIN
TABLE_CREATE_STATEMENT := 'CREATE TABLE BO.T_STAT_AGGREGATOR_METADATA (
    ID              NUMBER           PRIMARY KEY,
    SERVICE_NAME    VARCHAR2(255)    NOT NULL,
    DT              VARCHAR2(10)     NOT NULL
)';

EXECUTE IMMEDIATE TABLE_CREATE_STATEMENT;
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE = -955 THEN
      NULL;
    ELSE
      RAISE;
    END IF;
END;
\\

--changeset akatovda:BALANCE-26048
ALTER TABLE BO.T_STAT_AGGREGATOR_METADATA ADD input_hash VARCHAR2(64);

--changeset akatovda:BALANCE-26048-purpose
ALTER TABLE BO.T_STAT_AGGREGATOR_METADATA ADD purpose VARCHAR2(255);

--changeset akatovda:BALANCE-26048-initial-state
ALTER TABLE BO.T_STAT_AGGREGATOR_METADATA RENAME COLUMN input_hash TO initial_state;

--changeset akatovda:BALANCE-26331-seq
CREATE SEQUENCE BO.S_STAGER_ID START WITH 1000 INCREMENT BY 1 MAXVALUE 134217728;

--changeset akatovda:BALANCE-28407-initial-state-widen
ALTER TABLE BO.T_STAT_AGGREGATOR_METADATA MODIFY initial_state VARCHAR2(1024);

--changeset akatovda:BALANCE-29104-stager-connect-mon
ALTER TABLE BO.T_STAT_AGGREGATOR_METADATA ADD params VARCHAR(1024);
