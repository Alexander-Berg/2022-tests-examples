--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_SCALE_POINTS
--------------------------------------------------------------------------------

  CREATE TABLE "BO"."T_SCALE_POINTS"
   (	"ID" NUMBER NOT NULL ENABLE,
	"SCALE_CODE" VARCHAR2(40 BYTE),
	"START_DT" DATE,
	"END_DT" DATE,
	"X" NUMBER,
	"Y" NUMBER,
	"HIDDEN" NUMBER DEFAULT 0,
	"CURRENCY" VARCHAR2(16 BYTE),
	 CONSTRAINT "T_SCALE_POINTS_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS"  ENABLE,
	 CONSTRAINT "T_SCALE_POINTS_T_SCALE_FK1" FOREIGN KEY ("SCALE_CODE")
	  REFERENCES "BO"."T_SCALE" ("CODE") ENABLE
   ) SEGMENT CREATION IMMEDIATE
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 1048576 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_PERSONTS" ;

  CREATE INDEX "BO"."T_SCALE_POINTS_T_SCALE_IDX1" ON "BO"."T_SCALE_POINTS" ("SCALE_CODE")
  PCTFREE 10 INITRANS 83 MAXTRANS 255 COMPUTE STATISTICS NOLOGGING
  STORAGE(INITIAL 524288 NEXT 524288 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "YACC_ITS"
  PARALLEL 5 ;

-- changeset quark:BALANCE-24121
delete from bo.t_scale_points where scale_code in ('adfox_offer_requests');
insert into bo.t_scale_points (ID, SCALE_CODE, START_DT, END_DT, X, Y, HIDDEN, CURRENCY)
  select bo.s_scale_points_id.nextval, 'adfox_offer_requests', start_dt, end_dt, x, y, hidden, currency
  from (
    select  start_dt, end_dt, x - 1 x,
      lag(y) over (order by x) * 1.18 y, hidden, currency
    from bo.t_scale_points where scale_code = 'adfox_sites_requests' and x <= 24000001
  ) where x >= 1;

delete from bo.t_scale_points where scale_code in ('adfox_offer_requests_SNG');
insert into bo.t_scale_points (ID, SCALE_CODE, START_DT, END_DT, X, Y, HIDDEN, CURRENCY)
    select bo.s_scale_points_id.nextval, 'adfox_offer_requests_SNG', start_dt, end_dt, x, y * 0.7, hidden, currency
from bo.t_scale_points where scale_code = 'adfox_offer_requests';

--changeset nebaruzdin:BALANCE-23787

alter table bo.t_scale_points add units varchar2(16);

--changeset natabers:BALANCE-28470-t_scale_points endDelimiter:\\

begin
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, units)
    values (bo.s_scale_points_id.nextval, 'uz_agency_discount', null, null, 0, 10, 0, 'USD', 'USD');
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, units)
    values (bo.s_scale_points_id.nextval, 'uz_agency_discount', null, null, 150, 15, 0, 'USD', 'USD');
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, units)
    values (bo.s_scale_points_id.nextval, 'uz_agency_discount', null, null, 1000, 20, 0, 'USD', 'USD');
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, units)
    values (bo.s_scale_points_id.nextval, 'uz_agency_discount', null, null, 2000, 25, 0, 'USD', 'USD');
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, units)
    values (bo.s_scale_points_id.nextval, 'uz_agency_discount', null, null, 4000, 30, 0, 'USD', 'USD');
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, units)
    values (bo.s_scale_points_id.nextval, 'uz_agency_discount', null, null, 6000, 40, 0, 'USD', 'USD');
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, units)
    values (bo.s_scale_points_id.nextval, 'uz_agency_discount', null, null, 8000, 50, 0, 'USD', 'USD');
end;
\\

--changeset sfreest:BALANCE-29064-t_scale_points
alter table bo.t_scale_points add max_sum NUMBER;
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, max_sum)
    values (bo.s_scale_points_id.nextval, 'addappter_common_scale', date'2018-09-01', null, 0, 0, 0, 'RUB', null);
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, max_sum)
    values (bo.s_scale_points_id.nextval, 'addappter_common_scale', date'2018-09-01', null, 11, 35, 0, 'RUB', null);
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, max_sum)
    values (bo.s_scale_points_id.nextval, 'addappter_common_scale', date'2018-09-01', null, 21, 40, 0, 'RUB', null);
insert into bo.t_scale_points (id, scale_code, start_dt, end_dt, x, y, hidden, currency, max_sum)
    values (bo.s_scale_points_id.nextval, 'addappter_common_scale', date'2018-09-01', null, 31, 50, 0, 'RUB', 12500);
