--liquibase formatted sql

--------------------------------------------------------
--  DDL for Table T_PARTNER_PAYMENT_REGISTRY
--------------------------------------------------------

--changeset el-yurchito:BALANCE-28492-1 endDelimiter:\\
CREATE TABLE "BO"."T_PARTNER_PAYMENT_REGISTRY" (
  "ID" NUMBER NOT NULL CONSTRAINT C_SIDE_REGISTRY_PK PRIMARY KEY,
  "REGISTRY_DATE" DATE NOT NULL,
  "SERVICE_ID" NUMBER NOT NULL,
  "TOTAL_AMOUNT" NUMBER
)
\\

--changeset el-yurchito:BALANCE-28492-2 endDelimiter:\\
CREATE INDEX "BO"."IDX_SIDE_PAYMENT_REG_DT"
  ON "BO"."T_PARTNER_PAYMENT_REGISTRY" ("REGISTRY_DATE")
  ONLINE
\\

--changeset el-yurchito:BALANCE-28492-3 endDelimiter:\\
CREATE INDEX "BO"."IDX_SIDE_PAYMENT_SERVICE_ID"
  ON "BO"."T_PARTNER_PAYMENT_REGISTRY" ("SERVICE_ID")
  ONLINE
\\

--changeset halty:BALANCE-28492-4 endDelimiter:\\
CREATE SEQUENCE bo.s_partner_payment_registry_id START WITH 1000000000000 INCREMENT BY 10
\\

--changeset halty:BALANCE-28492-5 endDelimiter:\\
CREATE OR REPLACE EDITIONABLE TRIGGER "BO"."TR_PARTNER_PAYMENT_REG_INS"
BEFORE INSERT
ON T_PARTNER_PAYMENT_REGISTRY
REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW

DECLARE foo NUMBER;
BEGIN
  IF :new.id IS NULL THEN
     SELECT s_partner_payment_registry_id.nextval INTO foo FROM dual;
     :new.id := foo;
  END IF;
END;
\\
--changeset halty:BALANCE-28492-6 endDelimiter:\\
ALTER TRIGGER "BO"."TR_PARTNER_PAYMENT_REG_INS" ENABLE
\\

