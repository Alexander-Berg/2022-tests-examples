--liquibase formatted sql

CREATE TABLE t_promo_code
(
    id NUMBER NOT NULL CONSTRAINT t_promo_code_pk PRIMARY KEY,
    code VARCHAR2(64) NOT NULL CONSTRAINT t_promo_code_u_code UNIQUE,
    start_dt DATE NOT NULL,
    end_dt DATE NOT NULL,
    discount_pct NUMBER DEFAULT 0 NOT NULL,
    series NUMBER NOT NULL CONSTRAINT t_promo_code_r02 REFERENCES t_promo_code_series,
    new_clients_only NUMBER NOT NULL,
    valid_until_paid NUMBER NOT NULL,
    any_same_series NUMBER NOT NULL,
    middle_dt DATE NOT NULL,
    bonus1 NUMBER DEFAULT 0 NOT NULL,
    bonus2 NUMBER DEFAULT 0 NOT NULL,
    is_global_unique NUMBER NOT NULL,
    event_id NUMBER DEFAULT 0 NOT NULL CONSTRAINT t_promo_code_event_r REFERENCES t_promo_code_event,
    need_unique_urls NUMBER NOT NULL,
    firm_id NUMBER NOT NULL CONSTRAINT t_promo_code_r09firm REFERENCES meta.t_firm,
    reservation_days NUMBER,
    minimal_qty NUMBER,
    multicurrency_bonuses VARCHAR2(4000 CHAR),
    ticket_id VARCHAR2(25 CHAR) DEFAULT NULL,
    CONSTRAINT t_promo_code_c_dt CHECK (start_dt < middle_dt AND middle_dt <= end_dt),
    CONSTRAINT t_promo_code_c_bonuses CHECK (
        (middle_dt = end_dt AND bonus1 = 0 AND bonus2 = 0 AND discount_pct <> 0)
        OR (middle_dt <> end_dt AND bonus1 <> 0 AND bonus2 <> 0 AND discount_pct = 0)
    )
);

CREATE INDEX t_promo_code_i_series ON t_promo_code (series);
CREATE INDEX t_promo_code_i_event_id ON t_promo_code (event_id);
CREATE INDEX t_promo_code_firm_idx ON t_promo_code (firm_id);

--changeset lightrevan:BALANCE-28662-col
ALTER TABLE bo.t_promo_code ADD skip_reservation_check NUMBER NULL;

--changeset lightrevan:BALANCE-28662-null-cst
ALTER TABLE bo.t_promo_code MODIFY (
    start_dt NULL,
    end_dt NULL,
    discount_pct NULL,
    series NULL,
    new_clients_only NULL,
    valid_until_paid NULL,
    any_same_series NULL,
    middle_dt NULL,
    bonus1 NULL,
    bonus2 NULL,
    is_global_unique NULL,
    event_id NULL,
    need_unique_urls NULL,
    firm_id  NULL
);

--changeset lightrevan:BALANCE-28662-check-cst
ALTER TABLE bo.t_promo_code DISABLE CONSTRAINT t_promo_code_c_dt;
ALTER TABLE bo.t_promo_code DISABLE CONSTRAINT t_promo_code_c_bonuses;

--changeset lightrevan:BALANCE-28416-pc-col
ALTER TABLE bo.t_promo_code
  ADD group_id NUMBER;

--changeset lightrevan:BALANCE-28416-pc-col-fk
ALTER TABLE bo.t_promo_code
  ADD CONSTRAINT t_promo_code_group_id_fk
  FOREIGN KEY (group_id) REFERENCES bo.t_promo_code_group (id)
  ENABLE NOVALIDATE;

--changeset lightrevan:BALANCE-28416-pc-col-idx
CREATE INDEX bo.idx_t_promo_code_group_id
  ON bo.t_promo_code (group_id) PARALLEL 8 ONLINE;

--changeset lightrevan:BALANCE-28416-pc-col-idx-np
ALTER INDEX bo.idx_t_promo_code_group_id NOPARALLEL;
