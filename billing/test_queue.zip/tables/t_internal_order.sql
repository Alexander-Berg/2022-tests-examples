--liquibase formatted sql

--------------------------------------------------------------------------------
--  DDL for table T_INTERNAL_ORDER
--------------------------------------------------------------------------------

--changeset ecialo:DWH-333

CREATE TABLE t_internal_order
(
   client_id NUMBER,
   service_code VARCHAR2(5),
   ur_code VARCHAR2(4),
   CONSTRAINT client_uniq UNIQUE (client_id)
)

--changeset ecialo:DWH-333.2

DROP TABLE  t_internal_order;