--liquibase formatted sql

--changeset skydreamer:TRUST-2598-2 endDelimiter:\\

CREATE OR REPLACE TRIGGER bo.tr_t_ccard_bound_pay_upsert
BEFORE INSERT OR UPDATE ON bo.t_ccard_bound_payment
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
  BEGIN
      UPDATE bo.t_payment
      SET trust_payment_id = :NEW.trust_payment_id,
          purchase_token = :NEW.purchase_token,
          postauth_dt = :NEW.postauth_dt,
          postauth_amount = :NEW.postauth_amount,
          user_account = :NEW.phone,
          approval_code = substr(:NEW.approval_code, 0, 30),
          rrn = :NEW.rrn
      WHERE id = :NEW.id;
  END;

\\

CREATE OR REPLACE TRIGGER bo.tr_t_paycash_payment_v3_upsert
BEFORE INSERT OR UPDATE ON bo.t_paycash_payment_v3
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
  BEGIN
      UPDATE bo.t_payment
      SET transaction_id = to_char(:NEW.ym_invoice_id),
             user_account = :NEW.wallet
      WHERE id = :NEW.id;
  END;

\\

CREATE OR REPLACE TRIGGER bo.tr_t_paymaster_payment_upsert
BEFORE INSERT OR UPDATE ON bo.t_paymaster_payment
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
  BEGIN
      UPDATE bo.t_payment
      SET postauth_dt = :NEW.postauth_dt,
          transaction_id = to_char(:NEW.sys_payment_id)
      WHERE id = :NEW.id;
  END;

\\

CREATE OR REPLACE TRIGGER bo.tr_t_rbs_payment_upsert
BEFORE INSERT OR UPDATE ON bo.t_rbs_payment
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
  BEGIN
      UPDATE bo.t_payment
      SET transaction_id = substr(:NEW.mdorder, 0, 50),
          postauth_dt = :NEW.closed_dt,
          user_account = replace(:NEW.card_number, '**', '****'),
          card_holder = substr(:NEW.card_holder, 0, 50),
          approval_code = substr(:NEW.approval_code, 0, 30)
      WHERE id = :NEW.id;
  END;

\\

CREATE OR REPLACE TRIGGER bo.tr_t_ccard_six_payment_upsert
BEFORE INSERT OR UPDATE ON bo.t_ccard_six_payment
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
  BEGIN
      UPDATE bo.t_payment
      SET transaction_id = :NEW.saferpay_id,
          postauth_dt = :NEW.closed_dt
      WHERE id = :NEW.id;
  END;

\\

CREATE OR REPLACE TRIGGER bo.tr_t_ccard_ua_payment_upsert
BEFORE INSERT OR UPDATE ON bo.t_ccard_ua_payment
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
  BEGIN
      UPDATE bo.t_payment
      SET transaction_id = :NEW.liqpay_order_id,
          approval_code = :NEW.approval_code
      WHERE id = :NEW.id;
  END;

\\

CREATE OR REPLACE TRIGGER bo.tr_t_ccard_tur_payment_upsert
BEFORE INSERT OR UPDATE ON bo.t_ccard_tur_payment
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
  BEGIN
      UPDATE bo.t_payment
      SET transaction_id = :NEW.trans_id,
        user_account = replace(:NEW.cc_number, '***', '****')
      WHERE id = :NEW.id;
  END;

\\

CREATE OR REPLACE TRIGGER bo.tr_t_paypal_payment_upsert
BEFORE INSERT OR UPDATE ON bo.t_paypal_payment
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
  BEGIN
      UPDATE bo.t_payment
      SET transaction_id = substr(:NEW.txn_id, 0, 50)
      WHERE id = :NEW.id;
  END;

\\

