--liquibase formatted sql

--changeset lightrevan:BALANCE-30375
ALTER TABLE bo.t_tax_policy MODIFY firm_id NULL;
