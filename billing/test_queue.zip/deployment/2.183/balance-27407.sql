--liquibase formatted sql

--INSERT INTO BO.V_PYCRON (COMMAND, CRONTAB) VALUES ('yb-python -pysupport cluster_tools/monitor_shipments.py', '*/15 * * * *');
--INSERT INTO BO.T_JOB (ID, INTERVAL, START_TIME) VALUES ('monitor-shipments', 0.0104166666666666666666666666666666666667, 0);

--changeset lightrevan:BALANCE-27407-p-1 endDelimiter:\\
BEGIN
  bo.DELETE_PYCRON_TASK('monitor-shipments');
END; \\

--changeset lightrevan:BALANCE-27407-j
DELETE FROM bo.t_job WHERE id = 'monitor-shipments'
;
