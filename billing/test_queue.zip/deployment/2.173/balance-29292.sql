--liquibase formatted sql

--changeset lightrevan:BALANCE-29292-generate-acts endDelimiter:\\
BEGIN
  bo.create_pycron_task(
      'generate_monthly_acts'
      , 'yb-python -pysupport cluster_tools/generate_acts.py --task monthly_invoices --month current'
      , 'Генерация ежемесячных актов. Постановка в очередь.'
      , 'isupov'
      , '*/10 * * * *'
      , s_enabled => 0
      , d_timeout => 21600
      , r_email => 'isupov@yandex-team.ru'
  );

  bo.create_pycron_task(
      'generate_monthly_acts_check'
      , 'yb-python -pysupport cluster_tools/generate_acts.py --task monthly_acts_contract --month current'
      , 'Генерация ежемесячных актов. Проверка завершения.'
      , 'isupov'
      , '*/10 * * * *'
      , s_enabled => 0
      , d_timeout => 21600
      , r_email => 'isupov@yandex-team.ru'
  );

  bo.create_pycron_task(
      'generate_monthly_interbranch_acts'
      , 'yb-python -pysupport cluster_tools/generate_acts.py --task monthly_close_firms_enq --month current'
      , 'Генерация межфилиальных актов. Постановка в очередь.'
      , 'isupov'
      , '*/10 * * * *'
      , s_enabled => 0
      , d_timeout => 21600
      , r_email => 'isupov@yandex-team.ru'
  );

  bo.create_pycron_task(
      'generate_monthly_interbranch_acts_check'
      , 'yb-python -pysupport cluster_tools/generate_acts.py --task monthly_close_firms --month current'
      , 'Генерация межфилиальных актов. Проверка завершения.'
      , 'isupov'
      , '*/10 * * * *'
      , s_enabled => 0
      , d_timeout => 21600
      , r_email => 'isupov@yandex-team.ru'
  );

  bo.create_pycron_task(
      'generate_monthly_limits'
      , 'yb-python -pysupport cluster_tools/generate_acts.py --task monthly_limits --month current'
      , 'Обновление кредитных лимитов.'
      , 'isupov'
      , '*/10 * * * *'
      , s_enabled => 0
      , d_timeout => 21600
      , r_email => 'isupov@yandex-team.ru'
  );

  bo.create_pycron_task(
      'generate_hourly_acts'
      , 'yb-python -pysupport cluster_tools/generate_acts.py --task hourly_acts --month current'
      , 'Генерация ежедневных актов.'
      , 'isupov'
      , '*/10 * * * *'
      , s_enabled => 0
      , d_timeout => 21600
      , r_email => 'isupov@yandex-team.ru'
  );

  INSERT INTO bo.t_pycron_responsible (task_name, email)
    SELECT
      name,
      'balance-support-dev@yandex-team.ru'
    FROM (
      SELECT 'generate_monthly_acts' name FROM dual UNION ALL
      SELECT 'generate_monthly_acts_check' name FROM dual UNION ALL
      SELECT 'generate_monthly_interbranch_acts' name FROM dual UNION ALL
      SELECT 'generate_monthly_interbranch_acts_check' name FROM dual UNION ALL
      SELECT 'generate_monthly_limits' name FROM dual UNION ALL
      SELECT 'generate_hourly_acts' name FROM dual
    );
END;
\\

--changeset lightrevan:BALANCE-29292-generate-partner-acts endDelimiter:\\
DECLARE
  TYPE common_rows_type IS TABLE OF VARCHAR2(128) INDEX BY VARCHAR2(128);

  common_rows common_rows_type;
  cur_row VARCHAR2(128);
BEGIN
  common_rows('get_stat_from_bk') := 'gpa_stat_bk';
  common_rows('get_stat_adfox') := 'gpa_stat_adfox';
  common_rows('get_stat_health') := 'gpa_stat_health';
  common_rows('health_alignment_timeout') := 'gpa_health_alignment';
  common_rows('adfox_alignment_timeout') := 'gpa_adfox_alignment';
  common_rows('health_monthly_completions') := 'gpa_health_completions';
  common_rows('adfox_monthly_completions') := 'gpa_adfox_completions';
  common_rows('get_detailed_stat') := 'gpa_get_detailed_stat';
  common_rows('generate_partner_acts') := 'gpa_partner_acts';
  common_rows('generate_distribution_acts') := 'gpa_distribution_acts';
  common_rows('health_acts') := 'gpa_health_acts';
  common_rows('adfox_acts') := 'gpa_adfox_acts';
  common_rows('dmp_acts') := 'gpa_dmp_acts';
  common_rows('check_partner_acts') := 'gpa_check_partner_acts';
  common_rows('check_distribution_acts') := 'gpa_check_distribution_acts';
  common_rows('check_rev_partners') := 'gpa_check_rev_partners';
  common_rows('check_health_acts') := 'gpa_check_health_acts';
  common_rows('check_adfox_acts') := 'gpa_check_adfox_acts';
  common_rows('check_dmp_acts') := 'gpa_check_dmp_acts';
  common_rows('unmapped_payments_rerun') := 'gpa_unmapped_payments_rerun';
  common_rows('unmapped_payments_check_left') := 'gpa_unmapped_payments_check_left';
  common_rows('generate_rev_partners') := 'gpa_generate_rev_partners';
  common_rows('generate_rev_partners_mapped') := 'gpa_generate_rev_partners_mapped';
  common_rows('generate_afisha_acts') := 'gpa_generate_afisha_acts';

  cur_row := common_rows.first;
  WHILE cur_row is not null LOOP
    bo.create_pycron_task(
      common_rows(cur_row)
      , 'yb-python -pysupport cluster_tools/generate_partner_acts.py --task ' || cur_row
      , 'Генерация партнёрских актов: ' || cur_row
      , 'halty'
      , '*/15 * * * *'
      , s_enabled => 0
      , d_count_per_host => null
      , d_timeout => 10800
      , r_email => 'balance-reports-monitoring@yandex-team.ru'
    );

    cur_row := common_rows.next(cur_row);
  END LOOP ;

  bo.create_pycron_task(
    'gpa_run_queue'
    , 'yb-python -pysupport cluster_tools/generate_partner_acts.py --task run_queue'
    , 'Генерация партнёрских актов: run_queue'
    , 'halty'
    , '*/5 * * * *'
    , s_enabled => 0
    , d_count_per_host => 2
    , d_timeout => 21600
    , r_email => 'balance-reports-monitoring@yandex-team.ru'
  );
END;
\\
