--liquibase formatted sql

--changeset lightrevan:BALANCE-27778-mgr-ppp
INSERT INTO bo.t_pay_policy_part (id, firm_id, legal_entity, category, is_atypical, description)
  SELECT
    bo.s_pay_policy_part_id.nextval,
    pp.*
  FROM (
     SELECT DISTINCT
       firm_id,
       legal_entity,
       category,
       is_atypical,
       nvl(pm_group, '-') description
     FROM bo.v_pay_policy_csd_groups pp
  ) pp;

--changeset lightrevan:BALANCE-27778-mgr-ppm
INSERT INTO bo.t_pay_policy_paymethod (pay_policy_part_id, payment_method_id, iso_currency, paysys_group_id)
  SELECT
    (
      SELECT id
      FROM bo.t_pay_policy_part pp
      WHERE d.firm_id = pp.firm_id
            AND nvl(d.legal_entity, -1) = nvl(pp.legal_entity, -1)
            AND nvl(d.category, '-') = nvl(pp.category, '-')
            AND nvl(d.is_atypical, -1) = nvl(pp.is_atypical, -1)
            AND d.description = pp.description
    ) pay_policy_part_id,
    payment_method_id,
    decode(currency, 'RUR', 'RUB', currency) iso_currency,
    paysys_group_id
  FROM (
     SELECT DISTINCT
       firm_id,
       legal_entity,
       category,
       is_atypical,
       nvl(pm_group, '-') description,
       payment_method_id,
       currency,
       paysys_group_id
     FROM bo.v_pay_policy_csd_groups pp
     WHERE payment_method_id IS NOT NULL
  ) d;


--changeset lightrevan:BALANCE-27778-mgr-ppr-default
INSERT INTO bo.t_pay_policy_routing (region_id, service_id, is_agency, is_contract, pay_policy_part_id)
  WITH all_rows AS (
      SELECT DISTINCT
        CASE
          WHEN cnt_region > 150 THEN NULL
          ELSE region_id
        END region_id,
        service_id,
        agency,
        firm_id,
        legal_entity,
        category,
        is_atypical,
        description
      FROM (
        SELECT
          region_id,
          service_id,
          agency,
          firm_id,
          legal_entity,
          category,
          is_atypical,
          nvl(pm_group, '-') description,
          count(DISTINCT region_id)
            OVER (PARTITION BY service_id, agency, firm_id, legal_entity, category, is_atypical, pm_group) cnt_region
        FROM bo.v_pay_policy_csd_groups pg
        WHERE service_id = -1
      )
  )
  SELECT
    d.region_id,
    NULL,
    d.agency,
    null,
    (
      SELECT id FROM bo.t_pay_policy_part pp
      WHERE d.firm_id = pp.firm_id
        AND nvl(d.legal_entity, -1) = nvl(pp.legal_entity, -1)
        AND nvl(d.category, '-') = nvl(pp.category, '-')
        AND nvl(d.is_atypical, -1) = nvl(pp.is_atypical, -1)
        AND d.description = pp.description
    ) pay_policy_part_id
  FROM all_rows d;

--changeset lightrevan:BALANCE-27778-mgr-ppr
INSERT INTO bo.t_pay_policy_routing (region_id, service_id, is_agency, is_contract, pay_policy_part_id)
  WITH
    cnt_rows as (
      SELECT /*+materialize*/
          region_id,
          service_id,
          agency,
          firm_id,
          legal_entity,
          category,
          is_atypical,
          nvl(pm_group, '-') description,
          count(DISTINCT region_id)
            OVER (PARTITION BY service_id, agency, firm_id, legal_entity, category, is_atypical, pm_group) cnt_region
        FROM bo.v_pay_policy_csd_groups pg
        WHERE service_id != -1
    ),
    all_rows AS (
      SELECT /*+materialize*/ DISTINCT
        CASE
          WHEN cnt_region > 150 THEN NULL
          ELSE region_id
        END region_id,
        service_id,
        agency,
        firm_id,
        legal_entity,
        category,
        is_atypical,
        description
      FROM cnt_rows
  ),
  pp_rows AS (
    SELECT
      d.region_id,
      d.service_id,
      d.agency,
      0 is_contract,
      (
        SELECT id FROM bo.t_pay_policy_part pp
        WHERE d.firm_id = pp.firm_id
          AND nvl(d.legal_entity, -1) = nvl(pp.legal_entity, -1)
          AND nvl(d.category, '-') = nvl(pp.category, '-')
          AND nvl(d.is_atypical, -1) = nvl(pp.is_atypical, -1)
          AND d.description = pp.description
      ) pay_policy_part_id
    FROM all_rows d
  )
  SELECT
    d.region_id,
    d.service_id,
    d.agency,
    null,
    pay_policy_part_id
  FROM (
         SELECT
           d.*,
           max(
             CASE
               WHEN NOT EXISTS(
                   SELECT 1
                   FROM bo.v_pay_policy_routing ppr
                   WHERE ppr.service_id = d.service_id
                         AND ppr.region_id = nvl(d.region_id, ppr.region_id)
                         AND ppr.is_agency = nvl(d.agency, ppr.is_agency)
                         AND ppr.is_contract = d.is_contract
                         AND ppr.pay_policy_part_id = d.pay_policy_part_id
               ) THEN 1
               ELSE 0
             END
           )
           OVER (PARTITION BY service_id) has_rules
         FROM pp_rows d
       ) d
  WHERE has_rules = 1;

--changeset lightrevan:BALANCE-27778-mgr-ppr-extra
-- fix for inaccuracy in determination of default regions for service
INSERT INTO bo.t_pay_policy_routing (region_id, service_id, is_agency, is_contract, pay_policy_part_id)
  WITH
    csd as (
      select /*+materialize*/ DISTINCT
        region_id,
        service_id,
        agency,
        firm_id,
        legal_entity,
        category,
        is_atypical,
        pm_group
      from bo.V_PAY_POLICY_CSD_GROUPS
      where SERVICE_ID != -1
    ),
    pp AS (
      SELECT /*+materialize*/
        ppr.service_id,
        ppr.region_id,
        ppr.is_agency,
        ppp.firm_id,
        nvl(ppp.legal_entity, -1) legal_entity,
        nvl(ppp.category, '-')    category,
        nvl(ppp.is_atypical, -1)    is_atypical,
        nvl(ppp.description, '-') description
      FROM bo.v_pay_policy_routing ppr
        JOIN bo.t_pay_policy_part ppp ON ppr.pay_policy_part_id = ppp.id
  )
  SELECT /*+parallel(8)*/ DISTINCT
    region_id,
    service_id,
    agency,
    NULL,
    (
      SELECT id FROM bo.t_pay_policy_part pp
      WHERE csd.firm_id = pp.firm_id
            AND nvl(csd.legal_entity, -1) = nvl(pp.legal_entity, -1)
            AND nvl(csd.category, '-') = nvl(pp.category, '-')
            AND nvl(csd.is_atypical, -1) = nvl(pp.is_atypical, -1)
            AND nvl(csd.pm_group, '-') = pp.description
    ) pay_policy_part_id
  FROM csd
  WHERE 1 = 1
    AND NOT exists(
      SELECT 1 FROM pp
      WHERE csd.service_id = pp.service_id
        AND csd.region_id = pp.region_id
        AND nvl(csd.region_id, pp.region_id) = pp.region_id
        AND csd.firm_id = pp.firm_id
        AND nvl(csd.legal_entity, -1) = pp.legal_entity
        AND nvl(csd.category, '-') = pp.category
        AND nvl(csd.is_atypical, -1) = pp.is_atypical
        AND nvl(csd.pm_group, '-') = pp.description
    );

--changeset lightrevan:BALANCE-27778-mgr-c-tmp-t
CREATE TABLE bo.t_tmp_contract_pp_rows AS (
  SELECT 7 SERVICE_ID, 159 REGION_ID, 1 FIRM_ID, 'yt_kzu' CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|KZT|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'KZT' ISO_CURRENCY FROM dual UNION ALL
  SELECT 7 SERVICE_ID, NULL REGION_ID, 1 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|BYN|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'BYN' ISO_CURRENCY FROM dual UNION ALL
  SELECT 23 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 0 LEGAL_ENTITY, 'contract_card|RUR|0%yamoney_wallet|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 23 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 0 LEGAL_ENTITY, 'contract_card|RUR|0%yamoney_wallet|RUR|0' DESCRIPTION, 1201 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 37 SERVICE_ID, 159 REGION_ID, 1 FIRM_ID, 'yt_kzu' CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|KZT|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'KZT' ISO_CURRENCY FROM dual UNION ALL
  SELECT 37 SERVICE_ID, NULL REGION_ID, 1 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|BYN|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'BYN' ISO_CURRENCY FROM dual UNION ALL
  SELECT 50 SERVICE_ID, 225 REGION_ID, 1 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 50 SERVICE_ID, 225 REGION_ID, 1 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 67 SERVICE_ID, 225 REGION_ID, 12 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 67 SERVICE_ID, 225 REGION_ID, 12 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 67 SERVICE_ID, 225 REGION_ID, 111 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 67 SERVICE_ID, 225 REGION_ID, 111 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 67 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 67 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 70 SERVICE_ID, 225 REGION_ID, 12 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 70 SERVICE_ID, 225 REGION_ID, 12 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 70 SERVICE_ID, 225 REGION_ID, 111 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 70 SERVICE_ID, 225 REGION_ID, 111 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 70 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 70 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 77 SERVICE_ID, NULL REGION_ID, 1 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|BYN|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'BYN' ISO_CURRENCY FROM dual UNION ALL
  SELECT 77 SERVICE_ID, 225 REGION_ID, 12 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 77 SERVICE_ID, 225 REGION_ID, 12 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 77 SERVICE_ID, 225 REGION_ID, 111 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 77 SERVICE_ID, 225 REGION_ID, 111 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 77 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 77 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 98 SERVICE_ID, NULL REGION_ID, 7 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|USD|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'USD' ISO_CURRENCY FROM dual UNION ALL
  SELECT 98 SERVICE_ID, 225 REGION_ID, 12 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 98 SERVICE_ID, 225 REGION_ID, 12 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 111 SERVICE_ID, NULL REGION_ID, 115 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|USD|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'USD' ISO_CURRENCY FROM dual UNION ALL
  SELECT 114 SERVICE_ID, NULL REGION_ID, 16 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|EUR|0%card|EUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'EUR' ISO_CURRENCY FROM dual UNION ALL
  SELECT 114 SERVICE_ID, NULL REGION_ID, 16 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|EUR|0%card|EUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'EUR' ISO_CURRENCY FROM dual UNION ALL
  SELECT 118 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 118 SERVICE_ID, 225 REGION_ID, 121 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 135 SERVICE_ID, 159 REGION_ID, 31 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|KZT|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'KZT' ISO_CURRENCY FROM dual UNION ALL
  SELECT 205 SERVICE_ID, 149 REGION_ID, 27 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|BYN|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'BYN' ISO_CURRENCY FROM dual UNION ALL
  SELECT 205 SERVICE_ID, 225 REGION_ID, 113 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1001 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual UNION ALL
  SELECT 205 SERVICE_ID, 225 REGION_ID, 113 FIRM_ID, NULL CATEGORY, 1 LEGAL_ENTITY, 'contract_bank|RUR|0%card|RUR|0' DESCRIPTION, 1101 PAYMENT_METHOD_ID, 0 PAYSYS_GROUP_ID, 'RUB' ISO_CURRENCY FROM dual
);

--changeset lightrevan:BALANCE-27778-mgr-c-ppp
INSERT INTO bo.t_pay_policy_part (id, firm_id, legal_entity, category, is_atypical, description)
  SELECT
    bo.s_pay_policy_part_id.nextval,
    pp.*
  FROM (
     SELECT DISTINCT
       firm_id,
       legal_entity,
       category,
       1 is_atypical,
       description
     FROM bo.t_tmp_contract_pp_rows
  ) pp;

--changeset lightrevan:BALANCE-27778-mgr-c-ppm
INSERT INTO bo.t_pay_policy_paymethod (pay_policy_part_id, payment_method_id, iso_currency, paysys_group_id)
  SELECT
    (
      SELECT id
      FROM bo.t_pay_policy_part pp
      WHERE d.firm_id = pp.firm_id
        AND nvl(d.legal_entity, -1) = nvl(pp.legal_entity, -1)
        AND nvl(d.category, '-') = nvl(pp.category, '-')
        AND nvl(d.is_atypical, -1) = nvl(pp.is_atypical, -1)
        AND d.description = pp.description
    ) pay_policy_part_id,
    payment_method_id,
    iso_currency,
    paysys_group_id
  FROM (
    SELECT DISTINCT
      firm_id,
      legal_entity,
      category,
      1 is_atypical,
      description,
      payment_method_id,
      paysys_group_id,
      iso_currency
    FROM bo.t_tmp_contract_pp_rows
  ) d;

--changeset lightrevan:BALANCE-27778-mgr-c-ppr
INSERT INTO bo.t_pay_policy_routing (region_id, service_id, is_agency, is_contract, pay_policy_part_id)
  SELECT
    d.region_id,
    d.service_id,
    d.is_agency,
    1,
    (
      SELECT id
      FROM bo.t_pay_policy_part pp
      WHERE d.firm_id = pp.firm_id
        AND nvl(d.legal_entity, -1) = nvl(pp.legal_entity, -1)
        AND nvl(d.category, '-') = nvl(pp.category, '-')
        AND nvl(d.is_atypical, -1) = nvl(pp.is_atypical, -1)
        AND d.description = pp.description
    ) pay_policy_part_id
  FROM (
    SELECT DISTINCT
      firm_id,
      legal_entity,
      category,
      1 is_atypical,
      description,
      service_id,
      region_id,
      NULL is_agency,
      1 is_contract
    FROM bo.t_tmp_contract_pp_rows
  ) d;

--changeset lightrevan:BALANCE-27778-mgr-c-tmp-t-drop
DROP TABLE bo.t_tmp_contract_pp_rows;
