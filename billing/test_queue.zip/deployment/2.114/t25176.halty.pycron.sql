--liquibase formatted sql

--changeset halty:BALANCE-25176 endDelimiter:\\

BEGIN BO.CREATE_PYCRON_TASK(
    'process-taxi-processor', --name
    'YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor.cfg.xml yb-python -pysupport balance/queue_processor.py PROCESS_TAXI', --d_command
    'Taxi orders, bonus and netting queue processor', --d_description
    'halty', --d_owner_login
    '*/5 * * * *', --s_crontab
    1, --d_count_per_host
    18000, --d_timeout
    0, --d_terminate
    'halty@yandex-team.ru', --r_email
    NULL, --s_host
    1, --s_enabled
    5, --s_retry_count
    20 --s_retry_interval
);
EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN NULL;
        WHEN OTHERS THEN RAISE;
END;
\\

