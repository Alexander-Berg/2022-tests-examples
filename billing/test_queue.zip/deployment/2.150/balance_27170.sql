--liquibase formatted sql

--changeset ashvedunov:BALANCE-27170

ALTER TABLE bo.t_person
modify legal_address_home varchar2(250 char);  


--changeset ashvedunov:BALANCE-27170-1
ALTER TABLE bo.t_person_history
modify legal_address_home varchar2(250 char);  
