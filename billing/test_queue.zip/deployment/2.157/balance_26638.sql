--liquibase formatted sql

--changeset ashvedunov:BALANCE-26638-0

ALTER TABLE BO.T_FIAS_HOUSE
ADD (
    stat_status NUMBER,
    end_dt DATE
);

TRUNCATE TABLE BO.T_FIAS_HOUSE;

