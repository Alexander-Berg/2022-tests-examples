--liquibase formatted sql

--changeset isupov:BALANCE-20954-insert-config

insert into bo.t_config(item, "DESC", value_num) values('USE_ACTS_NEW_GROUP', 'Turn on split before group', 1);
