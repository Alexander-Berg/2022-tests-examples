--liquibase formatted sql

--changeset lightrevan:BALANCE-28185-turn-on-rows

MERGE INTO bo.t_extprops ep
USING (
    SELECT
      /*parallel(8)*/
      object_id,
      classname,
      'tmp_turn_on_rows' attr_name,
      value_num
    FROM bo.t_extprops
    WHERE classname = 'Request'
      AND attrname = 'turn_on_rows'
      AND nvl(value_num, 0) != 0
  ) d
ON (ep.object_id = d.object_id AND ep.classname = d.classname AND ep.attrname = d.attr_name)
WHEN NOT MATCHED THEN INSERT (id, object_id, classname, attrname, value_num)
  VALUES (bo.s_extprops.nextval, d.object_id, d.classname, d.attr_name, d.value_num)
;
