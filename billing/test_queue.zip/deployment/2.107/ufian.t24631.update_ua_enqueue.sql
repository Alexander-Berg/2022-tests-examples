--liquibase formatted sql

--changeset ufian:BALANCE-24631

update bo.t_pycron_descr
  set command = 'yb-python -pysupport cluster_tools/unified_account.py --enqueue 1000'
where name = 'unified_account_transfer_queue';
