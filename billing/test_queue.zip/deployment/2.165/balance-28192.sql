--liquibase formatted sql

--changeset el-yurchito:BALANCE-28192-1 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_UI_CONTRACT" AS
SELECT
  co.ID,
  co.ID AS contract_id,
  co.external_id AS contract_eid,
  f3.dt AS dt,
  f2.value_dt AS finish_dt,
  f12.value_dt AS sent_dt,
  sf_nullif (f4.value_num, 0) AS manager_code,
  m.NAME AS manager_name,
  m.login AS manager_login,
  m.email AS manager_email,
  sf_nullif (clients.ID, 0) AS client_id,
  clients.NAME AS client_name,
  sf_nullif (agencies.ID, 0) AS agency_id,
  agencies.NAME AS agency_name,
  sf_nullif (co.person_id, 0) AS person_id,
  p.NAME AS person_name,
  p.inn AS person_inn,
  com.value_num AS commission,
  f1.value_num AS wo_nds,
  f5.value_num AS commission_type,
  f6.value_num AS supercommission,
  f7.value_num AS payment_type,
  cl.is_signed AS is_signed,
  cl.is_faxed AS is_faxed,
  cl.is_cancelled AS is_cancelled,
  f8.value_num AS payment_term,
  f9.value_num AS discount_pct,
  f10.value_num AS discount_fixed,
  f13.value_num AS is_booked,
  f14.value_dt AS is_booked_dt,
  f15.value_dt AS is_suspended,
  f11.services
FROM
  "BO"."T_CONTRACT2" co
    LEFT OUTER JOIN
  "BO"."T_CONTRACT_COLLATERAL" cl
      ON cl.contract2_id = co.ID AND cl.num IS NULL
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" com
      ON com.contract_id = co.ID AND com.code = 'COMMISSION'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f1
      ON f1.contract_id = co.ID AND f1.code = 'DISCARD_NDS'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f2
      ON f2.contract_id = co.ID AND f2.code = 'FINISH_DT'
    LEFT OUTER JOIN
  (SELECT ID, MIN (dt) dt
   FROM (
     SELECT co.ID ID, cl.dt dt
     FROM "BO"."T_CONTRACT2" co, "BO"."T_CONTRACT_COLLATERAL" cl
     WHERE cl.contract2_id = co.ID
   )
   GROUP BY ID) f3
      ON f3.ID = co.ID
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f4
      ON f4.contract_id = co.ID AND f4.code = 'MANAGER_CODE'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f5
      ON f5.contract_id = co.ID AND f5.code = 'COMMISSION_TYPE'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f6
      ON f6.contract_id = co.ID AND f6.code = 'SUPERCOMMISSION'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f7
      ON f7.contract_id = co.ID AND f7.code = 'PAYMENT_TYPE'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f8
      ON f8.contract_id = co.ID AND f8.code = 'PAYMENT_TERM'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f9
      ON f9.contract_id = co.ID AND f9.code = 'DISCOUNT_PCT'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f10
      ON f10.contract_id = co.ID AND f10.code = 'DISCOUNT_FIXED'
    LEFT OUTER JOIN
  "BO"."T_CONTRACT_ATTRIBUTES" f12
      ON f12.attribute_batch_id = cl.attribute_batch_id AND f12.CODE = 'SENT_DT'
    LEFT OUTER JOIN
   "BO"."V_CONTRACT_SIGNED_ATTR" f13
      ON f13.contract_id = co.ID AND f13.code = 'IS_BOOKED'
    LEFT OUTER JOIN
   "BO"."V_CONTRACT_SIGNED_ATTR" f14
      ON f14.contract_id = co.ID AND f14.code = 'IS_BOOKED_DT'
    LEFT OUTER JOIN
   "BO"."V_CONTRACT_SIGNED_ATTR" f15
      ON f15.contract_id = co.ID AND f15.code = 'IS_SUSPENDED'
    LEFT OUTER JOIN
  "BO"."T_MANAGER" m
      ON m.manager_code = f4.value_num
    LEFT OUTER JOIN
  "BO"."V_PERSON" p
      ON p.ID = co.person_id
    LEFT OUTER JOIN
  "BO"."T_CLIENT" clients
      ON co.client_id = clients.ID AND clients.is_agency = 0
    LEFT OUTER JOIN
  "BO"."T_CLIENT" agencies
      ON co.client_id = agencies.ID AND agencies.is_agency <> 0
    LEFT OUTER JOIN
  (SELECT
     contract_id,
     LTRIM(EXTRACT(xmlagg(xmlelement( "V", ', ' || s.name ) ), '/V/text()') , ',') services
   FROM
     "BO"."V_CONTRACT_LAST_ATTR" la
      LEFT OUTER JOIN
     "BO"."T_SERVICE" s
       ON s.id = la.key_num
   WHERE
     code = 'SERVICES' AND value_num = 1
   GROUP BY contract_id) f11
      ON f11.contract_id = co.ID
WHERE
  co.TYPE = 'GENERAL'
\\


--changeset el-yurchito:BALANCE-28192-2 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_CONTRACT_SIGNED_ATTR_HISTORY" AS
SELECT
  ca.ID,
  ca.COLLATERAL_ID,
  ca.ATTRIBUTE_BATCH_ID,
  ca.DT,
  ca.CODE,
  ca.KEY_NUM,
  cast(ca.VALUE_STR || dbms_lob.substr(ca.VALUE_CLOB, 512, 1) as varchar2(512 CHAR)) VALUE_STR,
  ca.VALUE_NUM,
  ca.VALUE_DT,
  ca.UPDATE_DT,
  ca.PASSPORT_ID,
  cl.contract2_id,
  cl.dt cl_dt,
  cl.id cl_id,
  TO_CHAR (cl.dt, 'YYYYMMDD')
  || TO_CHAR (cl.ID, '00000000000000000000') stamp
FROM
  "BO"."T_CONTRACT_COLLATERAL" cl
  JOIN "BO"."T_CONTRACT_ATTRIBUTES" ca ON ca.attribute_batch_id = cl.attribute_batch_id
  LEFT JOIN "BO"."T_CONTRACT_COLLATERAL_TYPES" clt ON cl.collateral_type_id = clt.id
  JOIN "BO"."T_CONTRACT_COLLATERAL" cl0 ON cl.contract2_id = cl0.contract2_id AND cl0.num IS NULL AND cl0.collateral_type_id IS NULL
  LEFT JOIN "BO"."T_CONTRACT_ATTRIBUTES" cat ON cl0.attribute_batch_id = cat.attribute_batch_id AND cat.code = 'TEST_MODE'
WHERE
  cl0.is_cancelled is NULL
  AND cl.is_cancelled is NULL
  AND (
    cl.is_signed              is not NULL
    OR cl.is_faxed            is not NULL
    OR clt.collateral_class = 'ANNOUNCEMENT'
    OR nvl(cat.value_num,0) = 1
  )
\\

--changeset el-yurchito:BALANCE-28192-3 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_CONTRACT_SIGNED_ATTR2" AS
SELECT
  "ID", "COLLATERAL_ID", "ATTRIBUTE_BATCH_ID", "DT", "CODE", "KEY_NUM", "VALUE_STR", "VALUE_NUM", "VALUE_DT",
  "UPDATE_DT", "PASSPORT_ID", "CONTRACT2_ID", "CL_DT", "CL_ID", "STAMP"
FROM
  "BO"."V_CONTRACT_SIGNED_ATTR_HISTORY"
WHERE
  cl_dt < SYSDATE
\\

--changeset el-yurchito:BALANCE-28192-4 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_DISTR_CONTRACT_DOWNLOAD_PROD" AS
SELECT
  "CONTRACT_ID", "COLLATERAL_ID", "DT", "END_DT", "PAGE_ID", "PRICE", "PRICE_CURRENCY"
FROM (
  SELECT
      c.id contract_id,
      ca.collateral_id,
      CASE
        WHEN cl.id = cl0.id AND nvl(ca2.value_num, 1) NOT IN (3, 4, 6)
          THEN cl.dt - 365
        WHEN cl.id = cl0.id AND nvl(ca2.value_num, 1) IN (3, 4, 6)
          THEN nvl(ca3.value_dt,cl.dt)
        ELSE cl.dt
      END dt,
      (lead(cl.dt) OVER (PARTITION BY c.id, ca.key_num ORDER BY cl.dt) ) - 1  AS end_dt,
      ca.key_num page_id,
      ca.value_num price,
      ca4.value_num price_currency
  FROM
      bo.t_contract2 c,
      bo.v_contract_signed_attr2 ca,
      bo.v_contract_signed_attr2 ca2,
      bo.v_contract_signed_attr2 ca3,
      bo.v_contract_signed_attr2 ca4,
      bo.t_contract_collateral cl,
      bo.t_contract_collateral cl0
  WHERE
      c.id = cl0.contract2_id AND cl0.is_cancelled IS NULL AND cl0.num IS NULL AND cl0.collateral_type_id IS NULL AND cl.is_cancelled IS NULL
      AND cl.attribute_batch_id = ca.attribute_batch_id AND ca.contract2_id = c.id AND ca.code = 'PRODUCTS_DOWNLOAD'
      AND cl0.attribute_batch_id = ca2.attribute_batch_id AND ca2.code = 'CONTRACT_TYPE'
      AND cl0.attribute_batch_id = ca3.attribute_batch_id (+) AND ca3.code (+) = 'SERVICE_START_DT'
      AND cl.attribute_batch_id  = ca4.attribute_batch_id (+) AND ca4.code (+) = 'PRODUCTS_CURRENCY'
  UNION ALL
  SELECT
      c.id contract_id,
      ca.collateral_id,
      CASE
        WHEN cl.id = cl0.id AND nvl(ca2.value_num, 1) NOT IN (3, 4, 6)
          THEN cl.dt - 365
        WHEN cl.id = cl0.id AND nvl(ca2.value_num, 1) IN (3, 4, 6)
          THEN nvl(ca3.value_dt,cl.dt)
        ELSE cl.dt
      END dt,
      (lead(cl.dt) OVER (PARTITION BY c.id, ca.code ORDER BY cl.dt) ) - 1  AS end_dt,
      decode(ca.code,
        'INSTALL_PRICE', 10001,
        'ADVISOR_PRICE', 2080,
        'ACTIVATION_PRICE', 3010,
        100005) page_id,
      ca.value_num price,
      ca4.value_num price_currency
  FROM
      bo.t_contract2 c,
      bo.v_contract_signed_attr2 ca,
      bo.v_contract_signed_attr2 ca2,
      bo.v_contract_signed_attr2 ca3,
      bo.v_contract_signed_attr2 ca4,
      bo.t_contract_collateral cl,
      bo.t_contract_collateral cl0
  WHERE
      c.id = cl0.contract2_id AND cl0.is_cancelled IS NULL AND cl0.num IS NULL AND cl0.collateral_type_id IS NULL AND cl.is_cancelled IS NULL
      AND cl.attribute_batch_id = ca.attribute_batch_id AND ca.contract2_id = c.id
      AND cl0.attribute_batch_id = ca2.attribute_batch_id AND ca2.code = 'CONTRACT_TYPE'
      AND (
        (ca.code in ('INSTALL_PRICE', 'ADVISOR_PRICE', 'ACTIVATION_PRICE') AND cl.attribute_batch_id = ca4.attribute_batch_id AND ca4.code = 'PRODUCTS_CURRENCY')
        OR (ca.code = 'SEARCH_PRICE' AND cl.attribute_batch_id = ca4.attribute_batch_id AND ca4.code = 'SEARCH_CURRENCY')
      )
      AND cl0.attribute_batch_id = ca3.attribute_batch_id (+) AND ca3.code (+) = 'SERVICE_START_DT'
)
WHERE
  price IS NOT NULL
\\

--changeset el-yurchito:BALANCE-28192-5 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_DISTR_CONTRACT_REVSHARE_PROD" AS
SELECT "CONTRACT_ID", "COLLATERAL_ID", "DT", "END_DT", "PAGE_ID", "PARTNER_PCT"
FROM (
  SELECT
    c.id contract_id,
    ca.collateral_id,
    CASE
      WHEN cl.id = cl0.id AND nvl(ca2.value_num, 1) NOT IN (3, 4, 6)
        THEN cl.dt - 365
      WHEN cl.id = cl0.id AND nvl(ca2.value_num, 1) IN (3, 4, 6)
        THEN nvl(ca3.value_dt,cl.dt)
      ELSE cl.dt
    END dt,
    (lead(cl.dt) OVER (PARTITION BY c.id, ca.key_num ORDER BY cl.dt) ) - 1  AS end_dt,
    ca.key_num page_id,
    ca.value_num partner_pct
  FROM
      bo.t_contract2 c,
      bo.v_contract_signed_attr2 ca,
      bo.v_contract_signed_attr2 ca2,
      bo.v_contract_signed_attr2 ca3,
      bo.t_contract_collateral cl,
      bo.t_contract_collateral cl0
  WHERE
      c.id = cl0.contract2_id AND cl0.is_cancelled IS NULL AND cl0.num IS NULL AND cl0.collateral_type_id IS NULL AND cl.is_cancelled IS NULL
      AND cl.attribute_batch_id = ca.attribute_batch_id AND ca.contract2_id = c.id AND ca.code = 'PRODUCTS_REVSHARE'
      AND cl0.attribute_batch_id = ca2.attribute_batch_id AND ca2.code = 'CONTRACT_TYPE'
      AND cl0.attribute_batch_id = ca3.attribute_batch_id (+) AND ca3.code (+) = 'SERVICE_START_DT'
)
WHERE
    partner_pct IS NOT NULL
\\

--changeset el-yurchito:BALANCE-28192-6 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_DISTR_FIXED_CONTRACT_PROD" AS
SELECT
  "CONTRACT_ID", "COLLATERAL_ID", "DT", "END_DT", "PAGE_ID", "PRICE"
FROM (
  SELECT
    c.id contract_id,
    ca.collateral_id,
    cl.dt,
    (lead(cl.dt) OVER (PARTITION BY c.id, ca.key_num ORDER BY cl.dt) ) - 1  AS end_dt,
    ca.key_num page_id,
    ca.value_num price
  FROM
      bo.t_contract2 c,
      bo.v_contract_signed_attr2 ca,
      bo.t_contract_collateral cl
  WHERE
      (cl.is_signed IS NOT NULL OR cl.is_faxed IS NOT NULL) AND cl.is_cancelled IS NULL AND
      cl.attribute_batch_id = ca.attribute_batch_id AND ca.contract2_id = c.id AND
      ca.code = 'PRODUCTS_DOWNLOAD'
  UNION ALL
  SELECT
    c.id contract_id,
    ca.collateral_id,
    cl.dt,
    (lead(cl.dt) OVER (PARTITION BY c.id, ca.key_num ORDER BY cl.dt) ) - 1  AS end_dt,
    10001 page_id,
    ca.value_num price
  FROM
      bo.t_contract2 c,
      bo.v_contract_signed_attr2 ca,
      bo.t_contract_collateral cl
  WHERE
      (cl.is_signed IS NOT NULL OR cl.is_faxed IS NOT NULL) AND cl.is_cancelled IS NULL AND
      cl.attribute_batch_id = ca.attribute_batch_id AND ca.contract2_id = c.id AND
      ca.code = 'INSTALL_PRICE'
)
WHERE
  price IS NOT NULL
\\

--changeset el-yurchito:BALANCE-28192-7 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_DISTRIBUTION_CONTRACT" (
    "CLIENT_ID", "PERSON_ID", "ID", "PARENT_CONTRACT_ID", "CONTRACT_START_DT", "DT", "EXTERNAL_ID", "MANAGER_UID",
    "MANAGER_INTERNAL_UID", "COLLATERAL_ID", "IS_SIGNED", "IS_FAXED", "END_DT", "TAILLESS_END_DT", "NDS",
    "CONTRACT_END_DT", "TAIL_TIME", "AVG_DISCOUNT_PCT", "CONTRACT_TYPE", "TEST_MODE", "INSTALL_PRICE", "ADVISOR_PRICE",
    "ACTIVATION_PRICE", "SEARCH_PRICE", "REWARD_TYPE", "CURRENCY", "ISO_CURRENCY", "UNI_HAS_REVSHARE", "UNI_HAS_FIXED",
    "UNI_HAS_SEARCHES", "UNI_HAS_ADDAPTER_RET", "UNI_HAS_ADDAPTER_DEV", "FIXED_SCALE_ID", "CURRENCY_CALCULATION",
    "TAG_ID", "PRODUCTS_CURRENCY", "SEARCH_CURRENCY", "PLATFORM_TYPE", "FIRM_ID", "PAYMENT_TYPE"
) AS
  SELECT
    c.client_id,
    c.person_id,
    c.id,
    last_value(ca21.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS parent_contract_id,
    cl.dt AS contract_start_dt,
    CASE
      WHEN cl.id = cl0.id
        THEN nvl(ca14.value_dt,cl.dt)
      ELSE cl.dt
    END dt,
    c.external_id,
    last_value(mngr.passport_id IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS manager_uid,
    last_value(mngr.domain_passport_id IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS manager_internal_uid,
    cl.id AS collateral_id,
    cl.is_signed,
    cl.is_faxed,
    nvl(
      lead (cl.dt-1) OVER (PARTITION BY c.id ORDER BY cl.dt),
      bo.sf_add_months(
        last_value(ca3.value_dt IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt),
        nvl(last_value(ca4.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0)
      )
    ) AS end_dt,
    nvl(
      lead (cl.dt-1) OVER (PARTITION BY c.id ORDER BY cl.dt),
      last_value(ca3.value_dt IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt)
    ) AS tailless_end_dt,
    last_value(ca1.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS nds,
    last_value(ca3.value_dt IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS contract_end_dt,
    last_value(ca4.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS tail_time,
    last_value(ca15.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS avg_discount_pct,
    ca6.value_num AS contract_type,
    nvl(ca5.value_num,0) AS test_mode,
    nvl(last_value(ca7.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS install_price,
    nvl(last_value(ca22.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS advisor_price,
    nvl(last_value(ca23.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS activation_price,
    nvl(last_value(ca24.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS search_price,
    nvl(last_value(ca8.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 1) AS reward_type,
    upper(nvl(cr.char_code, cr.iso_code)) AS currency,
    iso_cur.alpha_code AS iso_currency,
    nvl(last_value(ca10.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS uni_has_revshare,
    nvl(last_value(ca11.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS uni_has_fixed,
    nvl(last_value(ca12.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS uni_has_searches,
    nvl(last_value(ca27.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS uni_has_addapter_ret,
    nvl(last_value(ca28.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS uni_has_addapter_dev,
    nvl(last_value(ca16.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS fixed_scale_id,
    nvl(last_value(ca17.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) AS currency_calculation,
    nvl(ca18.value_num, 0) AS tag_id,
    last_value(ca19.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS products_currency,
    last_value(ca20.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS search_currency,
    last_value(ca25.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS platform_type,
    last_value(ca26.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS firm_id,
    last_value(ca30.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) AS payment_type
  FROM
    bo.t_contract2 c
    LEFT JOIN bo.t_contract_collateral cl ON cl.contract2_id = c.id and nvl(cl.collateral_type_id, 0) != 3040
    LEFT JOIN bo.t_contract_collateral cl0 ON cl0.contract2_id = c.id and cl0.collateral_type_id is null and cl0.num is null
    LEFT OUTER JOIN bo.t_contract_attributes ca1 ON cl.attribute_batch_id = ca1.attribute_batch_id and ca1.code = 'NDS'
    LEFT OUTER JOIN bo.t_contract_attributes ca3 ON cl.attribute_batch_id = ca3.attribute_batch_id and ca3.code = 'END_DT'
    LEFT OUTER JOIN bo.t_contract_attributes ca4 ON cl.attribute_batch_id = ca4.attribute_batch_id and ca4.code = 'TAIL_TIME'
    LEFT OUTER JOIN bo.t_contract_attributes ca5 on cl0.attribute_batch_id = ca5.attribute_batch_id and ca5.code = 'TEST_MODE'
    LEFT OUTER JOIN bo.t_contract_attributes ca6 on cl0.attribute_batch_id = ca6.attribute_batch_id and ca6.code = 'CONTRACT_TYPE'
    LEFT OUTER JOIN bo.t_contract_attributes ca7 on cl.attribute_batch_id = ca7.attribute_batch_id and ca7.code = 'INSTALL_PRICE'
    LEFT OUTER JOIN bo.t_contract_attributes ca8 on cl.attribute_batch_id = ca8.attribute_batch_id and ca8.code = 'REWARD_TYPE'
    LEFT OUTER JOIN bo.t_contract_attributes ca10 on cl.attribute_batch_id = ca10.attribute_batch_id and ca10.code = 'SUPPLEMENTS' and ca10.key_num = 1 and ca10.value_num = 1
    LEFT OUTER JOIN bo.t_contract_attributes ca11 on cl.attribute_batch_id = ca11.attribute_batch_id and ca11.code = 'SUPPLEMENTS' and ca11.key_num = 2 and ca11.value_num = 1
    LEFT OUTER JOIN bo.t_contract_attributes ca12 on cl.attribute_batch_id = ca12.attribute_batch_id and ca12.code = 'SUPPLEMENTS' and ca12.key_num = 3 and ca12.value_num = 1
    LEFT OUTER JOIN bo.t_contract_attributes ca27 on cl.attribute_batch_id = ca27.attribute_batch_id and ca27.code = 'SUPPLEMENTS' and ca27.key_num = 4 and ca27.value_num = 1
    LEFT OUTER JOIN bo.t_contract_attributes ca28 on cl.attribute_batch_id = ca28.attribute_batch_id and ca28.code = 'SUPPLEMENTS' and ca28.key_num = 5 and ca28.value_num = 1
    LEFT OUTER JOIN bo.t_contract_attributes ca13 on cl0.attribute_batch_id = ca13.attribute_batch_id and ca13.code = 'CURRENCY'
    LEFT OUTER JOIN bo.t_contract_attributes ca14 on cl0.attribute_batch_id = ca14.attribute_batch_id and ca14.code = 'SERVICE_START_DT'
    LEFT OUTER JOIN bo.t_contract_attributes ca15 on cl.attribute_batch_id = ca15.attribute_batch_id and ca15.code = 'AVG_DISCOUNT_PCT'
    LEFT OUTER JOIN bo.t_contract_attributes ca16 on cl.attribute_batch_id = ca16.attribute_batch_id and ca16.code = 'FIXED_SCALE'
    LEFT OUTER JOIN bo.t_contract_attributes ca17 on cl.attribute_batch_id = ca17.attribute_batch_id and ca17.code = 'CURRENCY_CALCULATION'
    LEFT OUTER JOIN bo.t_contract_attributes ca18 on cl0.attribute_batch_id = ca18.attribute_batch_id and ca18.code = 'DISTRIBUTION_TAG'
    LEFT OUTER JOIN bo.t_contract_attributes ca19 on cl.attribute_batch_id = ca19.attribute_batch_id and ca19.code = 'PRODUCTS_CURRENCY'
    LEFT OUTER JOIN bo.t_contract_attributes ca20 on cl.attribute_batch_id = ca20.attribute_batch_id and ca20.code = 'SEARCH_CURRENCY'
    LEFT OUTER JOIN bo.t_contract_attributes ca21 on cl.attribute_batch_id = ca21.attribute_batch_id and ca21.code = 'PARENT_CONTRACT_ID'
    LEFT OUTER JOIN bo.t_contract_attributes ca22 on cl.attribute_batch_id = ca22.attribute_batch_id and ca22.code = 'ADVISOR_PRICE'
    LEFT OUTER JOIN bo.t_contract_attributes ca23 on cl.attribute_batch_id = ca23.attribute_batch_id and ca23.code = 'ACTIVATION_PRICE'
    LEFT OUTER JOIN bo.t_contract_attributes ca24 on cl.attribute_batch_id = ca24.attribute_batch_id and ca24.code = 'SEARCH_PRICE'
    LEFT OUTER JOIN bo.t_contract_attributes ca25 on cl.attribute_batch_id = ca25.attribute_batch_id and ca25.code = 'PLATFORM_TYPE'
    LEFT OUTER JOIN bo.t_contract_attributes ca26 on cl.attribute_batch_id = ca26.attribute_batch_id and ca26.code = 'FIRM'
    LEFT OUTER JOIN bo.t_contract_attributes ca29 on cl.attribute_batch_id = ca29.attribute_batch_id and ca29.code = 'MANAGER_CODE'
    LEFT OUTER JOIN bo.t_contract_attributes ca30 on cl.attribute_batch_id = ca30.attribute_batch_id and ca30.code = 'PAYMENT_TYPE'
    LEFT OUTER JOIN bo.t_manager_inner mngr on ca29.value_num = mngr.manager_code
    LEFT JOIN bo.t_currency cr ON cr.iso_num_code = ca13.value_num
    LEFT JOIN bo.t_iso_currency iso_cur ON iso_cur.num_code = decode(ca13.value_num, 810, 643, ca13.value_num)
  WHERE
    CL.IS_CANCELLED IS NULL
    AND CL0.IS_CANCELLED IS NULL
    AND ((CL.IS_SIGNED IS NOT NULL OR CL.IS_FAXED IS NOT NULL) OR (nvl(ca5.value_num,0) = 1))
    AND C.TYPE = 'DISTRIBUTION'
\\

--changeset el-yurchito:BALANCE-28192-8 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_PARTNER_CONTRACT_PUTTEE" AS
SELECT
  c.client_id,
  c.person_id,
  c.id,
  CASE
    WHEN cl.id = col0.id
      THEN nvl(f18.value_dt, cl.dt)
    ELSE cl.dt
  END dt,
  c.external_id,
  nvl(last_value(f16.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 1) reward_type,
  last_value(f2.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) partner_pct,
  last_value(f3.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) agregator_pct,
  last_value(f15.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) dsp_agregation_pct,
  last_value(f14.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) contract_type,
  last_value(f4.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) doc_set,
  last_value(f5.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) payment_type,
  last_value(f7.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) bm_direct_pct,
  last_value(f8.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) bm_market_pct,
  last_value(f1.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) nds,
  last_value(f9.value_dt IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) contract_end_dt,
  last_value(f10.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) search_forms,
  last_value(f11.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) market_banner,
  nvl(lead (cl.dt-1) OVER (PARTITION BY c.id ORDER BY cl.dt),
    last_value(f9.value_dt IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt)
  ) AS end_dt,
  nvl(f12.value_num, 1) firm_id,
  last_value(f13.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) market_api_pct,
  last_value(f17.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) test_mode
FROM
  bo.t_contract2 c
  LEFT JOIN bo.t_contract_collateral cl ON cl.contract2_id = c.id
  LEFT JOIN bo.t_contract_collateral col0 ON col0.contract2_id = c.id
  LEFT OUTER JOIN bo.t_contract_collateral_types coltype on cl.collateral_type_id = coltype.id
  LEFT OUTER JOIN bo.t_contract_attributes f1 ON f1.attribute_batch_id = cl.attribute_batch_id AND f1.code = 'NDS'
  LEFT OUTER JOIN bo.t_contract_attributes f2 ON f2.attribute_batch_id = cl.attribute_batch_id AND f2.code = 'PARTNER_PCT'
  LEFT OUTER JOIN bo.t_contract_attributes f3 ON f3.attribute_batch_id = cl.attribute_batch_id AND f3.code = 'AGREGATOR_PCT'
  LEFT OUTER JOIN bo.t_contract_attributes f4 ON f4.attribute_batch_id = cl.attribute_batch_id AND f4.code = 'DOC_SET'
  LEFT OUTER JOIN bo.t_contract_attributes f5 ON f5.attribute_batch_id = cl.attribute_batch_id AND f5.code = 'PAYMENT_TYPE'
  LEFT OUTER JOIN bo.t_contract_attributes f7 ON f7.attribute_batch_id = cl.attribute_batch_id AND f7.code = 'BM_DIRECT_PCT'
  LEFT OUTER JOIN bo.t_contract_attributes f8 ON f8.attribute_batch_id = cl.attribute_batch_id AND f8.code = 'BM_MARKET_PCT'
  LEFT OUTER JOIN bo.t_contract_attributes f9 ON f9.attribute_batch_id = cl.attribute_batch_id AND f9.code = 'END_DT'
  LEFT OUTER JOIN bo.t_contract_attributes f10 ON f10.attribute_batch_id = cl.attribute_batch_id AND f10.code = 'SEARCH_FORMS'
  LEFT OUTER JOIN bo.t_contract_attributes f11 ON f11.attribute_batch_id = cl.attribute_batch_id AND f11.code = 'MARKET_BANNER'
  LEFT OUTER JOIN bo.t_contract_attributes f12 ON f12.attribute_batch_id = col0.attribute_batch_id AND f12.code = 'FIRM'
  LEFT OUTER JOIN bo.t_contract_attributes f13 ON f13.attribute_batch_id = cl.attribute_batch_id AND f13.code = 'MARKET_API_PCT'
  LEFT OUTER JOIN bo.t_contract_attributes f14 ON f14.attribute_batch_id = col0.attribute_batch_id AND f14.code = 'CONTRACT_TYPE'
  LEFT OUTER JOIN bo.t_contract_attributes f15 ON f15.attribute_batch_id = cl.attribute_batch_id AND f15.code = 'DSP_AGREGATION_PCT'
  LEFT OUTER JOIN bo.t_contract_attributes f16 ON f16.attribute_batch_id = cl.attribute_batch_id AND f16.code = 'REWARD_TYPE'
  LEFT OUTER JOIN bo.t_contract_attributes f17 ON f17.attribute_batch_id = cl.attribute_batch_id AND f17.code = 'TEST_MODE'
  LEFT OUTER JOIN bo.t_contract_attributes f18 ON f18.attribute_batch_id = cl.attribute_batch_id AND f18.code = 'SERVICE_START_DT'
WHERE
  c.type = 'PARTNERS' AND cl.is_cancelled IS NULL AND col0.collateral_type_id IS NULL AND col0.num IS NULL
  AND (coltype.collateral_class = 'ANNOUNCEMENT' OR cl.is_signed IS NOT NULL OR cl.is_faxed IS NOT NULL OR f17.value_num = 1)
  AND nvl(cl.collateral_type_id, 0) != 2040
\\

--changeset el-yurchito:BALANCE-28192-9 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_PARTNER_MARKET_NPP_CONTRACT" AS
SELECT
  contract_id,
  start_dt,
  max(nvl(end_dt, date'9999-01-01')) end_dt,
  max(client_id) client_id,
  max(person_type) person_type,
  max(firm_id) firm_id,
  max(currency_id) currency_id,
  max(payment_type) payment_type
FROM (
  SELECT
    c.id contract_id,
    c.client_id client_id,
    p.type person_type,
    last_value(ca5.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) firm_id,
    last_value(ca2.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) currency_id,
    last_value(ca4.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) payment_type,
    cl.dt start_dt,
    nvl(
        lead (cl.dt) OVER (PARTITION BY c.id ORDER BY cl.dt),
        last_value(ca3.value_dt IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt)
    ) end_dt
  FROM
    "BO"."T_CONTRACT2" c
    INNER JOIN "BO"."T_PERSON" p on p.id = c.person_id
    LEFT JOIN "BO"."T_CONTRACT_COLLATERAL" cl ON cl.contract2_id = c.id
    LEFT JOIN "BO"."T_CONTRACT_ATTRIBUTES" ca1 ON cl.attribute_batch_id = ca1.attribute_batch_id and ca1.code = 'COMMISSION'
    LEFT JOIN "BO"."T_CONTRACT_ATTRIBUTES" ca2 ON cl.attribute_batch_id = ca2.attribute_batch_id and ca2.code = 'CURRENCY'
    LEFT JOIN "BO"."T_CONTRACT_ATTRIBUTES" ca3 ON cl.attribute_batch_id = ca3.attribute_batch_id and ca3.code = 'FINISH_DT'
    LEFT JOIN "BO"."T_CONTRACT_ATTRIBUTES" ca4 ON cl.attribute_batch_id = ca4.attribute_batch_id and ca4.code = 'PAYMENT_TYPE'
    LEFT JOIN "BO"."T_CONTRACT_ATTRIBUTES" ca5 ON cl.attribute_batch_id = ca5.attribute_batch_id and ca5.code = 'FIRM'
  WHERE
    c.type = 'GENERAL'
    AND cl.is_cancelled IS NULL
    AND (cl.is_signed IS NOT NULL OR cl.is_faxed IS NOT NULL)
    AND exists (
      SELECT 1
      FROM "BO"."T_CONTRACT_ATTRIBUTES"
      WHERE
        attribute_batch_id = cl.attribute_batch_id
        AND code = 'SERVICES'
        AND key_num IN (139, 205, 601, 602)
        AND value_num = 1
    )
)
GROUP BY
  contract_id, start_dt
\\

--changeset el-yurchito:BALANCE-28192-10 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_PARTNER_TAXI_CONTRACT" AS
SELECT
  contract_id,
  start_dt,
  max(nvl(end_dt, date'9999-01-01')) end_dt,
  max(client_id) client_id,
  max(person_type) person_type,
  max(firm_id) firm_id,
  max(commission_type) commission_type,
  max(commission_pct) commission_pct,
  max(commission_pct_card) commission_pct_card,
  max(commission_sum) commission_sum,
  max(currency_id) currency_id,
  max(min_commission_sum) min_commission_sum,
  max(max_commission_sum) max_commission_sum,
  max(advance_payment_sum) advance_payment_sum,
  max(payment_type) payment_type,
  max(service_min_cost) service_min_cost,
  max(card_enabled) card_enabled,
  max(cash_enabled) cash_enabled
FROM (
  SELECT
    c.id contract_id,
    c.client_id client_id,
    p.type person_type,
    last_value(ca15.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) firm_id,
    last_value(ca3.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) commission_type,
    nvl(last_value(ca4.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) commission_pct,
    nvl(last_value(ca13.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) commission_pct_card,
    last_value(ca5.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) commission_sum,
    last_value(ca6.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) currency_id,
    last_value(ca8.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) min_commission_sum,
    last_value(ca14.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) max_commission_sum,
    last_value(ca9.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) advance_payment_sum,
    last_value(ca10.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt) payment_type,
    cl.dt start_dt,
    nvl(lead (cl.dt) OVER (PARTITION BY c.id ORDER BY cl.dt),
    last_value(ca7.value_dt IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt)
    ) end_dt,
    ca11.value_num service_min_cost,
    nvl(last_value(ca2.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) cash_enabled,
    nvl(last_value(ca12.value_num IGNORE NULLS) OVER (PARTITION BY c.id ORDER BY cl.dt), 0) card_enabled
  FROM
    bo.t_contract2 c
    join bo.t_person p ON p.id = c.person_id
    LEFT JOIN bo.t_contract_collateral cl ON cl.contract2_id = c.id
    LEFT JOIN bo.t_contract_collateral cl0 ON cl0.contract2_id = c.id AND cl0.collateral_type_id IS NULL AND cl0.num IS NULL
    LEFT JOIN bo.t_contract_attributes ca1 ON cl0.attribute_batch_id = ca1.attribute_batch_id AND ca1.code = 'COMMISSION'
    LEFT JOIN bo.t_contract_attributes ca2 ON cl0.attribute_batch_id = ca2.attribute_batch_id AND ca2.code = 'SERVICES' AND nvl(ca2.key_num, 666) = 111
    LEFT JOIN bo.t_contract_attributes ca3 ON cl.attribute_batch_id = ca3.attribute_batch_id AND ca3.code = 'PARTNER_COMMISSION_TYPE'
    LEFT JOIN bo.t_contract_attributes ca4 ON cl.attribute_batch_id = ca4.attribute_batch_id AND ca4.code = 'PARTNER_COMMISSION_PCT'
    LEFT JOIN bo.t_contract_attributes ca5 ON cl.attribute_batch_id = ca5.attribute_batch_id AND ca5.code = 'PARTNER_COMMISSION_SUM'
    LEFT JOIN bo.t_contract_attributes ca6 ON cl0.attribute_batch_id = ca6.attribute_batch_id AND ca6.code = 'CURRENCY'
    LEFT JOIN bo.t_contract_attributes ca7 ON cl.attribute_batch_id = ca7.attribute_batch_id AND ca7.code = 'FINISH_DT'
    LEFT JOIN bo.t_contract_attributes ca8 ON cl.attribute_batch_id = ca8.attribute_batch_id AND ca8.code = 'PARTNER_MIN_COMMISSION_SUM'
    LEFT JOIN bo.t_contract_attributes ca9 ON cl.attribute_batch_id = ca9.attribute_batch_id AND ca9.code = 'ADVANCE_PAYMENT_SUM'
    LEFT JOIN bo.t_contract_attributes ca10 ON cl.attribute_batch_id = ca10.attribute_batch_id AND ca10.code = 'PAYMENT_TYPE'
    LEFT JOIN bo.t_contract_attributes ca11 ON cl.attribute_batch_id = ca11.attribute_batch_id AND ca11.code = 'SERVICE_MIN_COST'
    LEFT JOIN bo.t_contract_attributes ca12 ON cl.attribute_batch_id = ca12.attribute_batch_id AND ca12.code = 'SERVICES' and nvl(ca12.key_num, 666) = 128
    LEFT JOIN bo.t_contract_attributes ca13 ON cl.attribute_batch_id = ca13.attribute_batch_id AND ca13.code = 'PARTNER_COMMISSION_PCT2'
    LEFT JOIN bo.t_contract_attributes ca14 ON cl.attribute_batch_id = ca14.attribute_batch_id AND ca14.code = 'PARTNER_MAX_COMMISSION_SUM'
    LEFT JOIN bo.t_contract_attributes ca15 ON cl.attribute_batch_id = ca15.attribute_batch_id AND ca15.code = 'FIRM'
  WHERE
    c.type = 'GENERAL' AND cl.is_cancelled IS NULL AND cl0.is_cancelled IS NULL
    AND (cl.is_signed IS NOT NULL OR cl.is_faxed IS NOT NULL)
    AND nvl(ca1.value_num, 1) IN (0, 9)
    AND exists (
        SELECT 1
        FROM "BO"."T_CONTRACT_ATTRIBUTES"
        WHERE
          attribute_batch_id = cl0.attribute_batch_id
          AND value_num = 1
          AND key_num in (111, 128, 135)
    )
)
GROUP BY
  contract_id, start_dt
\\

--changeset el-yurchito:BALANCE-28192-11 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_CONTRACT_LAST_ATTR2" AS
SELECT
  ca.ID,
  ca.COLLATERAL_ID,
  ca.ATTRIBUTE_BATCH_ID,
  ca.DT,
  ca.CODE,
  ca.KEY_NUM,
  cast(ca.VALUE_STR || dbms_lob.substr(ca.VALUE_CLOB, 512, 1) as varchar2(512 CHAR)) VALUE_STR,
  ca.VALUE_NUM,
  ca.VALUE_DT,
  ca.UPDATE_DT,
  ca.PASSPORT_ID,
  cl.contract2_id,
  cl.dt cl_dt,
  cl.id cl_id,
  TO_CHAR (cl.dt, 'YYYYMMDD') || TO_CHAR (cl.ID, '00000000000000000000') stamp
FROM
  bo.t_contract_collateral cl
  JOIN bo.t_contract_attributes ca ON ca.attribute_batch_id = cl.attribute_batch_id
WHERE
  cl.is_cancelled IS NULL
  OR cl.num       IS NULL
\\

--changeset el-yurchito:BALANCE-28192-12 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_CONTRACT_LAST_ATTR" AS
SELECT
  ca.contract2_id contract_id,
  ca."ID",
  ca."COLLATERAL_ID",
  ca."ATTRIBUTE_BATCH_ID",
  ca."DT",
  ca."CODE",
  ca."KEY_NUM",
  ca."VALUE_STR",
  ca."VALUE_NUM",
  ca."UPDATE_DT",
  ca."VALUE_DT",
  ca."PASSPORT_ID"
FROM
  bo.t_contract2 co
  JOIN bo.v_contract_last_attr2 ca ON co.ID = ca.contract2_id
WHERE NOT exists (
    SELECT 0
    FROM bo.v_contract_last_attr2 caa
    WHERE
      ca.contract2_id = caa.contract2_id
      AND caa.code = ca.code
      AND NVL (caa.key_num, -1) = NVL (ca.key_num, -1)
      AND caa.stamp > ca.stamp
)
\\

--changeset el-yurchito:BALANCE-28192-13 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_UI_PARTNER_CONTRACT" AS
SELECT
  co.TYPE contract_class,
  co.ID,
  co.ID AS contract_id,
  co.external_id AS contract_eid,
  f3.dt AS dt,
  f2.value_dt AS finish_dt,
  f13.value_num currency,
  f14.value_num reward_type,
  bo.sf_nullif (f4.value_num, 0) AS manager_code,
  m.NAME AS manager_name,
  m.login AS manager_login,
  m.email AS manager_email,
  bo.sf_nullif (clients.ID, 0) AS client_id,
  logins.login AS client_login,
  clients.NAME AS client_name,
  bo.sf_nullif (co.person_id, 0) AS person_id,
  p.NAME AS person_name,
  p.inn AS person_inn,
  f1.value_num AS nds_pct,
  f5.value_num AS contract_type,
  f5.value_num AS distribution_ctype,
  f7.value_num AS payment_type,
  cl.is_signed AS is_signed,
  cl.is_faxed AS is_faxed,
  cl.is_cancelled AS is_cancelled,
  f8.value_num AS doc_set,
  f9.value_num AS partner_pct,
  f10.value_num AS agregator_pct,
  nvl(f11.value_num, 1) AS firm,
  f12.value_num AS test_mode,
  f2_1.value_dt AS sent_dt,
  f16.value_dt AS is_booked_dt,
  f17.value_dt AS is_suspended,
  f15.value_num AS tag_id,
  dist_tag.name AS tag_name,
  f18.value_num AS platform_type,
  f19.services,
  f20.value_num as is_offer
FROM
  bo.t_contract2 co
  LEFT OUTER JOIN bo.t_contract_collateral cl ON cl.contract2_id = co.ID AND cl.num IS NULL AND cl.collateral_type_id IS NULL
  LEFT OUTER JOIN bo.v_contract_last_attr f1 ON f1.contract_id = co.ID AND f1.code = 'NDS'
  LEFT OUTER JOIN bo.v_contract_last_attr f2 ON f2.contract_id = co.ID AND f2.code = 'END_DT'
  LEFT OUTER JOIN (SELECT ID, MIN (dt) dt
                   FROM (SELECT co.ID ID, cl.dt dt
                         FROM bo.t_contract2 co, bo.t_contract_collateral cl
                         WHERE cl.contract2_id = co.ID)
                   GROUP BY ID) f3 ON f3.ID = co.ID
  LEFT OUTER JOIN bo.v_contract_last_attr f4 ON f4.contract_id = co.ID AND f4.code = 'MANAGER_CODE'
  LEFT OUTER JOIN bo.v_contract_last_attr f5 ON f5.contract_id = co.ID AND f5.code = 'CONTRACT_TYPE'
  LEFT OUTER JOIN bo.v_contract_last_attr f7 ON f7.contract_id = co.ID AND f7.code = 'PAYMENT_TYPE'
  LEFT OUTER JOIN bo.v_contract_last_attr f8 ON f8.contract_id = co.ID AND f8.code = 'DOC_SET'
  LEFT OUTER JOIN bo.v_contract_last_attr f9 ON f9.contract_id = co.ID AND f9.code = 'PARTNER_PCT'
  LEFT OUTER JOIN bo.v_contract_last_attr f10 ON f10.contract_id = co.ID AND f10.code = 'AGREGATOR_PCT'
  LEFT OUTER JOIN bo.v_contract_last_attr f11 ON f11.contract_id = co.ID AND f11.code = 'FIRM'
  LEFT OUTER JOIN bo.v_contract_last_attr f12 ON f12.contract_id = co.ID AND f12.code = 'TEST_MODE'
  LEFT OUTER JOIN bo.v_contract_last_attr f13 ON f13.contract_id = co.ID AND f13.code = 'CURRENCY'
  LEFT OUTER JOIN bo.v_contract_last_attr f14 ON f14.contract_id = co.ID AND f14.code = 'REWARD_TYPE'
  LEFT OUTER JOIN bo.v_contract_last_attr f15 ON f15.contract_id = co.ID AND f15.code = 'DISTRIBUTION_TAG'
  LEFT OUTER JOIN bo.t_distribution_tag dist_tag ON f15.value_num=dist_tag.id
  LEFT OUTER JOIN bo.t_manager m ON m.manager_code = f4.value_num
  LEFT OUTER JOIN bo.t_person p ON p.ID = co.person_id
  LEFT OUTER JOIN bo.t_client clients ON co.client_id = clients.ID
  LEFT OUTER JOIN bo.v_contract_last_attr f2_1 ON f2_1.attribute_batch_id = cl.attribute_batch_id AND f2_1.code = 'SENT_DT'
  LEFT OUTER JOIN bo.v_contract_last_attr f16 ON f16.attribute_batch_id = cl.attribute_batch_id AND f16.code = 'IS_BOOKED_DT'
  LEFT OUTER JOIN bo.v_contract_last_attr f17 ON f17.attribute_batch_id = cl.attribute_batch_id AND f17.code = 'IS_SUSPENDED'
  LEFT OUTER JOIN (SELECT client_id, max(login) login
                   FROM bo.t_account
                   GROUP BY client_id
                  ) logins ON co.client_id = logins.client_id
  LEFT OUTER JOIN bo.v_contract_last_attr f17 ON f17.contract_id = co.ID AND f17.code = 'PARENT_CONTRACT_ID' AND co.type = 'DISTRIBUTION'
  LEFT OUTER JOIN bo.v_contract_last_attr f18 ON f18.attribute_batch_id = cl.attribute_batch_id AND f18.code = 'PLATFORM_TYPE'
  LEFT OUTER JOIN (SELECT contract_id, LTRIM( EXTRACT( xmlagg( xmlelement( "V", ', ' || s.name ) ), '/V/text()') , ',') services
                   FROM
                     bo.v_contract_last_attr la
                     LEFT OUTER JOIN bo.t_service s ON s.id = la.key_num
                   WHERE
                     code = 'SERVICES' AND value_num = 1
                   GROUP BY contract_id
                  ) f19 ON f19.contract_id = co.ID AND co.type = 'SPENDABLE'
  LEFT OUTER JOIN bo.v_contract_last_attr f20 ON f20.attribute_batch_id = cl.attribute_batch_id AND f20.code = 'IS_OFFER'
WHERE
  co.type IN ('GEOCONTEXT', 'PARTNERS', 'DISTRIBUTION', 'AFISHA', 'PREFERRED_DEAL', 'SPENDABLE', 'ACQUIRING')
  AND f17.value_num IS NULL
\\
