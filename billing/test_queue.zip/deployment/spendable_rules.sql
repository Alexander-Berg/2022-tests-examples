--liquibase formatted sql
--liquibase formatted sql

--changeset ashvedunov:BALANCE-23866-16 runOnChange:true stripComments:false

-- lock type for avoid deadlocks
select * from bo.T_CONTRACT_TYPES WHERE TYPE='SPENDABLE' FOR UPDATE;

-- contract_collateral_types
merge into BO.T_CONTRACT_COLLATERAL_TYPES b using
(select 7010 id, 20 pos,'изменение налогообложения' caption,'COLLATERAL' collateral_class from dual union all select
7020,1000, 'прочее','COLLATERAL' from dual union all select
7030, 45, 'изменение суммы выплаты', 'COLLATERAL' from dual union all select
7040, 100, 'продление договора', 'COLLATERAL' from dual union all select
7050, 110, 'расторжение договора', 'COLLATERAL' from dual
) m
on (b.id = m.id)
when matched then
  update set b.pos = m.pos, b.caption = m.caption, b.contract_type = 'SPENDABLE', b.collateral_class = m.collateral_class where b.id = m.id
when not matched then
  insert (ID,POS,CONTRACT_TYPE,CAPTION, COLLATERAL_CLASS) values (m.id, m.pos, 'SPENDABLE', m.caption, m.collateral_class)
;


delete from BO.t_contract_collateral_attrs where contract_type='SPENDABLE';

Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (7010,7010,'SPENDABLE','NDS',null,null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT, INHERIT_VALUE,VALUE) values (7030,7030,'SPENDABLE','PAYMENT_SUM',null, 0, null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (7040,7040,'SPENDABLE','END_DT',null,null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (7050,7050,'SPENDABLE','END_DT',null,null);

---------------------------------------
-- TYPES
---------------------------------------

delete from BO.t_contract_attribute_types where type='SPENDABLE';

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) 
   values ('FIRM','SPENDABLE','int','refselect','firms','Фирма',1,0,25,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) 
   values ('CONTRACT_TYPE','SPENDABLE','int','refselect','spendablectype','Тип договора',null,0,5,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) 
   values ('CURRENCY','SPENDABLE','int','refselect','partnercurrency','Валюта',null,0,25,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('DT','SPENDABLE','date','date',null,'Дата начала',null,1,39,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('END_DT','SPENDABLE','date','date',null,'Дата окончания',null,0,40,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MANAGER_CODE','SPENDABLE','int','autocomplete','managers?params=manager_type=1','Менеджер',1,0,30,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MANAGER_BO_CODE','SPENDABLE','int','autocomplete','managers?params=manager_type=2','Менеджер БО',1,0,30.1,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MEMO','SPENDABLE','clob','text?rows=7'||chr(38)||'cols=30',null,'Примечание',1,1,60,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('ATYPICAL_CONDITIONS','SPENDABLE','int','checkbox',null,'Нетиповые условия',0,0,61,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PAYMENT_TYPE','SPENDABLE','int','refselect','billinterval','Период актов (выплат)',null,0,50,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('NDS','SPENDABLE','int','refselect','ndsreal','Ставка НДС',null,0,58,2,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('NUM','SPENDABLE','str','input',null,'№',0,1,4,1,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('COLLATERAL_TYPE','SPENDABLE','int','colselect','spendable_collaterals','на',0,1,5,1,null);

-- выплаты
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PAYMENT_SUM','SPENDABLE','money','pctinput?precision=0',null,'Сумма выплаты в указанной валюте',null,0,59.1,2,null);

-- подписи
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('IS_FAXED','SPENDABLE','date','datecheckbox',null,'Подписан по факсу',0,1,10,3,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) 
   values ('IS_SIGNED','SPENDABLE','date','datecheckbox',null,'Подписан',0,1,20,3,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('SENT_DT','SPENDABLE','date','datecheckbox',null,'Отправлен оригинал',0,1,25,3,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('IS_CANCELLED','SPENDABLE','date','datecheckbox',null,'Аннулирован',0,1,30,3,null);
INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
   VALUES ('IS_BOOKED', 'SPENDABLE', 'int', 'checkbox', null, 'Бронь подписи', 0, 1, 8, 3, null);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR)
   values ('IS_SUSPENDED','SPENDABLE','date',25,3,1,'Приостановлен','datecheckbox',null,0);
INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
   VALUES ('IS_BOOKED_DT', 'SPENDABLE', 'date', 'date?readonly=readonly', null, 'Дата брони', 0, 1, 9, 3, null);

-- связанный договор
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP)
    values ('LINK_CONTRACT_ID','SPENDABLE','int','contractinput','','Связанный договор',1,0,60.1,2);


Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_ARCHIVED','SPENDABLE','int','checkbox',null,'Принят в архив',0,1,21,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_ARCHIVED_DT', 'SPENDABLE', 'date', 'date?readonly=readonly', null, 'Дата принятия в архив', 0, 1, 22, 3, null);

---------------------------------------
-- RULES
---------------------------------------

delete from BO.t_contract_rules where type='SPENDABLE';

-- DOCUMENT RULES

-- init
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(1,'SPENDABLE','document',null,'any_signed = 0;enabled = lambda col, attr: (((col.selected and getattr(col.selected, attr, None)) and getattr(col.selected, attr).enabled) and getattr(col.selected, attr).visible)',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(2,'SPENDABLE','document',null,'visible = lambda col, attr: ((col.selected and getattr(col.selected, attr, None)) and getattr(col.selected, attr).visible)',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(3,'SPENDABLE','document',null,'can_edit = None; disable_main = None; new_contract = None',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(7,'SPENDABLE','document','loading','glob.lsigned=is_signed.value;glob.lfaxed=is_faxed.value;glob.lcancelled=is_cancelled.value;glob.lsent=sent_dt.value',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(7.02,'SPENDABLE','document','"BillingSupport" in permissions and len(collaterals) < 2','can_edit = True','can_edit = False');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(10,'SPENDABLE','document','not id.value','new_contract = True',null);

-- sign conditions
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(7.03,'SPENDABLE','document','glob.lsigned and not can_edit','is_signed.disable()',null);
INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (7.04, 'SPENDABLE', 'glob.lfaxed and not can_edit', 'is_faxed.disable(); is_booked.disable(); is_booked_dt.disable();', null, 'document');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(7.05,'SPENDABLE','document','glob.lsent and not can_edit','sent_dt.disable()',null);
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(7.31,'SPENDABLE','is_signed.value and is_signed.value>datetime()','is_signed.highlight();invalid="Дата подписания больше текущей даты"',null,'document');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(7.32,'SPENDABLE','is_faxed.value and is_faxed.value>datetime()','is_faxed.highlight();invalid="Дата подписания больше текущей даты"',null,'document');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(7.33,'SPENDABLE','is_cancelled.value and is_cancelled.value>datetime()','is_cancelled.highlight();invalid="Дата отмены больше текущей даты"',null,'document');

-- firms
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(19.03,'SPENDABLE',null,'firm.showitems((13,))',null,'document');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(81.6,'SPENDABLE','document','firm.value==13 and not nds.value in (0, 18)','nds.highlight();invalid="Неверная ставка НДС для заданной фирмы";',null);


-- nds
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(19.07,'SPENDABLE',null,'nds.showitems((18,0))',null,'document');

--
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(23,'SPENDABLE','document','glob.lsigned or glob.lfaxed','disable_main = True','col_new_form.hide()');

-- currency
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(30.0,'SPENDABLE','document',null,'payment_sum.caption("Сумма выплаты в указанной валюте:")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(30.1,'SPENDABLE','document','currency.value == 643','payment_sum.caption("Сумма выплаты в рублях (RUR):")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(30.2,'SPENDABLE','document','currency.value == 840','payment_sum.caption("Сумма выплаты в долларах (USD):")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(30.3,'SPENDABLE','document','currency.value == 980','payment_sum.caption("Сумма выплаты в гривнах (UAH):")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(30.4,'SPENDABLE','document','currency.value == 978','payment_sum.caption("Сумма выплаты в евро (EUR):")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(30.5,'SPENDABLE','document','currency.value == 949','payment_sum.caption("Сумма выплаты в лирах (TRY):")',null);

-- contract_type
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(50,'SPENDABLE','document','loading and not contract_type.value','contract_type.value=85',null);
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(67,'SPENDABLE','document','not contract_type.value or contract_type.value<0','contract_type.highlight();invalid="Выберите тип договора";',null);
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(70,'SPENDABLE','document','contract_type.value == 85','payment_sum.enable();payment_sum.show();','payment_sum.disable();payment_sum.hide()');

-- form checks
Insert into BO.t_contract_rules (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(80.1,'SPENDABLE','dt.value and end_dt.value and (end_dt.value < dt.value)','dt.highlight(); end_dt.highlight(); invalid = "Дата окончания меньше даты начала действия договора"',null,'document');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.06,'SPENDABLE','document','not loading','any_signed = ((sent_dt and sent_dt.value) or (is_signed and is_signed.value) or (is_faxed and is_faxed.value));', null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.084,'SPENDABLE','document','not manager_code.value','manager_code.highlight(); invalid = "не выбран менеджер";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.085,'SPENDABLE','document','not person_id.value','person_id.highlight(); invalid = "не выбран плательщик";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.086,'SPENDABLE','document','payment_sum.enabled and (not payment_sum.value or payment_sum.value=="0")','payment_sum.highlight(); invalid = "не выбрана сумма выплаты";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.3,'SPENDABLE','document','not dt.value','dt.highlight(); invalid = "Укажите дату начала действия договора";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(81,'SPENDABLE','document','not client_id.value','client_id.highlight();invalid="Не выбран клиент";',null);

-- sign
INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.667, 'SPENDABLE',
        'loading and is_booked.value',
          'glob.l_is_booked = True',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.668, 'SPENDABLE',
        'not glob.l_is_booked and is_booked.value and is_booked_dt.value',
          'is_faxed.value = is_booked_dt.value; glob.l_is_booked = True;',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.669, 'SPENDABLE',
        'not glob.l_is_booked and is_booked.value and not is_booked_dt.value',
          'is_booked_dt.value = datetime(); is_faxed.value = datetime(); glob.l_is_booked = True;',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.670, 'SPENDABLE',
        'glob.l_is_booked and not is_booked.value',
          'is_faxed.value = datetime(); glob.l_is_booked = False;',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.671, 'SPENDABLE',
        'is_booked.value',
          'is_faxed.disable()',
          null,
        'document');

-- footer
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(500,'SPENDABLE','document',null,'err_message(invalid);collateral_type.disable();collateral_type.hide();num.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(800.1,'SPENDABLE','document','invalid','button_submit.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(3500,'SPENDABLE','document','disable_main','client_id.disable();firm.disable();manager_bo_code.disable();manager_code.disable();person_id.disable();currency.disable();dt.disable();end_dt.disable();payment_type.disable();group02.disable();contract_type.disable()',null);


-- COLLATERAL RULES

-- header
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(20,'SPENDABLE','col',null,'col.invalid=""',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(500.4,'SPENDABLE','col','col.new_col','map(lambda x: x.hide(), col.group02.subitems)',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(500.41,'SPENDABLE','col','(col.new_col and col.collateral_type) and col.group02["grp_"+str(col.collateral_type.value)]','col.selected = col.group02["grp_"+str(col.collateral_type.value)];col.selected.show()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501,'SPENDABLE','col','loading','col.lfaxed = col.is_faxed.value; col.lsigned = col.is_signed.value; col.lsent=col.sent_dt.value;col.lcancelled = col.is_cancelled.value',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.1,'SPENDABLE','col','col.lcancelled and not (col.lsigned or col.lfaxed)','col.form.hide()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.3,'SPENDABLE','col','col.lcancelled and col.is_cancelled.value','col.memo.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.4,'SPENDABLE','col','col.lsigned','col.is_signed.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.5,'SPENDABLE','col','col.lfaxed','col.is_faxed.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.55,'SPENDABLE','col','col.lsent','col.sent_dt.disable()',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.6,'SPENDABLE','col','(not col.new_col) and (col.lsigned or col.lfaxed)','col.dt.disable();col.num.disable();col.group02.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.7,'SPENDABLE','col','not col.new_col','col.collateral_type.disable()','col.is_cancelled.disable()');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512,'SPENDABLE','col','visible(col,"end_dt") and not col.selected.end_dt.value','col.selected.end_dt.highlight();col.invalid="не заполнена дата окончания договора"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(513,'SPENDABLE','col','visible(col, "payment_sum") and (not col.selected.payment_sum.value or col.selected.payment_sum.value=="0")','col.selected.payment_sum.highlight(); col.invalid = "не выбрана сумма выплаты";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(514,'SPENDABLE','col','visible(col, "nds")','col.selected.nds.showitems((18,0))',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(515,'SPENDABLE','col','contract_type.value != 85','col.collateral_type.hideitems((7030,))',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(516,'SPENDABLE','col','col.dt.value and (col.dt.value < dt.value)','col.dt.highlight(); col.invalid = "Дата начала действия допсоглашения должна превышать дату договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(517,'SPENDABLE','col','not col.dt.value','col.dt.highlight(); col.invalid = "Не выбрана дата начала действия допсоглашения"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(518,'SPENDABLE','col','not col.collateral_type.value','col.collateral_type.highlight(); col.invalid = "Выберите тип допсоглашения"',null);

-- currency
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(519.0,'SPENDABLE','col','visible(col, "payment_sum")','col.selected.payment_sum.caption("Сумма выплаты в указанной валюте:")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(519.1,'SPENDABLE','col','visible(col, "payment_sum") and currency.value == 643','col.selected.payment_sum.caption("Сумма выплаты в рублях (RUR):")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(519.2,'SPENDABLE','col','visible(col, "payment_sum") and currency.value == 840','col.selected.payment_sum.caption("Сумма выплаты в долларах (USD):")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(519.3,'SPENDABLE','col','visible(col, "payment_sum") and currency.value == 980','col.selected.payment_sum.caption("Сумма выплаты в гривнах (UAH):")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(519.4,'SPENDABLE','col','visible(col, "payment_sum") and currency.value == 978','col.selected.payment_sum.caption("Сумма выплаты в евро (EUR):")',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(519.5,'SPENDABLE','col','visible(col, "payment_sum") and currency.value == 949','col.selected.payment_sum.caption("Сумма выплаты в лирах (TRY):")',null);


-- signs
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(522.01,'SPENDABLE','col.is_signed.value and col.is_signed.value>datetime()', 'col.is_signed.highlight();col.invalid="Дата подписания допсоглашения больше текущей даты"', null,'col');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(522.02,'SPENDABLE','col.is_faxed.value and col.is_faxed.value>datetime()', 'col.is_faxed.highlight();col.invalid="Дата подписания допсоглашения больше текущей даты"', null,'col');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(522.03,'SPENDABLE','col.is_cancelled.value and col.is_cancelled.value>datetime()', 'col.is_cancelled.highlight();col.invalid="Дата отмены допсоглашения больше текущей даты"', null,'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.667, 'SPENDABLE',
        'loading and col.is_booked.value',
          'col.l_col_is_booked = True',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.668, 'SPENDABLE',
        'not col.l_col_is_booked and col.is_booked.value and col.is_booked_dt.value',
          'col.is_faxed.value = col.is_booked_dt.value; col.l_col_is_booked = True;',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.669, 'SPENDABLE',
        'not col.l_col_is_booked and col.is_booked.value and not col.is_booked_dt.value',
          'col.is_booked_dt.value = datetime(); col.is_faxed.value = col.is_booked_dt.value; col.l_col_is_booked = True;',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.670, 'SPENDABLE',
        'col.l_col_is_booked and not col.is_booked.value',
          'col.is_faxed.value = datetime(); col.l_col_is_booked = False;',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.671, 'SPENDABLE',
        'col.is_booked.value',
          'col.is_faxed.disable()',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (502.05, 'SPENDABLE',
        'col.new_col and not loading and col.collateral_type.value == 7050',
          'col.is_faxed.value = datetime(); col.is_faxed.disable(); col.is_booked.value = True; col.is_booked_dt = datetime(); col.force_signed = True',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (502.06, 'SPENDABLE',
        'col.new_col and col.force_signed and col.collateral_type.value != 7050',
          'col.force_signed = False;col.is_faxed.value = None; col.is_booked.value = None; col.is_booked_dt = None;',
          null,
        'col');

-- footer
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(800,'SPENDABLE','col','col.invalid','col.button_submit.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(801,'SPENDABLE','col','True and not col.hidden','err_message(col.invalid, col.form)',null);



