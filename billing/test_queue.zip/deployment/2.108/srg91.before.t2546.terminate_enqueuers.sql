--liquibase formatted sql

--changeset srg91:TRUST-2546-before

update bo.t_pycron_descr
set terminate = 1
where 1=1
  and name in (
    'postauth_payments-processor',
    'process_refunds-processor'
  )
;
