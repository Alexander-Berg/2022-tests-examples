--liquibase formatted sql

--changeset srg91:TRUST-2546-after endDelimiter:\\

declare
  old_task_name varchar2(50);
  task_name_ varchar2(50);
  task_command varchar2(1024);

  type paysys_tasks is table of varchar2(50);
  tasks paysys_tasks := paysys_tasks(
    'walletone-crontask',
    'six_ccard_cron',
    'rbs_cron_task',
    'qiwi_check_payments',
    'privat-ccard-crontask',
    'paysys-report-proc',
    'nestpay-crontask',
    'parking_register',
    'postauth_payments-processor',
    'process_refunds-processor',
    'fraud_report_crontask'
  );
begin
  for i in 1..tasks.count loop
    task_name_ := tasks(i);
    old_task_name := 'old-' || task_name_;

    select
      pd.command
    into task_command
    from bo.t_pycron_descr pd
    where
      pd.name = task_name_
    ;

    task_command := replace(
      task_command, '/balance-paysys/', '/yb-balance-paysys/tools/'
    );

    task_command := replace(
      task_command, '/balance-paysys-tools/', '/yb-balance-paysys/tools/'
    );

    task_command := replace(
      task_command,
      ' yb-python -pysupport ',
      ' /opt/venvs/yb-balance-paysys/bin/python '
    );

    task_command := replace(
      task_command,
      ' balance/',
      ' /usr/share/pyshared/balance/'
    );

    task_command := replace(
      task_command,
      ' paysys/',
      ' /opt/venvs/yb-balance-paysys/lib/python2.7/site-packages/yb_balance_paysys_tools/'
    );

    task_command := replace(
      task_command,
      ' paysys_tools/',
      ' /opt/venvs/yb-balance-paysys/lib/python2.7/site-packages/yb_balance_paysys_tools/'
    );

    task_command := replace(
      task_command,
      'run_rep_proc',
      'balance_registers'
    );

    -- Clone old pycron tasks
    insert into bo.t_pycron_descr
    select
      old_task_name name,
      pd.command,
      pd.timeout,
      pd.description || ' (deprecated)',
      pd.terminate,
      pd.owner_login,
      pd.count_per_host
    from bo.t_pycron_descr pd
    where
      pd.name = task_name_
    ;

    insert into bo.t_pycron_schedule
    select
      bo.s_pycron_schedule.nextval id,
      old_task_name name,
      ps.crontab,
      ps.host,
      0 enabled,
      ps.retry_count,
      ps.retry_interval
    from bo.t_pycron_schedule ps
    where
      ps.name = task_name_
    ;

    insert into bo.t_pycron_responsible
      (task_name, email)
    select
      old_task_name task_name,
      pr.email
    from bo.t_pycron_responsible pr
    where
      pr.task_name = task_name_
    ;

    -- Move current tasks
    update bo.t_pycron_descr pd
    set
      pd.command = task_command
    where
      pd.name = task_name_
    ;

  end loop;
end;
\\


--changeset srg91:TRUST-2546-after-update
update bo.t_pycron_descr
set terminate = 0
where 1=1
  and name in (
    'postauth_payments-processor',
    'process_refunds-processor'
  )
;


--changeset buyvich:TRUST-2626
update bo.t_pycron_schedule set enabled=0 where name='subscriptions';
update bo.t_pycron_descr set DESCRIPTION='Monitor subscriptions for simple services in simple (deprecated)' where name='subscriptions';

insert into bo.t_pycron_descr (name, command, timeout, description, terminate, owner_login, count_per_host)
  values ('yb-balance-subscriptions', '/usr/bin/yb-balance-subscriptions.sh', 1800.00, 'monitor subscriptions for services based in BO', 0, 'buyvich', null);

insert into bo.t_pycron_schedule (id, name, crontab, host, enabled, retry_count, retry_interval)
  values ((select max(id)+1 from bo.t_pycron_schedule), 'yb-balance-subscriptions', '* * * * *', null, 1, null, null);

