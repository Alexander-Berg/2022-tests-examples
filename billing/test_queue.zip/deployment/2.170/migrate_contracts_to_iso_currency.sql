--liquibase formatted sql

--changeset nebaruzdin:BALANCE-28708

merge into bo.t_contract_attributes ca
using bo.t_currency c
on (ca.value_num = c.num_code)
when matched then update set
    ca.value_str = decode(upper(c.char_code), 'RUR', 'RUB', upper(c.char_code))
where
    ca.code in ('CURRENCY', 'PRODUCTS_CURRENCY', 'SEARCH_CURRENCY');

--changeset nebaruzdin:BALANCE-28708-1

update bo.t_contract_attributes
set value_str = 'RUB'
where
    value_num = 643
    and code in ('CURRENCY', 'PRODUCTS_CURRENCY', 'SEARCH_CURRENCY');
