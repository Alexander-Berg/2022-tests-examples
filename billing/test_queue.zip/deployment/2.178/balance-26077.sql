--liquibase formatted sql

--changeset ashchek:BALANCE-26077

INSERT
INTO bo.t_config(item, "DESC", value_json)
VALUES (
  'SAUTH_USERS_WITH_BALANCE_MODE',
  'Use Balance instead of Passport for Sauth check for specified users',
  '[]'
);
