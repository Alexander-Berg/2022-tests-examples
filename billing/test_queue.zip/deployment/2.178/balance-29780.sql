--liquibase formatted sql

--changeset lightrevan:BALANCE-29780-drop-f-1
DROP FUNCTION bo.SF_CREATE_HASH_DATA;

--changeset lightrevan:BALANCE-29780-drop-f-2
DROP FUNCTION bo.SF_INS_HASH_DATA;
