--liquibase formatted sql

--changeset ashvedunov:BALANCE-23866-12 runOnChange:true stripComments:false

-- lock type for avoid deadlocks
select * from bo.T_CONTRACT_TYPES WHERE TYPE='DISTRIBUTION' FOR UPDATE;

-- COLLATERAL TYPES
merge into BO.T_CONTRACT_COLLATERAL_TYPES b using
(select 3010 id, 20 pos,'изменение налогообложения' caption,'COLLATERAL' collateral_class from dual union all select
3020,30, 'изменение процента партнера','COLLATERAL' from dual union all select
3030,40, 'изменение номенклатуры','COLLATERAL' from dual union all select
3035,41, 'изменение номенклатуры ГД','COLLATERAL' from dual union all select
3070,42, 'изменение/добавление приложения загрузок','COLLATERAL' from dual union all select
3080,44, 'изменение/добавление приложения установок','COLLATERAL' from dual union all select
3040,1000, 'прочее','COLLATERAL' from dual union all select
3060,90, 'расторжение договора','COLLATERAL' from dual union all select
3090,50, 'переход на NET-базу для вознаграждения','COLLATERAL' from dual union all select
3100,55, 'изменение цены поисков','COLLATERAL' from dual union all select
3200,60, 'изменение условий УДД/ГД', 'COLLATERAL' from dual
) m
on (b.id = m.id)
when matched then
  update set b.pos = m.pos, b.caption = m.caption, b.contract_type = 'DISTRIBUTION', b.collateral_class = m.collateral_class where b.id = m.id
when not matched then
  insert (ID,POS,CONTRACT_TYPE,CAPTION, COLLATERAL_CLASS) values (m.id, m.pos, 'DISTRIBUTION', m.caption, m.collateral_class);

-- COLLATERAL ATTRS
DELETE FROM BO.t_contract_collateral_attrs
WHERE contract_type='DISTRIBUTION';

Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4010,3010,'DISTRIBUTION','NDS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4020,3020,'DISTRIBUTION','PRODUCTS_REVSHARE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4030,3030,'DISTRIBUTION','DISTRIBUTION_PLACES',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4032,3030,'DISTRIBUTION','PRODUCT_SEARCH',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4034,3030,'DISTRIBUTION','PRODUCT_SEARCHF',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4036,3030,'DISTRIBUTION','PRODUCT_OPTIONS',null,null);

Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4031,3035,'DISTRIBUTION','PARTNER_RESOURCES',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4033,3035,'DISTRIBUTION','DISTRIBUTION_PRODUCTS',null,null);

Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4040,3060,'DISTRIBUTION','END_DT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (4050,3060,'DISTRIBUTION','TAIL_TIME',null,null);

Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3071,3070,'DISTRIBUTION','PRODUCTS_DOWNLOAD',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3072,3070,'DISTRIBUTION','DOWNLOAD_DOMAINS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3073,3070,'DISTRIBUTION','PARTNER_RESOURCES',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3074,3070,'DISTRIBUTION','FIXED_SCALE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3075,3070,'DISTRIBUTION','PRODUCTS_CURRENCY',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3081,3080,'DISTRIBUTION','INSTALL_PRICE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3082,3080,'DISTRIBUTION','INSTALL_SOFT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3083,3080,'DISTRIBUTION','PARTNER_RESOURCES',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3084,3080,'DISTRIBUTION','DISTRIBUTION_PRODUCTS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3085,3080,'DISTRIBUTION','PRODUCTS_CURRENCY',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3091,3090,'DISTRIBUTION','REWARD_TYPE',1,2);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3092,3090,'DISTRIBUTION','PRODUCTS_REVSHARE',null,null);

Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3093,3100,'DISTRIBUTION','SEARCH_PRICE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3094,3100,'DISTRIBUTION','SEARCH_CURRENCY',null,null);

-- Универсальное ДС на изменение условий УДД/ГД
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE, INHERIT_VALUE) values (3201,3200,'DISTRIBUTION','SUPPLEMENTS',null,null, 1);

Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3202,3200,'DISTRIBUTION','PARTNER_RESOURCES',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3203,3200,'DISTRIBUTION','DISTRIBUTION_PRODUCTS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3211,3200,'DISTRIBUTION','REWARD_TYPE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3212,3200,'DISTRIBUTION','AVG_DISCOUNT_PCT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3215,3200,'DISTRIBUTION','PRODUCTS_REVSHARE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3216,3200,'DISTRIBUTION','DISTRIBUTION_PLACES',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3217,3200,'DISTRIBUTION','TAIL_TIME',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3218,3200,'DISTRIBUTION','PRODUCT_SEARCH',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3219,3200,'DISTRIBUTION','PRODUCT_SEARCHF',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3220,3200,'DISTRIBUTION','PRODUCT_OPTIONS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3221,3200,'DISTRIBUTION','PRODUCTS_DOWNLOAD',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3222,3200,'DISTRIBUTION','DOWNLOAD_DOMAINS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3223,3200,'DISTRIBUTION','INSTALL_PRICE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3224,3200,'DISTRIBUTION','INSTALL_SOFT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3225,3200,'DISTRIBUTION','FIXED_SCALE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3226,3200,'DISTRIBUTION','ACTIVATION_PRICE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3227,3200,'DISTRIBUTION','ADVISOR_PRICE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3228,3200,'DISTRIBUTION','PRODUCTS_CURRENCY',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3231,3200,'DISTRIBUTION','SEARCH_PRICE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3232,3200,'DISTRIBUTION','SEARCH_CURRENCY',null,null);

-- ATTRIBUTE TYPES
DELETE FROM bo.t_contract_attribute_types
WHERE type='DISTRIBUTION';

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('FIRM','DISTRIBUTION','int','refselect','firms','Фирма',0,0,6,1);

Insert into BO.t_contract_attribute_types  (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) 
   values ('CONTRACT_TYPE','DISTRIBUTION','int','refselect','distributionctype','Тип договора',null,0,5,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) 
   values ('CURRENCY','DISTRIBUTION','int','refselect','partnercurrency','Валюта',null,0,25,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('DT','DISTRIBUTION','date','date',null,'Дата начала',null,1,39,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('SERVICE_START_DT','DISTRIBUTION','date','date',null,'Рассчитывать с',1,0,39.5,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('END_DT','DISTRIBUTION','date','date',null,'Дата окончания',null,0,40,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PRODUCTS_REVSHARE', 'DISTRIBUTION','unheritableintdict',
   'products_revshare_grid?additem=0'||chr(38)||'col_0_id=type=number,editable=0,width=1,hidden=1'||chr(38)||'col_2_num=type=number,width=1,editable=0,hidden=1'||chr(38)||'col_20_price=type=number,caption=% партнера,editable=1,formatter=pct_formatter_float,formatter_options={value_min:0,value_max:60,allow_empty:1},width=150'||chr(38)||'col_10_name=type=string,editable=0,width=180,caption=Продукт', 'revshare_types','Продукты разделения',null,null,59,2,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MANAGER_CODE','DISTRIBUTION','int','autocomplete','managers?params=manager_type=4','Менеджер',1,0,30,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MANAGER_BO_CODE','DISTRIBUTION','int','autocomplete','managers?params=manager_type=2','Менеджер БО',1,0,30,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MEMO','DISTRIBUTION','clob','text?rows=7'||chr(38)||'cols=30',null,'Примечание',1,1,60,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('ATYPICAL_CONDITIONS','DISTRIBUTION','int','checkbox',null,'Нетиповые условия',0,0,61,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PAYMENT_TYPE','DISTRIBUTION','int','refselect','billinterval','Период актов',null,0,50,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('DISTRIBUTION_TAG','DISTRIBUTION','int','taginput','distribution_tag','Тэг',null,0,53,1,null);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
    values ('SUPPLEMENTS','DISTRIBUTION','unheritableintset','checkboxes','distr_supplements','Приложения договора',0,0,50.5,2,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('REWARD_TYPE','DISTRIBUTION','int','refselect','distr_reward_type','Вознаграждение от оборота',null,0,51,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('AVG_DISCOUNT_PCT','DISTRIBUTION','money','pctinput?precision=2',null,'Фикс. процент средней скидки',null,0,51.5,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('TAIL_TIME','DISTRIBUTION','money','pctinput?precision=0',null,'период выплат(месяцев)',null,0,59.1,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('DISTRIBUTION_PLACES','DISTRIBUTION','unheritableintset','checkboxes','distr_places','Типы дистрибуции',null,null,66,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PRODUCT_SEARCH','DISTRIBUTION','str','text?rows=4'||chr(38)||'cols=30',null,'Пакет дистрибуции + настройки поиска',null,null,66.1,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PRODUCT_SEARCHF','DISTRIBUTION','str','text?rows=4'||chr(38)||'cols=30',null,'Поисковая форма в ПО партнера',null,null,66.2,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PRODUCT_OPTIONS','DISTRIBUTION','str','text?rows=4'||chr(38)||'cols=30',null,'Настройки яндекса в браузерах и ОС',null,null,66.3,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('NDS','DISTRIBUTION','int','refselect','ndsreal','Ставка НДС',null,0,50.3,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('TEST_MODE','DISTRIBUTION','int','checkbox',null,'Тестовый режим',1,1,9,3,null);

INSERT INTO bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
VALUES ('IS_BOOKED','DISTRIBUTION','int','checkbox',null,'Бронь подписи',0,1,8,3,null);

INSERT INTO bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
VALUES ('IS_BOOKED_DT', 'DISTRIBUTION', 'date', 'date?readonly=readonly', null, 'Дата брони', 0, 1, 9, 3, null);
   
Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_ARCHIVED','DISTRIBUTION','int','checkbox',null,'Принят в архив',0,1,21,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_ARCHIVED_DT', 'DISTRIBUTION', 'date', 'date?readonly=readonly', null, 'Дата принятия в архив', 0, 1, 22, 3, null);

INSERT INTO bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
VALUES ('IS_FAXED','DISTRIBUTION','date','datecheckbox',null,'Подписан по факсу',0,1,10,3,null);
   
INSERT INTO bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code) 
VALUES ('IS_SIGNED','DISTRIBUTION','date','datecheckbox',null,'Подписан',0,1,20,3,null);
   
INSERT INTO bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
VALUES ('SENT_DT','DISTRIBUTION','date','datecheckbox',null,'Отправлен оригинал',0,1,25,3,null);
   
INSERT INTO bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
VALUES ('IS_CANCELLED','DISTRIBUTION','date','datecheckbox',null,'Аннулирован',0,1,30,3,null);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) 
   values ('PRODUCTS_DOWNLOAD', 'DISTRIBUTION','unheritableintdict',
   'products_grid?additem=0'||chr(38)||'col_0_id=type=number,editable=0,width=1,hidden=1'||chr(38)||'col_2_num=type=number,width=1,editable=0,hidden=1'||chr(38)||'col_20_price=type=string,caption=Цена за загрузку,editable=1,formatter=money_formatter,width=150'||chr(38)||'col_10_name=type=string,editable=0,width=180,caption=Продукт', 'distribution_download_types','Продукты загрузок:',null,null,67,2,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('FIXED_SCALE','DISTRIBUTION','int','refselect','fixed_scale','Шкала загрузок',null,0,66.7,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('DOWNLOAD_DOMAINS','DISTRIBUTION','str','text?rows=4'||chr(38)||'cols=30',null,'Список сайтов загрузок',null,null,70,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('INSTALL_SOFT','DISTRIBUTION','str','text?rows=4'||chr(38)||'cols=30',null,'Список ПО установок',null,null,75,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('INSTALL_PRICE','DISTRIBUTION','money','pctinput?precision=2',null,'Цена за установку',null,null,66.6,2, null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('SEARCH_PRICE','DISTRIBUTION','money','pctinput?precision=2',null,'Цена за 1000 поисков(без налогов)',null,null,80,2, null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('ADVISOR_PRICE','DISTRIBUTION','money','pctinput?precision=2',null,'Цена за клик Маркета',null,null,67.005,2, null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('ACTIVATION_PRICE','DISTRIBUTION','money','pctinput?precision=2',null,'Цена за Активацию',null,null,67.025,2, null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) 
   values ('NUM','DISTRIBUTION','str','input',null,'№',0,1,4,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) 
   values ('COLLATERAL_TYPE','DISTRIBUTION','int','colselect','distribution_collaterals','на',0,1,5,1,null);

-- Расчёт в валюте договора
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('CURRENCY_CALCULATION','DISTRIBUTION','int','checkbox',null,'Расчёт в валюте договора',0,0,26,1,null);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values
('PRINT_FORM_TYPE','DISTRIBUTION','int','refselect','print_form_types','Тип ПФ',0,1,5.5,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PARTNER_RESOURCES','DISTRIBUTION','str','text?rows=4'||chr(38)||'cols=30',null,'Ресурсы партнёра',null,null,50.41,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('DISTRIBUTION_PRODUCTS','DISTRIBUTION','str','text?rows=4'||chr(38)||'cols=30',null,'Продукты дистрибуции',null,null,50.42,2,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PRODUCTS_CURRENCY','DISTRIBUTION','int','taginput','allowed_currencies','Валюта цены загрузок/установок/активаций/кликов',null,0,67.01,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('SEARCH_CURRENCY','DISTRIBUTION','int','taginput','allowed_currencies','Валюта цены поисков',null,0,80.01,2,null);

-- Связанные договоры
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP)
    values ('PARENT_CONTRACT_ID','DISTRIBUTION','int','contractinput','','Родительский договор',1,0,4.12,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP)
    values ('PLATFORM_TYPE','DISTRIBUTION','int','refselect','platform_type','Тип платформы',0,0,81,1);

-- RULES
DELETE FROM bo.t_contract_rules
WHERE type='DISTRIBUTION';

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (0.1,'DISTRIBUTION','document',null,'firm_to_currency_map = {1: (643, 840, 980, 978, 949), 7: (840, 978)};',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (0.2,'DISTRIBUTION','document',null,'firm_to_nds_map = {1: (18, 0, 20, 8), 7: (0, 8)};',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(1,'DISTRIBUTION','document',null,'avg_discount_pct.disable();client_id.caption("Партнер:");any_signed = 0;enabled = lambda col, attr: (((col.selected and getattr(col.selected, attr, None)) and getattr(col.selected, attr).enabled) and getattr(col.selected, attr).visible)',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(2,'DISTRIBUTION','document',null,'visible = lambda col, attr: ((col.selected and getattr(col.selected, attr, None)) and getattr(col.selected, attr).visible)',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(3,'DISTRIBUTION','document',null,'can_edit = None; disable_main = None; new_contract = None',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(7,'DISTRIBUTION','document','loading','glob.lsigned=is_signed.value;glob.lfaxed=is_faxed.value;glob.lcancelled=is_cancelled.value;glob.lsent=sent_dt.value;glob.somehow_signed=is_signed.value or is_faxed.value;',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(7.02,'DISTRIBUTION','document','"BillingSupport" in permissions and len(collaterals) < 2','can_edit = True','can_edit = False');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(7.03,'DISTRIBUTION','document','glob.lsigned and not can_edit','is_signed.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(7.04,'DISTRIBUTION','document','glob.lfaxed and not can_edit','is_faxed.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(7.05,'DISTRIBUTION','document','glob.lsent and not can_edit','sent_dt.disable()',null);
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values
(7.06,'DISTRIBUTION','glob.lfaxed and not can_edit','is_faxed.disable(); is_booked.disable(); is_booked_dt.disable();',null,'document');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(10,'DISTRIBUTION','document','not id.value','new_contract = True',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(23.1,'DISTRIBUTION','document','(glob.lsigned or glob.lfaxed) and ((glob.somehow_signed.year < date().year or (glob.somehow_signed.year == date().year and glob.somehow_signed.month < date().month)) or (contract_type.value and contract_type.value != 4))','disable_main = True',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(23.2,'DISTRIBUTION','document','not (glob.lsigned or glob.lfaxed)','col_new_form.hide()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(30.3,'DISTRIBUTION','document','not contract_type.value','contract_type.value=1','');

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.06666,'DISTRIBUTION','document',null,'firm.showitems(firm_to_currency_map.keys());',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.07777,'DISTRIBUTION','document',null,'currency.showitems(firm_to_currency_map[firm.value]);',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.08888,'DISTRIBUTION','document',null,'nds.showitems(firm_to_nds_map[firm.value]);',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.4,'DISTRIBUTION','document','contract_type.value and (contract_type.value==1 or (contract_type.value in (3, 4) and not (2 in supplements.value)))','fixed_scale.hide();products_download.hide();install_soft.hide();download_domains.hide();install_price.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.41,'DISTRIBUTION','document','fixed_scale.visible and fixed_scale.value>0','products_download.hide();','fixed_scale.visible and products_download.show();');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.42,'DISTRIBUTION','document','contract_type.value and (contract_type.value==2 or (contract_type.value in (3, 4) and not (1 in supplements.value)))','distribution_places.hide();products_revshare.hide();products_revshare.hide();reward_type.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.421,'DISTRIBUTION','document','contract_type.value and contract_type.value == 2','tail_time.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.422,'DISTRIBUTION','document','contract_type.value and contract_type.value != 4','partner_resources.hide(); distribution_products.hide();','');
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.423,'DISTRIBUTION','document','not (contract_type.value in (3, 4)) or (contract_type.value in (3, 4) and not (2 in supplements.value))','advisor_price.hide();activation_price.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.424,'DISTRIBUTION','document','contract_type.value in (3, 4) and len(supplements.value) == 1 and advisor_price.visible and not advisor_price.value','tail_time.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.425,'DISTRIBUTION','document','contract_type.value and (contract_type.value in (3, 4) and not (3 in supplements.value))','search_price.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.43,'DISTRIBUTION','document','contract_type.value and not (contract_type.value in (3, 4))','supplements.hide();search_price.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.431,'DISTRIBUTION','document','contract_type.value and contract_type.value == 5','partner_resources.hide(); distribution_products.hide(); reward_type.hide(); avg_discount_pct.hide(); products_revshare.hide(); distribution_places.hide(); tail_time.hide(); product_search.hide(); product_searchf.hide(); product_options.hide(); products_download.hide(); download_domains.hide(); install_price.hide(); install_soft.hide(); fixed_scale.hide(); activation_price.hide(); advisor_price.hide(); products_currency.hide(); search_price.hide(); search_currency.hide();',null);
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.441,'DISTRIBUTION','document','contract_type.value and (contract_type.value == 4 and (1 in supplements.value))','distribution_places.hide();','');
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.442,'DISTRIBUTION','document','contract_type.value and (contract_type.value == 4 and (2 in supplements.value))','install_soft.hide();download_domains.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.451,'DISTRIBUTION','document','partner_resources.visible and not partner_resources.value','partner_resources.highlight();invalid="Не указаны ресурсы партнёра";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (30.452,'DISTRIBUTION','document','distribution_products.visible and not distribution_products.value','distribution_products.highlight();invalid="Не указаны продукты дистрибуции";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(30.5,'DISTRIBUTION','document','loading and new_contract and test_mode.visible and not test_mode.value','test_mode.value = 1',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(31,'DISTRIBUTION','document','loading and (tail_time.value == "")','tail_time.value=12',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(31.4,'DISTRIBUTION','document','contract_type.value and contract_type.value in (3, 4)','service_start_dt.show()','service_start_dt.hide()');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(31.5,'DISTRIBUTION','document','service_start_dt.visible and not service_start_dt.value','service_start_dt.highlight();invalid="Не указана дата начала расчёта";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(31.6,'DISTRIBUTION','document','reward_type.visible and reward_type.value==2','avg_discount_pct.show()','avg_discount_pct.hide()');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(33,'DISTRIBUTION','document','distribution_places.visible and (1 in distribution_places.value)','product_search.show()','product_search.hide()');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(35,'DISTRIBUTION','document','distribution_places.visible and (2 in distribution_places.value)','product_searchf.show()','product_searchf.hide()');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(37,'DISTRIBUTION','document','distribution_places.visible and (3 in distribution_places.value)','product_options.show()','product_options.hide()');

-- Tag selector rules
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (40.1,'DISTRIBUTION','document','contract_type.value == 5 or not client_id.value','distribution_tag.hide()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (40.2,'DISTRIBUTION','document','contract_type.value != 5 and client_id.value','distribution_tag.show();distribution_tag.update_source("distribution_tag", "client_id==%s"%client_id.value);',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (40.3,'DISTRIBUTION','document','distribution_tag.visible and (not distribution_tag.value or distribution_tag.value == 0)','distribution_tag.highlight();invalid="Не выбран тэг";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(41.1,'DISTRIBUTION','document','contract_type.value and dt.value and client_id.value and distribution_tag.value and ((is_signed and is_signed.value) or (is_faxed and is_faxed.value) or test_mode.value) and not is_cancelled.value','glob.tag_errors = call("get_contracts_crossing_by_dates", {"contract_id": id.value, "contract_type": contract_type.value, "client_id": client_id.value, "tag_id": distribution_tag.value, "start_dt": dt.value, "service_start_dt": service_start_dt.value, "finish_dt": end_dt.value, "tail_time": tail_time.value if tail_time.visible else "", "supplements": supplements.value})','glob.tag_errors = ""');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(41.2,'DISTRIBUTION','document','glob.tag_errors','invalid = "Тэг уже используется договорами: " + glob.tag_errors',null);

Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(65.0666,'DISTRIBUTION','document','firm.visible and firm.value and person_id.visible and person_id.p.person_type and not (person_id.p.person_type in firm2person_categories[firm.value])','person_id.highlight(); invalid = "Тип плательщика не соответствует фирме"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(76,'DISTRIBUTION','document','not (contract_type.value in (3, 4)) and install_price.visible and not install_price.value and not install_price.value_strictly_equals(0) and (len(products_download.value)==0 and fixed_scale.value==0)','install_price.highlight();fixed_scale.highlight();products_download.highlight();invalid="Должны быть заданы либо продукты загрузок, либо цена за установку";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(76.1,'DISTRIBUTION','document','contract_type.value in (3, 4) and (install_price.visible and not install_price.value and not install_price.value_strictly_equals(0)) and (len(products_download.value)==0 and fixed_scale.value==0) and (activation_price.visible and not activation_price.value and not activation_price.value_strictly_equals(0)) and (advisor_price.visible and not advisor_price.value and advisor_price.value_strictly_equals(0))','install_price.highlight();fixed_scale.highlight();products_download.highlight();activation_price.highlight();advisor_price.highlight();invalid="Должны быть заданы либо продукты загрузок, либо цена за установку, либо цена за активацию, либо цена за клик Маркета";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(76.5,'DISTRIBUTION','document','search_price.visible and not search_price.value and contract_type.value == 4 and not search_price.value_strictly_equals(0)','search_price.highlight();invalid="Не задана цена за поиски";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(77,'DISTRIBUTION','document','install_price.visible and install_price.value and install_soft.visible and not install_soft.value','install_soft.highlight();invalid="Укажите список ПО";',null);


Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(78,'DISTRIBUTION','document','((products_download.visible and len(products_download.value)>0) or (fixed_scale.visible and fixed_scale.value>0)) and download_domains.visible and not download_domains.value','download_domains.highlight();invalid="Укажите домены";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(79,'DISTRIBUTION','document','products_download.visible and products_download.validate_ctrl()','products_download.highlight();invalid="Неверно заполнены продукты";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80,'DISTRIBUTION','document','not client_id.value','client_id.highlight();invalid="Не выбран партнер";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values (80.1,'DISTRIBUTION','dt.value and end_dt.value and (end_dt.value < dt.value)','dt.highlight(); end_dt.highlight(); invalid = "Дата окончания меньше даты начала действия договора"',null,'document');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.05,'DISTRIBUTION','document','products_revshare.visible and len(products_revshare.value)==0','products_revshare.highlight();invalid="не задан процент партнера";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.06,'DISTRIBUTION','document','not loading','any_signed = ((sent_dt and sent_dt.value) or (is_signed and is_signed.value) or (is_faxed and is_faxed.value));', null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.0601,'DISTRIBUTION','document','is_signed.value or is_faxed.value or sent_dt.value','test_mode.value=0;', null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.061,'DISTRIBUTION','document','not test_mode.value and new_contract and product_search.visible and not product_search.value','product_search.highlight();invalid="не заполнена номенклатура";', null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.062,'DISTRIBUTION','document','not test_mode.value and new_contract and product_searchf.visible and not product_searchf.value','product_searchf.highlight();invalid="не заполнена номенклатура";', null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.063,'DISTRIBUTION','document','not test_mode.value and new_contract and product_options.visible and not product_options.value','product_options.highlight();invalid="не заполнена номенклатура";', null);


Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.07,'DISTRIBUTION','document','not test_mode.value and distribution_places.visible and (not len(distribution_places.value))','distribution_places.highlight(); invalid = "выберите дистрибуционный пакет";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.08,'DISTRIBUTION','document','not test_mode.value and tail_time.visible and tail_time.value == ""','tail_time.highlight(); invalid = "не заполнен период окончания выплат";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.084,'DISTRIBUTION','document','not test_mode.value and not manager_code.value','manager_code.highlight(); invalid = "не выбран менеджер";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.085,'DISTRIBUTION','document','not test_mode.value and not person_id.value','person_id.highlight(); invalid = "не выбран плательщик";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.086,'DISTRIBUTION','document','person_id.p.person_type and (person_id.p.person_type=="yt" or person_id.p.person_type=="ph") and person_id.p.person_is_partner==1','nds.value=0;nds.disable()',null);


Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(80.3,'DISTRIBUTION','document','not dt.value','dt.highlight(); invalid = "Укажите дату начала действия договора";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(81,'DISTRIBUTION','document','not client_id.value','client_id.highlight();invalid="Не выбран партнер";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(81.4,'DISTRIBUTION','document','search_price.visible and ((1 in supplements.value) or (2 in supplements.value)) and not currency_calculation.value','supplements.highlight();search_price.highlight();invalid="приложение на поиски не совместимо с другими возможными приложениями"','');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(90.1,'DISTRIBUTION','document','loading and new_contract and not currency_calculation.value','currency_calculation.value = 1',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(91.1,'DISTRIBUTION','document','currency.value','products_currency.update_source("allowed_currencies", "cc_num==%s"%currency.value);',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(91.2,'DISTRIBUTION','document','currency.value','search_currency.update_source("allowed_currencies", "cc_num==%s"%currency.value);',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(92.1,'DISTRIBUTION','document','not products_download.visible and not fixed_scale.visible','products_currency.hide()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(92.2,'DISTRIBUTION','document','not search_price.visible','search_currency.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(93.1,'DISTRIBUTION','document','products_currency.visible and (not products_currency.value or products_currency.value == 0)','products_currency.highlight();invalid="укажите валюту цены загрузок/установок/активаций/кликов";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(93.2,'DISTRIBUTION','document','search_currency.visible and (not search_currency.value or search_currency.value == 0)','search_currency.highlight();invalid="укажите валюту цены поисков";',null);

-- Связанные договоры
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (100.11,'DISTRIBUTION','document','not (contract_type.value in (3, 4))','parent_contract_id.hide()',null);
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (100.12,'DISTRIBUTION','document','not client_id.value','parent_contract_id.hide()',null);
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (100.13,'DISTRIBUTION','document','parent_contract_id.visible','parent_contract_id.update_source and parent_contract_id.update_source("contract_list", "client_id==%s'||Chr(38)||'type==''DISTRIBUTION'''||Chr(38)||'distr_contract_type==5"%client_id.value)',null);
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (100.21,'DISTRIBUTION','document','parent_contract_id.value and currency.value','glob.currency_check_result = call("check_parent_contract_currency", {"parent_contract_id": parent_contract_id.value, "currency": currency.value})','glob.currency_check_result=""');
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (100.22,'DISTRIBUTION','document','glob.currency_check_result','currency.highlight();invalid="валюта не совпадает с валютой родительского договора: " + glob.currency_check_result',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(500,'DISTRIBUTION','document',null,'err_message(invalid);collateral_type.disable();collateral_type.hide();num.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(800.1,'DISTRIBUTION','document','invalid','button_submit.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(3500,'DISTRIBUTION','document','disable_main','service_start_dt.disable();external_id.disable();client_id.disable();contract_type.disable();manager_code.disable();manager_bo_code.disable();person_id.disable();firm.disable();currency.disable();dt.disable();end_dt.disable();payment_type.disable();tail_time.disable();group02.disable();currency_calculation.disable();distribution_tag.disable();',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(20,'DISTRIBUTION','col',null,'col.invalid="";col.test_mode.hide()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(500.4,'DISTRIBUTION','col','col.new_col','map(lambda x: x.hide(), col.group02.subitems)',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(500.41,'DISTRIBUTION','col','(col.new_col and col.collateral_type) and col.group02["grp_"+str(col.collateral_type.value)]','col.selected = col.group02["grp_"+str(col.collateral_type.value)];col.selected.show()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501,'DISTRIBUTION','col','loading','col.lfaxed = col.is_faxed.value; col.lsigned = col.is_signed.value; col.lsent=col.sent_dt.value; col.lcancelled = col.is_cancelled.value; col.somehow_signed = col.is_signed.value or col.is_faxed.value;',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.3,'DISTRIBUTION','col','col.lcancelled and col.is_cancelled.value','col.memo.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.35,'DISTRIBUTION','col','col and colclass and colclass(col)=="ANNOUNCEMENT"','col.is_cancelled.enable();col.is_signed.hide();col.is_faxed.hide();col.sent_dt.hide();col.num.value="";col.num.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.4,'DISTRIBUTION','col','col.lsigned','col.is_signed.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.5,'DISTRIBUTION','col','col.lfaxed','col.is_faxed.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.55,'DISTRIBUTION','col','col.lsent','col.sent_dt.disable()',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.6,'DISTRIBUTION','col','(not col.new_col) and (col.lsigned or col.lfaxed) and ((col.somehow_signed.year < date().year or (col.somehow_signed.year == date().year and col.somehow_signed.month < date().month))  or (contract_type.value and contract_type.value != 4))','col.dt.disable();col.num.disable();col.group02.disable()',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.65,'DISTRIBUTION','col','(not col.new_col) and colclass and colclass(col)=="ANNOUNCEMENT"','col.dt.disable();col.num.disable();col.group02.disable();',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(501.7,'DISTRIBUTION','col','not col.new_col','col.collateral_type.disable()','col.is_cancelled.disable()');

Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(7.31,'DISTRIBUTION','is_signed.value and is_signed.value>datetime()','is_signed.highlight();invalid="Дата подписания больше текущей даты"',null,'document');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(7.32,'DISTRIBUTION','is_faxed.value and is_faxed.value>datetime()','is_faxed.highlight();invalid="Дата подписания больше текущей даты"',null,'document');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(7.33,'DISTRIBUTION','is_cancelled.value and is_cancelled.value>datetime()','is_cancelled.highlight();invalid="Дата отмены больше текущей даты"',null,'document');

Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(522.01,'DISTRIBUTION','col.is_signed.value and col.is_signed.value>datetime()', 'col.is_signed.highlight();col.invalid="Дата подписания допсоглашения больше текущей даты"', null,'col');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values
 (522.02,'DISTRIBUTION','col.is_faxed.value and col.is_faxed.value>datetime()', 'col.is_faxed.highlight();col.invalid="Дата подписания допсоглашения больше текущей даты"', null,'col');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values 
(522.03,'DISTRIBUTION','col.is_cancelled.value and col.is_cancelled.value>datetime()', 'col.is_cancelled.highlight();col.invalid="Дата отмены допсоглашения больше текущей даты"', null,'col');

--is_booked
INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.667, 'DISTRIBUTION',
        'loading and is_booked.value',
          'glob.l_is_booked = True',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.669, 'DISTRIBUTION',
        'not glob.l_is_booked and is_booked.value and is_booked_dt.value',
          'is_faxed.value = is_booked_dt.value; glob.l_is_booked = True;',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.6691, 'DISTRIBUTION',
        'not glob.l_is_booked and is_booked.value and not is_booked_dt.value',
          'is_booked_dt.value = datetime(); is_faxed.value = is_booked_dt.value; glob.l_is_booked = True;',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.670, 'DISTRIBUTION',
        'glob.l_is_booked and not is_booked.value',
          'is_faxed.value = datetime(); glob.l_is_booked = False;',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.671, 'DISTRIBUTION',
        'is_booked.value',
          'is_faxed.disable()',
          null,
        'document');


INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (522.667,'DISTRIBUTION',
        'loading and col.is_booked.value',
          'col.l_col_is_booked = True',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (522.669, 'DISTRIBUTION',
        'not col.l_col_is_booked and col.is_booked.value and col.is_booked_dt.value',
          'col.is_faxed.value = col.is_booked_dt.value; col.l_col_is_booked = True;',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (522.6691, 'DISTRIBUTION',
        'not col.l_col_is_booked and col.is_booked.value and not col.is_booked_dt.value',
          'col.is_booked_dt.value = datetime(); col.is_faxed.value = col.is_booked_dt.value; col.l_col_is_booked = True;',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (522.670, 'DISTRIBUTION',
        'col.l_col_is_booked and not col.is_booked.value',
          'col.is_faxed.value = datetime(); col.l_col_is_booked = False;',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (522.671,'DISTRIBUTION',
        'col.is_booked.value',
          'col.is_faxed.disable()',
          null,
        'col');


Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(510,'DISTRIBUTION','col','visible(col,"products_revshare") and len(col.selected.products_revshare.value)==0','col.selected.products_revshare.highlight();col.invalid="не заполнен процент партнера"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512,'DISTRIBUTION','col','visible(col,"end_dt") and not col.selected.end_dt.value','col.selected.end_dt.highlight();col.invalid="не заполнена дата окончания договора"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.1,'DISTRIBUTION','col','col.collateral_type.value != 3200 and visible(col, "products_download") and (len(col.selected.products_download.value)==0 or col.selected.products_download.validate_ctrl()) and col.selected.fixed_scale.value==0','col.selected.products_download.highlight();col.selected.fixed_scale.highlight();col.invalid="неверно заполнены продукты загрузок";',null);
insert into bo.t_contract_rules (position,type,context,condition,action,elseaction) values
(512.11,'DISTRIBUTION','col','visible(col, "products_revshare") and (len(col.selected.products_revshare.value)==0 or col.selected.products_revshare.validate_ctrl())','col.selected.products_revshare.highlight();col.invalid="неверно заполнены продукты разделения";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.15,'DISTRIBUTION','col','col.selected and visible(col, "fixed_scale") and col.selected.fixed_scale.value>0','col.selected.products_download.hide()', '');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.161,'DISTRIBUTION','col','(visible(col, "products_download") or visible(col, "fixed_scale")) and contract_type.value == 4','col.selected.download_domains.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.162,'DISTRIBUTION','col','visible(col, "install_price") and contract_type.value == 4','col.selected.install_soft.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.163,'DISTRIBUTION','col','visible(col, "products_download") and contract_type.value in (2, 3)','col.selected.partner_resources.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.164,'DISTRIBUTION','col','visible(col, "install_price") and contract_type.value in (2, 3)','col.selected.partner_resources.hide(); col.selected.distribution_products.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.165,'DISTRIBUTION','col','visible(col, "fixed_scale") and contract_type.value in (2, 3)','col.selected.partner_resources.hide();','');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.2,'DISTRIBUTION','col','((visible(col, "products_download") and len(col.selected.products_download.value)>0) or (visible(col, "fixed_scale") and col.selected.fixed_scale.value>0)) and visible(col, "download_domains") and not col.selected.download_domains.value ','col.selected.download_domains.highlight();col.invalid="укажите домены";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.3,'DISTRIBUTION','col','col.collateral_type.value != 3200 and visible(col, "install_price") and not col.selected.install_price.value and not col.selected.install_price.value_strictly_equals(0)','col.selected.install_price.highlight();col.invalid="укажите цену за установку";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.35,'DISTRIBUTION','col','visible(col, "install_price") and col.selected.install_price.value and visible(col, "install_soft") and not col.selected.install_soft.value','col.selected.install_soft.highlight();col.invalid="укажите список ПО";',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.4,'DISTRIBUTION','col','col.collateral_type.value in (3030, 3200) and visible(col, "product_search") and (not (1 in col.selected.distribution_places.value))','col.selected.product_search.hide();', null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.41,'DISTRIBUTION','col','col.collateral_type.value in (3030, 3200) and visible(col, "product_searchf") and (not (2 in col.selected.distribution_places.value))','col.selected.product_searchf.hide();', null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.42,'DISTRIBUTION','col','col.collateral_type.value in (3030, 3200) and visible(col, "product_options") and (not (3 in col.selected.distribution_places.value))','col.selected.product_options.hide();', null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.421,'DISTRIBUTION','col','col.collateral_type.value == 3050 and (not (1 in distribution_places.value))','col.selected.product_search.hide();', null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.422,'DISTRIBUTION','col','col.collateral_type.value == 3050 and (not (2 in distribution_places.value))','col.selected.product_searchf.hide();', null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.423,'DISTRIBUTION','col','col.collateral_type.value == 3050 and (not (3 in distribution_places.value))','col.selected.product_options.hide();', null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.45,'DISTRIBUTION','col','visible(col, "product_search") and not col.selected.product_search.value','col.selected.product_search.highlight();col.invalid="не заполнена номенклатура"', null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.46,'DISTRIBUTION','col','visible(col, "product_searchf") and not col.selected.product_searchf.value','col.selected.product_searchf.highlight();col.invalid="не заполнена номенклатура"', null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(512.47,'DISTRIBUTION','col','visible(col, "product_options") and not col.selected.product_options.value','col.selected.product_options.highlight();col.invalid="не заполнена номенклатура"', null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.481,'DISTRIBUTION','col','visible(col,"partner_resources") and not col.selected.partner_resources.value','col.selected.partner_resources.highlight();col.invalid="Не указаны ресурсы партнёра"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.482,'DISTRIBUTION','col','visible(col,"distribution_products") and not col.selected.distribution_products.value','col.selected.distribution_products.highlight();col.invalid="Не указаны продукты дистрибуции"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(512.5,'DISTRIBUTION','col','col.collateral_type.value == 3060 and visible(col,"tail_time") and not tail_time.visible','col.selected.tail_time.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(513,'DISTRIBUTION','col','visible(col,"tail_time") and col.selected.tail_time.value == ""','col.selected.tail_time.highlight();col.invalid="не заполнен период окончания выплат"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(514,'DISTRIBUTION','col','visible(col,"search_price") and not col.selected.search_price.value and not col.selected.search_price.value_strictly_equals(0)','col.selected.search_price.highlight();col.invalid="не задана цена за поиски"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(515,'DISTRIBUTION','col','visible(col,"distribution_places") and not len(col.selected.distribution_places.value)','col.selected.distribution_places.highlight();col.invalid="выберите один из продуктов"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(516,'DISTRIBUTION','col','col.dt.value and (col.dt.value < dt.value)','col.dt.highlight(); col.invalid = "Дата начала действия допсоглашения должна превышать дату договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(517,'DISTRIBUTION','col','not col.dt.value','col.dt.highlight(); col.invalid = "Не выбрана дата начала действия допсоглашения"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(517.3,'DISTRIBUTION','col','','type_cols = {1:(3010, 3020, 3030, 3040, 3060, 3090), 2:(3010, 3070, 3080, 3040, 3060,)}',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(517.4,'DISTRIBUTION','col','contract_type.value in (1,2) and col.collateral_type.value and (not (col.collateral_type.value in type_cols[contract_type.value]))','col.collateral_type.highlight();col.invalid = "Недопустимое доп. соглашение для данного договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(517.5,'DISTRIBUTION','col','contract_type.value in (3, 4) and (not 1 in supplements.value) and (col.collateral_type.value in [3020, 3090, 3030])','col.collateral_type.highlight();col.invalid = "Недопустимое доп. соглашение для данного договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(517.6,'DISTRIBUTION','col','contract_type.value in (3, 4) and (not 2 in supplements.value) and (col.collateral_type.value in [3070, 3080])','col.collateral_type.highlight();col.invalid = "Недопустимое доп. соглашение для данного договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(517.7,'DISTRIBUTION','col','contract_type.value in (3, 4) and (not 3 in supplements.value) and (col.collateral_type.value in [3100])','col.collateral_type.highlight();col.invalid = "Недопустимое доп. соглашение для данного договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(517.81,'DISTRIBUTION','col','contract_type.value == 3 and col.collateral_type.value == 3035','col.collateral_type.highlight();col.invalid = "Недопустимое доп. соглашение для данного договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(517.82,'DISTRIBUTION','col','contract_type.value == 4 and col.collateral_type.value == 3030','col.collateral_type.highlight();col.invalid = "Недопустимое доп. соглашение для данного договора"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values 
(518,'DISTRIBUTION','col','not col.collateral_type.value','col.collateral_type.highlight(); col.invalid = "Выберите тип допсоглашения"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(519.02,'DISTRIBUTION','col','tail_time.visible and tail_time.value','glob.c_tail_time = tail_time.value','glob.c_tail_time = 0');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(519.03,'DISTRIBUTION','col','visible(col,"supplements")','glob.c_supplements = col.selected.supplements.value','glob.c_supplements = supplements.value');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(519.04,'DISTRIBUTION','col','visible(col,"end_dt") and col.selected.end_dt.value','glob.c_end_dt = col.selected.end_dt.value','glob.c_end_dt = end_dt.value');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(519.1,'DISTRIBUTION','col','col.dt.value and not col.invalid','glob.col_tag_errors = call("get_contracts_crossing_by_dates", {"contract_id": id.value, "contract_type": contract_type.value, "client_id": client_id.value, "tag_id": distribution_tag.value, "start_dt": col.dt.value, "finish_dt": glob.c_end_dt, "tail_time": glob.c_tail_time, "supplements": glob.c_supplements})','glob.col_tag_errors = ""');
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(519.2,'DISTRIBUTION','col','glob.col_tag_errors','col.invalid = "Тэг уже используется договорами: " + glob.col_tag_errors',null);

-- Тип ПФ
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values
(520,'DISTRIBUTION',null,'print_form_type.hide()',null,'document');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values
(520.01,'DISTRIBUTION','col.print_form_type.value == 1 and not(unicode(col.num.value).lower().encode("utf8").startswith("у"))','col.num.highlight();col.invalid = "Номер допсоглашения должен начинаться с У"','','col');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values
(520.02,'DISTRIBUTION','col.print_form_type.value == 2 and not(unicode(col.num.value).lower().encode("utf8").startswith("п"))','col.num.highlight();col.invalid = "Номер допсоглашения должен начинаться с П"','','col');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values
(520.03,'DISTRIBUTION','col.print_form_type.value == 3 and not(unicode(col.num.value).lower().encode("utf8").startswith("ф"))','col.num.highlight();col.invalid = "Номер допсоглашения должен начинаться с Ф"','','col');
Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONDITION,ACTION,ELSEACTION,CONTEXT) values
(520.8,'DISTRIBUTION','(not col.new_col) and (col.lsigned or col.lfaxed)','col.print_form_type.disable()',null,'col');

-- Валюта цена загрузок/установок/поисков в ДС
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(521.1,'DISTRIBUTION','col','visible(col,"search_currency") and contract_type.value == 2','col.selected.search_currency.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(521.2,'DISTRIBUTION','col','visible(col,"products_currency")','col.selected.products_currency.update_source("allowed_currencies", "cc_num==%s"%currency.value);',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(521.3,'DISTRIBUTION','col','visible(col,"search_currency")','col.selected.search_currency.update_source("allowed_currencies", "cc_num==%s"%currency.value);',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(621.4,'DISTRIBUTION','col','visible(col,"products_currency") and (not col.selected.products_currency.value or col.selected.products_currency.value == 0)','col.selected.products_currency.highlight();col.invalid="укажите валюту цены загрузок/установок/активаций/кликов";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(621.5,'DISTRIBUTION','col','visible(col,"search_currency") and (not col.selected.search_currency.value or col.selected.search_currency.value == 0)','col.selected.search_currency.highlight();col.invalid="укажите валюту цены поисков";',null);

-- Универсальное ДС на изменение условий УДД/ГД
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.01,'DISTRIBUTION','col','col.collateral_type.value == 3200 and not (contract_type.value in (3, 4))','col.collateral_type.highlight();col.invalid = "Недопустимое доп. соглашение для данного договора";',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.02,'DISTRIBUTION','col','visible(col,"supplements") and contract_type.value != 4','col.selected.partner_resources.hide(); col.selected.distribution_products.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.041,'DISTRIBUTION','col','visible(col,"supplements") and 1 in supplements.value and not (1 in col.selected.supplements.value)','col.selected.supplements.highlight();col.invalid="Нельзя удалять приложения договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.042,'DISTRIBUTION','col','visible(col,"supplements") and 2 in supplements.value and not (2 in col.selected.supplements.value)','col.selected.supplements.highlight();col.invalid="Нельзя удалять приложения договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.043,'DISTRIBUTION','col','visible(col,"supplements") and 3 in supplements.value and not (3 in col.selected.supplements.value)','col.selected.supplements.highlight();col.invalid="Нельзя удалять приложения договора"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.11,'DISTRIBUTION','col','visible(col,"supplements") and not (1 in col.selected.supplements.value)','col.selected.reward_type.hide();col.selected.avg_discount_pct.hide();col.selected.products_revshare.hide();col.selected.distribution_places.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.12,'DISTRIBUTION','col','visible(col,"supplements") and (1 in col.selected.supplements.value) and contract_type.value == 4','col.selected.distribution_places.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.13,'DISTRIBUTION','col','visible(col,"supplements") and (1 in col.selected.supplements.value) and col.selected.reward_type.value != 2','col.selected.avg_discount_pct.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.21,'DISTRIBUTION','col','visible(col,"supplements") and not (2 in col.selected.supplements.value)','col.selected.products_download.hide();col.selected.download_domains.hide();col.selected.install_price.hide();col.selected.install_soft.hide();col.selected.fixed_scale.hide();col.selected.activation_price.hide();col.selected.advisor_price.hide();col.selected.products_currency.hide();',null);
Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.22,'DISTRIBUTION','col','visible(col,"supplements") and contract_type.value == 4 and (2 in col.selected.supplements.value)','col.selected.download_domains.hide();col.selected.install_soft.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.23,'DISTRIBUTION','col','((visible(col,"supplements") and len(col.selected.supplements.value) == 1) or (col.collateral_type.value != 3200 and len(supplements.value) == 1)) and visible(col,"advisor_price") and not col.selected.advisor_price.value','col.selected.tail_time.hide();',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(509.24,'DISTRIBUTION','col','visible(col,"supplements") and visible(col, "install_price") and visible(col, "products_download") and visible(col, "fixed_scale") and visible(col,"activation_price") and visible(col,"advisor_price") and not col.selected.install_price.value and not col.selected.install_price.value_strictly_equals(0) and (len(col.selected.products_download.value)==0 and col.selected.fixed_scale.value==0) and not col.selected.activation_price.value and not col.selected.activation_price.value_strictly_equals(0) and not col.selected.advisor_price.value and not col.selected.advisor_price.value_strictly_equals(0)','col.selected.install_price.highlight();col.selected.fixed_scale.highlight();col.selected.products_download.highlight();col.selected.activation_price.highlight();col.selected.advisor_price.highlight();col.invalid="Должны быть заданы либо продукты загрузок, либо цена за установку, либо цена за активацию, либо цена за клик Маркета";',null);
insert into bo.t_contract_rules (position,type,context,condition,action,elseaction) values
(509.31,'DISTRIBUTION','col','visible(col,"supplements") and not (3 in col.selected.supplements.value)','col.selected.search_price.hide();col.selected.search_currency.hide();',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(530,'DISTRIBUTION','col','contract_type.value == 5 and not (col.collateral_type.value in (3010, 3040, 3060))','col.collateral_type.highlight();col.invalid = "Недопустимое доп. соглашение для данного договора"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(790,'DISTRIBUTION','col','invalid','col.invalid="Нельзя сохранить допсоглашение из-за ошибок в договоре"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(800,'DISTRIBUTION','col','col.invalid','col.button_submit.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(801,'DISTRIBUTION','col','True and not col.hidden','err_message(col.invalid, col.form)',null);
