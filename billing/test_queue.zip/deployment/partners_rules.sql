--liquibase formatted sql

--changeset ashvedunov:BALANCE-23866-14 runOnChange:true stripComments:false

-- lock type for avoid deadlocks
select * from bo.T_CONTRACT_TYPES WHERE TYPE='PARTNERS' FOR UPDATE;

merge into BO.T_CONTRACT_COLLATERAL_TYPES b using
(select
2010 id ,20 pos,'РСЯ: изменение налогообложения' caption,'COLLATERAL' collateral_class from dual union all select
2020,30, 'РСЯ: изменение процента партнера','COLLATERAL' from dual union all select
2030,40, 'РСЯ: подключение площадок МКБ','COLLATERAL' from dual union all select
2070,45, 'РСЯ: о баннеромаркете','COLLATERAL' from dual union all select
2080,47, 'РСЯ: о поисковых формах','COLLATERAL' from dual union all select
2040,50, 'РСЯ: прочее','COLLATERAL' from dual union all select
2060,60, 'РСЯ: о доменах','COLLATERAL' from dual union all select
2050,90, 'РСЯ: расторжение договора','COLLATERAL' from dual union all select
2110,100, 'РСЯ: изменение способа выплат','COLLATERAL' from dual union all select
2090,1000, 'РСЯ: о закрытии договора','ANNOUNCEMENT' from dual union all select
2100,1010, 'РСЯ: изменение налогообложения','ANNOUNCEMENT' from dual
) m
on (b.id = m.id)
when matched then
  update set b.pos = m.pos, b.caption = m.caption, b.contract_type = 'PARTNERS', b.collateral_class = m.collateral_class where b.id = m.id
when not matched then
  insert (ID,POS,CONTRACT_TYPE,CAPTION, COLLATERAL_CLASS) values (m.id, m.pos, 'PARTNERS', m.caption, m.collateral_class);


-- contract_collateral_attrs
delete from BO.t_contract_collateral_attrs where contract_type='PARTNERS';
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2010,2010,'PARTNERS','NDS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2020,2020,'PARTNERS','PARTNER_PCT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2030,2020,'PARTNERS','AGREGATOR_PCT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2031,2020,'PARTNERS','DSP_AGREGATION_PCT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2040,2030,'PARTNERS','MKB_PRICE',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2050,2050,'PARTNERS','END_DT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2110,2060,'PARTNERS','DOMAINS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2070,2070,'PARTNERS','MARKET_BANNER',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2080,2070,'PARTNERS','BM_DIRECT_PCT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2090,2070,'PARTNERS','BM_MARKET_PCT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2095,2070,'PARTNERS','BM_DOMAINS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2097,2070,'PARTNERS','BM_PLACES',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2100,2080,'PARTNERS','SEARCH_FORMS',1, 1);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3000,2090,'PARTNERS','END_DT',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3005,2090,'PARTNERS','END_REASON',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3010,2100,'PARTNERS','NDS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (3020,2110,'PARTNERS','PAY_TO',null,null);

---------------------------------------
-- TYPES
---------------------------------------

delete from BO.t_contract_attribute_types where type='PARTNERS';

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('COLLATERAL_TYPE','PARTNERS','int','colselect','partners_collaterals','на',null,1,5,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('CONTRACT_TYPE','PARTNERS','int','refselect','partnerctype','Тип договора',null,0,5,1);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('FIRM','PARTNERS','int','refselect','firms','Фирма',0,0,6,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('CURRENCY','PARTNERS','int','refselect','partnercurrency','Валюта',null,0,25,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('DOC_SET','PARTNERS','int','refselect','docset','Комплект документов',null,0,20,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('PAY_TO','PARTNERS','int','refselect','payment_type','Тип выплат',null,0,22,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('DT','PARTNERS','date','date',null,'Дата начала',null,1,39,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('END_DT','PARTNERS','date','date',null,'Дата окончания',null,0,40,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('END_REASON','PARTNERS','int','refselect','endreason','Причина окончания',null,0,42,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('MANAGER_CODE','PARTNERS','int','autocomplete','managers?params=manager_type=3','Менеджер РСЯ',null,0,30,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('MEMO','PARTNERS','clob','text?rows=7' ||Chr(38)|| 'cols=30',null,'Примечание',0,1,60,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('ATYPICAL_CONDITIONS','PARTNERS','int','checkbox',null,'Нетиповые условия',0,0,61,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('NUM','PARTNERS','str','input',null,'№',null,1,4,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('PAYMENT_TYPE','PARTNERS','int','refselect','billinterval','Период актов',null,0,50,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('AGREGATOR_PCT','PARTNERS','money','pctinput?precision=13' ||Chr(38)|| 'currency=%%' ||Chr(38)|| 'max=60' ||Chr(38)|| 'min=25',null,'% агрегатора',null,0,68,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('DSP_AGREGATION_PCT','PARTNERS','money','pctinput?precision=0' ||Chr(38)|| 'currency=%%' ||Chr(38)|| 'max=60' ||Chr(38)|| 'min=5',null,'% за агрегацию в РТБ',null,0,69,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('BM_DIRECT_PCT','PARTNERS','money','pctinput?precision=0' ||Chr(38)|| 'currency=%%' ||Chr(38)|| 'max=60' ||Chr(38)|| 'min=25',null,'% за БМ низ',null,0,100,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('BM_DOMAINS','PARTNERS','str','input',null,'домены БМ',null,0,105,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('BM_MARKET_PCT','PARTNERS','money','pctinput?precision=0' ||Chr(38)|| 'currency=%%' ||Chr(38)|| 'max=60' ||Chr(38)|| 'min=25',null,'% за БМ верх',null,0,95,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('BM_PLACES','PARTNERS','str','input',null,'ID площадок БМ',null,0,107,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('DOMAINS','PARTNERS','str','input',null,'домены',null,0,69,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('MARKET_BANNER','PARTNERS','int','checkbox',null,'Баннеромаркет',null,0,90,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values ('REWARD_TYPE','PARTNERS','int','refselect','distr_reward_type','Вознаграждение от оборота',null,0,51,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('MKB_PRICE','PARTNERS','intdict','mkbselector?precision=0' ||Chr(38)|| 'key_caption=Площадка' ||Chr(38)|| 'value_caption=Цена','mkb','МКБ',null,0,80,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('NDS','PARTNERS','int','refselect','ndsreal','Ставка НДС',null,0,70,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('UNILATERAL_ACTS','PARTNERS','int','checkbox',null,'Односторонние акты',null,0,71,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('OPEN_DATE','PARTNERS','int','checkbox',null,'Открытая дата',null,0,89,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP)
values ('PARTNER_PCT','PARTNERS','money','pctinput?precision=2' ||Chr(38)||'currency=%%' ||Chr(38)|| 'max=99' ||Chr(38)|| 'min=25',null,'% партнера',null,0,58,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('MARKET_API_PCT','PARTNERS','money','pctinput?precision=0' ||Chr(38)||'currency=%%' ||Chr(38)|| 'max=60' ||Chr(38)|| 'min=25',null,'% за API маркета',null,0,58.1,2);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('SEARCH_FORMS','PARTNERS','int','checkbox',null,'Поисковые формы',null,0,85,2);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('IS_CANCELLED','PARTNERS','date','datecheckbox',null,'Аннулирован',0,1,30,3);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('IS_FAXED','PARTNERS','date','datecheckbox',null,'Подписан по факсу',0,1,10,3);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('IS_SIGNED','PARTNERS','date','datecheckbox',null,'Подписан',0,1,20,3);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('SENT_DT','PARTNERS','date','datecheckbox',null,'Отправлен оригинал',0,1,25,3);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_BOOKED', 'PARTNERS', 'int', 'checkbox', null, 'Бронь подписи', 0, 1, 8, 3, null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_BOOKED_DT', 'PARTNERS', 'date', 'date?readonly=readonly', null, 'Дата брони', 0, 1, 9, 3, null);

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_ARCHIVED','PARTNERS','int','checkbox',null,'Принят в архив',0,1,21,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_ARCHIVED_DT', 'PARTNERS', 'date', 'date?readonly=readonly', null, 'Дата принятия в архив', 0, 1, 22, 3, null);

---------------------------------------
-- RULES
---------------------------------------

delete from BO.t_contract_rules where type='PARTNERS';
