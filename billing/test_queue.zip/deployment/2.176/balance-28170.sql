--liquibase formatted sql

--changeset lightrevan:BALANCE-28170-upd
UPDATE bo.t_consume q
SET current_sum = current_sum
WHERE q.archive = 1
  AND (
    q.act_sum != q.current_sum
    OR q.act_sum != q.completion_sum
    OR q.current_sum != q.completion_sum
  )
;