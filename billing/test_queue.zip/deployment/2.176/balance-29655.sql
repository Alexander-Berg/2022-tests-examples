--liquibase formatted sql

--changeset lightrevan:BALANCE-29655
update (
  select
    pcg.*,
    replace(pcg.CALC_PARAMS, json_value(pcg.CALC_PARAMS, '$.middle_dt'),
            replace(json_value(pcg.CALC_PARAMS, '$.middle_dt'), 'T', ' ')) new_calc_params
  from bo.T_PROMO_CODE_GROUP pcg
  where pcg.CALC_CLASS_NAME = 'LegacyPromoCodeGroup'
    and json_value(pcg.CALC_PARAMS, '$.middle_dt') like '%T%'
)
  set CALC_PARAMS = new_calc_params
;
