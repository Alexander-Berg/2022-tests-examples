--liquibase formatted sql

-- Сначала убираем всё, что помешает манипуляциям с t_scale и t_scale_points

--changeset vorobyov-as:BALANCE-29088-1
alter table bo.t_scale_points drop constraint T_SCALE_POINTS_T_SCALE_FK1;

--changeset vorobyov-as:BALANCE-29088-2
alter table bo.t_product_scale drop constraint FK_PROD_SCALE_SCALE_CODE;

--changeset vorobyov-as:BALANCE-29088-3
alter table bo.t_distr_download_scale_prod drop constraint FK_DISTR_DOWNLOAD_SCALE;

--changeset vorobyov-as:BALANCE-29088-4
drop materialized view log on t_scale_points;

-- Теперь создаём новые таблицы и заполняем их

--changeset vorobyov-as:BALANCE-29088-5
create table bo.t_scale_new
(
  namespace varchar2(32) not null,
  code      varchar2(40) not null,
  type      varchar2(40) not null,
  comments  varchar2(256),
  x_unit_id number,
  y_unit_id number,
  update_dt date,
  operator_uid number
);

--changeset vorobyov-as:BALANCE-29088-6
alter table bo.t_scale_new add constraint t_scale_new_pk primary key (code, namespace);

--changeset vorobyov-as:BALANCE-29088-7-v2
insert into bo.t_scale_new (
       code, namespace, type, comments, x_unit_id, y_unit_id)
select
    code,
    case
        when code = 'addappter_common_scale' then 'addappter_2'
        when (code like 'adfox%'
              and code not in ('adfox_offer_requests', 'adfox_offer_requests_SNG'))
            then 'adfox'
        when code like 'Y.Browser%' then 'distribution'
        else 'discount'
    end,
    type,
    comments,
    x_unit_id,
    y_unit_id
from bo.t_scale;

--changeset vorobyov-as:BALANCE-29088-8
create table bo.t_scale_points_new
   (id number not null,
    namespace varchar2(32) not null,
	scale_code varchar2(40) not null,
	start_dt date,
	end_dt date,
	x number,
	y number,
	hidden number default 0,
	currency varchar2(16),
	units varchar2(16),
	max_sum number,
	update_dt date,
    operator_uid number,

	constraint t_scale_points_new_pk primary key (id)
	);

--changeset vorobyov-as:BALANCE-29088-9-v2
insert into bo.t_scale_points_new
      (id, namespace, scale_code, start_dt, end_dt, x, y, hidden, currency, units, max_sum)
select
    id,
    case
        when scale_code = 'addappter_common_scale' then 'addappter_2'
        when (scale_code like 'adfox%'
              and scale_code not in ('adfox_offer_requests', 'adfox_offer_requests_SNG'))
            then 'adfox'
        when scale_code like 'Y.Browser%' then 'distribution'
        else 'discount'
    end,
    scale_code,
    start_dt,
    end_dt,
    x,
    y,
    hidden,
    currency,
    units,
    max_sum
from bo.t_scale_points;

--changeset vorobyov-as:BALANCE-29088-10
create index bo.t_scale_points_new_idx1 on bo.t_scale_points_new(namespace, scale_code);

-- Теперь меняем старые таблицы на новые

--changeset vorobyov-as:BALANCE-29088-11
alter table bo.t_scale rename to t_scale_old;

--changeset vorobyov-as:BALANCE-29088-12
alter table bo.t_scale_points rename to t_scale_points_old;

--changeset vorobyov-as:BALANCE-29088-13
alter table bo.t_scale_new rename to t_scale;

--changeset vorobyov-as:BALANCE-29088-14
alter table bo.t_scale_points_new rename to t_scale_points;

--changeset vorobyov-as:BALANCE-29088-15
update bo.t_scale set x_unit_id = 866 where namespace = 'distribution' and x_unit_id is null;