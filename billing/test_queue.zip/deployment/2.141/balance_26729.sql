--liquibase formatted sql

--changeset ashvedunov:BALANCE-26729-0 endDelimiter:\\
BEGIN BO.CREATE_PYCRON_TASK(
    'balance-by-file-export', --name
    'YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor.cfg.xml yb-python -pysupport balance/queue_processor.py BY_FILE', --d_command
    'Database-to-JSON dumper for YANDEX ADS', --d_description
    'ashvedunov', --d_owner_login
    '0 6 * * *', --s_crontab
    NULL, --s_run_at_dt
    1, --d_count_per_host
    18000, --d_timeout
    0, --d_terminate
    'ashvedunov@yandex-team.ru', --r_email
    NULL, --s_host
    1, --s_enabled
    5, --s_retry_count
    20 --s_retry_interval
);
EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN NULL;
        WHEN OTHERS THEN RAISE;
END;
\\

--changeset ashvedunov:BALANCE-26729-1
insert into bo.t_export_type (TYPE) values ('BY_FILE');

