--liquibase formatted sql

--changeset isupov:BALANCE-26671-3
insert into bo.t_config(item, value_num) values('USE_ZERO_ACTS', 0);
