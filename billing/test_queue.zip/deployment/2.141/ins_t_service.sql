--liquibase formatted sql


--changeset srg91:TRUST-4187
insert into meta.t_service (
  id, catalog_id, cc, name, url,
  extra_pay, version, iface_version,
  display_name, show_to_user, suppress_discouts, in_contract, show_to_external_user,
  is_auto_completion, shipment_auto, direct_payment, service_group_id, client_only,
  token, unilateral, fiscal_agent_type
)
select
  605, 0, 'ubertaxi_roaming', 'Яндекс.Убер: Платежи в роуминге', '',
  1, 4, 2,
  'Яндекс.Убер: Платежи в роуминге', 1, 1, 1, 1,
  1, 0, 0, 605, 0,
  'ubertaxi_roaming_8f0cbb8d35468f87bdae164f17e09011', 1, 'agent'
from dual
where not exists(select 1 from bo.t_service where id=605);


