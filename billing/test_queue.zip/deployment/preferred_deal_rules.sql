--liquibase formatted sql

--changeset ashvedunov:BALANCE-23866-15 runOnChange:true stripComments:false

-- lock type for avoid deadlocks
select * from bo.T_CONTRACT_TYPES WHERE TYPE='PREFERRED_DEAL' FOR UPDATE;

-- COLLATERAL TYPES
------------------------------
MERGE INTO bo.t_contract_collateral_types b
USING (
  SELECT 6670 id, 20 pos, 'Приоритетная сделка: продление договора' caption, 'COLLATERAL' collateral_class
  FROM dual
  UNION ALL
  SELECT 6690, 70, 'Приоритетная сделка: добавление площадок', 'COLLATERAL'
  FROM dual
  UNION ALL
  SELECT 6680, 100, 'Приоритетная сделка: прочее', 'COLLATERAL'
  FROM dual
  UNION ALL
  SELECT 6650, 90, 'Приоритетная сделка: расторжение договора', 'COLLATERAL'
  FROM dual
) m
ON (b.id = m.id)
WHEN MATCHED THEN
  UPDATE
  SET b.pos = m.pos, b.caption = m.caption, b.contract_type = 'PREFERRED_DEAL', b.collateral_class = m.collateral_class
  WHERE b.id = m.id
WHEN NOT MATCHED THEN
  INSERT (id, pos, contract_type, caption, collateral_class)
  VALUES (m.id, m.pos, 'PREFERRED_DEAL', m.caption, m.collateral_class)
;

-- COLLATERAL ATTRS
DELETE FROM bo.t_contract_collateral_attrs
WHERE contract_type = 'PREFERRED_DEAL';

INSERT INTO bo.t_contract_collateral_attrs (id, coltype_id, contract_type, attribute_code, usedefault, value)
VALUES (6651, 6650, 'PREFERRED_DEAL', 'END_DT', null, null);

INSERT INTO bo.t_contract_collateral_attrs (id, coltype_id, contract_type, attribute_code, usedefault, value)
VALUES (6660, 6670, 'PREFERRED_DEAL', 'END_DT', null, null);

INSERT INTO bo.t_contract_collateral_attrs (id, coltype_id, contract_type, attribute_code, usedefault, value)
VALUES (6680, 6690, 'PREFERRED_DEAL', 'PLACEMENT_IDS', null, null);

-- ATTRIBUTE TYPES
DELETE FROM bo.t_contract_attribute_types
WHERE type = 'PREFERRED_DEAL';

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('FIRM', 'PREFERRED_DEAL', 'int', 'refselect', 'firms', 'Фирма', 0, 0, 6, 1);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('CURRENCY', 'PREFERRED_DEAL', 'int', 'refselect', 'partnercurrency', 'Валюта', null, 0, 7, 1);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('NUM', 'PREFERRED_DEAL', 'str', 'input', null, '№', null, 1, 4, 1);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('COLLATERAL_TYPE', 'PREFERRED_DEAL', 'int', 'colselect', 'preferred_deal_collaterals', 'на', 0, 1, 5, 1, null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('DT', 'PREFERRED_DEAL', 'date', 'date', null, 'Дата начала', null, 1, 39, 1);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('END_DT', 'PREFERRED_DEAL', 'date', 'date', null, 'Дата окончания', null, 0, 40, 1);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('MEMO', 'PREFERRED_DEAL', 'clob', 'text?rows=7' || Chr(38) || 'cols=30', null, 'Примечание', 0, 1, 60, 1);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('ATYPICAL_CONDITIONS', 'PREFERRED_DEAL', 'int', 'checkbox', null, 'Нетиповые условия', 0, 0, 61, 1);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('FIXED_PRICE_COEF', 'PREFERRED_DEAL', 'money', 72, 2, 0, 'Коэффициент сделки', 'pctinput?precision=6' || Chr(38) || 'min=0.000001', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('DISCOUNT_PCT', 'PREFERRED_DEAL', 'money', 70, 2, 0, 'Скидка', 'pctinput?precision=6' || Chr(38) || 'min=0.0' || Chr(38) || 'max=99.999999' || Chr(38) || 'currency=%%', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('MARGIN_PCT', 'PREFERRED_DEAL', 'money', 69, 2, 0, 'Наценка', 'pctinput?precision=6' || Chr(38) || 'min=0.0' || Chr(38) || 'currency=%%', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('K_COEF', 'PREFERRED_DEAL', 'money', 68, 2, 0, 'Коэффициент К', 'pctinput?precision=6' || Chr(38) || 'min=0.0', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('PRODUCT_ID', 'PREFERRED_DEAL', 'money', 71, 2, 0, 'Продукт', 'pctinput?precision=0' || Chr(38) || 'min=1', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('RENDER_LIMIT', 'PREFERRED_DEAL', 'money', 73, 2, 0, 'Бюджет сделки в показах', 'pctinput?precision=0' || Chr(38) || 'min=1', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('DEAL_TYPE', 'PREFERRED_DEAL', 'int', 'refselect', 'preferred_deal_type', 'Тип сделки', null, 0, 67, 2, null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('DSP_IDS', 'PREFERRED_DEAL', 'strdict', 'ids_grid?additem=1' || chr(38) || 'maxitems=1' || chr(38) || 'col_0_id=type=number,editable=0,width=1,hidden=1' || chr(38) || 'col_10_num=type=number,editable=1,formatter=number_formatter,width=150,caption=Идентификатор DSP' || chr(38) || 'col_20_sub=type=string,editable=0,width=1,hidden=1', null, 'Допустимые DSP', null, null, 74, 2, null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('PLACEMENT_IDS', 'PREFERRED_DEAL', 'strdict', 'ids_grid?additem=1' || chr(38) || 'col_0_id=type=number,editable=0,width=1,hidden=1' || chr(38) || 'col_10_num=type=number,editable=1,formatter=number_formatter,width=100,caption=Идентификатор площадки' || chr(38) || 'col_20_sub=type=string,editable=1,editoptions=defaultValue:,caption=Дочерние площадки,width=100', null, 'Допустимые площадки', null, null, 75, 2, null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('BRAND_ID', 'PREFERRED_DEAL', 'money', 76, 2, 0, 'Идентификатор бренда (из справочника TNS)', 'pctinput?precision=0' || Chr(38) || 'min=1', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('OWNER_ID', 'PREFERRED_DEAL', 'money', 77, 2, 0, 'Владелец сделки', 'pctinput?precision=0' || Chr(38) || 'min=1', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('YANDEX_PRICE', 'PREFERRED_DEAL', 'money', 78, 2, 0, 'Yandex.Price', 'pctinput?precision=2' || Chr(38) || 'min=0.00', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('PARTNER_SHARE', 'PREFERRED_DEAL', 'money', 79, 2, 0, 'Доля партнера', 'pctinput?precision=2' || Chr(38) || 'min=0.00', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('MIN_CPM', 'PREFERRED_DEAL', 'money', 80, 2, 0, 'Изменение порога CPM', 'pctinput?precision=2' || Chr(38) || 'min=0.00', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, position, grp, headattr, caption, htmltype, source, persistattr)
VALUES ('INFO_PRICE', 'PREFERRED_DEAL', 'money', 81, 2, 0, 'InfoPrice', 'pctinput?precision=2' || Chr(38) || 'min=0.00', null, 0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('IS_CANCELLED', 'PREFERRED_DEAL', 'date', 'datecheckbox', null, 'Аннулирован', 0, 1, 30, 3);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('IS_FAXED', 'PREFERRED_DEAL', 'date', 'datecheckbox', null, 'Подписан по факсу', 0, 1, 10, 3);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('IS_SIGNED', 'PREFERRED_DEAL', 'date', 'datecheckbox', null, 'Подписан', 0, 1, 20, 3);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('SENT_DT', 'PREFERRED_DEAL', 'date', 'datecheckbox', null, 'Отправлен оригинал', 0, 1, 25, 3);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_BOOKED', 'PREFERRED_DEAL', 'int', 'checkbox', null, 'Бронь подписи', 0, 1, 8, 3, null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_BOOKED_DT', 'PREFERRED_DEAL', 'date', 'date?readonly=readonly', null, 'Дата брони', 0, 1, 9, 3, null);

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_ARCHIVED','PREFERRED_DEAL','int','checkbox',null,'Принят в архив',0,1,21,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_ARCHIVED_DT', 'PREFERRED_DEAL', 'date', 'date?readonly=readonly', null, 'Дата принятия в архив', 0, 1, 22, 3, null);

-- RULES
DELETE FROM BO.t_contract_rules
WHERE TYPE='PREFERRED_DEAL';
