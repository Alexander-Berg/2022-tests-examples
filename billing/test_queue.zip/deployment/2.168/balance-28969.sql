--liquibase formatted sql

--changeset lightrevan:BALANCE-28969-1
DROP VIEW bo.v_agency_type_manager;

--changeset lightrevan:BALANCE-28969-2
DROP VIEW bo.v_calculation_commission;

--changeset lightrevan:BALANCE-28969-3
DROP VIEW bo.v_calculation_commission_frcst;

--changeset lightrevan:BALANCE-28969-4
DROP VIEW bo.v_partner_usage;

--changeset lightrevan:BALANCE-28969-5
DROP VIEW bo.v_client_service_usage;
