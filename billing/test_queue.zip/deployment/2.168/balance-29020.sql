--liquibase formatted sql

--changeset lightrevan:BALANCE-29020
DELETE FROM bo.t_extprops
WHERE classname = 'Request' AND attrname = 'tmp_turn_on_rows';
