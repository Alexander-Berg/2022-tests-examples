--liquibase formatted sql

--changeset retard:TRUST-2450
insert into bo.T_INSTANT_PAYSYS values (1080, 'ECOMM_QIWI');

--changeset retard:TRUST-2450-1
update bo.t_processing  set module='rbs_webapi' where id in (10102, 50102);
