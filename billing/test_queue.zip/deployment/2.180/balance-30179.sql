--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30179
update bo.t_thirdparty_service
set product_mapping_config =
'{"default_product_mapping": {"RUB": {"nds_0": 509168, "nds_none": 509168, "nds_10": 509167, "nds_18_118": 509167, "nds_18": 509167, "nds_20_120": 509167, "nds_20": 509167}}}'
where id = 600;
