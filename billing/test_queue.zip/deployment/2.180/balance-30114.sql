--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30114-1 endDelimiter:\\
begin
    DBMS_MVIEW.REFRESH('BO.MV_PARTNER_DSP_CONTRACT');
    DBMS_MVIEW.REFRESH('BO.MV_ADDAPTER_COMM_PLACES');
end;
\\
