--liquibase formatted sql

--changeset lightrevan:BALANCE-27736-drop-views

DROP VIEW bo.monitor_direct_discount;
DROP VIEW bo.monitor_direct_discount_sup;
DROP VIEW bo.v_missing_direct_discounts;

DROP VIEW bo.v_client_direct_act_discounts;
DROP VIEW bo.v_client_direct_cmpl_discounts;
DROP VIEW bo.v_client_direct_discounts_fast;
DROP VIEW bo.v_client_direct_new_discounts;
DROP VIEW bo.V_DIRECT_BUDGET_CLIENTS;
DROP VIEW bo.V_DIRECT_BUDGET_CLIENTS_FAST;

DROP VIEW bo.XXXXX_DIRECT_BUDGET;
DROP VIEW bo.MV_DIRECT_BUDGET;
DROP VIEW bo.MV_DIRECT_BUDGET_F;

--changeset lightrevan:BALANCE-27736-drop-budget-1
DROP MATERIALIZED VIEW bo.MV_DIRECT_BUDGET_1;

--changeset lightrevan:BALANCE-27736-drop-budget-2
DROP MATERIALIZED VIEW bo.MV_DIRECT_BUDGET_2;

--changeset lightrevan:BALANCE-27736-drop-budget-cl
DROP MATERIALIZED VIEW bo.MV_CLIENT_BUDGET;

--changeset lightrevan:BALANCE-27736-drop-budget-view
DROP VIEW bo.v_direct_budget;

--changeset lightrevan:BALANCE-27736-drop-budget-cl-view
DROP VIEW bo.v_client_budget;
