--liquibase formatted sql

--changeset ashvedunov:BALANCE-23866-11 runOnChange:true stripComments:false

-- lock type for avoid deadlocks
select * from bo.T_CONTRACT_TYPES WHERE TYPE='AFISHA' FOR UPDATE;


------------------------------
-- COLLATERAL TYPES
------------------------------
merge into BO.T_CONTRACT_COLLATERAL_TYPES b using
  (select
     6010 id ,20 pos,'Афиша: изменение налогообложения' caption,'COLLATERAL' collateral_class from dual union all select
6040,50, 'Афиша: Изменение цены','COLLATERAL' from dual union all select
6070, 100, 'Афиша: продление договора', 'COLLATERAL' from dual union all select
6080, 100, 'Афиша: прочее', 'COLLATERAL' from dual union all select
   6050,90, 'Афиша: расторжение договора','COLLATERAL' from dual
  ) m
on (b.id = m.id)
when matched then
update set b.pos = m.pos, b.caption = m.caption, b.contract_type = 'AFISHA', b.collateral_class = m.collateral_class where b.id = m.id
when not matched then
insert (ID,POS,CONTRACT_TYPE,CAPTION, COLLATERAL_CLASS) values (m.id, m.pos, 'AFISHA', m.caption, m.collateral_class)
;
------------------------------

------------------------------
-- COLLATERAL ATTRS
------------------------------
DELETE FROM bo.t_contract_collateral_attrs
WHERE contract_type='AFISHA';

Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (6010,6010,'AFISHA','NDS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (6040,6040,'AFISHA','AFISHA_INFO',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (6050,6040,'AFISHA','AFISHA_RIGHTS',null,null);
Insert into BO.t_contract_collateral_attrs (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (6051,6050,'AFISHA','END_DT',null,null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (6060,6070,'AFISHA','END_DT',null,null);
------------------------------

------------------------------
-- ATTRIBUTE TYPES
------------------------------
DELETE FROM bo.t_contract_attribute_types
WHERE type='AFISHA';

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('FIRM','AFISHA','int','refselect','firms','Фирма',0,0,6,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('NUM','AFISHA','str','input',null,'№',null,1,4,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
  values ('COLLATERAL_TYPE','AFISHA','int','colselect','afisha_collaterals','на',0,1,5,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('CURRENCY','AFISHA','int','refselect','partnercurrency','Валюта',null,0,25,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('DT','AFISHA','date','date',null,'Дата начала',null,1,39,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('END_DT','AFISHA','date','date',null,'Дата окончания',null,0,40,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('MANAGER_CODE','AFISHA','int','autocomplete','managers?params=manager_type=6','Менеджер Афиши',null,0,30,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MANAGER_BO_CODE','AFISHA','int','autocomplete','managers?params=manager_type=2','Менеджер БО',1,0,30,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('MEMO','AFISHA','clob','text?rows=7' ||Chr(38)|| 'cols=30',null,'Примечание',0,1,60,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('ATYPICAL_CONDITIONS','AFISHA','int','checkbox',null,'Нетиповые условия',0,0,61,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values
 ('PAYMENT_TYPE','AFISHA','int','refselect','billinterval','Период актов',null,0,50,1);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('NDS','AFISHA','int','refselect','ndsreal','Ставка НДС',null,0,70,2);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('AFISHA_INFO','AFISHA','money',71,2,0,'Цена за предоставление информации, без НДС','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38),null,0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('AFISHA_RIGHTS','AFISHA','money',72,2,0,'Цена за право на использование информации, без НДС','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38),null,0);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('IS_CANCELLED','AFISHA','date','datecheckbox',null,'Аннулирован',0,1,30,3);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('IS_FAXED','AFISHA','date','datecheckbox',null,'Подписан по факсу',0,1,10,3);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('IS_SIGNED','AFISHA','date','datecheckbox',null,'Подписан',0,1,20,3);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp)
VALUES ('SENT_DT','AFISHA','date','datecheckbox',null,'Отправлен оригинал',0,1,25,3);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_BOOKED', 'AFISHA', 'int', 'checkbox', null, 'Бронь подписи', 0, 1, 8, 3, null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_BOOKED_DT', 'AFISHA', 'date', 'date?readonly=readonly', null, 'Дата брони', 0, 1, 9, 3, null);

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_ARCHIVED','AFISHA','int','checkbox',null,'Принят в архив',0,1,21,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_ARCHIVED_DT', 'AFISHA', 'date', 'date?readonly=readonly', null, 'Дата принятия в архив', 0, 1, 22, 3, null);

------------------------------

------------------------------
-- RULES
------------------------------
DELETE FROM bo.t_contract_rules
WHERE type='AFISHA';

-- DOCUMENT RULES
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (3,'AFISHA','document',null,'can_edit = None; disable_main = None; new_contract = None',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (500,'AFISHA','document',null,'err_message(invalid);collateral_type.disable();collateral_type.hide();num.hide();',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.6661,'AFISHA','document','(glob.lcancelled or is_cancelled.value) or page_readonly','disable_main = True;is_signed.disable();is_faxed.disable();invalid=""',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (0.1,'AFISHA','document',null,'firm_to_currency_map = {1:(643,)};',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (0.16,'AFISHA','document',null,'client_id.caption("Партнер:")',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (0.2,'AFISHA','document',null,'firm_to_nds_map = {1:(18, 0)};',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (1,'AFISHA','document',null,'enabled = lambda col, attr: (((col.selected and getattr(col.selected, attr, None)) and getattr(col.selected, attr).enabled) and getattr(col.selected, attr).visible)',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (2,'AFISHA','document',null,'visible = lambda col, attr: ((col.selected and getattr(col.selected, attr, None)) and getattr(col.selected, attr).visible)',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7,'AFISHA','document','loading','glob.lsigned=is_signed.value;glob.lfaxed=is_faxed.value;glob.lcancelled=is_cancelled.value;glob.lsent=sent_dt.value',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.02,'AFISHA','document','"BillingSupport" in permissions and len(collaterals) < 2','can_edit = True','can_edit = False');

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.03,'AFISHA','document','glob.lsigned and not can_edit','is_signed.disable()',null);

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (7.04, 'AFISHA', 'glob.lfaxed and not can_edit', 'is_faxed.disable(); is_booked.disable(); is_booked_dt.disable();', null, 'document');

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.05,'AFISHA','document','glob.lsent and not can_edit','sent_dt.disable()',null);

-- Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.1,'AFISHA','document','(glob.lcancelled or is_cancelled.value) or page_readonly','invalid=""',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.1,'AFISHA','document','','invalid=""',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.31,'AFISHA','document','is_signed.value and is_signed.value>datetime()','is_signed.highlight();invalid="Дата подписания больше текущей даты"',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.32,'AFISHA','document','is_faxed.value and is_faxed.value>datetime()','is_faxed.highlight();invalid="Дата подписания больше текущей даты"',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.33,'AFISHA','document','is_cancelled.value and is_cancelled.value>datetime()','is_cancelled.highlight();invalid="Дата отмены больше текущей даты"',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (7.4,'AFISHA','document','glob.lcancelled and is_cancelled.value','memo.disable()',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (10,'AFISHA','document','not id.value','new_contract = True',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (23,'AFISHA','document','glob.lsigned or glob.lfaxed','disable_main = True','col_new_form.hide()');

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (41.91,'AFISHA','document',null,'firm.showitems(firm_to_currency_map.keys());',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (41.92,'AFISHA','document',null,'currency.showitems(firm_to_currency_map[firm.value]);',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (41.93,'AFISHA','document',null,'nds.showitems(firm_to_nds_map[firm.value]);',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (41.96,'AFISHA','document',null,'payment_type.showitems((2, ));',null);


Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (64.1,'AFISHA','document','loading and not afisha_info.value','afisha_info.value=500;',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (64.2,'AFISHA','document','loading and not afisha_rights.value','afisha_rights.value=500;',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (65,'AFISHA','document','not person_id.value','person_id.highlight();invalid="Не выбран плательщик";',null);

Insert into BO.T_CONTRACT_RULES (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (65.0666,'AFISHA','document','firm.visible and firm.value and person_id.visible and person_id.p.person_type and not (person_id.p.person_type in firm2person_categories[firm.value])','person_id.highlight(); invalid = "Тип плательщика не соответствует фирме"',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (80.05,'AFISHA','document','end_dt.value and not dt.value','dt.highlight(); invalid = "Укажите дату начала действия договора"',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (80.1,'AFISHA','document','dt.value and end_dt.value and (end_dt.value < dt.value)','dt.highlight(); end_dt.highlight(); invalid = "Дата окончания меньше даты начала действия договора"',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (80.3,'AFISHA','document','person_id.p.person_type and not person_id.p.person_type in ("ur", "ph")','person_id.highlight();invalid="Недопустимый тип плательщика"',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (800.1,'AFISHA','document','invalid','button_submit.disable()',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (800.6,'AFISHA','document','invalid','err_message(invalid)',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (3500,'AFISHA','document','disable_main','dt.disable();firm.disable();end_dt.disable();external_id.disable();client_id.disable();person_id.disable();currency.disable();manager_code.disable();group02.disable();',null);

-- is_booked
INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.667, 'AFISHA',
        'loading and is_booked.value',
          'glob.l_is_booked = True',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.668, 'AFISHA',
        'not glob.l_is_booked and is_booked.value and is_booked_dt.value',
          'is_faxed.value = is_booked_dt.value; glob.l_is_booked = True;',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.669, 'AFISHA',
        'not glob.l_is_booked and is_booked.value and not is_booked_dt.value',
          'is_booked_dt.value = datetime(); is_faxed.value = datetime(); glob.l_is_booked = True;',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.670, 'AFISHA',
        'glob.l_is_booked and not is_booked.value',
          'is_faxed.value = datetime(); glob.l_is_booked = False;',
          null,
        'document');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (377.671, 'AFISHA',
        'is_booked.value',
          'is_faxed.disable()',
          null,
        'document');
------------

-- COLLATERAL RULES

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(516,'AFISHA','col','col.dt.value and (col.dt.value < dt.value)','col.dt.highlight(); col.invalid = "Дата начала действия допсоглашения должна превышать дату договора"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(516.6666,'AFISHA','col','col.collateral_type.value and col.collateral_type.value == 6040 and col.dt.value and not ((col.dt.value.month % 3 == 1) and (col.dt.value.day == 1))','col.dt.highlight(); col.invalid = "Дата начала допсоглашения может быть только 1-ым числом квартала"',null);


Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (500.4,'AFISHA','col','col.new_col','map(lambda x: x.hide(), col.group02.subitems)',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (500.41,'AFISHA','col','(col.new_col and col.collateral_type) and col.group02["grp_"+str(col.collateral_type.value)]','col.selected = col.group02["grp_"+str(col.collateral_type.value)];col.selected.show()',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(20,'AFISHA','col',null,'col.invalid=""',null);

Insert into bo.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values (501.6666,'AFISHA','col','(not col.new_col) and (col.is_signed.value or col.is_faxed.value)','col.dt.disable();col.num.disable();col.group02.disable()',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(501.7,'AFISHA','col','not col.new_col','col.collateral_type.disable()','col.is_cancelled.disable()');

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(517,'AFISHA','col','not col.dt.value','col.dt.highlight(); col.invalid = "Не выбрана дата начала действия допсоглашения"',null);

Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(518,'AFISHA','col','not col.collateral_type.value','col.collateral_type.highlight(); col.invalid = "Выберите тип допсоглашения"',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(800,'AFISHA','col','col.invalid','col.button_submit.disable()',null);
Insert into BO.t_contract_rules (POSITION,TYPE,CONTEXT,CONDITION,ACTION,ELSEACTION) values
(801,'AFISHA','col','True and not col.hidden','err_message(col.invalid, col.form)',null);

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.667, 'AFISHA',
        'loading and col.is_booked.value',
          'col.l_col_is_booked = True',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.668, 'AFISHA',
        'not col.l_col_is_booked and col.is_booked.value and col.is_booked_dt.value',
          'col.is_faxed.value = col.is_booked_dt.value; col.l_col_is_booked = True;',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.669, 'AFISHA',
        'not col.l_col_is_booked and col.is_booked.value and not col.is_booked_dt.value',
          'col.is_booked_dt.value = datetime(); col.is_faxed.value = col.is_booked_dt.value; col.l_col_is_booked = True;',
          null,
        'col');

-- BALANCE-18593
INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.670, 'AFISHA',
        'col.l_col_is_booked and not col.is_booked.value',
          'col.is_faxed.value = datetime(); col.l_col_is_booked = False;',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (500.671, 'AFISHA',
        'col.is_booked.value',
          'col.is_faxed.disable()',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (502.05, 'AFISHA',
        'col.new_col and not loading and col.collateral_type.value == 90',
          'col.is_faxed.value = datetime(); col.is_faxed.disable(); col.is_booked.value = True; col.is_booked_dt = datetime(); col.force_signed = True',
          null,
        'col');

INSERT INTO bo.t_contract_rules (position, type, condition, action, elseaction, context)
VALUES (502.06, 'AFISHA',
        'col.new_col and col.force_signed and col.collateral_type.value != 90',
          'col.force_signed = False; col.is_faxed.value = None; col.is_booked.value = None; col.is_booked_dt = None;',
          null,
        'col');
