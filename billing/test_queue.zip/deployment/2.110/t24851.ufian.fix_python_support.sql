--liquibase formatted sql

--changeset ufian:BALANCE-24851

update bo.T_PYCRON_descr
   set command = 'YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor_email_document.cfg.xml PYTHONPATH=$PYTHONPATH:/usr/lib/python2.7/dist-packages/muzzle-stubs yb-python -pysupport balance/queue_processor.py EMAIL_DOCUMENT'
 where name = 'email_document-processor';
