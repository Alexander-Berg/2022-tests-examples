--liquibase formatted sql

--changeset ashvedunov:BALANCE-244888-3 runOnChange:true stripComments:false

INSERT INTO BO.T_PYCRON_DESCR (name, command, timeout, description, terminate, owner_login)
VALUES ('edo_offers', 'yb-python -pysupport cluster_tools/edo_offers.py', 3600, 'Получение информации о принятых офертах ЭДО',
   0, 'perseus');

INSERT INTO BO.t_pycron_schedule (name, crontab, enabled)
VALUES ('edo_offers', '0 * * * *', 1);

INSERT INTO BO.T_PYCRON_RESPONSIBLE (task_name, email)
values ('edo_offers', 'ashvedunov@yandex-team.ru');
