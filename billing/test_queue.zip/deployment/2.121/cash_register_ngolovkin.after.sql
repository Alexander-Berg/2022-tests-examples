--liquibase formatted sql

--changeset ngolovkin:BALANCE-25211-after endDelimiter:\\
begin
  bo.create_pycron_task( 'cash_register_processor'
                       , 'YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor.cfg.xml yb-python -pysupport balance/queue_processor.py CASH_REGISTER'
                       , 'Печатает чеки'
                       , 'ngolovkin'
                       , '* * * * *'
                       , d_count_per_host => 1
                       , d_timeout => 1200
                       , r_email => 'ngolovkin@yandex-team.ru'
                       );
end;

\\
