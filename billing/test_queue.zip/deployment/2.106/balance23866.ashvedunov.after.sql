--liquibase formatted sql

--changeset ashvedunov:BALANCE-23866-3
insert into bo.t_contract_attributes (collateral_id, code)
select t2.id collateral_id, 'IS_ARCHIVED' code
  from bo.t_contract2 t1
  join bo.t_contract_collateral t2
  on t1.type = 'GENERAL' and t1.id = t2.CONTRACT2_ID
;

--changeset ashvedunov:BALANCE-23866-4
insert into bo.t_contract_attributes (collateral_id, code)
select t2.id collateral_id, 'IS_ARCHIVED_DT' code
  from bo.t_contract2 t1
  join bo.t_contract_collateral t2
  on t1.type = 'GENERAL' and t1.id = t2.CONTRACT2_ID
;

--changeset ashvedunov:BALANCE-23866-5
insert into bo.t_contract_attributes (collateral_id, code)
select t2.id collateral_id, 'IS_ARCHIVED' code
  from bo.t_contract2 t1
  join bo.t_contract_collateral t2
  on t1.type != 'GENERAL' and t1.id = t2.CONTRACT2_ID
;

--changeset ashvedunov:BALANCE-23866-6
insert into bo.t_contract_attributes (collateral_id, code)
select t2.id collateral_id, 'IS_ARCHIVED_DT' code
  from bo.t_contract2 t1
  join bo.t_contract_collateral t2
  on t1.type != 'GENERAL' and t1.id = t2.CONTRACT2_ID
;
