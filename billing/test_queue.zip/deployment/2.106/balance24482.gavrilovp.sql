--liquibase formatted sql

--changeset gavrilovp:BALANCE-24482
UPDATE bo.t_pycron_schedule SET crontab = '*/5 * * * *' WHERE name = 'process-completions';

