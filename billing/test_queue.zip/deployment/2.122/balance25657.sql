--liquibase formatted sql

--changeset ashvedunov:BALANCE-25657-0

UPDATE meta.t_edo_types
SET ED_OPERATOR_CODE = '2BE'
WHERE ED_OPERATOR_CODE = '2ВЕ';

--changeset ashvedunov:BALANCE-25657-1
UPDATE bo.t_contract_attributes
SET VALUE_STR = '2BE'
WHERE CODE = 'EDO_TYPE'
AND VALUE_STR = '2ВЕ';
