--liquibase formatted sql

--changeset akatovda:BALANCE-24291 endDelimiter:\\
BEGIN BO.CREATE_PYCRON_TASK(
    'stat_aggregator', --name
    'yb-python -pysupport cluster_tools/stat_aggregator.py', --d_command
    'Aggregate user activity info in YT', --d_description
    'akatovda', --d_owner_login
    '00,30 * * * *', --s_crontab
    1, --d_count_per_host
    18000, --d_timeout
    0, --d_terminate
    'akatovda@yandex-team.ru', --r_email
    NULL, --s_host
    1, --s_enabled
    5, --s_retry_count
    20 --s_retry_interval
);
EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN NULL;
        WHEN OTHERS THEN RAISE;
END;
\\

--changeset akatovda:BALANCE-24291-1
UPDATE BO.T_PYCRON_SCHEDULE SET CRONTAB='00,01 * * * *' WHERE NAME='stat_aggregator';

--changeset akatovda:BALANCE-24291-2 endDelimiter:\\
BEGIN BO.CREATE_PYCRON_TASK(
    'stat_aggregator-processor', --name
    'YANDEX_XML_CONFIG=/etc/yandex/balance-scripts/stat_aggregator.cfg.xml yb-python -pysupport balance/queue_processor.py STAT_AGGREGATOR', --d_command
    'Process stat_aggregator queue', --d_description
    'akatovda', --d_owner_login
    '* * * * *', --s_crontab
    1, --d_count_per_host
    86400, --d_timeout
    0, --d_terminate
    'akatovda@yandex-team.ru', --r_email
    NULL, --s_host
    1, --s_enabled
    NULL, --s_retry_count
    NULL --s_retry_interval
);
EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN NULL;
        WHEN OTHERS THEN RAISE;
END;
\\

--changeset akatovda:BALANCE-24291-3
UPDATE BO.T_PYCRON_SCHEDULE SET CRONTAB='* * * * *' WHERE NAME='stat_aggregator';
