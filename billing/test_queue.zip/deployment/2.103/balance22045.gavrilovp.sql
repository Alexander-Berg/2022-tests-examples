--liquibase formatted sql

--changeset gavrilovp:BALANCE-22045
INSERT INTO bo.t_export_type (TYPE) VALUES ('RESUSPENSION');
