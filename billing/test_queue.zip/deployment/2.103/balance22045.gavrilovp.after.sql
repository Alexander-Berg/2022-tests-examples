--liquibase formatted sql

--changeset gavrilovp:BALANCE-22045-after endDelimiter:\\
BEGIN bo.create_pycron_task(
    'resuspension-processor',
    'YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor.cfg.xml yb-python -pysupport balance/queue_processor.py RESUSPENSION',
    'Приостанавливает договоры, если причина первоначальной приостановки не была исправлена, посылает письма на соответствующую рассылку',
    'gavrilovp',
    '* * * * *',
    d_count_per_host => 1,
    r_email => 'gavrilovp@yandex-team.ru'
);
END;

\\
