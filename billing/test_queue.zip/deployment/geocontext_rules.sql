--liquibase formatted sql

--changeset ashvedunov:BALANCE-23866-13 runOnChange:true stripComments:false

-- lock type for avoid deadlocks
select * from bo.T_CONTRACT_TYPES WHERE TYPE='GEOCONTEXT' FOR UPDATE;

merge into BO.t_contract_types b using
(select 'GEOCONTEXT' type ,'distribution partner contracts' note from dual) m
on (b.type = m.type)
when matched then
    update set b.note = m.note where b.type = m.type
when not matched then
    insert (type, note) values (m.type, m.note);


-- contract_collateral_types
merge into BO.T_CONTRACT_COLLATERAL_TYPES b using
(select 4010 id, 20 pos,'изменение налогообложения' caption,'COLLATERAL' collateral_class from dual union all select
4030,40, 'добавление региона','COLLATERAL' from dual union all select
4040,1000, 'прочее','COLLATERAL' from dual union all select
4060,90, 'расторжение договора','COLLATERAL' from dual union all select
4070, 100, 'продление договора', 'COLLATERAL' from dual union all select
4080, 45, 'изменение процента на регион', 'COLLATERAL' from dual union all select
4090, 110, 'изменение типа выплат КВ', 'COLLATERAL' from dual
) m
on (b.id = m.id)
when matched then
  update set b.pos = m.pos, b.caption = m.caption, b.contract_type = 'GEOCONTEXT', b.collateral_class = m.collateral_class where b.id = m.id
when not matched then
  insert (ID,POS,CONTRACT_TYPE,CAPTION, COLLATERAL_CLASS) values (m.id, m.pos, 'GEOCONTEXT', m.caption, m.collateral_class)
;


delete from BO.t_contract_collateral_attrs where contract_type='GEOCONTEXT';

Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (5010,4010,'GEOCONTEXT','NDS',null,null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT, INHERIT_VALUE,VALUE) values (5030,4030,'GEOCONTEXT','REGIONS',null, 0, null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (5060,4070,'GEOCONTEXT','END_DT',null,null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (5040,4060,'GEOCONTEXT','END_DT',null,null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (5045,4060,'GEOCONTEXT','SUSPEND_PAYMENTS',null,null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT, INHERIT_VALUE,VALUE) values (5070,4080,'GEOCONTEXT','REGIONS',null, 0, null);
Insert into BO.t_contract_collateral_attrs
(ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (5080,4090,'GEOCONTEXT','COMMISSION_PAYBACK_TYPE',null,null);

---------------------------------------
-- TYPES
---------------------------------------

delete from BO.t_contract_attribute_types where type='GEOCONTEXT';

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) 
   values ('FIRM','GEOCONTEXT','int','refselect','firms','Фирма',1,0,25,1);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) 
   values ('CURRENCY','GEOCONTEXT','int','refselect','partnercurrency','Валюта',null,0,25,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('DT','GEOCONTEXT','date','date',null,'Дата начала',null,1,39,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('END_DT','GEOCONTEXT','date','date',null,'Дата окончания',null,0,40,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('SUSPEND_PAYMENTS','GEOCONTEXT','int','checkbox',null,'Остановить выплаты',null,0,42,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MANAGER_CODE','GEOCONTEXT','int','autocomplete','managers?params=manager_type=3','Менеджер',1,0,30,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MANAGER_BO_CODE','GEOCONTEXT','int','autocomplete','managers?params=manager_type=2','Менеджер БО',1,0,30,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('MEMO','GEOCONTEXT','clob','text?rows=7'||chr(38)||'cols=30',null,'Примечание',1,1,60,1,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('ATYPICAL_CONDITIONS','GEOCONTEXT','int','checkbox',null,'Нетиповые условия',0,0,61,1,null);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) 
   values ('COMMISSION_PAYBACK_TYPE','GEOCONTEXT','int',40.05,2,0,'Тип выплаты КВ','refselect','commission_paybacks',0);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('PAYMENT_TYPE','GEOCONTEXT','int','refselect','billinterval','Период актов',null,0,50,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('NDS','GEOCONTEXT','int','refselect','ndsreal','Ставка НДС',null,0,58,2,null);

Insert into BO.t_contract_attribute_types (CODE, TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('REGIONS', 'GEOCONTEXT','unheritableintdict',
   'regions_grid?additem=1'||chr(38)||'maxitems=1'||chr(38)||'col_10_num=type=number,editable=1,width=100,caption=ID региона'||chr(38)||'col_0_id=type=number,editable=0,width=50,hidden=1'||chr(38)||'col_20_region=type=string,caption=Регион,editable=0,width=150'||chr(38)||'col_30_pct=type=number,editable=1,width=50,caption=%,formatter=pct_formatter', '','Регионы',null,null,66,2,null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('ACT_SIGNED','GEOCONTEXT','date','datecheckbox',null,'Подписан акт о комиссии',0,1,27,3,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('IS_FAXED','GEOCONTEXT','date','datecheckbox',null,'Подписан по факсу',0,1,10,3,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) 
   values ('IS_SIGNED','GEOCONTEXT','date','datecheckbox',null,'Подписан',0,1,20,3,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('SENT_DT','GEOCONTEXT','date','datecheckbox',null,'Отправлен оригинал',0,1,25,3,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE)
   values ('IS_CANCELLED','GEOCONTEXT','date','datecheckbox',null,'Аннулирован',0,1,30,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('NUM','GEOCONTEXT','str','input',null,'№',0,1,4,1,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('COLLATERAL_TYPE','GEOCONTEXT','int','colselect','geocontext_collaterals','на',0,1,5,1,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_BOOKED', 'GEOCONTEXT', 'int', 'checkbox', null, 'Бронь подписи', 0, 1, 8, 3, null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_BOOKED_DT', 'GEOCONTEXT', 'date', 'date?readonly=readonly', null, 'Дата брони', 0, 1, 9, 3, null);

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_ARCHIVED','GEOCONTEXT','int','checkbox',null,'Принят в архив',0,1,21,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_ARCHIVED_DT', 'GEOCONTEXT', 'date', 'date?readonly=readonly', null, 'Дата принятия в архив', 0, 1, 22, 3, null);

---------------------------------------
-- RULES
---------------------------------------

delete from BO.t_contract_rules where type='GEOCONTEXT';
