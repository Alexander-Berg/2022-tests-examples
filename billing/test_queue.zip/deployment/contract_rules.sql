--liquibase formatted sql


--changeset yanametro:BALANCE-24253 runOnChange:true stripComments:false

-- lock type for avoid deadlocks
select * from bo.T_CONTRACT_TYPES WHERE TYPE='GENERAL' FOR UPDATE;

-- remove new style rules if present
update BO.T_CONTRACT_ATTRIBUTE_TYPES set parent_code=null where type='GENERAL';
delete from BO.T_CONTRACT_ATTRIBUTE_RULES where type='GENERAL';
-- add attribute
delete bo.t_contract_attribute_types where type='GENERAL';


Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('ACCOUNT_TYPE','GENERAL','int','refselect','accounts','Вид аккаунта','1','0',20,'1',null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('COMMISSION_CHARGE_TYPE','GENERAL','int','refselect','commission_charges','Тип нач. КВ','0','0',20.03,'2',null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('DT','GENERAL','date','date',null,'Дата начала','0','1','39','1',null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('FINISH_DT','GENERAL','date','date',null,'Дата окончания','0','0','40','1',null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('DISCARD_NDS','GENERAL','int','refselect','nds_charges','НДС','1','0','50','2',null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('FAKE_ID','GENERAL','int','input',null,'Вторичный ID',0,0,'5','1',null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('NUM','GENERAL','str','input',null,'№','0','1','4','1',null);

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('ADFOX_PRODUCTS', 'GENERAL','jsondict', 'adfox_products_grid?additem=0'||chr(38)||'col_0_id=type=number,editable=0,width=1,hidden=1'||chr(38)||'col_2_num=type=number,width=1,editable=0,hidden=1'||chr(38)||'col_10_name=type=string,editable=0,width=180,caption=Продукт', 'adfox_products','Шкалы продуктов:',null,null,67,2,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values ('COMMISSION_CATEGORIES', 'GENERAL','strdict',
'ids_grid?additem=1'||chr(38)||'maxitems=1000'||chr(38)||'col_0_id=type=number,editable=0,width=1,hidden=1'||chr(38)||'col_10_num=type=number,editable=1,formatter=number_formatter,formatter_options={value_min:0,value_max:10000,allow_empty:0},width=150,caption=ID Категории'||chr(38)||'col_20_sub=type=string,editable=0,width=1,hidden=1',null,'Категории комиссии',null,null,74,2,null);
Insert into BO.t_contract_attribute_types (CODE, TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values ('LOYAL_CLIENTS', 'GENERAL','unheritablejsondict',
   'loyals_grid?additem=1'||chr(38)||'col_10_num=type=number,editable=0,hidden=1,width=100'||chr(38)||'col_0_id=type=number,editable=0,width=50,hidden=1'||chr(38)||'col_20_client=type=string,caption=Клиент,editable=0,width=100'||chr(38)||'col_30_turnover=type=number,editable=1,width=50,caption=оборот'||chr(38)||'col_40_todate=type=string,editable=1,width=50,caption=до', '','Лояльные клиенты', null,null,2001,2,null);
Insert into BO.t_contract_attribute_types (CODE, TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values ('CLIENT_LIMITS', 'GENERAL','unheritablejsondict',
   'client_limits_grid?additem=1'||chr(38)||'col_10_num=type=number,editable=0,hidden=1,width=100'||chr(38)||'col_0_id=type=number,editable=0,width=50,hidden=1'||chr(38)||'col_20_client=type=string,caption=Клиент,editable=0,width=100'||chr(38)||'col_30_client_limit=type=number,editable=1,width=50,caption=Лимит'||chr(38)||'col_40_client_payment_term=type=string,source=payment_terms,editable=1,width=70,edittype=select,formatter=select,caption=Срок оплаты'||chr(38)||'col_50_client_credit_type=type=string,source=credit_types,editable=1,width=150,edittype=select,formatter=select,caption=Тип кредита'||chr(38)||'col_60_client_limit_currency=type=string,editable=0,width=70,caption=Валюта', '','Лимиты по клиентам', null,null,2001.03,2,null);
Insert into BO.t_contract_attribute_types (CODE, TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values ('BRAND_CLIENTS', 'GENERAL','intset',
   'promotion_brand_grid?additem=1'||chr(38)||'col_10_num=type=number,editable=0,hidden=1,width=100'||chr(38)||'col_0_id=type=number,editable=0,width=50,hidden=1'||chr(38)||'col_20_client=type=string,caption=Клиент,editable=0,width=100', '','Объединённые клиенты', null,null,2001.07,2,null);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('BRAND_TYPE','GENERAL','int','refselect','brand_types','Тип бренда',1,0,6,1);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('FIXED_MARKET_DISCOUNT_PCT','GENERAL','money','pctinput?precision=2'||Chr(38)||'currency=%%'||Chr(38)||'min=1'||Chr(38)||'max=99.99',null,'Скидка на маркет',0,0,1055,2,null);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('UKR_MEDIA_DECLARED_SUM','GENERAL','money','pctinput?precision=0'||Chr(38)||'currency=грн.'||Chr(38)||'max=100000000000',null,'Заявленные обороты по медийке',0,0,1054,2,null);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('UKR_DIRECT_DECLARED_SUM','GENERAL','money','pctinput?precision=0'||Chr(38)||'currency=грн.'||Chr(38)||'max=100000000000',null, 'Заявленные обороты по директу',0,0,1053,2,null);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('UKR_DIRECT_DECLARED_PCT','GENERAL','money','pctinput?precision=0'||Chr(38)||'currency=%%'||Chr(38)||'max=25',null, 'Фиксированная скидка на директ',0,0,1053.03,2,null);


Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values ('ATYPICAL_CONDITIONS','GENERAL','int','checkbox',null,'Нетиповые условия',0,0,61,1,null);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values ('DISCARD_MEDIA_DISCOUNT','GENERAL','int','checkbox',null,'Не считать общую медийную скидку',0,0,2061,2,null);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values ('MEMO','GENERAL','clob','text?rows=7'||Chr(38)||'cols=30',null,'Примечание',0,1,60,1,null);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('COLLATERAL_TYPE','GENERAL','int','colselect','collateral_types','на',0,1,5,1);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('COMMISSION','GENERAL','int','refselect','contracts','Тип договора',1,0,5.03,1);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('ATTORNEY_AGENCY_ID','GENERAL','int','attorney_agency_input',null,'Агентство',2,0,5.07,2);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('DISCOUNT_PCT','GENERAL','money',55,2,0,'Скидка','pctinput?precision=0'||Chr(38)||'currency=%%'||Chr(38)||'readonly=readonly',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('DISCOUNT_FIXED','GENERAL','int',53.2,2,0,'Фиксированная скидка','refselect', 'fixed_discounts', 0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('DISCOUNT_COMMISSION','GENERAL','money',58,2,0,'Комиссия','pctinput?precision=0'||Chr(38)||'currency=%%',null,0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('DECLARED_SUM','GENERAL','money',54,2,0,'Заявленные обороты без НДС по медийке','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('FEDERAL_BUDGET','GENERAL','money',54.2,2,0,'Федеральный бюджет без НДС','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('FEDERAL_DECLARED_BUDGET','GENERAL','money',54.21,2,0,'Федеральный бюджет без НДС','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('FEDERAL_ANNUAL_PROGRAM_BUDGET','GENERAL','money',54.22,2,0,'Годовая программа без НДС','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('BELARUS_BUDGET','GENERAL','money',54.23,2,0,'Заявленный оборот','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('BELARUS_BUDGET_PRICE','GENERAL','money',54.24,2,0,'Заявленный оборот без учета скидок','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('UKR_BUDGET','GENERAL','money',54.25,2,0,'Заявленный оборот','pctinput?precision=0'||Chr(38)||'currency=грн.'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('KZT_BUDGET','GENERAL','money',54.26,2,0,'Заявленный оборот, тенге','pctinput?precision=0'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('KZT_AGENCY_BUDGET','GENERAL','money',54.27,2,0,'Заявленный оборот, тенге','pctinput?precision=0'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('KZ_BUDGET','GENERAL','money',54.28,2,0,'Заявленный оборот, руб.','pctinput?precision=0'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('USE_UA_CONS_DISCOUNT','GENERAL','int',54.4,2,0,'Консолидированная скидка','checkbox',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('YEAR_PLANNING_DISCOUNT','GENERAL','money',54.3,2,0,'Скидка за годовое планирование','pctinput?precision=0'||Chr(38)||'currency=%%'||Chr(38)||'max=7',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('YEAR_PLANNING_DISCOUNT_CUSTOM','GENERAL','money',54.33,2,0,'Скидка за годовое планирование','pctinput?precision=0'||Chr(38)||'currency=%%'||Chr(38)||'max=5',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('YEAR_PRODUCT_DISCOUNT','GENERAL','money',54.35,2,0,'Скидка на годовой продукт','pctinput?precision=2'||Chr(38)||'currency=%%'||Chr(38)||'max=30',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('CONSOLIDATED_DISCOUNT','GENERAL','money',54.43,2,0,'Консолидированная скидка','pctinput?precision=2'||Chr(38)||'currency=%%'||Chr(38)||'max=15',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('USE_CONSOLIDATED_DISCOUNT','GENERAL','int',54.47,2,0,'Федеральная дополнительная скидка','checkbox',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('REGIONAL_BUDGET','GENERAL','money',54.5,2,0,'Региональный бюджет без НДС','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('USE_REGIONAL_CONS_DISCOUNT','GENERAL','int',54.6,2,0,'Региональная дополнительная скидка','checkbox',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PDA_BUDGET','GENERAL','money',54.7,2,0,'Бюджет PDA без НДС','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('AUTORU_BUDGET','GENERAL','money',54.75,2,0,'Бюджет Авто.ру без НДС','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('RETRO_DISCOUNT','GENERAL','money',54.8,2,0,'Ретроскидка','pctinput?precision=0'||Chr(38)||'min=0'||Chr(38)||'max=20'||Chr(38)||'currency=%%',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('CONTRACT_DISCOUNT','GENERAL','money',54.85,2,0,'Фиксированная скидка','pctinput?precision=2'||Chr(38)||'min=0'||Chr(38)||'max=100'||Chr(38)||'currency=%%',null,0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values ('SERVICES','GENERAL','intset','checkboxes','services','Сервисы',0,0,59,1,null);


Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PAYMENT_TERM','GENERAL','int',56.01,2,0,'Срок оплаты счетов', 'refselect','payment_terms',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PAYMENT_TERM_MAX','GENERAL','int',56.011,2,0,'Максимальный срок оплаты счетов', 'refselect','payment_terms',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('CALC_DEFERMANT','GENERAL','int',56.02,2,0,'Расчет отсрочки', 'refselect','calc_defermants',0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('CREDIT_TYPE','GENERAL','int',56,2,0,'Вид кредита.','refselect','credit_types', 0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('CREDIT_LIMIT','GENERAL','intdict',56.1,2,0,'Лимит, руб.','limitselector?precision=0'||Chr(38)||'key_caption=Тип рекламы'||Chr(38)||'value_caption=лимит','activity_types',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('CREDIT_CURRENCY_LIMIT','GENERAL','intdict',56.15,2,0,'Лимит в валюте','limitselector?precision=0'||Chr(38)||'key_caption=Валюта'||Chr(38)||'value_caption=лимит','currencies',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('CREDIT_LIMIT_SINGLE','GENERAL','int',56.2,2,0,'Лимит кредита','pctinput?precision=0'||Chr(38)||'max=100000000000'||Chr(38)||'min=1','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('CREDIT_LIMIT_IN_CONTRACT_CURRENCY','GENERAL','int',56.25,2,0,'Лимит в валюте договора','checkbox','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PARTNER_CREDIT','GENERAL','int',56.3,2,0,'Партнерский кредит','checkbox','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PARTNER_COMMISSION_TYPE','GENERAL','int',40.2,2,0,'Тип комиссии партнера','refselect','partner_commissions',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PARTNER_COMMISSION_PCT','GENERAL','money',40.3,2,0,'Процент комиссии','pctinput?precision=2'||Chr(38)||'currency=%%'||Chr(38)||'max=20'||Chr(38)||'min=0','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PARTNER_COMMISSION_PCT2','GENERAL','money',40.33,2,0,'Процент комиссии с карт','pctinput?precision=2'||Chr(38)||'currency=%%'||Chr(38)||'max=20'||Chr(38)||'min=0','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PARTNER_COMMISSION_SUM','GENERAL','money',40.4,2,0,'Размер комиссии','pctinput?precision=2','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PARTNER_MIN_COMMISSION_SUM','GENERAL','money',40.6,2,0,'Размер мин.стоимости','pctinput?precision=2','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PARTNER_MAX_COMMISSION_SUM','GENERAL','money',40.66,2,0,'Размер макс.стоимости','pctinput?precision=2','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('ADVANCE_PAYMENT_SUM','GENERAL','money',40.7,2,0,'Авансовый платеж','pctinput?precision=2','',0);

INSERT INTO bo.t_contract_attribute_types (CODE, TYPE, PYTYPE, POSITION, GRP, HEADATTR, CAPTION, HTMLTYPE, SOURCE, PERSISTATTR)
VALUES ('REGION', 'GENERAL', 'str', 40.8, 2, 0, 'Регион', 'kladrautocomplete?ajaxmethod=kladr_get_city', '', 0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values
('COUNTRY','GENERAL','int',40.323,2,0,'Страна','autocomplete','countries',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('NETTING','GENERAL','int','checkbox','','Взаимозачет',2,0,56.06,2);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('NETTING_PCT','GENERAL','money',56.07,2,0,'Процент взаимозачета','pctinput?precision=2'||Chr(38)||'currency=%%'||Chr(38)||'max=300'||Chr(38)||'min=0','',0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('TURNOVER_FORECAST','GENERAL','intdict',56.25,2,0,'Прогнозируемые среднемесячные обороты, руб.','limitselector?precision=0'||Chr(38)||'key_caption=Тип рекламы'||Chr(38)||'value_caption=оборот','activity_types',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('PAYMENT_TYPE','GENERAL','int',50,1,0,'Оплата','refselect','payments',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('DISCOUNT_FINDT','GENERAL','date',55.5,2,0,'Действует по','date',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('PERSONAL_ACCOUNT','GENERAL','int','checkbox','','Лицевой счет',2,0,56.05,2);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('AUTO_CREDIT','GENERAL','int','checkbox','','Автоматическое взятие в кредит',2,0,56.06,2);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('PP_1137','GENERAL','int','checkbox','','ПП 1137',1,0,59.89,2);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('LIFT_CREDIT_ON_PAYMENT','GENERAL','int','checkbox','','Поднятие лимита кредита при оплате',2,0,56.065,2);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('PERSONAL_ACCOUNT_FICTIVE','GENERAL','int','checkbox','','Агентская схема лицевого счета',2,0,56.07,2);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('REPAYMENT_ON_CONSUME','GENERAL','int','checkbox','','Выставление счетов по открученному',2,0,56.075,2);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('COMMISSION_TYPE','GENERAL','int',40.1,2,0,'Комиссия','refselect','commissions',0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('COMMISSION_PAYBACK_TYPE','GENERAL','int',40.05,2,0,'Тип выплаты КВ','refselect','commission_paybacks',0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('COMMISSION_PAYBACK_PCT','GENERAL','money',40.055,2,0,'Процент выплачиваемого КВ (без делькредере)','pctinput?precision=2'||Chr(38)||'currency=%%'||Chr(38)||'min=0.01'||Chr(38)||'max=8','',0);


Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('SUPERCOMMISSION','GENERAL','int',40.35,2,0,'Суперкомиссия','refselect','supercommissions',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('SUPERCOMMISSION_BONUS','GENERAL','intset',40.25,2,0,'Бонусные программы','checkboxes','supercommission_bonuses',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('NAMED_CLIENT_DECLARED_SUM','GENERAL','int',40.37,2,0,'Годовой план, без НДС','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('LINKED_CONTRACTS','GENERAL','intset',40.45,2,0,'Связанные договоры','contractlist?key_caption=Договор'||Chr(38)||'value_caption=сервисы','',0);


Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('MANAGER_CODE','GENERAL','int',30.0,1,1,'Менеджер','autocomplete','managers?params=manager_type=1',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('MANAGER_BO_CODE','GENERAL','int',30.1,1,1,'Менеджер БО','autocomplete','managers?params=manager_type=2',0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('UNILATERAL','GENERAL','int',51,1,0,'Односторонние акты','refselect','unilaterals',0);


Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('FIXED_DISCOUNT_PCT','GENERAL','money',54.1,2,0,'Фиксированная скидка','pctinput?precision=2'||Chr(38)||'currency=%%'||Chr(38)||'readonly=readonly',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('BUDGET_DISCOUNT_PCT','GENERAL','money',54.29,2,0,'Накопительная скидка','pctinput?precision=0'||Chr(38)||'currency=%%'||Chr(38)||'readonly=readonly',null,0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('DISCOUNT_POLICY_TYPE','GENERAL','int',53.1,2,0,'Тип скидочной политики','refselect','discount_policies',0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('SENT_DT','GENERAL','date',24,3,0,'Отправлен оригинал','datecheckbox',null,1);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('DEAL_PASSPORT','GENERAL','date',23,3,0,'Заявка на ПС','datecheckbox',null,0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('IS_SUSPENDED','GENERAL','date',25,3,1,'Приостановлен','datecheckbox',null,0);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('FIRM','GENERAL','int','refselect','firms','Фирма',1,0,25.05,1);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('COMMISSION_DECLARED_SUM','GENERAL','money','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null,'Заявленные обороты',0,0,40.39,2);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('CURRENCY','GENERAL','int','refselect','currencies','Валюта расчетов',1,0,26,1);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('BANK_DETAILS_ID','GENERAL','int','refselect','banks','Банк расчетов',1,0,27,1);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('NON_RESIDENT_CLIENTS','GENERAL','int','checkbox','','Работа с нерезидентами',1,0,59.9,2);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('NEW_COMMISSIONER_REPORT','GENERAL','int','checkbox','','Новая схема отчета',1,0,59.91,2);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('LINK_CONTRACT_ID','GENERAL','int','contractinput','','Связанный договор',1,0,60.1,2);

Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('SERVICE_MIN_COST','GENERAL','money',61.1,2,0,'Минимальная стоимость услуг','pctinput?precision=2'||Chr(38)||'min=0','',0);
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,POSITION,GRP,HEADATTR,CAPTION,HTMLTYPE,SOURCE,PERSISTATTR) values ('TEST_PERIOD_DURATION','GENERAL','money',61.2,2,0,'Длительность тестового периода (месяцев)','pctinput?precision=0','',0);


Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_CANCELLED','GENERAL','date','datecheckbox',null,'Аннулирован',0,1,30,3,null);

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_BOOKED','GENERAL','int','checkbox',null,'Бронь подписи',0,1,8,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_BOOKED_DT', 'GENERAL', 'date', 'date?readonly=readonly', null, 'Дата брони', 0, 1, 9, 3, null);

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_ARCHIVED','GENERAL','int','checkbox',null,'Принят в архив',0,1,21,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_ARCHIVED_DT', 'GENERAL', 'date', 'date?readonly=readonly', null, 'Дата принятия в архив', 0, 1, 22, 3, null);

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_FAXED','GENERAL','date','datecheckbox',null,'Подписан по факсу',0,1,10,3,null);

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_SIGNED','GENERAL','date','datecheckbox',null,'Подписан',0,1,20.05,3,null);

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp)
values ('CALC_TERMINATION','GENERAL','date','date',null,'Завершение расчетов',0,0,61.05,1);

insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp)
values ('AUTORU_Q_PLAN','GENERAL','money','pctinput?precision=0'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000',null, 'План',0,0,1053.07,2);

insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp)
values ('FORCE_DIRECT_MIGRATION','GENERAL','int','checkbox',null,'Переход на валюту',0,0,8.05,2);

--
-- RIT contract
--

INSERT INTO bo.t_contract_attribute_types (CODE, TYPE, PYTYPE, POSITION, GRP, HEADATTR, CAPTION, HTMLTYPE, SOURCE, PERSISTATTR)
VALUES ('RIT_LIMIT', 'GENERAL', 'money', 54.15, 2, 0, 'РИТ Лимит, руб.', 'pctinput?precision=2'||Chr(38)||'currency=руб.'||Chr(38)||'max=100000000000', NULL, 0);

INSERT INTO bo.t_contract_attribute_types (CODE, TYPE, PYTYPE, POSITION, GRP, HEADATTR, CAPTION, HTMLTYPE, SOURCE, PERSISTATTR)
VALUES ('RIT_DISCOUNT', 'GENERAL', 'money', 54.295, 2, 0, 'РИТ Скидка, %', 'pctinput?precision=2' || Chr(38) || 'currency=%%' || Chr(38) || 'min=1' || Chr(38) || 'max=100.00', NULL, 0);

--
-- Wholesale agent contract
--

INSERT INTO bo.t_contract_attribute_types (CODE, TYPE, PYTYPE, POSITION, GRP, HEADATTR, CAPTION, HTMLTYPE, SOURCE, PERSISTATTR)
VALUES ('WHOLESALE_AGENT_PREMIUM_AWARDS_SCALE_TYPE', 'GENERAL', 'int', 54.37, 2, 0, 'Шкала премии', 'refselect', 'wholesale_agent_premium_awards_scale', 0);

--
-- Доставка: минимальная комиссия с платежа
--

insert into bo.t_contract_attribute_types (CODE, TYPE, PYTYPE, HTMLTYPE, SOURCE, CAPTION, HEADATTR, PERSISTATTR, POSITION, GRP, PARENT_CODE)
values ('MINIMAL_PAYMENT_COMMISSION','GENERAL','money','pctinput?precision=2'||Chr(38)||'currency=руб.'||Chr(38)||'min=0', null,'Минимальная комиссия с платежа','1','0',20.07,'2',null);

--
-- Apikeys
--

Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('SERVICE_START_DT','GENERAL','date','date',null,'Дата оказания услуг',1,0,39.5,1,null);
Insert into BO.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP,PARENT_CODE) values
('APIKEYS_TARIFFS', 'GENERAL', 'jsondict', 'tariffs_grid?additem=0'||chr(38)||'select_empty_option=Отключить'||chr(38)||'group_caption=API Service'||chr(38)||'member_caption=Tariff'||chr(38)||'member_source=apikeys_tariffs', 'apikeys_tariff_groups','Тарифы',null,null,67.05,2,null);

--
-- ADFox
--

--INSERT INTO BO.T_CONTRACT_ATTRIBUTE_TYPES (CODE, TYPE, PYTYPE, HTMLTYPE, SOURCE, CAPTION, HEADATTR, PERSISTATTR, POSITION, GRP, PARENT_CODE) VALUES ('ADFOX_DISCOUNTS', 'GENERAL', 'intdict', 'products_revshare_grid?additem=0&col_0_id=type=number,editable=0,width=1,hidden=1&col_2_num=type=number,width=1,editable=0,hidden=1&col_20_price=type=number,caption=% партнера,editable=1,formatter=pct_formatter,width=150&col_10_name=type=string,editable=0,width=180,caption=Продукт', 'adfox_discounts', 'Шкалы продуктов:', null, null, 67, 2, null);
--INSERT INTO BO.T_CONTRACT_ATTRIBUTE_TYPES (CODE, TYPE, PYTYPE, HTMLTYPE, SOURCE, CAPTION, HEADATTR, PERSISTATTR, POSITION, GRP, PARENT_CODE) VALUES ('ADFOX_SCALE', 'GENERAL', 'str', 'strselect', 'adfox_scale', 'Шкала', 1, null, 20, 1, null);


-- print form
Insert into bo.t_contract_attribute_types (CODE,TYPE,PYTYPE,HTMLTYPE,SOURCE,CAPTION,HEADATTR,PERSISTATTR,POSITION,GRP) values ('PRINT_FORM_TYPE','GENERAL','int','refselect','print_form_types','Тип ПФ',0,1,5.5,1);

delete BO.T_CONTRACT_COLLATERAL_ATTRS where CONTRACT_TYPE='GENERAL';


merge into BO.T_CONTRACT_COLLATERAL_TYPES b using
(select
115 id,  115 pos,'изменение скидки' caption                                     from dual union select
10,      10,     'переход на УСН (вознаграждение не облагается НДС)'            from dual union select
20,      20,     'переход на ОСН (вознаграждение облагается НДС)'               from dual union select
50,      50,     'переход на суперкомиссию'                                     from dual union select
80,      80,     'продление договора'	                                        from dual union select
70,      70,     'отмена суперкомиссии' 	                                from dual union select
90,      90,     'расторжение договора' 	                                from dual union select
1001,   120,     'изменение сервисов'                                           from dual union select
1003,   140,     'прочее'                                                       from dual union select
100,    100,     'перевод на предоплату'                                        from dual union select
110,    110,     'перевод на постоплату'                                        from dual union select
1004,   112,     'изменение кредита'                                            from dual union select
1005,   113,     'изменение вида кредита'                                       from dual union select
1006,    81,     'пролонгация+односторонние акты'                               from dual union select
1007,    82,     'переход на односторонние акты'                                from dual union select
1008,  81.1,     'пролонгация+односторонние акты+изменение комиссии'            from dual union select
1009,  81.2,     'пролонгация+односторонние акты+изменение комиссии+кредит по сроку' from dual union select
1010,  81.3,     'пролонгация+односторонние акты+кредит по сроку'               from dual union select
1011, 115.1,     'изменение скидочной политики'                                 from dual union select
1012,   114,     'изменение расчета рассрочки'                                  from dual union select
1013,  81.4,     'пролонгация+изменение комиссии'                               from dual union select
1000,    25,     'изменение % комиссии + суперкомиссия'                         from dual union select
1014,  25.1,     'изменение бонусной программы'                                 from dual union select
1015, 115.2,     'изменение гарантированного объема'                            from dual union select
1016,    30,     'работа с нерезидентами'                                       from dual union select
1017,   112,     'изменение максимального срока оплаты'                         from dual union select
1018,   300,     'связывание договоров'                                         from dual union select
1019,   81.4,    'пролонгация+изменение скидки'                                 from dual union select
1020,   81.5,    'пролонгация+изменение вида кредита'                           from dual union select
1021,   80.1,    'универсальный договор'                                        from dual union select
1022,   80.1,    'Украина: изменение скидки на маркет'                          from dual union select
1023,    130,    'изменение валюты договора'                                    from dual union select
1024,    131,    'лояльные клиенты'                                             from dual union select
1025,    132,    'изменение состояния ПП 1137'                                  from dual union select
1026,    133,    'изменение состава рекламного бренда'                          from dual union select
1027,    134,    'изменение процента ретроскидки'                               from dual union select
1028,    135,    'изменение минимального размера комиссии'                      from dual union select
2222,    136,    'изменение размера авансового платежа'                         from dual union select
1030,    137,    'изменение типа комиссии партнеров такси'                      from dual union select
1031,    110,    'перевод на постоплату+бонусная программа'                     from dual union select
1032,    81.4,   'изменение значения процента выплачиваемого КВ'                from dual union select
1033,    110.1,  'Перевод на постоплату, ЛС'                                    from dual union select
1034,    110.1,  'перевод на Маркет СРА, постоплата'                            from dual union select
1035,    110.1,  'лимит кредита субклиента'                                     from dual union select
1036,    110.1,  'завершение расчетов'                                          from dual union select
1037,    111,    'Билеты: изменение категорий'                                  from dual union select
1038,    138,    'изменение минимальной стоимости услуг'                        from dual union select
1039,    112,    'ADFox: изменение продуктов'                                   from dual union select
1040,    113,    'План'                                                         from dual union select
1041,    114,    'Директ: Переход на валюту'                                    from dual union select
1042,    116,    'изменение минимальной комиссии с платежа'                     from dual union select
1044,    117,    'изменение шкалы премий'                                       from dual union select
1043,    1043,   'Apikeys: изменение тарифов'                                   from dual union select
1045,    1045,   'Aвтобусы: изменение комиссии'                                 from dual union select
1046,    138,    'Такси: взаимозачет'                                           from dual union select
1047,    1047,   'Исключение из расчета премий'                                 from dual union select
1048,    21,     'Статус ЭДО'                                                   from dual
) m
on (b.id = m.id)
when matched then
  update set b.pos = m.pos, b.caption = m.caption, b.contract_type = 'GENERAL', b.collateral_class = 'COLLATERAL' where b.id = m.id
when not matched then
  insert (ID,POS,CONTRACT_TYPE,CAPTION, COLLATERAL_CLASS) values (m.id, m.pos, 'GENERAL', m.caption, 'COLLATERAL')
;

Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (3,50,'GENERAL','SUPERCOMMISSION',null,null,1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (1010,70,'GENERAL','SUPERCOMMISSION',1,'0',1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (4,80,'GENERAL','FINISH_DT',null,null,1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (1011,90,'GENERAL','FINISH_DT',null,null,1);

-- такси: взаимозачет
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values 
(1046.01,1046,'GENERAL','NETTING',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values 
(1046.02,1046,'GENERAL','NETTING_PCT',null,null);


--- изменение шкалы премий
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (10600,1044,'GENERAL','WHOLESALE_AGENT_PREMIUM_AWARDS_SCALE_TYPE',null,null,1);

--- ADFox: изменение продуктов
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (10450,1039,'GENERAL','ADFOX_PRODUCTS',null,null,1);

--- ADFox: скидка за монетизацию
--INSERT INTO BO.T_CONTRACT_COLLATERAL_ATTRS (ID, COLTYPE_ID, CONTRACT_TYPE, ATTRIBUTE_CODE, USEDEFAULT, VALUE, INHERIT_VALUE) VALUES (10452, 1047, 'GENERAL', 'ADFOX_DISCOUNTS', null, null, 1);
--INSERT INTO BO.T_CONTRACT_COLLATERAL_ATTRS (ID, COLTYPE_ID, CONTRACT_TYPE, ATTRIBUTE_CODE, USEDEFAULT, VALUE, INHERIT_VALUE) VALUES (10453, 1047, 'GENERAL', 'ADFOX_SCALE', null, null, 1);

--- Доставка: минимальная комиссия с платежа
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (10500,1042,'GENERAL','MINIMAL_PAYMENT_COMMISSION',null,null,0);

--- Билеты: изменение категорий
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (10440,1037,'GENERAL','COMMISSION_CATEGORIES',null,null,1);


--- переход на УСН (вознаграждение не облагается НДС)
Insert into bo.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (5,10,'GENERAL','DISCARD_NDS',1,'1',1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (5.1,10,'GENERAL','PP_1137',null,null,1);
--- переход на ОСН (вознаграждение облагается НДС)
Insert into bo.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (6,20,'GENERAL','DISCARD_NDS',1,'0',1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (6.1,20,'GENERAL','PP_1137',1,'0');

-- лояльные клиенты
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (1044,1024,'GENERAL','LOYAL_CLIENTS',null,null,0);

-- лимиты кредита субклиентов
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (1045,1035,'GENERAL','CLIENT_LIMITS',null,null,0);

--- изменение скидки
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1022,1022,'GENERAL','FIXED_MARKET_DISCOUNT_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1017,115,'GENERAL','DECLARED_SUM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1018,115,'GENERAL','DISCOUNT_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1024,115,'GENERAL','DISCOUNT_FINDT',null,null);


--- изменение % комиссии + суперкомиссия
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1000.0,1000,'GENERAL','COMMISSION_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1000.1,1000,'GENERAL','SUPERCOMMISSION',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1000.2,1000,'GENERAL','COMMISSION_DECLARED_SUM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1000.3,1000,'GENERAL','COMMISSION_PAYBACK_PCT',null,null);

--- перевод на предоплату
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (100.1,100,'GENERAL','PAYMENT_TYPE',1,2);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (100.2,100,'GENERAL','PAYMENT_TERM',1,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (100.3,100,'GENERAL','CREDIT_LIMIT',1,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (100.4,100,'GENERAL','TURNOVER_FORECAST',1,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (100.5,100,'GENERAL','CREDIT_TYPE',1,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (100.9,100,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (100.6,100,'GENERAL','PAYMENT_TERM_MAX',1,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (100.7,100,'GENERAL','PERSONAL_ACCOUNT',0,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (100.8,100,'GENERAL','PARTNER_CREDIT',1, 0);


--- перевод на постоплату
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.1,110,'GENERAL','PAYMENT_TYPE',1,3);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.2,110,'GENERAL','PAYMENT_TERM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.3,110,'GENERAL','CREDIT_LIMIT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.4,110,'GENERAL','TURNOVER_FORECAST',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.55,110,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.5,110,'GENERAL','CREDIT_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.6,110,'GENERAL','CALC_DEFERMANT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.7,110,'GENERAL','PAYMENT_TERM_MAX',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.8,110,'GENERAL','REPAYMENT_ON_CONSUME',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (110.9,110,'GENERAL','COMMISSION_PAYBACK_PCT',null,null);


--- изменение сервисов
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1001.1,1001,'GENERAL','SERVICES',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1001.2,1001,'GENERAL','SUPERCOMMISSION_BONUS',null,null);

--- изменение кредита
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1004.1,1004,'GENERAL','PAYMENT_TERM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1004.2,1004,'GENERAL','CREDIT_LIMIT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1004.3,1004,'GENERAL','PAYMENT_TERM_MAX',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1004.4,1004,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1004.5,1004,'GENERAL','TURNOVER_FORECAST',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1004.6,1004,'GENERAL','CREDIT_TYPE',null,null);

--- изменение вида кредита
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1005.2,1005,'GENERAL','PAYMENT_TERM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1005.3,1005,'GENERAL','CREDIT_LIMIT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1005.4,1005,'GENERAL','TURNOVER_FORECAST',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1005.5,1005,'GENERAL','CREDIT_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1005.6,1005,'GENERAL','PAYMENT_TERM_MAX',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1005.7,1005,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1005.8,1005,'GENERAL','REPAYMENT_ON_CONSUME',null,null);


--- пролонгация+односторонние акты
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1006.1,1006,'GENERAL','FINISH_DT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1006.2,1006,'GENERAL','UNILATERAL',1,1);

--- односторонние акты
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1007.1,1007,'GENERAL','UNILATERAL',1,1);

--- пролонгация+односторонние акты+изменение комиссии
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1008.1,1008,'GENERAL','FINISH_DT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1008.2,1008,'GENERAL','UNILATERAL',1,1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1008.3,1008,'GENERAL','COMMISSION_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1008.4,1008,'GENERAL','SUPERCOMMISSION',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1008.5,1008,'GENERAL','COMMISSION_DECLARED_SUM',null,null);

--- пролонгация+односторонние акты+изменение комиссии+кредит по сроку
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.01,1009,'GENERAL','FINISH_DT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.02,1009,'GENERAL','UNILATERAL',1,1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.03,1009,'GENERAL','COMMISSION_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.04,1009,'GENERAL','SUPERCOMMISSION',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.05,1009,'GENERAL','PAYMENT_TERM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.06,1009,'GENERAL','CREDIT_LIMIT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.07,1009,'GENERAL','TURNOVER_FORECAST',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.08,1009,'GENERAL','CREDIT_TYPE',1,1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.10,1009,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1009.09,1009,'GENERAL','COMMISSION_DECLARED_SUM',null,null);

--- пролонгация+односторонние акты+кредит по сроку
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1010.1,1010,'GENERAL','FINISH_DT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1010.2,1010,'GENERAL','UNILATERAL',1,1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1010.3,1010,'GENERAL','PAYMENT_TERM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1010.4,1010,'GENERAL','CREDIT_LIMIT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1010.7,1010,'GENERAL','TURNOVER_FORECAST',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1010.9,1010,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1010.8,1010,'GENERAL','CREDIT_TYPE',1,1);

--- изменение скидочной политики
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1011.01,1011,'GENERAL','DECLARED_SUM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1011.02,1011,'GENERAL','DISCOUNT_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1011.03,1011,'GENERAL','DISCOUNT_FINDT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1011.04,1011,'GENERAL','FIXED_DISCOUNT_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1011.05,1011,'GENERAL','BUDGET_DISCOUNT_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1011.06,1011,'GENERAL','DISCOUNT_POLICY_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1011.07,1011,'GENERAL','DISCOUNT_FIXED',null,null);

--- изменение расчета отсрочки
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1012.1,1012,'GENERAL','CALC_DEFERMANT',null,null);

--- пролонгация+изменение комиссии
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1013.1,1013,'GENERAL','FINISH_DT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1013.2,1013,'GENERAL','COMMISSION_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1013.3,1013,'GENERAL','SUPERCOMMISSION',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1013.4,1013,'GENERAL','COMMISSION_DECLARED_SUM',null,null);

Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1013.5,1013,'GENERAL','COMMISSION_CHARGE_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1013.6,1013,'GENERAL','COMMISSION_PAYBACK_TYPE',null,null);

--- изменение бонусной программы
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1014.1,1014,'GENERAL','SUPERCOMMISSION_BONUS',null,null);

--- изменение гарантированного объема
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.07,1015,'GENERAL','FEDERAL_BUDGET',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.08,1015,'GENERAL','YEAR_PLANNING_DISCOUNT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.085,1015,'GENERAL','YEAR_PRODUCT_DISCOUNT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.09,1015,'GENERAL','CONSOLIDATED_DISCOUNT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.10,1015,'GENERAL','REGIONAL_BUDGET',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.11,1015,'GENERAL','PDA_BUDGET',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.12,1015,'GENERAL','BELARUS_BUDGET',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.13,1015,'GENERAL','UKR_BUDGET',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.14,1015,'GENERAL','FEDERAL_DECLARED_BUDGET',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.15,1015,'GENERAL','FEDERAL_ANNUAL_PROGRAM_BUDGET',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.16,1015,'GENERAL','USE_CONSOLIDATED_DISCOUNT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.17,1015,'GENERAL','USE_REGIONAL_CONS_DISCOUNT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.18,1015,'GENERAL','USE_UA_CONS_DISCOUNT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1015.19,1015,'GENERAL','AUTORU_BUDGET',null,null);

--- работа с нерезидентами
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1016.01,1016,'GENERAL','NON_RESIDENT_CLIENTS',1,1);

--- изменение максимального срока оплаты
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1017.01,1017,'GENERAL','PAYMENT_TERM_MAX',null,null);

--- связывание договоров
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1018.01,1018,'GENERAL','LINK_CONTRACT_ID',null,null);

--- пролонгация+изменение скидки
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1019.01,1019,'GENERAL','FINISH_DT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1019.02,1019,'GENERAL','DECLARED_SUM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1019.03,1019,'GENERAL','DISCOUNT_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1019.04,1019,'GENERAL','DISCOUNT_FINDT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1019.05,1019,'GENERAL','FIXED_DISCOUNT_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1019.06,1019,'GENERAL','BUDGET_DISCOUNT_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1019.07,1019,'GENERAL','DISCOUNT_POLICY_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1019.08,1019,'GENERAL','DISCOUNT_FIXED',null,null);

--- пролонгация+изменение вида кредита
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1020.01,1020,'GENERAL','FINISH_DT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1020.02,1020,'GENERAL','PAYMENT_TERM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1020.03,1020,'GENERAL','CREDIT_LIMIT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1020.08,1020,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1020.04,1020,'GENERAL','TURNOVER_FORECAST',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1020.05,1020,'GENERAL','CREDIT_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1020.06,1020,'GENERAL','PAYMENT_TERM_MAX',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1020.07,1020,'GENERAL','REPAYMENT_ON_CONSUME',null,null);

--- пролонгация+изменение комиссии
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.01,1021,'GENERAL','FINISH_DT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.02,1021,'GENERAL','COMMISSION_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.03,1021,'GENERAL','SUPERCOMMISSION',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.04,1021,'GENERAL','COMMISSION_DECLARED_SUM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.05,1021,'GENERAL','SUPERCOMMISSION_BONUS',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.06,1021,'GENERAL','LINKED_CONTRACTS',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.07,1021,'GENERAL','SERVICES',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.08,1021,'GENERAL','NAMED_CLIENT_DECLARED_SUM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.09,1021,'GENERAL','PAYMENT_TERM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.10,1021,'GENERAL','CREDIT_LIMIT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.17,1021,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.11,1021,'GENERAL','TURNOVER_FORECAST',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.12,1021,'GENERAL','CREDIT_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.13,1021,'GENERAL','PAYMENT_TERM_MAX',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.14,1021,'GENERAL','PAYMENT_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.15,1021,'GENERAL','COMMISSION_CHARGE_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1021.16,1021,'GENERAL','COMMISSION_PAYBACK_TYPE',null,null);


--- изменение валюты в договоре
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1023.01,1023,'GENERAL','CURRENCY',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1023.02,1023,'GENERAL','BANK_DETAILS_ID',null,null);

--- Изменение ПП 1137
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1025.01,1025,'GENERAL','PP_1137',null,null);

--- Изменение состава рекламного бренда
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1026.01,1026,'GENERAL','BRAND_CLIENTS',null,null);

--- изменение процента ретроскидки
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1027.01,1027,'GENERAL','RETRO_DISCOUNT',null,null);
--- изменение минимального размера комиссии
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1028.01,1028,'GENERAL','PARTNER_MIN_COMMISSION_SUM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1028.02,1028,'GENERAL','PARTNER_MAX_COMMISSION_SUM',null,null);

--- изменение размера авансового платежа
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (2222.01,2222,'GENERAL','ADVANCE_PAYMENT_SUM',null,null);


--- изменение типа комиссии такси
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1030.01,1030,'GENERAL','PARTNER_COMMISSION_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1030.03,1030,'GENERAL','PARTNER_COMMISSION_SUM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1030.05,1030,'GENERAL','PARTNER_COMMISSION_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1030.08,1030,'GENERAL','PARTNER_COMMISSION_PCT2',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1030.07,1030,'GENERAL','PARTNER_MIN_COMMISSION_SUM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1030.1,1030,'GENERAL','PARTNER_MAX_COMMISSION_SUM',null,null);

--- перевод на постоплату+бонусная программа
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.01,1031,'GENERAL','PAYMENT_TYPE',1,3);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.02,1031,'GENERAL','PAYMENT_TERM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.03,1031,'GENERAL','CREDIT_LIMIT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.04,1031,'GENERAL','TURNOVER_FORECAST',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.13,1031,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.05,1031,'GENERAL','CREDIT_TYPE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.06,1031,'GENERAL','CALC_DEFERMANT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.07,1031,'GENERAL','PAYMENT_TERM_MAX',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.08,1031,'GENERAL','REPAYMENT_ON_CONSUME',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.09,1031,'GENERAL','COMMISSION_PAYBACK_PCT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1031.10,1031,'GENERAL','SUPERCOMMISSION_BONUS',null,null);

--- изменение значения процента выплачиваемого КВ
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1032.01,1032,'GENERAL','COMMISSION_PAYBACK_PCT',null,null);

--- перевод на Маркет СРА, предоплата
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.01,1033,'GENERAL','PAYMENT_TYPE',1,3);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.02,1033,'GENERAL','PAYMENT_TERM',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.03,1033,'GENERAL','CREDIT_LIMIT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.04,1033,'GENERAL','TURNOVER_FORECAST',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.05,1033,'GENERAL','CREDIT_TYPE',1,1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.10,1033,'GENERAL','SUPERCOMMISSION_BONUS',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.11,1033,'GENERAL','FINISH_DT',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.13,1033,'GENERAL','CREDIT_LIMIT_SINGLE',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.14,1033,'GENERAL','PERSONAL_ACCOUNT',1,1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.15,1033,'GENERAL','PERSONAL_ACCOUNT_FICTIVE',1,1);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1033.16,1033,'GENERAL','LIFT_CREDIT_ON_PAYMENT',1,1);



--- перевод на Маркет СРА, постоплата
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1034.01,1034,'GENERAL','SUPERCOMMISSION_BONUS',null,null);
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1034.02,1034,'GENERAL','FINISH_DT',null,null);

-- завершение расчетов
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1036.01,1036,'GENERAL','CALC_TERMINATION',null,null);

--- изменение минимальной стоимости услуг
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1038.01,1038,'GENERAL','SERVICE_MIN_COST',null,null);

-- Авто.ру: квартальный план
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS  (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1040.01,1040,'GENERAL','AUTORU_Q_PLAN',null,null);


-- Перевод на валюту в Директе
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1041.01,1041,'GENERAL','FORCE_DIRECT_MIGRATION',null,null);

-- Apikeys
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE,INHERIT_VALUE) values (1043,1043,'GENERAL','APIKEYS_TARIFFS',null,null,1);

-- Автобусы
Insert into BO.T_CONTRACT_COLLATERAL_ATTRS (ID,COLTYPE_ID,CONTRACT_TYPE,ATTRIBUTE_CODE,USEDEFAULT,VALUE) values (1045.01, 1045,'GENERAL','PARTNER_COMMISSION_PCT2',null,null);

delete BO.T_CONTRACT_RULES where TYPE='GENERAL';








