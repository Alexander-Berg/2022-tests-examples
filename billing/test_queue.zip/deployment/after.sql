--liquibase formatted sql

--changeset quark:BALANCE-29843

insert into bo.T_CONTRACT_ATTRIBUTES (ID,
                                      COLLATERAL_ID,
                                      CODE,
                                      KEY_NUM,
                                      VALUE_NUM,
                                      UPDATE_DT,
                                      PASSPORT_ID,
                                      ATTRIBUTE_BATCH_ID,
                                      RELATED_OBJECT_TABLE)
select bo.S_CONTRACT_ATTRIBUTES_ID.nextval,
       cl.id,
       'SERVICES',
       290,
       1,
       sysdate,
       1120000000017695,
       ca.attribute_batch_id,
       ca.related_object_table
from bo.T_CONTRACT2 c
       join bo.T_CONTRACT_COLLATERAL cl on c.id = cl.contract2_id
       join bo.T_CONTRACT_ATTRIBUTES ca on ca.collateral_id = cl.id
where c.type = 'PARTNERS'
  and ca.code = 'FIRM'
  and not exists (select * from bo.T_CONTRACT_COLLATERAL cl2
    join bo.T_CONTRACT_ATTRIBUTES ca2 on ca2.collateral_id = cl2.id where cl2.contract2_id = c.id and ca2.code = 'SERVICES');

insert into bo.T_CONTRACT_ATTRIBUTES (ID,
                                      COLLATERAL_ID,
                                      CODE,
                                      KEY_NUM,
                                      VALUE_NUM,
                                      UPDATE_DT,
                                      PASSPORT_ID,
                                      ATTRIBUTE_BATCH_ID,
                                      RELATED_OBJECT_TABLE)
select bo.S_CONTRACT_ATTRIBUTES_ID.nextval,
       cl.id,
       'SERVICES',
       300,
       1,
       sysdate,
       1120000000017695,
       ca.attribute_batch_id,
       ca.related_object_table
from bo.T_CONTRACT2 c
       join bo.T_CONTRACT_COLLATERAL cl on c.id = cl.contract2_id
       join bo.T_CONTRACT_ATTRIBUTES ca on ca.collateral_id = cl.id
where c.type = 'DISTRIBUTION'
  and ca.code = 'FIRM'
  and not exists (select * from bo.T_CONTRACT_COLLATERAL cl2
    join bo.T_CONTRACT_ATTRIBUTES ca2 on ca2.collateral_id = cl2.id where cl2.contract2_id = c.id and ca2.code = 'SERVICES');
