--liquibase formatted sql

--changeset ashvedunov:BALANCE-25740-0
Insert into bo.t_paysys_old
(ID,DT,WEIGHT,CC,
EXTERN,NAME,NSP,PRIVATE,
REVERSABLE,INVOICE_SENDABLE,NDS,
PERSON_TYPE_CODE,CURRENCY,FOR_AGENCY,SUPPRESS_DISCOUNTS,
CATEGORY,NDS_PCT,PREFIX,FIRM_ID,
INSTANT,ALLOW_UNMODERATED,FRAUDABLE,LANG_ID,CONTRACT_NEEDED,
MONTHLY_REPORTABLE,ISO_CURRENCY,WAIT_PAYMENT_DAY_NUM,WAIT_PAYMENT_DAY_TYPE,
BARTER,CREDIT_CARD,MOBILE,INAPP,FIRST_LIMIT,SECOND_LIMIT,
CERTIFICATE,PAYMENT_METHOD_ID)
values ('1127',to_date('01.07.17','DD.MM.RR'),'700','ce_ofd',
'0','Оплата промокодом','0','0',
'1','1','1',
'0','RUR','0','1',
'ur','18','Б','18',
'0','0','0','1','0',
'1','RUB',null,'0',
'0','0','0','0',null,null,
'0','1505');

--changeset ashvedunov:BALANCE-25740-1
Insert into bo.t_paysys_service (PAYSYS_ID,SERVICE_ID,WEIGHT,EXTERN) 
values ('1127','26','700','0');


--changeset ashvedunov:BALANCE-25740-2 stripComments:false endDelimiter:\\
begin
  dbms_mview.refresh('bo.t_paysys');
end;

\\
