--liquibase formatted sql

--changeset vorobyov-as:balance-27108 endDelimiter:\\

declare
    start_dt date;
    end_dt date;
begin
    start_dt := to_date('01-01-2010', 'DD-MM-YYYY');
    end_dt := to_date('01-11-2015', 'DD-MM-YYYY');
    for cur_day in 0..(end_dt-start_dt)
    loop
        update bo.t_partner_tags_stat3
            set source_id = decode(page_id, 10003, 13, 11)
            where dt = (start_dt + cur_day);
        commit;
    end loop;

end;
\\
