--liquibase formatted sql

--changeset halty:BALANCE-26276 endDelimiter:\\
begin
  bo.create_pycron_task( 'prepay_partner_acts'
                       , 'YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor.cfg.xml yb-python -pysupport balance/queue_processor.py PREPAY_ACTS'
                       , 'Processor for prepay partner contracts'
                       , 'halty@yandex-team.ru'
                       , '*/5 * * * *'
                       , d_count_per_host => 1
   );
end;

\\

