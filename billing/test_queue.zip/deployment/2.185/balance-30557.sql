--liquibase formatted sql

--changeset lightrevan:BALANCE-30557-pycron endDelimiter:\\
BEGIN
  bo.create_pycron_task(
      'generate_acts_ua_transfer_check'
      , 'yb-python -pysupport cluster_tools/generate_acts.py --task monthly_ua_transfer_check --month current'
      , 'Проверка разбора общего счёта'
      , 'lightrevan'
      , '*/10 * * * *'
      , s_mnclose_task => 'monthly_ua_transfer_check'
      , s_enabled => 1
      , d_timeout => 21600
      , r_email => 'balance-core-errors@yandex-team.ru'
  );
END; \\

--changeset lightrevan:BALANCE-30557-mnclose endDelimiter:\\
BEGIN
  mnclose.create_mnclose_task(
    'monthly_ua_transfer_check',
    'Проверка разбора общего счёта',
    'nt_begin',
    'monthly_invoices',
    t_td_shift => 0,
    tg_taskgroup => 'lazareva_taskgroup_robot'
  );

  DELETE
  FROM mnclose.t_task_relations tr
  WHERE 1 = 1
    AND tr.task_destination_id = (SELECT id FROM mnclose.t_tasks WHERE name_id = 'monthly_invoices')
    AND tr.task_source_id = (SELECT id FROM mnclose.t_tasks WHERE name_id = 'nt_begin');

  UPDATE mnclose.t_task_relations tr
  SET
    tr.task_source_id = (SELECT id FROM mnclose.t_tasks WHERE name_id = 'monthly_ua_transfer_check')
  WHERE 1 = 1
    AND tr.task_destination_id = (SELECT id FROM mnclose.t_tasks WHERE name_id = 'monthly_auto_overdraft')
    AND tr.task_source_id = (SELECT id FROM mnclose.t_tasks WHERE name_id = 'nt_begin');
END; \\
