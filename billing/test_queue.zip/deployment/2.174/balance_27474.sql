--liquibase formatted sql

--changeset natabers:BALANCE-27474-1-after endDelimiter:\\

begin
  bo.create_pycron_task( 'email_message_processor'
                       , 'YANDEX_XML_CONFIG=/etc/yandex/balance-mailer/balance_mailer.cfg.xml' ||
                         ' OMNIORB_CONFIG=/etc/yandex/balance-mailer/omniORB.cfg' ||
                         ' yb-python -pysupport balance/queue_processor.py EMAIL_MESSAGE'
                       , 'Отправка сообщений Баланса'
                       , 'natabers'
                       , '* * * * *'
                       , d_timeout => 3600
                       , r_email => 'natabers@yandex-team.ru'
                       );
end;
\\

--changeset natabers:BALANCE-27474-2-after

update BO.T_PYCRON_SCHEDULE set enabled=0 where name='balance-mailer';

--changeset natabers:BALANCE-27474-3-after

insert into bo.t_export(classname, type, object_id, next_export)
  select 'EmailMessage', 'EMAIL_MESSAGE', id, send_dt from bo.t_message m
  left join bo.t_export e on e.classname='EmailMessage' and e.object_id=m.id
  where m.sent = 0 and m.rate <= 5 and e.object_id is null;
