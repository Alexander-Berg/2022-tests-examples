--liquibase formatted sql

--changeset lightrevan:balance-26623

UPDATE (
  SELECT o.main_order
  FROM bo.t_order o
  WHERE 1 = 1
        AND o.service_id IN (7, 11, 26, 110, 111, 128)
        AND o.group_order_id IS NULL
        AND nvl(o.main_order, 0) = 0
        AND exists(
            SELECT 1
            FROM bo.t_order o_
            WHERE o_.group_order_id = o.id
        )
)
    SET main_order = 1
;
