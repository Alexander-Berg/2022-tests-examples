--liquibase formatted sql

--changeset el-yurchito:BALANCE-26548-17-1 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_UI_CONTRACT" AS
SELECT
  co.ID,
  co.ID AS contract_id,
  co.external_id AS contract_eid,
  f3.dt AS dt,
  f2.value_dt AS finish_dt,
  f12.value_dt AS sent_dt,
  sf_nullif (f4.value_num, 0) AS manager_code,
  m.NAME AS manager_name,
  m.login AS manager_login,
  m.email AS manager_email,
  sf_nullif (clients.ID, 0) AS client_id,
  clients.NAME AS client_name,
  sf_nullif (agencies.ID, 0) AS agency_id,
  agencies.NAME AS agency_name,
  sf_nullif (co.person_id, 0) AS person_id,
  p.NAME AS person_name,
  p.inn AS person_inn,
  com.value_num AS commission,
  f1.value_num AS wo_nds,
  f5.value_num AS commission_type,
  f6.value_num AS supercommission,
  f7.value_num AS payment_type,
  cl.is_signed AS is_signed,
  cl.is_faxed AS is_faxed,
  cl.is_cancelled AS is_cancelled,
  f8.value_num AS payment_term,
  f9.value_num AS discount_pct,
  f10.value_num AS discount_fixed,
  f13.value_num AS is_booked,
  f14.value_dt AS is_booked_dt,
  f15.value_dt AS is_suspended,
  f11.services
FROM
  "BO"."T_CONTRACT2" co
    LEFT OUTER JOIN
  "BO"."T_CONTRACT_COLLATERAL" cl
      ON cl.contract2_id = co.ID AND cl.num IS NULL
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" com
      ON com.contract_id = co.ID AND com.code = 'COMMISSION'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f1
      ON f1.contract_id = co.ID AND f1.code = 'DISCARD_NDS'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f2
      ON f2.contract_id = co.ID AND f2.code = 'FINISH_DT'
    LEFT OUTER JOIN
  (SELECT ID, MIN (dt) dt
   FROM (
     SELECT co.ID ID, cl.dt dt
     FROM "BO"."T_CONTRACT2" co, "BO"."T_CONTRACT_COLLATERAL" cl
     WHERE cl.contract2_id = co.ID
   )
   GROUP BY ID) f3
      ON f3.ID = co.ID
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f4
      ON f4.contract_id = co.ID AND f4.code = 'MANAGER_CODE'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f5
      ON f5.contract_id = co.ID AND f5.code = 'COMMISSION_TYPE'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f6
      ON f6.contract_id = co.ID AND f6.code = 'SUPERCOMMISSION'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f7
      ON f7.contract_id = co.ID AND f7.code = 'PAYMENT_TYPE'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f8
      ON f8.contract_id = co.ID AND f8.code = 'PAYMENT_TERM'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f9
      ON f9.contract_id = co.ID AND f9.code = 'DISCOUNT_PCT'
    LEFT OUTER JOIN
  "BO"."V_CONTRACT_SIGNED_ATTR" f10
      ON f10.contract_id = co.ID AND f10.code = 'DISCOUNT_FIXED'
    LEFT OUTER JOIN
  "BO"."T_CONTRACT_ATTRIBUTES" f12
      ON f12.collateral_id = cl.id AND f12.CODE = 'SENT_DT'
    LEFT OUTER JOIN
   "BO"."V_CONTRACT_SIGNED_ATTR" f13
      ON f13.contract_id = co.ID AND f13.code = 'IS_BOOKED'
    LEFT OUTER JOIN
   "BO"."V_CONTRACT_SIGNED_ATTR" f14
      ON f14.contract_id = co.ID AND f14.code = 'IS_BOOKED_DT'
    LEFT OUTER JOIN
   "BO"."V_CONTRACT_SIGNED_ATTR" f15
      ON f15.contract_id = co.ID AND f15.code = 'IS_SUSPENDED'
    LEFT OUTER JOIN
  "BO"."T_MANAGER" m
      ON m.manager_code = f4.value_num
    LEFT OUTER JOIN
  "BO"."V_PERSON" p
      ON p.ID = co.person_id
    LEFT OUTER JOIN
  "BO"."T_CLIENT" clients
      ON co.client_id = clients.ID AND clients.is_agency = 0
    LEFT OUTER JOIN
  "BO"."T_CLIENT" agencies
      ON co.client_id = agencies.ID AND agencies.is_agency <> 0
    LEFT OUTER JOIN
  (SELECT
     contract_id,
     LTRIM(EXTRACT(xmlagg(xmlelement( "V", ', ' || s.name ) ), '/V/text()') , ',') services
   FROM
     "BO"."V_CONTRACT_LAST_ATTR" la
      LEFT OUTER JOIN
     "BO"."T_SERVICE" s
       ON s.id = la.key_num
   WHERE
     code = 'SERVICES' AND value_num = 1
   GROUP BY contract_id) f11
      ON f11.contract_id = co.ID
WHERE co.TYPE = 'GENERAL'
\\

--changeset el-yurchito:BALANCE-26548-17-2 endDelimiter:\\
CALL dbms_mview.refresh('BO.MV_UI_CONTRACT')
\\

--changeset el-yurchito:BALANCE-26548-18 endDelimiter:\\
CREATE OR REPLACE VIEW "BO"."V_UI_ACTS" AS
SELECT
  a.external_id,
  a.id              AS act_id,
  a.dt              AS act_dt,
  i.id              AS invoice_id,
  i.request_id,
  i.request_seq,
  i.passport_id,
  a.client_id,
  p.cc              AS paysys_cc,
  p.name            AS paysys_name,
  p.certificate     AS paysys_certificate,
  a.amount,
  NULL              AS act_sum,
  a.amount_nds,
  i.currency,
  i.iso_currency,
  cur.num_code      AS currency_num_code,
  iso_cur.num_code  AS iso_currency_num_code,
  i.external_id     AS invoice_eid,
  a.factura,
  i.person_id,
  pe.name           AS person_name,
  i.total_sum       AS invoice_amount,
  i.currency        AS invoice_currency,
  i.iso_currency    AS invoice_iso_currency,
  i.currency_rate   AS invoice_currency_rate,
  i.nds_pct,
  a.payment_term_dt,
  a.paid_amount,
  i.overdraft,
  i.credit,
  i.contract_id,
  co.external_id    AS contract_eid,
  inv_closed.closed AS invoice_closed,
  ba.our_fault,
  i.firm_id
FROM
  "BO"."T_ACT" a,
  (SELECT *
   FROM "BO"."T_BAD_DEBT_ACT"
   WHERE hidden = 0) ba,
  "BO"."T_INVOICE" i,
  "BO"."T_CURRENCY" cur,
  "BO"."T_ISO_CURRENCY" iso_cur,
  "BO"."T_PAYSYS" p,
  "BO"."V_PERSON" pe,
  "BO"."T_CONTRACT2" co,
  (SELECT
     id,
     CASE
      WHEN invoice_sum = act_sum THEN 1
      ELSE 0
     END closed
     FROM
       (SELECT
          i.id,
          i.total_act_sum * i.currency_rate act_sum,
          decode(
              i.credit,
              1, i.receipt_sum,
              greatest(
                  i.receipt_sum,
                  decode(
                      i.overdraft,
                      1, i.effective_sum,
                      i.consume_sum)
              )
          ) * i.internal_rate               invoice_sum
        FROM "BO"."T_INVOICE" i)) inv_closed
WHERE
  cur.char_code = i.currency AND
  iso_cur.alpha_code = decode(upper(i.currency), 'RUR', 'RUB', upper(i.currency)) AND
  a.invoice_id = i.ID AND
  i.paysys_id = p.ID AND
  a.type <> 'internal' AND
  a.hidden <> 4 AND
  i.person_id = pe.id (+) AND
  i.contract_id = co.id (+) AND
  a.id = ba.act_id (+) AND
  inv_closed.id = i.id
\\
