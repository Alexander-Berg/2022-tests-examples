--liquibase formatted sql

--changeset vorobyov_as:BALANCE-25977 endDelimiter:\\
begin
  bo.create_pycron_task( 'fill_manager_passport'
                       , 'yb-python -pysupport cluster_tools/fill_manager_passport.py'
                       , 'Заполняет внешние и домменые passport_id для менеджеров'
                       , 'vorobyov-as'
                       , '*/5 * * * *'
                       , d_count_per_host => 1
   );
end;

\\

--changeset vorobyov_as:BALANCE-25977-1-1

update bo.t_pycron_descr
    set count_per_host = null
    where name = 'fill_manager_passport'
;

--changeset vorobyov_as:BALANCE-25977-1-2

update bo.t_pycron_responsible
    set email = 'vorobyov-as@yandex-team.ru'
    where task_name = 'fill_manager_passport'
;