--liquibase formatted sql

--changeset gavrilovp:BALANCE-24899
UPDATE bo.t_export_type
   SET params = '{"MaxRate": 5}'
 WHERE type = 'PROCESS_PAYMENTS'
;

--changeset gavrilovp:BALANCE-24899-1 endDelimiter:\\
BEGIN BO.CREATE_PYCRON_TASK(
    'process_payments-processor', --name
    'YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor.cfg.xml yb-python -pysupport balance/queue_processor.py PROCESS_PAYMENTS', -- d_command
    'Обработчик очереди с типом PROCESS_PAYMENTS', --d_description
    'gavrilovp', --d_owner_login
    '*/1 * * * *', --s_crontab
    1, --d_count_per_host
    900, --d_timeout
    0, --d_terminate
    'gavrilovp@yandex-team.ru', --r_email
    null, --s_host
    1, --s_enabled
    null, --s_retry_count
    null --s_retry_interval
);
END;
\\

--changeset akatovda:BALANCE-24899-2
UPDATE bo.t_pycron_schedule
   SET enabled = 0
 WHERE NAME='process_payments'
;
