--liquibase formatted sql

--changeset azurkin:BALANCE-29575-pycron stripComments:false splitStatements:false
begin
  bo.create_pycron_task(
    'reenqueue_deferred_exports',
    'yb-python -pysupport cluster_tools/reenqueue_deferred_exports.py --update-batch-size 10000 --execute-interval 1.0',
    'Перепростановка в очередь отложенных объектов, для которых пришло время повторной попытки экспорта.',
    'balance-core-team',
    '* * * * *',
    d_timeout => 60 * 60,
    r_email => 'balance-core-errors@yandex-team.ru',
    s_retry_interval => null,
    s_enabled => 0
  );
end;

--changeset azurkin:BALANCE-29575-next_export-default-null
ALTER TABLE BO.t_export modify next_export default null;
