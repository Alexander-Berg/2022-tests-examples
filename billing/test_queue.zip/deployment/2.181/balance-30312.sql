--liquibase formatted sql

--changeset natabers:BALANCE-30312
update bo.t_config
set value_json = '[{"firm_ids": [2], "service_ids": [7, 16, 114, 35, 37, 70, 77, 11]}, {"service_ids": [115]}]'
where item = 'ACT_CREATION_FILTER';
