--liquibase formatted sql

--changeset vorobyov-as:BALANCE-30318 endDelimiter:\\

declare
    request VARCHAR2(4096);
begin

    for item
    in (select table_name, partition_name
        from all_tab_partitions
        where table_owner = 'BO'
        and table_name in ('T_ENTITY_COMPLETION', 'T_ENTITY_COMPLETION_INT')
        )

        loop

            request := 'ALTER TABLE BO.' || item.table_name || ' MODIFY PARTITION  ' || item.partition_name ||
                       ' ADD SUBPARTITION ' || item.partition_name || '_avia_rs VALUES ( 15 )';
            begin
                execute immediate request;
                dbms_output.put_line(request);
                exception when others then
                    if sqlcode = -14622 then
                        null;
                    else
                        raise;
                    end if;
            end;

            request := 'ALTER TABLE BO.' || item.table_name || ' MODIFY PARTITION  ' || item.partition_name ||
                       ' ADD SUBPARTITION ' || item.partition_name || '_downloads VALUES ( 101 )';
            begin
                execute immediate request;
                dbms_output.put_line(request);
                exception when others then
                    if sqlcode = -14622 then
                        null;
                    else
                        raise;
                    end if;
            end;

        end loop;
end;
\\