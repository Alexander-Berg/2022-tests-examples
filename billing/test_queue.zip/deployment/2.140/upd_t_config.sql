--liquibase formatted sql

--changeset isupov:BALANCE-26671-1
delete from bo.t_config where item = 'BALANCE_VERSION';
