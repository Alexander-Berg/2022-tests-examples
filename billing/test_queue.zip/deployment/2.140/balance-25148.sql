--liquibase formatted sql

--changeset vorobyov-as:BALANCE-26629 stripComments:false endDelimiter:\\

merge into t_contract_attributes ca
    using (

        select
          cl0.dt as contract_start_dt,
          max(ca14.id) ca_id,
          cl0.id cl0_id
        FROM bo.t_contract2 c
        LEFT JOIN bo.t_contract_collateral cl0 ON cl0.contract2_id = c.id and cl0.collateral_type_id is null and cl0.num is null
        LEFT OUTER JOIN bo.t_contract_attributes ca6 on cl0.id = ca6.collateral_id and ca6.code = 'CONTRACT_TYPE'
        LEFT OUTER JOIN bo.t_contract_attributes ca14 on cl0.id = ca14.collateral_id and ca14.code = 'SERVICE_START_DT'
        WHERE
          C.TYPE='DISTRIBUTION'

        and ca14.value_dt is null
        and ca6.value_num not in (3, 4)

        group by cl0.id, cl0.dt

    ) e on (ca.id = e.ca_id)

-- Исправляем случаи, где в нулевом коллатерале есть аттрибут 'SERVICE_START_DT', но с пустой датой
when matched then
    update set ca.value_dt = e.contract_start_dt - 365

-- Исправляем случаи, где в нулевом коллатерале нет аттрибута 'SERVICE_START_DT'
when not matched then
    insert
        (collateral_id, code, value_dt)
    values
        (e.cl0_id, 'SERVICE_START_DT', e.contract_start_dt - 365)

\\