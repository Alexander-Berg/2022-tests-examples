--liquibase formatted sql

--changeset ashvedunov:BALANCE-23866-10 runOnChange:true stripComments:false

-- lock type for avoid deadlocks
select * from bo.T_CONTRACT_TYPES WHERE TYPE='ACQUIRING' FOR UPDATE;


-- contract_collateral_types
merge into bo.t_contract_collateral_types mt
using (
  select 8020 id, 1000 pos, 'прочее' caption, 'COLLATERAL' collateral_class from dual
  union all
  select 8030 id, 100 pos, 'продление договора' caption, 'COLLATERAL' collateral_class from dual
  union all
  select 8040 id, 110 pos, 'расторжение договора' caption, 'COLLATERAL' collateral_class from dual
) ut on (ut.id = mt.id)
when matched then update
  set
    mt.pos = ut.pos,
    mt.caption = ut.caption,
    mt.contract_type = 'ACQUIRING',
    mt.collateral_class = ut.collateral_class
when not matched then insert
  (id, pos, contract_type, caption, collateral_class)
values
  (ut.id, ut.pos, 'ACQUIRING', ut.caption, ut.collateral_class)
;


-- contract_collateral_attrs
delete from bo.t_contract_collateral_attrs where contract_type = 'ACQUIRING';

insert into bo.t_contract_collateral_attrs
  (id, coltype_id, contract_type, attribute_code)
values
  (8030, 8030, 'ACQUIRING', 'END_DT')
;
insert into bo.t_contract_collateral_attrs
  (id, coltype_id, contract_type, attribute_code)
values
  (8040, 8040, 'ACQUIRING', 'END_DT')
;


-- contract_attribute_types
delete from bo.t_contract_attribute_types where type = 'ACQUIRING';

insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('COLLATERAL_TYPE','ACQUIRING','int','colselect','acquiring_collaterals','на',0,1,5,1,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('IS_FAXED','ACQUIRING','date','datecheckbox',null,'Подписан по факсу',0,1,10,3,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('END_DT','ACQUIRING','date','date',null,'Дата окончания',null,0,40,1,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('FIRM','ACQUIRING','int','refselect','firms','Фирма',1,0,25,1,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('OEBS_FIRM','ACQUIRING','int','refselect','firms','Фирма, OEBS',1,0,26,1,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('DT','ACQUIRING','date','date',null,'Дата начала',null,1,39,1,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('MEMO','ACQUIRING','str','text?rows=7&cols=30',null,'Примечание',1,1,60,1,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('NUM','ACQUIRING','str','input',null,'№',0,1,4,1,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('IS_SIGNED','ACQUIRING','date','datecheckbox',null,'Подписан',0,1,20,3,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('SENT_DT','ACQUIRING','date','datecheckbox',null,'Отправлен оригинал',0,1,25,3,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('IS_CANCELLED','ACQUIRING','date','datecheckbox',null,'Аннулирован',0,1,30,3,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('IS_BOOKED','ACQUIRING','int','checkbox',null,'Бронь подписи',0,1,8,3,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('IS_SUSPENDED','ACQUIRING','date','datecheckbox',null,'Приостановлен',1,0,25,3,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('IS_BOOKED_DT','ACQUIRING','date','date?readonly=readonly',null,'Дата брони',0,1,9,3,null)
;
insert into bo.t_contract_attribute_types
  (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values
  ('PROCESSING_TARIFFS','ACQUIRING','str','input',null,'Тариф, %',1,0,58,2,null)
;

Insert into bo.t_contract_attribute_types (code,type,pytype,htmltype,source,caption,headattr,persistattr,position,grp,parent_code)
values ('IS_ARCHIVED','ACQUIRING','int','checkbox',null,'Принят в архив',0,1,21,3,null);

INSERT INTO bo.t_contract_attribute_types (code, type, pytype, htmltype, source, caption, headattr, persistattr, position, grp, parent_code)
VALUES ('IS_ARCHIVED_DT', 'ACQUIRING', 'date', 'date?readonly=readonly', null, 'Дата принятия в архив', 0, 1, 22, 3, null);
