--liquibase formatted sql

--changeset gavrilovp:BALANCE-25100-2 stripComments:false endDelimiter:\\

begin
  bo.delete_pycron_task('process_payments');
end;

\\
