--liquibase formatted sql

--changeset natabers:BALANCE-30312-description
update bo.t_config
set "DESC" = 'If any of filters in Act dont do it.' ||chr(10)||
             'Check rules in an order of json.' ||chr(10)||
             'Structure: list with dicts.' ||chr(10)||
             'Allowed dict keys: act_types, firm_ids, service_ids, exclude_firm_ids, exclude_service_ids.' ||chr(10)||
             'Any of filter fields can be null.'
where item = 'ACT_CREATION_FILTER';
