--liquibase formatted sql

--changeset ashvedunov:BALANCE-26519-0
ALTER TABLE bo.t_edo_offer_cal
MODIFY (PERSON_KPP NULL);

--changeset ashvedunov:BALANCE-26519-1
UPDATE bo.t_pycron_descr
SET TIMEOUT = 86400
WHERE NAME ='edo_offers';
