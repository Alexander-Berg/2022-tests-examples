--liquibase formatted sql

--changeset shorrty:BALANCE-26274-20 endDelimiter:\\
begin
  bo.create_pycron_task( 'yt_export_inc_triggers'
                       , 'yb-python -pysupport cluster_tools/yt_export_inc.py --update-triggers'
                       , 'Обновление триггеров для инк.экспорта в YT'
                       , 'shorrty'
                       , '*/5 * * * *'
                       , d_count_per_host => 1
                       , r_email => 'shorrty@yandex-team.ru'
   );
end;

\\

--changeset shorrty:BALANCE-26274-21
Insert into BO.t_export_type (TYPE, PARAMS) values ('YT_EXPORT_INC_TRIG', null);
Insert into BO.t_export_type (TYPE, PARAMS) values ('YT_EXPORT_INC_DATA', null);

--changeset shorrty:BALANCE-26274-23 endDelimiter:\\
begin
  bo.create_pycron_task( 'yt_export_inc'
                       , 'yb-python -pysupport cluster_tools/yt_export_inc.py'
                       , 'Инк.экспорт в YT'
                       , 'shorrty'
                       , '*/10 * * * *'
                       , d_count_per_host => 1
                       , r_email => 'shorrty@yandex-team.ru'
   );
end;

\\
