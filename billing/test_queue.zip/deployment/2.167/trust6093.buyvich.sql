--liquibase formatted sql

--changeset buyvich:TRUST-6105-0 endDelimiter:\\
BEGIN bo.create_pycron_task(
    'trust-payment-data-processor',
    'YANDEX_XML_CONFIG=/etc/yandex/balance-queue-processor/queue_processor.cfg.xml yb-python -pysupport balance/queue_processor.py TRUST_PAYMENT_DATA',
    'Разбор платежей из Trust',
    'buyvich',
    '* * * * *',
    d_count_per_host => 1,
    r_email => 'buyvich@yandex-team.ru'
);
END;

\\
