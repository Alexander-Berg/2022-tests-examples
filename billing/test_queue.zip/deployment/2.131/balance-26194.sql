--liquibase formatted sql

--changeset ashchek:BALANCE-26194-0

INSERT
INTO bo.t_config(item, "DESC", value_json)
VALUES ('SAUTH_REQUIRED_REGIONS', 'Regions required Sauth auth method', '[149, 159, 167, 168, 169, 170, 171, 187, 207, 208, 209, 225, 29386]');
