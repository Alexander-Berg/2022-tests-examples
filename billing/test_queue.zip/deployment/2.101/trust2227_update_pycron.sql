--liquibase formatted sql

--changeset skydreamer:TRUST-2227

update bo.t_pycron_descr
  set command = 'yb-python -pysupport cluster_tools/process_payments.py'
where name = 'process_payments';
