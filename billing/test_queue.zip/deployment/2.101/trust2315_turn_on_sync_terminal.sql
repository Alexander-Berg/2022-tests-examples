--liquibase formatted sql

--changeset srg91:TRUST-2315-after

update bo.t_pycron_descr
  set terminate = 0
where name = 'yb-sync-terminals';
