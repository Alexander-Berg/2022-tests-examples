--liquibase formatted sql

--changeset srg91:TRUST-2315-before

update bo.t_pycron_descr
  set terminate = 1
where name = 'yb-sync-terminals';
