--liquibase formatted sql

--changeset vorobyov-as:BALANCE-26787 stripComments:false endDelimiter:\\

merge into bo.t_partner_act_data ad
    using (

                select
                    ca_parent.value_num parent,
                    c.id child,
                    ca_tag.value_num tag_id
                from bo.t_contract2 c
                join bo.t_contract_collateral cl on (cl.contract2_id = c.id)
                join bo.t_contract_attributes ca_parent on (ca_parent.collateral_id = cl.id
                                                            and ca_parent.code = 'PARENT_CONTRACT_ID'
                                                            and ca_parent.value_num is not null)
                join bo.t_contract_attributes ca_tag on (ca_tag.collateral_id = cl.id
                                                         and ca_tag.code = 'DISTRIBUTION_TAG')

            ) tag_map on (tag_map.parent = ad.partner_contract_id
                          and tag_map.tag_id = ad.tag_id)

when matched then
    update set ad.real_contract_id = tag_map.child where ad.real_contract_id is null

\\