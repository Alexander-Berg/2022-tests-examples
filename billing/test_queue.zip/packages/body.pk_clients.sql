--liquibase formatted sql

--changeset azurkin:BALANCE-29575-pk_clients-body stripComments:false splitStatements:false

create or replace PACKAGE BODY BO.pk_clients
AS
   FUNCTION sf_get_direct25 (p_client_id IN NUMBER)
      RETURN NUMBER
   AS
      p_class_id    NUMBER;
      p_direct25    NUMBER;
   BEGIN
      RETURN 1;

      p_class_id := sf_get_class (p_client_id);

      SELECT MAX (NVL (direct25, 0))
        INTO p_direct25
        FROM BO.t_client
       WHERE class_id = p_class_id;

      return p_direct25;
   END;

   FUNCTION sf_get_required_category (
      p_client_id   IN   NUMBER,
      p_is_agency   IN   NUMBER,
      p_agency_id   IN   NUMBER
   )
      RETURN NUMBER
   AS
      p_class_id   NUMBER;
      p_count      NUMBER;
      p_count_ag   NUMBER;
   BEGIN
      IF p_is_agency <> 0
      THEN
         IF ((p_agency_id IS NULL) OR (p_agency_id = p_client_id))
         THEN
            RETURN c_agency;
         ELSE
            raise_application_error
                             (-20001,
                                 'Client '
                              || p_client_id
                              || ' can''t be a subclient and an agency at once.'
                             );
         END IF;
      ELSE
         IF (p_agency_id IS NOT NULL) AND (p_agency_id <> p_client_id)
         THEN
            RETURN c_subclient;
         ELSE
            RETURN c_client;
         END IF;
      END IF;
   END;

   FUNCTION sf_get_client_category (p_client_id IN NUMBER)
      RETURN NUMBER
   AS
      p_class_id    NUMBER;
      p_is_agency   NUMBER;
      p_agency_id   NUMBER;
      p_count       NUMBER;
   BEGIN
      p_class_id := sf_get_class (p_client_id);

      SELECT SUM (is_agency), MAX (agency_id), COUNT (*)
        INTO p_is_agency, p_agency_id, p_count
        FROM t_client
       WHERE class_id = p_class_id;

      IF p_is_agency = p_count
      THEN
         SELECT COUNT (*)
           INTO p_count
           FROM t_client
          WHERE agency_id NOT IN (SELECT ID
                                    FROM t_client
                                   WHERE class_id = p_class_id)
            AND class_id = p_class_id;

         IF p_count > 0
         THEN
            raise_application_error
                             (-20001,
                                 'Client '
                              || p_client_id
                              || ' can''t be a subclient and an agency at once.'
                             );
         END IF;

         RETURN c_agency;
      END IF;

      IF p_is_agency = 0
      THEN
         IF p_agency_id IS NULL
         THEN
            RETURN c_client;
         ELSE
            SELECT COUNT (DISTINCT c1.class_id)
              INTO p_count
              FROM t_client c, t_client c1
             WHERE c.agency_id = c1.ID AND c.class_id = p_class_id;

            IF p_count = 1
            THEN
               RETURN c_subclient;
            ELSE
               raise_application_error (-20001,
                                           'Subclient '
                                        || p_client_id
                                        || ' has more then one agency'
                                       );
            END IF;
         END IF;
      END IF;

      raise_application_error
                          (-20001,
                              'Client '
                           || p_client_id
                           || ' can''t be a direct client and an agency at once.'
                          );
   END;

   PROCEDURE sp_client_to_agency (p_client_id IN NUMBER)
   IS
      p_class_id   NUMBER;
   BEGIN
      IF sf_get_client_category (p_client_id) <> c_client
      THEN
         raise_application_error (-20001,
                                     'Client '
                                  || p_client_id
                                  || ' is not a direct client.'
                                 );
      END IF;

      p_class_id := sf_get_class (p_client_id);

      UPDATE t_client
         SET is_agency = 1,
             agency_id = ID
       WHERE class_id = p_class_id;
   END;

   PROCEDURE sp_agency_to_client (p_client_id IN NUMBER)
   IS
      p_class_id   NUMBER;
      p_count      NUMBER;
   BEGIN
      IF sf_get_client_category (p_client_id) <> c_agency
      THEN
         raise_application_error (-20001, p_client_id || ' Is not agency.');
      END IF;

      p_class_id := sf_get_class (p_client_id);

      SELECT COUNT (*)
        INTO p_count
        FROM t_client
       WHERE agency_id IN (SELECT ID
                             FROM t_client
                            WHERE class_id = p_class_id)
         AND ID NOT IN (SELECT ID
                          FROM t_client
                         WHERE class_id = p_class_id);

      IF p_count > 0
      THEN
         raise_application_error (-20001,
                                  'Agency ' || p_client_id
                                  || ' has subclients.'
                                 );
      END IF;

      UPDATE t_client
         SET is_agency = 0,
             agency_id = NULL
       WHERE class_id = p_class_id;
   END;

   PROCEDURE sp_client_to_subclient (
      p_client_id   IN   NUMBER,
      p_agency_id   IN   NUMBER
   )
   IS
      p_class_id   NUMBER;
   BEGIN
      IF sf_get_client_category (p_client_id) <> c_client
      THEN
         raise_application_error (-20001,
                                     'Client '
                                  || p_client_id
                                  || ' is not direct client.'
                                 );
      END IF;

      p_class_id := sf_get_class (p_client_id);

      UPDATE t_client
         SET agency_id = p_agency_id
       WHERE class_id = p_class_id;
   END;

   PROCEDURE sp_subclient_to_client (p_client_id IN NUMBER)
   IS
      p_class_id   NUMBER;
   BEGIN
      IF sf_get_client_category (p_client_id) <> c_subclient
      THEN
         raise_application_error (-20001,
                                     'Client '
                                  || p_client_id
                                  || ' is not subclient.'
                                 );
      END IF;

      p_class_id := sf_get_class (p_client_id);

      UPDATE t_client
         SET agency_id = NULL
       WHERE class_id = p_class_id;
   END;

   PROCEDURE sp_create_client (
      p_id               IN OUT   NUMBER,
      p_id_1c            IN       NUMBER := NULL,
      p_passport_id      IN       NUMBER := NULL,
      p_client_type_id   IN       NUMBER,
      p_name             IN       VARCHAR,
      p_email            IN       VARCHAR,
      p_phone            IN       VARCHAR,
      p_fax              IN       VARCHAR,
      p_url              IN       VARCHAR,
      p_is_agency        IN       NUMBER := 0,
      p_agency_id        IN       NUMBER := NULL,
      p_commit           IN       NUMBER := 0,
      p_full_repay       IN       NUMBER := NULL,
      p_oper_id          IN       NUMBER := NULL,
      p_manual_suspect   IN       NUMBER := 0,
      p_city             IN       VARCHAR := NULL
   )
   IS
      h_client_id   NUMBER;
   BEGIN
      IF p_id IS NULL OR p_id = 0
      THEN
         SELECT s_client_id.NEXTVAL
           INTO h_client_id
           FROM DUAL;
      ELSE
         h_client_id := p_id;
      END IF;

      p_id := h_client_id;
      pk_clients.sp_new_client (p_id                  => h_client_id,
                                p_id_1c               => p_id_1c,
                                p_passport_id         => p_passport_id,
                                p_client_type_id      => p_client_type_id,
                                p_name                => p_name,
                                p_email               => p_email,
                                p_phone               => p_phone,
                                p_fax                 => p_fax,
                                p_url                 => p_url,
                                p_is_agency           => p_is_agency,
                                p_commit              => p_commit,
                                p_agency_id           => p_agency_id,
                                p_full_repay          => p_full_repay,
                                p_oper_id             => p_oper_id,
                                p_manual_suspect      => p_manual_suspect,
                                p_city                => p_city
                               );
   END sp_create_client;

   PROCEDURE sp_new_client (
      p_id               IN   NUMBER,
      p_id_1c            IN   NUMBER := NULL,
      p_passport_id      IN   NUMBER := NULL,
      p_client_type_id   IN   NUMBER,
      p_name             IN   VARCHAR,
      p_email            IN   VARCHAR,
      p_phone            IN   VARCHAR,
      p_fax              IN   VARCHAR,
      p_url              IN   VARCHAR,
      p_is_agency        IN   NUMBER := 0,
      p_commit           IN   NUMBER := 0,
      p_agency_id        IN   NUMBER := NULL,
      p_full_repay       IN   NUMBER := NULL,
      p_oper_id          IN   NUMBER := NULL,
      p_manual_suspect   IN   NUMBER := 0,
      p_city             IN   VARCHAR := NULL
   )
   IS
      h_client_id      NUMBER;
      p_new_category   NUMBER;
   BEGIN
      IF p_id = 0
      THEN
         SELECT s_client_id.NEXTVAL
           INTO h_client_id
           FROM DUAL;
      ELSE
         h_client_id := p_id;
      END IF;

      INSERT INTO t_client
                  (ID, client_type_id, NAME, email, phone,
                   fax, url, id_1c, full_repayment, oper_id,
                   creator_uid, manual_suspect, city
                  )
           VALUES (h_client_id, p_client_type_id, p_name, p_email, p_phone,
                   p_fax, p_url, p_id_1c, NVL (p_full_repay, 1), p_oper_id,
                   p_oper_id, p_manual_suspect, p_city
                  );

      pk_export_queue.enqueue(
        p_id => h_client_id,
        p_cls => 'Client',
        p_queue => 'OEBS'
      );

      IF p_passport_id IS NOT NULL
      THEN
         UPDATE t_passport
            SET client_id = h_client_id
          WHERE passport_id = p_passport_id;
      END IF;

      p_new_category :=
                     sf_get_required_category (p_id, p_is_agency, p_agency_id);

      IF p_new_category = c_agency
      THEN
         sp_client_to_agency (h_client_id);
      ELSIF p_new_category = c_subclient
      THEN
         sp_client_to_subclient (h_client_id, p_agency_id);
      END IF;

      IF p_commit != 0
      THEN
         COMMIT;
      END IF;
   END sp_new_client;

   PROCEDURE sp_set_client (
      p_id               IN   NUMBER,
      p_client_type_id   IN   NUMBER,
      p_name             IN   VARCHAR,
      p_email            IN   VARCHAR,
      p_phone            IN   VARCHAR,
      p_fax              IN   VARCHAR,
      p_url              IN   VARCHAR,
      p_is_agency        IN   NUMBER := 0,
      p_agency_id        IN   NUMBER := NULL,
      p_oper_id               NUMBER := NULL,
      p_commit           IN   NUMBER := 0,
      p_full_repay       IN   NUMBER := NULL,
      p_manual_suspect   IN   NUMBER := 0,
      p_city             IN   VARCHAR := NULL
   )
   IS
      p_old_category   NUMBER;
      p_new_category   NUMBER;
   BEGIN
      UPDATE t_client
         SET client_type_id = p_client_type_id,
             NAME = p_name,
             email = p_email,
             phone = p_phone,
             fax = p_fax,
             url = p_url,
             full_repayment = NVL (p_full_repay, full_repayment),
             manual_suspect = p_manual_suspect,
             city = p_city,
             oper_id = p_oper_id
       WHERE ID = p_id;

      p_old_category := sf_get_client_category (p_id);
      p_new_category :=
                     sf_get_required_category (p_id, p_is_agency, p_agency_id);

      IF p_old_category = c_client AND p_new_category = c_agency
      THEN
         sp_client_to_agency (p_id);
      ELSIF p_old_category = c_client AND p_new_category = c_subclient
      THEN
         sp_client_to_subclient (p_id, p_agency_id);
      ELSIF p_old_category = c_agency AND p_new_category = c_client
      THEN
         sp_agency_to_client (p_id);
      ELSIF p_old_category = c_agency AND p_new_category = c_subclient
      THEN
         sp_agency_to_client (p_id);
         sp_client_to_subclient (p_id, p_agency_id);
      ELSIF p_old_category = c_subclient AND p_new_category = c_client
      THEN
         sp_subclient_to_client (p_id);
      ELSIF p_old_category = c_subclient AND p_new_category = c_agency
      THEN
         sp_subclient_to_client (p_id);
         sp_client_to_agency (p_id);
      ELSIF     p_old_category = c_subclient
            AND p_new_category = c_subclient
            AND sf_get_agency_class (p_id) <> sf_get_class (p_agency_id)
      THEN
         sp_subclient_to_client (p_id);
         sp_client_to_subclient (p_id, p_agency_id);
      END IF;

      IF p_commit != 0
      THEN
         COMMIT;
      END IF;
   END sp_set_client;

   PROCEDURE sp_remove_from_class (p_id NUMBER, p_commit NUMBER := 0)
   IS
      l_tmp   NUMBER;
   BEGIN
      UPDATE t_client
         SET class_id = p_id
       WHERE ID = p_id;

      SELECT COUNT (*)
        INTO l_tmp
        FROM t_client
       WHERE class_id = p_id;

      IF l_tmp > 1
      THEN
         SELECT ID
           INTO l_tmp
           FROM t_client
          WHERE class_id = p_id AND ID <> class_id AND ROWNUM = 1;

         UPDATE t_client
            SET class_id = l_tmp
          WHERE class_id = p_id AND ID <> class_id;
      END IF;

      IF p_commit <> 0
      THEN
         COMMIT;
      END IF;
   END sp_remove_from_class;

   PROCEDURE sp_add_to_class (p_id NUMBER, p_class_id NUMBER, p_commit NUMBER)
   IS
      p_root_class_id       NUMBER;
      p_old_class_id        NUMBER;
      p_tmp                 NUMBER;
      p_root_agency_cnt     NUMBER;
      p_leaf_agency_cnt     NUMBER;
      p_common_agency_cnt   NUMBER;
      p_category1           NUMBER;
      p_category2           NUMBER;
   BEGIN
      p_root_class_id := sf_get_class (p_class_id);
      p_old_class_id := sf_get_class (p_id);

      IF p_old_class_id = p_root_class_id
      THEN
         RETURN;
      END IF;

      p_category1 := sf_get_client_category (p_id);
      p_category2 := sf_get_client_category (p_class_id);

      IF p_category1 <> p_category2
      THEN
         raise_application_error (-20000,
                                     'Two clients '
                                  || p_id
                                  || ', '
                                  || p_class_id
                                  || ' belong to different categories'
                                 );
      END IF;

      IF     p_category1 = c_subclient
         AND sf_get_agency_class (p_id) <> sf_get_agency_class (p_class_id)
      THEN
         raise_application_error (-20000,
                                     'Two subclients '
                                  || p_id
                                  || ', '
                                  || p_class_id
                                  || ' belong to different agencies'
                                 );
      END IF;

      UPDATE t_client
         SET class_id = p_root_class_id
       WHERE class_id = p_old_class_id;

      IF p_commit <> 0
      THEN
         COMMIT;
      END IF;
   END sp_add_to_class;

   FUNCTION sf_get_class (p_client_id IN NUMBER)
      RETURN NUMBER
   AS
      p_result   NUMBER;
   BEGIN
      SELECT class_id
        INTO p_result
        FROM t_client
       WHERE ID = p_client_id;

      RETURN p_result;
   END sf_get_class;

   FUNCTION sf_get_agency_class (p_client_id IN NUMBER)
      RETURN NUMBER
   AS
      p_cnt        NUMBER;
      p_class_id   NUMBER;
   BEGIN
      SELECT COUNT (DISTINCT cc3.class_id)
        INTO p_cnt
        FROM t_client cc1, t_client cc2, t_client cc3
       WHERE p_client_id = cc1.ID
         AND cc1.class_id = cc2.class_id
         AND cc2.agency_id = cc3.ID;

      IF p_cnt = 1
      THEN
         SELECT DISTINCT cc3.class_id
                    INTO p_class_id
                    FROM t_client cc1, t_client cc2, t_client cc3
                   WHERE p_client_id = cc1.ID
                     AND cc1.class_id = cc2.class_id
                     AND cc2.agency_id = cc3.ID;

         RETURN p_class_id;
      ELSIF p_cnt = 0
      THEN
         RETURN NULL;
      ELSE
         /* vaclav: need to fix consistency.
         raise_application_error (-20000,
                                     'Client '
                                  || p_client_id
                                  || ' belongs to more than one agency'
                                 );
         */
         RETURN NULL;
      END IF;
   END;

   FUNCTION sf_get_root_class (p_client_id IN NUMBER)
      RETURN NUMBER
   AS
      p_class_id   NUMBER;
   BEGIN
      p_class_id := sf_get_agency_class (p_client_id);

      IF p_class_id IS NULL
      THEN
         p_class_id := sf_get_class (p_client_id);
      END IF;

      RETURN p_class_id;
   END;

   PROCEDURE sp_update_suspect_status (p_client_id NUMBER)
   AS
      p_sum_inv   NUMBER;
   BEGIN
      /*IF fn_get_suspect_status (p_client_id) = 1
      THEN
         UPDATE t_client
            SET suspect = 1
          WHERE ID = p_client_id AND suspect = 0;
      ELSE
         UPDATE t_client
            SET suspect = 0
          WHERE ID = p_client_id AND suspect = 1;
      END IF;*/
      SELECT COUNT (*)
        INTO p_sum_inv
        FROM v_suspect_client
       WHERE ID = p_client_id;

      IF p_sum_inv > 0
      THEN
         UPDATE t_client
            SET suspect = 1
          WHERE ID = p_client_id AND suspect = 0;
      ELSE
         UPDATE t_client
            SET suspect = 0
          WHERE ID = p_client_id AND suspect = 1;
      END IF;
   END;

   PROCEDURE sp_daily_suspect_status
   AS
   BEGIN
      UPDATE t_client c
         SET c.suspect = (SELECT COUNT (*)
                            FROM v_suspect_client
                           WHERE ID = c.ID)
       WHERE c.suspect <> (SELECT COUNT (*)
                             FROM v_suspect_client
                            WHERE ID = c.ID);
   END;
/* FUNCTION fn_get_suspect_status (p_client_id NUMBER)
    RETURN NUMBER
 AS
    p_sum_inv   NUMBER;
 BEGIN
    SELECT COUNT (*)
      INTO p_sum_inv
      FROM t_invoice i
     WHERE i.receipt_sum > 0
       AND i.credit = 0
       AND i.paysys_id IN (1001, 1013, 1014, 1003)
       AND i.client_id = p_client_id;

    IF p_sum_inv = 0
    THEN
       SELECT COUNT (*)
         INTO p_sum_inv
         FROM t_invoice i
        WHERE i.receipt_sum = 0
          AND i.credit = 0
          AND i.paysys_id IN (1001, 1013, 1014, 1003)
          AND i.client_id = p_client_id;

       IF p_sum_inv > 0
       THEN
          RETURN 1;
       ELSE
          RETURN 0;
       END IF;
    END IF;

    SELECT COUNT (*)
      INTO p_sum_inv
      FROM t_invoice i
     WHERE i.receipt_sum > 0
       AND i.credit = 0
       AND i.receipt_sum_1c = 0
       AND i.paysys_id IN (1001, 1013, 1014, 1003)
       AND TRUNC (  NVL (i.receipt_dt, TO_DATE ('01.01.2003', 'dd.mm.yyyy'))
                  + INTERVAL '11' HOUR
                 ) <
              TRUNC (  SYSDATE
                     + INTERVAL '11' HOUR
                     - DECODE (i.paysys_id,
                               1001, 14,
                               1003, (DECODE (  TRUNC (i.receipt_dt + 1)
                                              - TRUNC (i.receipt_dt, 'D'),
                                              5, 3,
                                              6, 2,
                                              1
                                             )
                                ),
                               1013, 14,
                               1014, 14,
                               1000
                              )
                    )
       AND i.client_id = p_client_id;

    IF p_sum_inv > 0
    THEN
       RETURN 1;
    END IF;

    SELECT COUNT (*)
      INTO p_sum_inv
      FROM t_invoice i
     WHERE i.receipt_sum > 0
       AND i.credit = 0
       AND i.receipt_sum_1c = 0
       AND i.paysys_id IN (1001, 1013, 1014)
       AND i.client_id = p_client_id;

    IF p_sum_inv > 4
    THEN
       RETURN 1;
    END IF;

    SELECT COUNT (*)
      INTO p_sum_inv
      FROM t_invoice i
     WHERE i.receipt_sum > 0
       AND i.credit = 0
       AND i.receipt_sum_1c = 0
       AND i.paysys_id IN (1003)
       AND i.client_id = p_client_id;

    IF p_sum_inv > 2
    THEN
       RETURN 1;
    END IF;

    RETURN 0;
 END;*/
END pk_clients;
