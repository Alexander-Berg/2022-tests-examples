--liquibase formatted sql

--changeset nebaruzdin:BALANCE-25885 stripComments:false endDelimiter:\\

CREATE OR REPLACE PACKAGE BODY BO.PK_DISCOUNTS
AS
    function sf_get_currency_rate(p_dt in date, p_currency in varchar2,
                                  p_src_cc in varchar2 default 'cbr')
        return number parallel_enable deterministic
    as
        p_rate number;
    begin
        if p_currency = 'RUB' then
            return 1;
        end if;

        if p_currency is null then
            return 30 / 1.18;
        end if;

        begin
            select rate_to / rate_from
            into p_rate
            from (
                select
                    rate_from,
                    rate_to,
                    row_number() over (order by dt desc) rn
                from bo.t_iso_currency_rate
                where
                    iso_currency_from = p_currency
                    and iso_currency_to = 'RUB'
                    and src_cc = p_src_cc
                    and dt <= p_dt
            )
            where rn = 1;

            exception
            when no_data_found then
                p_rate := null;
        end;

        return p_rate;
    end;

   FUNCTION sf_get_client_nds(p_client_id IN NUMBER, p_dt IN DATE:=SYSDATE, p_service_id IN NUMBER:=7)
      RETURN NUMBER
   AS
      p_nds NUMBER;
   BEGIN
      select
          r1.nds_pct into p_nds
      from bo.V_CLIENT_NDS_BY_REGION r1
      join (
        select client_id, max(dt) dt from bo.V_CLIENT_NDS_BY_REGION
        where dt < sysdate and service_id = p_service_id
        group by client_id
      ) r2 on r2.client_id=r1.client_id and r2.dt=r1.dt
      where r1.client_id=p_client_id and r1.service_id = p_service_id;
      RETURN p_nds;
   END;

END pk_discounts;

\\
