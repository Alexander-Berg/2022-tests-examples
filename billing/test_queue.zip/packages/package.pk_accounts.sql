--liquibase formatted sql

--changeset lightrevan:BALANCE-27268-acc-p stripComments:false endDelimiter:\\
CREATE OR REPLACE PACKAGE BO.pk_accounts
AS
    --
    -- Currency titles
    --
    c_rubles CONSTANT    NUMBER := 810;
    c_dollars CONSTANT   NUMBER := 840;

    need_python_processing      EXCEPTION;
    need_python_processing_err  CONSTANT NUMBER := -20666;
    PRAGMA EXCEPTION_INIT( need_python_processing, -20666 );

    --------------------------------------------------------------
    -- Procedures and functions
    --------------------------------------------------------------

    PROCEDURE sp_consume (p_order_id             IN     NUMBER,
                          p_order_manager_code   IN     NUMBER,
                          p_qty                  IN     NUMBER,
                          p_dt                   IN     DATE);

    PROCEDURE raise_need_python_processing(p_message IN varchar2);

    PROCEDURE update_payment   (p_payment_id    IN  NUMBER,
                                p_payment_delta IN  NUMBER);

END pk_accounts;

\\
