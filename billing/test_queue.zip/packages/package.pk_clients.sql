--liquibase formatted sql

--changeset azurkin:BALANCE-29575-pk_clients-package stripComments:false splitStatements:false

CREATE OR REPLACE PACKAGE BO.pk_clients
AS
   c_agency      CONSTANT NUMBER := 1;
   c_client      CONSTANT NUMBER := 0;
   c_subclient   CONSTANT NUMBER := 2;
   
   FUNCTION sf_get_direct25 (p_client_id IN NUMBER)
      RETURN NUMBER;   

   FUNCTION sf_get_client_category (p_client_id IN NUMBER)
      RETURN NUMBER;

   PROCEDURE sp_client_to_agency (p_client_id IN NUMBER);

   PROCEDURE sp_agency_to_client (p_client_id IN NUMBER);

   PROCEDURE sp_client_to_subclient (
      p_client_id   IN   NUMBER,
      p_agency_id   IN   NUMBER
   );

   PROCEDURE sp_subclient_to_client (p_client_id IN NUMBER);

   PROCEDURE sp_create_client (
      p_id               IN OUT   NUMBER,
      p_id_1c            IN       NUMBER := NULL,
      p_passport_id      IN       NUMBER := NULL,
      p_client_type_id   IN       NUMBER,
      p_name             IN       VARCHAR,
      p_email            IN       VARCHAR,
      p_phone            IN       VARCHAR,
      p_fax              IN       VARCHAR,
      p_url              IN       VARCHAR,
      p_is_agency        IN       NUMBER := 0,
      p_agency_id        IN       NUMBER := NULL,
      p_commit           IN       NUMBER := 0,
      p_full_repay       IN       NUMBER := NULL,
      p_oper_id          IN       NUMBER := NULL,
      p_manual_suspect   IN       NUMBER := 0,
      p_city             IN       VARCHAR := NULL
   );

   PROCEDURE sp_new_client (
      p_id               IN   NUMBER,
      p_id_1c            IN   NUMBER := NULL,
      p_passport_id      IN   NUMBER := NULL,
      p_client_type_id   IN   NUMBER,
      p_name             IN   VARCHAR,
      p_email            IN   VARCHAR,
      p_phone            IN   VARCHAR,
      p_fax              IN   VARCHAR,
      p_url              IN   VARCHAR,
      p_is_agency        IN   NUMBER := 0,
      p_commit           IN   NUMBER := 0,
      p_agency_id        IN   NUMBER := NULL,
      p_full_repay       IN   NUMBER := NULL,
      p_oper_id          IN   NUMBER := NULL,
      p_manual_suspect   IN   NUMBER := 0,
      p_city             IN   VARCHAR := NULL
   );

   PROCEDURE sp_set_client (
      p_id               IN   NUMBER,
      p_client_type_id   IN   NUMBER,
      p_name             IN   VARCHAR,
      p_email            IN   VARCHAR,
      p_phone            IN   VARCHAR,
      p_fax              IN   VARCHAR,
      p_url              IN   VARCHAR,
      p_is_agency        IN   NUMBER := 0,
      p_agency_id        IN   NUMBER := NULL,
      p_oper_id               NUMBER := NULL,
      p_commit           IN   NUMBER := 0,
      p_full_repay       IN   NUMBER := NULL,
      p_manual_suspect   IN   NUMBER := 0,
      p_city             IN   VARCHAR := NULL
   );

   PROCEDURE sp_add_to_class (
      p_id         NUMBER,
      -- any client id from client class or free (is not inside any class) client id
      p_class_id   NUMBER,
      p_commit     NUMBER := 0
   );

   PROCEDURE sp_remove_from_class (p_id NUMBER, p_commit NUMBER := 0);

   FUNCTION sf_get_class (p_client_id IN NUMBER)
      RETURN NUMBER;

   FUNCTION sf_get_agency_class (p_client_id IN NUMBER)
      RETURN NUMBER;

   FUNCTION sf_get_root_class (p_client_id IN NUMBER)
      RETURN NUMBER;

   PROCEDURE sp_update_suspect_status (p_client_id NUMBER);

   PROCEDURE sp_daily_suspect_status;
/*FUNCTION fn_get_suspect_status (p_client_id NUMBER)
   RETURN NUMBER;*/
END pk_clients;
