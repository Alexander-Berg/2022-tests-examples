--liquibase formatted sql

--changeset shorrty:BALANCE-26274-11 stripComments:false endDelimiter:\\
create or replace package body bo.pk_yt_export
as

    -- Изменения (тип)
    type tt_src is table of bo.t_yt_export_changes.source_name%type index by pls_integer;
    type tt_id  is table of bo.t_yt_export_changes.object_id%type index by pls_integer;
    type tt_dt  is table of bo.t_yt_export_changes.dml_dt%type index by pls_integer;
    type tt_tp  is table of bo.t_yt_export_changes.dml_type%type index by pls_integer;

    -- Коллекции изменений
    g_src   tt_src;
    g_id    tt_id;
    g_dt    tt_dt;
    g_tp    tt_tp;


    -- Запомнить изменение
    procedure add_change(p_src in varchar2, p_id in number, p_tp in varchar2, p_dt in date := null)
    as
        l_idx   pls_integer := g_src.count + 1;
    begin
        g_src(l_idx) := p_src;
        g_id(l_idx)  := p_id;
        g_dt(l_idx)  := nvl(p_dt, sysdate);
        g_tp(l_idx)  := p_tp;
    end;


    -- Сбросить изменение
    procedure flush_changes as
    begin
        forall i in 1..g_src.count
        insert into bo.t_yt_export_changes(source_name, object_id, dml_dt, dml_type)
                                    values(g_src(i), g_id(i), g_dt(i), g_tp(i));

        g_src.delete();
        g_id.delete();
        g_dt.delete();
        g_tp.delete();
    end;

    -- Возвращает тип DML (предназначено только для триггера)
    function get_dml_type return varchar2 as
    begin
        return CASE 
            WHEN UPDATING   THEN 'U' 
            WHEN INSERTING  THEN 'I' 
            WHEN DELETING   THEN 'D' 
            ELSE 'Procedure not executed from DML trigger!' 
        END;
    end;

    -- Возвращает id объекта (предназначено только для триггера)
    function get_object_id(p_old_id in number, p_new_id in number) 
      return number as
    begin
        if DELETING then
            return p_old_id;
        end if;
        return p_new_id;
    end;

end pk_yt_export;