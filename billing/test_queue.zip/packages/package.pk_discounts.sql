--liquibase formatted sql

--changeset nebaruzdin:BALANCE-25885 stripComments:false endDelimiter:\\

CREATE OR REPLACE PACKAGE BO.pk_discounts
AS
   FUNCTION sf_get_client_nds(p_client_id IN NUMBER, p_dt IN DATE:=SYSDATE, p_service_id IN NUMBER:=7)
      RETURN NUMBER;

   function sf_get_currency_rate(p_dt in date, p_currency in varchar2,
                                 p_src_cc in varchar2 default 'cbr')
      return number parallel_enable deterministic;

END pk_discounts;

\\
