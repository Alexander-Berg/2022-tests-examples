--liquibase formatted sql

--changeset dimonb:BALANCE-26265-02 stripComments:false endDelimiter:\\
create or replace type bo.system_stat_object force as object(
        INSTANCE_NUMBER NUMBER,
        CLIENT_ID VARCHAR2(1024),
        MODULE VARCHAR2(64),
        USERNAME VARCHAR2(128),
        SQL_ID VARCHAR2(13),
        PLAN_HASH_VALUE NUMBER,
        TEXT VARCHAR2(4000),
        value NUMBER,
        PER_CENT NUMBER
    );
\\

--changeset dimonb:BALANCE-26265-12 stripComments:false endDelimiter:\\
create or replace type bo.system_stat_tbl IS table of bo.system_stat_object;
\\

--changeset dimonb:BALANCE-26265-22 stripComments:false endDelimiter:\\
create or replace PACKAGE    BO.pk_system
AS


    function sf_top_by_metric_ref(
        p_metric in varchar2,
        p_from in DATE,
        p_to in DATE
        )
    return sys_refcursor;

    function sf_top_by_metric(p_metric varchar2, p_from in DATE, p_to in DATE)
     return bo.system_stat_tbl;

END pk_system;
\\


--changeset dimonb:BALANCE-26265-32 stripComments:false endDelimiter:\\
grant execute on BO.pk_system to ALL_RO
\\