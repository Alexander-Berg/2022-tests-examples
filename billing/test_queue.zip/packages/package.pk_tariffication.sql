--liquibase formatted sql

--changeset lightrevan:BALANCE-29882-tariff-p stripComments:false endDelimiter:\\
create or replace PACKAGE    BO.pk_tariffication
AS
   TYPE varchar2_list IS TABLE OF VARCHAR2 (256);
   TYPE number_list IS TABLE OF NUMBER;
   TYPE dates IS TABLE OF DATE;
   
   --
   --
   -- map product shipment to money expense
   PROCEDURE sp_calculate_consumption (
      -- equiv to service_id
      p_service_id         IN   NUMBER,
      -- equiv to service_order_id
      p_service_order_id   IN   NUMBER,
      p_dt                 IN   DATE,
      p_completion_qty     IN   NUMBER,
      p_stop               IN   NUMBER,
      p_commit             IN   NUMBER
   );

   PROCEDURE process_order_completion (
      p_service_id         IN   NUMBER,
      p_service_order_id   IN   NUMBER,
      p_skip_deny_shipment IN   NUMBER DEFAULT 0
   );
END pk_tariffication; 

\\
