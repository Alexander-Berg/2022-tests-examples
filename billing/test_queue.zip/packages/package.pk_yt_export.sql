--liquibase formatted sql

--changeset shorrty:BALANCE-26274-10 stripComments:false endDelimiter:\\
create or replace package bo.pk_yt_export
as
    -- Запомнить изменение
    procedure add_change(p_src in varchar2, p_id in number, p_tp in varchar2, p_dt in date := null);

    -- Сбросить изменение
    procedure flush_changes;

    -- Возвращает тип DML (предназначено только для триггера)
    function get_dml_type return varchar2;

    -- Возвращает id объекта (предназначено только для триггера)
    function get_object_id(p_old_id in number, p_new_id in number) return number;

end pk_yt_export;
