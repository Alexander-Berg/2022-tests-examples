--liquibase formatted sql

--changeset lightrevan:BALANCE-29780-pc-body stripComments:false endDelimiter:\\
CREATE OR REPLACE PACKAGE BODY bo.pk_hash_data
AS
  FUNCTION INSERT_NEW(m_hash IN VARCHAR2, m_data CLOB)
    RETURN NUMBER
  IS
    hash_data_id NUMBER;
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    hash_data_id := bo.s_hash_data_id.nextval;

    INSERT INTO bo.t_hash_data (id, hash, json_data)
    VALUES (hash_data_id, m_hash, m_data);

    COMMIT;

    RETURN hash_data_id;
  END insert_new;

  FUNCTION GET_BY_HASH(m_hash IN VARCHAR2)
    RETURN NUMBER
  IS
    hash_data_id NUMBER;
  BEGIN
    SELECT id
      INTO hash_data_id
    FROM bo.t_hash_data
    WHERE hash = m_hash;

    RETURN hash_data_id;
  END get_by_hash;

  FUNCTION CREATE_FROM_CLOB(m_data CLOB)
    RETURN NUMBER
  IS
    m_hash VARCHAR2(128);
  BEGIN
    m_hash := dbms_crypto.Hash(m_data, dbms_crypto.hash_sh1);

    BEGIN
      RETURN pk_hash_data.GET_BY_HASH(m_hash);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    RETURN pk_hash_data.INSERT_NEW(m_hash, m_data);
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      RETURN pk_hash_data.GET_BY_HASH(m_hash);
  END CREATE_FROM_CLOB;

  FUNCTION CREATE_FROM_COMPRESSED(m_data VARCHAR2, m_hash VARCHAR2)
    RETURN NUMBER
  IS
    uncompressed RAW(32767);
  BEGIN
    BEGIN
      RETURN pk_hash_data.GET_BY_HASH(m_hash);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    uncompressed := utl_compress.lz_uncompress(utl_raw.cast_to_raw(m_data));
    RETURN pk_hash_data.INSERT_NEW(m_hash, to_clob(utl_raw.cast_to_varchar2(uncompressed)));
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      RETURN pk_hash_data.GET_BY_HASH(m_hash);
  END CREATE_FROM_COMPRESSED;

END pk_hash_data;

\\
