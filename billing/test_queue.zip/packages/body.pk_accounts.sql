--liquibase formatted sql

--changeset lightrevan:BALANCE-30269-acc-b stripComments:false endDelimiter:\\
CREATE OR REPLACE PACKAGE BODY BO.pk_accounts
AS
    PROCEDURE sp_consume (p_order_id             IN     NUMBER,
                          p_order_manager_code   IN     NUMBER,
                          p_qty                  IN     NUMBER,
                          p_dt                   IN     DATE)
    AS
        p_cons_new_sum              NUMBER;
        p_cons_new_qty              NUMBER;
        p_order_active_consume_id   NUMBER;
        p_order_completion_qty      NUMBER;
        p_order_consume_qty         NUMBER;
        p_order_completion_sum      NUMBER;
        p_act_cons_discount         NUMBER;
        p_act_cons_manager_code     NUMBER;
        p_act_cons_completion_sum   NUMBER;
        p_act_cons_completion_qty   NUMBER;
        p_act_cons_consume_qty      NUMBER;
        p_act_cons_consume_sum      NUMBER;
        p_act_cons_current_qty      NUMBER;
        p_act_cons_act_qty          NUMBER;
        p_act_cons_tax_pct_id       NUMBER;
        p_act_cons_tax_policy_id    NUMBER;
        p_new_tax_pct_id            NUMBER;
    BEGIN
        DBMS_OUTPUT.put_line (
               'sp_smart_consume: p_order_id='
            || p_order_id
            || ', p_qty='
            || p_qty
            || ', p_order_manager_code='
            || p_order_manager_code
        );

        SELECT active_consume_id,
               completion_qty,
               consume_qty
          INTO p_order_active_consume_id,
               p_order_completion_qty,
               p_order_consume_qty
          FROM t_order
        WHERE ID = p_order_id;

        -- BALANCE-19386 p_order_completion_qty <= p_order_consume_qty - условие убрано
        -- BALANCE-20186 условие возвращено
        -- BALANCE-24456 Изменили > на >= в условии
        IF p_order_active_consume_id IS NULL
        THEN
            IF NOT(p_order_completion_qty >= p_order_consume_qty AND p_qty >= p_order_consume_qty)
            THEN
                raise_need_python_processing ('p_order_active_consume_id IS NULL');
            END IF;
        END IF;

        IF p_order_active_consume_id IS NOT NULL
        THEN
            SELECT 100 * (1 - (100 - NVL (co.discount_pct, 0)) / (100 - NVL (co.static_discount_pct, 0))),
                   co.manager_code,
                   co.completion_qty,
                   co.completion_sum,
                   co.consume_qty,
                   co.consume_sum,
                   co.current_qty,
                   co.act_qty,
                   co.tax_policy_pct_id,
                   tpp.tax_policy_id
            INTO p_act_cons_discount,
                 p_act_cons_manager_code,
                 p_act_cons_completion_qty,
                 p_act_cons_completion_sum,
                 p_act_cons_consume_qty,
                 p_act_cons_consume_sum,
                 p_act_cons_current_qty,
                 p_act_cons_act_qty,
                 p_act_cons_tax_pct_id,
                 p_act_cons_tax_policy_id
            FROM t_consume co
              LEFT JOIN t_tax_policy_pct tpp on co.tax_policy_pct_id = tpp.id
            WHERE co.ID = p_order_active_consume_id;

            IF nvl(p_act_cons_discount, 0) > 0
            THEN
                raise_need_python_processing ('Has dynamic discount ' || p_act_cons_discount);
            END IF;
            IF NVL(p_act_cons_manager_code, 0) != NVL(p_order_manager_code, 0)
            THEN
                raise_need_python_processing ('Manager changed ' || p_act_cons_manager_code || ' -> ' || p_order_manager_code);
            END IF;

            p_cons_new_qty := p_qty - p_order_completion_qty + p_act_cons_completion_qty;

            IF p_cons_new_qty < 0 OR p_cons_new_qty >= p_act_cons_current_qty
            THEN
                raise_need_python_processing ('Operation don`t use one consume');
            END IF;

            IF p_act_cons_tax_policy_id IS NULL
            THEN
              --TODO: change only with RECONSUME_START_DT in balance/actions/taxes_update.py
              IF sysdate >= date'2018-12-20' THEN
                raise_need_python_processing ('Null tax_policy_pct_id for consume');
              END IF;
            ELSIF p_dt IS NOT NULL THEN
              SELECT id INTO p_new_tax_pct_id
              FROM (
                SELECT id
                FROM t_tax_policy_pct tpp
                WHERE tpp.tax_policy_id = p_act_cons_tax_policy_id
                  AND tpp.dt <= p_dt
                ORDER BY tpp.dt DESC
              )
              WHERE rownum = 1;

              IF p_act_cons_tax_pct_id != p_new_tax_pct_id THEN
                raise_need_python_processing ('Tax change for active consume');
              END IF;
            END IF;

            p_cons_new_sum := 0;

            IF p_act_cons_consume_qty <> 0
            THEN
                p_cons_new_sum := sf_rounded_delta (
                    p_act_cons_consume_qty,
                    0,
                    p_cons_new_qty,
                    p_act_cons_consume_sum
                );
            END IF;

            IF p_cons_new_qty < p_act_cons_act_qty
            THEN
                raise_need_python_processing ('descended into act');
            END IF;

            UPDATE t_consume
              SET completion_sum = p_cons_new_sum,
                  completion_qty = p_cons_new_qty
            WHERE ID = p_order_active_consume_id;

        END IF;

        UPDATE t_order
          SET completion_qty = p_qty
        WHERE ID = p_order_id;

        DBMS_OUTPUT.put_line ('sp_consume_end');
    END;

    PROCEDURE raise_need_python_processing (p_message IN varchar2)
    AS
    BEGIN
        DBMS_OUTPUT.put_line (
            'Need python processing: '
         || p_message
        );
        raise_application_error(need_python_processing_err, p_message);
    END;

    PROCEDURE update_payment   (p_payment_id    IN  NUMBER,
                                p_payment_delta IN  NUMBER)
    AS
        p_paysys_code               VARCHAR2(100);
        p_amount                    NUMBER;
        p_receipt_sum_1c            NUMBER;
        p_payment_dt                DATE;
        p_cancel_dt                 DATE;
    BEGIN
        SELECT  paysys_code,
                amount,
                receipt_sum_1c,
                payment_dt,
                cancel_dt
        INTO    p_paysys_code,
                p_amount,
                p_receipt_sum_1c,
                p_payment_dt,
                p_cancel_dt
        FROM t_payment
        WHERE id = p_payment_id;
        IF p_paysys_code = 'BANK' THEN
            IF p_payment_dt IS NULL AND p_cancel_dt IS NULL THEN
                UPDATE bo.t_payment
                    SET receipt_sum_1c = LEAST(p_amount,  nvl(receipt_sum_1c, 0) + p_payment_delta)
                WHERE id = p_payment_id;
            END IF;
        ELSE
            UPDATE bo.t_payment
                SET receipt_sum_1c = nvl(receipt_sum_1c, 0) + p_payment_delta
            WHERE id = p_payment_id AND receipt_sum IS NOT NULL;
        END IF;
    END;
END pk_accounts;

\\
