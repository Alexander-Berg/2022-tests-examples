--liquibase formatted sql

--changeset lightrevan:BALANCE-30269-tariff-b stripComments:false endDelimiter:\\
CREATE OR REPLACE PACKAGE BODY BO.pk_tariffication
AS
    PROCEDURE sp_calculate_consumption (p_service_id         IN NUMBER,
                                       p_service_order_id   IN NUMBER,
                                       p_dt                 IN DATE,
                                       p_completion_qty     IN NUMBER,
                                       p_stop               IN NUMBER,
                                       p_commit             IN NUMBER)
    AS
        p_order_manager_code   NUMBER;
        p_order_id             NUMBER;
        p_order_completion_qty NUMBER;
        p_client_id            NUMBER;
        p_budget               NUMBER;
        p_currency             VARCHAR2(20);
        p_linked_order_id      NUMBER;
        p_product_id           NUMBER;
    BEGIN                                                                 --{{{
        DBMS_OUTPUT.put_line ('sp_calculate_consumption');

        SELECT ID,
               manager_code,
               client_id,
               completion_qty,
               linked_order_id,
               service_code
          INTO p_order_id,
               p_order_manager_code,
               p_client_id,
               p_order_completion_qty,
               p_linked_order_id,
               p_product_id
          FROM bo.t_order
        WHERE pid IS NULL
          AND service_id = p_service_id
          AND service_order_id = p_service_order_id;

        pk_accounts.sp_consume (p_order_id,
                                p_order_manager_code,
                                p_completion_qty,
                                p_dt);

        IF p_commit != 0
        THEN
            COMMIT;
        END IF;
    END sp_calculate_consumption;                                         --}}}

    PROCEDURE process_order_completion (p_service_id         IN NUMBER,
                                        p_service_order_id   IN NUMBER,
                                        p_skip_deny_shipment IN NUMBER DEFAULT 0)
    AS
        p_order_shdt     DATE;
        p_shdt           DATE;
        p_sh_update_dt   DATE;
        p_sh_qty         NUMBER;
        p_sh_money       NUMBER;
        p_sh_money_wo_overshipment  NUMBER;
        p_sh_type        VARCHAR(20);
        p_sh_stop        NUMBER;
        p_sh_deny_shipment     NUMBER;
        p_completion_fixed_money_qty NUMBER;
        p_consume_money_qty    NUMBER;
        p_order_id       NUMBER;
        p_old_qty        NUMBER;
        p_consume_qty    NUMBER;
        p_completion_fixed_qty NUMBER;
        p_need_actual_completions NUMBER;
        p_migration_case NUMBER;
        p_root_order     NUMBER;
        p_root_root_order     NUMBER;
        status     NUMBER := 1;
        p_main_client NUMBER;
    BEGIN
        DBMS_OUTPUT.put_line ('process_order_completion: start processing');

        SELECT dt,
               consumption,
               stop,
               update_dt,
               money,
               shipment_type,
               deny_shipment
          INTO p_shdt,
               p_sh_qty,
               p_sh_stop,
               p_sh_update_dt,
               p_sh_money,
               p_sh_type,
               p_sh_deny_shipment
          FROM bo.t_shipment
        WHERE service_id = p_service_id AND service_order_id = p_service_order_id;

        IF (p_sh_deny_shipment IS NOT NULL AND nvl(p_skip_deny_shipment, 0) = 0)
        THEN
            RETURN;
        END IF;

        IF (p_sh_stop > 0)
        THEN
            bo.pk_accounts.raise_need_python_processing ('got stop flag');
        END IF;

        SELECT id,
               completion_qty,
               shipment_dt,
               completion_fixed_qty,
               consume_qty,
               need_actual_completions,
               group_order_id
          INTO p_order_id,
               p_old_qty,
               p_order_shdt,
               p_completion_fixed_qty,
               p_consume_qty,
               p_need_actual_completions,
               p_root_order
          FROM bo.t_order
        WHERE service_id = p_service_id AND service_order_id = p_service_order_id

        FOR UPDATE WAIT 1;

        IF p_root_order IS NOT NULL
        THEN
            SELECT group_order_id
            INTO p_root_root_order
            FROM bo.t_order
            WHERE id = p_root_order;

            -- NOTE: we need to go deeper!!!
            -- Внимание! Предполагается дерево максимальной глубины 2!
            IF p_root_root_order IS NOT NULL
            THEN
                p_root_order := p_root_root_order;
            END IF;

            status := dbms_lock.request(
                lockhandle => bo.sf_oracle_lock_handler_new(
                    tablename => 't_order',
                    object_id => p_root_order),
                lockmode => 3,
                timeout => 0,
                release_on_commit => True
            );

            IF status <> 0 AND status <> 4
            THEN
                RETURN;
            END IF;
        END IF;

        SELECT nvl(agency_id, client_id)
        INTO p_main_client
          FROM bo.t_order
          WHERE id = nvl(p_root_order, p_order_id);

        status := dbms_lock.request(
            lockhandle => bo.sf_oracle_lock_handler_new(
                tablename => 't_client',
                object_id => p_main_client),
            lockmode => 3,
            timeout => 0,
            release_on_commit => True
        );

        IF status <> 0 AND status <> 4
        THEN
            RETURN;
        END IF;

        IF (p_need_actual_completions > 0)
        THEN
            bo.pk_accounts.raise_need_python_processing ('need_actual_completions flag found');
        END IF;

        IF p_service_id = 7 AND p_sh_type <> 'Money'

        THEN
            select case
                    when exists (select * from bo.v_direct_converted_orders where order_id = p_order_id and dt <= sysdate)
                    then 1
                    else 0
                    end val
            into p_migration_case
            from dual;
            IF (p_completion_fixed_qty <> p_sh_qty OR p_completion_fixed_qty IS NULL) and p_migration_case = 1
            THEN
                bo.pk_accounts.raise_need_python_processing ('fixed part of money consumption changed ' || p_completion_fixed_qty || ' -> ' || p_sh_qty);
            END IF;


            -- TODO ADD CACHE-table
            if p_migration_case = 1
            then
                select consume_money_qty, completion_fixed_money_qty
                into p_consume_money_qty, p_completion_fixed_money_qty
                from bo.v_direct_migration_money
                right join dual on order_id = p_order_id;

                IF p_completion_fixed_money_qty is NULL or p_consume_money_qty is NULL
                THEN
                    bo.pk_accounts.raise_need_python_processing ('something strange happened. p_completion_fixed_money_qty = ' || p_completion_fixed_money_qty || ', p_consume_money_qty = ' || p_consume_money_qty);
                END IF;
                
                p_sh_qty := p_sh_qty + round(nvl(p_sh_money, 0) / 30, 6);
                
                UPDATE bo.t_order
                    SET  completion_money = p_sh_money
                WHERE  id = p_order_id;
            END IF;


        END IF;

        pk_tariffication.sp_calculate_consumption (
            p_service_id         => p_service_id,
            p_service_order_id   => p_service_order_id,
            p_dt                 => p_shdt,
            p_completion_qty     => p_sh_qty,
            p_stop               => p_sh_stop,
            p_commit             => 0);

        IF p_sh_qty < p_old_qty
        THEN
            INSERT INTO t_reverse_completion
                     (  order_id,     dt,      update_dt,   old_qty,      qty)
              VALUES (p_order_id, p_shdt, p_sh_update_dt, p_old_qty, p_sh_qty);
        END IF;

        UPDATE t_order
            SET shipment_dt = p_shdt,
                shipment_update_dt = p_sh_update_dt
        WHERE service_id = p_service_id AND service_order_id = p_service_order_id;

        UPDATE t_shipment_accepted
            SET dt = p_shdt,
                update_dt = p_sh_update_dt
        WHERE service_id = p_service_id AND service_order_id = p_service_order_id;

    END;
END pk_tariffication;

\\