--liquibase formatted sql

--changeset lightrevan:BALANCE-29780-pc stripComments:false endDelimiter:\\
CREATE OR REPLACE PACKAGE bo.pk_hash_data
AS
  FUNCTION create_from_clob(m_data CLOB)
    RETURN NUMBER;

  FUNCTION create_from_compressed(m_data VARCHAR2, m_hash VARCHAR2)
    RETURN NUMBER;

END pk_hash_data;

\\
