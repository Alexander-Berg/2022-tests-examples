--liquibase formatted sql

--changeset azurkin:BALANCE-29575-pk_export_queue stripComments:false splitStatements:false
CREATE OR REPLACE PACKAGE BODY BO.pk_export_queue
AS
    /* Позволяет добавлять элементы в очередь t_export
     */
    PROCEDURE enqueue(
        p_id         IN NUMBER,
        p_cls        IN VARCHAR2,
        p_queue      IN VARCHAR2,
        p_priority   IN NUMBER := 0,
        p_input      IN BLOB := NULL,
        p_reason     IN VARCHAR2 := NULL,
        p_nowait     IN NUMBER := 0,
        p_config     IN VARCHAR2 := NULL

    ) AS
        p_temp_id    NUMBER := 0;
    BEGIN
        IF p_nowait > 0
        THEN
            SELECT object_id
              INTO p_temp_id
            FROM bo.t_export
            WHERE
                object_id = p_id
                and type = p_queue
                and classname = p_cls
            FOR UPDATE NOWAIT;
        END IF;

        UPDATE bo.t_export
               SET state = 0,
                   rate = 0,
                   priority = p_priority,
                   update_dt = sysdate,
                   next_export = null,
                   enqueue_dt = sysdate,
                   input = nvl(p_input, input),
                   reason = p_reason,
                   config = p_config
        WHERE
            object_id = p_id
            and type = p_queue
            and classname = p_cls;

        IF sql%rowcount = 0
        THEN

            INSERT INTO bo.t_export (classname, object_id, rate, state, type, enqueue_dt, priority, input, reason, config)
                             VALUES (p_cls, p_id, 0, 0, p_queue, sysdate, p_priority, p_input, p_reason, p_config);

        END IF;

    END enqueue;


    PROCEDURE enqueue_skipping(
        p_id            IN NUMBER,
        p_cls           IN VARCHAR2,
        p_queue         IN VARCHAR2,
        p_priority      IN NUMBER := 0,
        p_input         IN BLOB := NULL,
        p_reason        IN VARCHAR2 := NULL,
        p_nowait        IN NUMBER := 0,
        p_skip_after_dt IN DATE := NULL,
        p_config        IN VARCHAR2 := NULL
    ) AS
        p_temp_id    NUMBER := 0;
    BEGIN
        IF p_nowait > 0
        THEN
            SELECT object_id
              INTO p_temp_id
            FROM bo.t_export
            WHERE
                object_id = p_id
                and type=p_queue
                and classname=p_cls
            FOR UPDATE NOWAIT;
        END IF;

        UPDATE bo.t_export
               SET state = 0,
                   rate = 0,
                   priority = p_priority,
                   update_dt = sysdate,
                   next_export = null,
                   enqueue_dt = sysdate,
                   input = nvl(p_input, input),
                   reason = p_reason,
                   config = p_config
        WHERE
            object_id = p_id
            and type = p_queue
            and classname = p_cls
            and (p_skip_after_dt is NULL or update_dt < p_skip_after_dt);

        IF sql%rowcount = 0
        THEN
            SELECT count(object_id) INTO p_temp_id
            FROM bo.t_export
            WHERE
                object_id = p_id
                and type = p_queue
                and classname = p_cls;

            IF p_temp_id = 0
            THEN

                INSERT INTO bo.t_export (classname, object_id, rate, state, type, enqueue_dt, priority, input, reason, config)
                                 VALUES (p_cls, p_id, 0, 0, p_queue, sysdate, p_priority, p_input, p_reason, p_config);
            END IF;

        END IF;

    END enqueue_skipping;

END pk_export_queue;
