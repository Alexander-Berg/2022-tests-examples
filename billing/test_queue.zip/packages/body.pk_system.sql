--liquibase formatted sql

--changeset dimonb:BALANCE-26265-37 stripComments:false endDelimiter:\\
CREATE OR REPLACE PACKAGE BODY BO.pk_system
AS
function sf_top_by_metric_ref(p_metric in varchar2, p_from in DATE, p_to in DATE) return sys_refcursor is
    v_rc sys_refcursor;
begin
  open v_rc for 'with q as
 (select min(snap_id) begin_snap_id, max(snap_id) end_snap_id
    from dba_hist_snapshot
   where :p_from between BEGIN_INTERVAL_TIME and END_INTERVAL_TIME
      or :p_to between BEGIN_INTERVAL_TIME and END_INTERVAL_TIME)
select uu.*
       --, (select LISTAGG(client_id, ''; '') WITHIN GROUP (order by 1) from (select distinct REGEXP_SUBSTR(client_id, ''.+\#'') as client_id from dba_hist_active_sess_history, q where snap_id between begin_snap_id and end_snap_id and sql_id = uu.SQL_ID and INSTANCE_NUMBER = uu.INSTANCE_NUMBER)) as CLIENT_IDS
      ,dbms_lob.substr((select rtrim(xmlagg(xmlelement(e, client_id || ''('' || cows || ''%)'', '';'').extract(''//text()'') order by cows desc).GetClobVal(), '';'')
                          from (select REGEXP_SUBSTR(client_id, ''.+\#'') as client_id,
                                       round((RATIO_TO_REPORT(count(*)) OVER()) * 100, 1) as cows
                                  from dba_hist_active_sess_history, q
                                 where snap_id between begin_snap_id and end_snap_id
                                   and sql_id = uu.SQL_ID
                                   and INSTANCE_NUMBER = uu.INSTANCE_NUMBER
                                 group by REGEXP_SUBSTR(client_id, ''.+\#'')))
                      , 1000) as CLIENT_IDS
  from (select INSTANCE_NUMBER,
               sql_id,
               plan_hash_value,
               module,
               username,
               dbms_lob.substr(sql_text, 2000) as sql_text,
               sum(' || p_metric || '_delta) as sum_disk_reads_delta,
               round((RATIO_TO_REPORT(sum(' || p_metric || '_delta)) OVER()) * 100, 2) AS Per_Cent
          from dba_hist_sqlstat st
          join q
            on 1 = 1
          left join dba_users u
            on u.user_id = parsing_user_id
          left join dba_hist_sqltext s
         using (sql_id)
         where snap_id between begin_snap_id and end_snap_id
         group by INSTANCE_NUMBER,
                  sql_id,
                  plan_hash_value,
                  module,
                  username,
                  dbms_lob.substr(sql_text, 2000)
         order by sum(' || p_metric || '_delta) desc nulls last) uu
 where rownum <= 15' using p_from, p_to;
  return v_rc;
end;

function SF_TOP_BY_METRIC(p_metric varchar2, p_from in DATE, p_to in DATE)
  return bo.system_stat_tbl is
    v_result bo.system_stat_tbl := bo.system_stat_tbl();
    v_cnt NUMBER := 0;
    v_rc      sys_refcursor;
    v_SQL_ID VARCHAR2(13);
    v_PLAN_HASH_VALUE NUMBER;
    v_MODULE VARCHAR2(64);
    v_USERNAME VARCHAR2(128);
    v_TEXT VARCHAR2(4000);
    v_READS NUMBER;
    v_PER_CENT NUMBER;
    v_CLIENT_ID VARCHAR2(1000);
    v_INSTANCE_NUMBER NUMBER;
begin
  v_rc := sf_top_by_metric_ref(p_metric, p_from, p_to);
  loop
    fetch v_rc into v_INSTANCE_NUMBER, v_SQL_ID, v_PLAN_HASH_VALUE, v_MODULE, v_USERNAME, v_TEXT, v_READS, v_PER_CENT, v_CLIENT_ID;
    exit when v_rc%NOTFOUND;
    v_result.extend;
    v_cnt := v_cnt + 1;
    v_result(v_cnt) := bo.system_stat_object(v_INSTANCE_NUMBER, v_CLIENT_ID, v_MODULE, v_USERNAME, v_SQL_ID, v_PLAN_HASH_VALUE, v_TEXT, v_READS, v_PER_CENT);
  end loop;
  close v_rc;
  return v_result;
end;

END pk_system;
\\