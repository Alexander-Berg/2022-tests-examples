--liquibase formatted sql

--changeset isupov:BALANCE-24170-1 stripComments:false endDelimiter:\\
CREATE OR REPLACE PACKAGE BO.pk_export_queue
AS
    /* Позволяет добавлять элементы в очередь t_export
     */
    PROCEDURE enqueue(
        p_id         IN NUMBER,
        p_cls        IN VARCHAR2,
        p_queue      IN VARCHAR2,
        p_priority   IN NUMBER := 0,
        p_input      IN BLOB := NULL,
        p_reason     IN VARCHAR2 := NULL,
        p_nowait     IN NUMBER := 0,
        p_config     IN VARCHAR2 := NULL
    );

    /* Позволяет добавлять элементы в очередь t_export
     * Пропускает строки, которые имеют update_dt > p_skip_after_dt
     */
    PROCEDURE enqueue_skipping(
        p_id            IN NUMBER,
        p_cls           IN VARCHAR2,
        p_queue         IN VARCHAR2,
        p_priority      IN NUMBER := 0,
        p_input         IN BLOB := NULL,
        p_reason        IN VARCHAR2 := NULL,
        p_nowait        IN NUMBER := 0,
        p_skip_after_dt IN DATE := NULL,
        p_config        IN VARCHAR2 := NULL
    );

end pk_export_queue; -- end of package spec bo.pk_export_queue
\\
