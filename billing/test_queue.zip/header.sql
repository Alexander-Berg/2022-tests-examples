--liquibase formatted sql

--changeset ufian:BALANCE-23728-1 runAlways:true runOnChange:true
alter session set ddl_lock_timeout = 600;


--changeset ufian:BALANCE-23728-2 runAlways:true runOnChange:true endDelimiter:\\

begin
    dbms_output.put_line('recompiling object: ');
    --DBMS_SESSION.set_identifier('balance_ddl_batch#666');
end;

\\

